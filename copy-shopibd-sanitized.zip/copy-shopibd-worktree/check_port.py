import socket, time
for i in range(15):
    try:
        s = socket.socket()
        s.settimeout(2)
        s.connect(("127.0.0.1", 8000))
        s.close()
        print("port8000 OPEN after", i, "tries")
        break
    except Exception as e:
        time.sleep(2)
else:
    print("port8000 CLOSED after waiting")
