# Design System — KILLSTAR

## Brand Identity (colors with hex, logo url, tagline)
KILLSTAR is a gothic and alternative fashion commerce brand with a stark monochrome foundation, sharp rectangular UI, and high-contrast promotional messaging. The brand positioning observed in metadata is: “Clothing & Lifestyle company with a twist of darkness, channeling emotional power and raw energy into every thread.”

- Site name: KILLSTAR / Killstar
- Tagline: “In Goth We Trust”
- Primary logo: https://us.killstar.com/cdn/shop/files/KILLSTAR-BLACK-LOGO_170x.png?v=1761048385
- Compact header logo: https://us.killstar.com/cdn/shop/files/KILLSTAR-BLACK-LOGO_x60.png?v=1761048385
- Favicon: https://us.killstar.com/cdn/shop/files/K-LOGO-FAVICON.png?crop=center&height=32&v=1761049519&width=32
- Open Graph brand image: http://us.killstar.com/cdn/shop/files/KS-Logo_1200x628.jpg?v=1767700660
- Brand personality: bold, high-energy, alternative, dark, promotional, direct.

The visual identity is driven by black typography and controls on an off-white canvas, with blood-red sale messaging and occasional utility colors inherited from Bootstrap-style semantics.

## Typography (families, scale, weights, usage)
The storefront consistently uses “Be Vietnam Pro” for both headings and body text, with a sans-serif emoji fallback stack. Product JSON and agent documentation expose browser-default serif fonts, but those are not representative of the customer-facing storefront UI.

Observed font stack:
- Primary / body: Be Vietnam Pro, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji
- Heading: Be Vietnam Pro, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji
- Utility fallbacks observed: Verdana, Geneva

Observed sizes:
- Body: 12.375px; compact, commerce-oriented, dense navigation and product metadata.
- Small heading / nav heading: 15px; used around menu headings and homepage heading extraction.
- Page heading: 37.5px; observed on blog and 404-style pages.

Recommended type scale based on observed values:
- Caption / utility: 10px–11px, uppercase for minor labels.
- Body compact: 12.375px, regular weight.
- Body default: 14px, regular weight for readable product copy.
- Nav / menu item: 15px, uppercase or bold where needed.
- Section heading: 24px–30px, bold.
- Page heading: 37.5px, bold, tight line-height.

Weights and casing:
- Use 400 for body copy and descriptions.
- Use 600–700 for navigation labels, promotional snippets, and product names.
- Use 700 for page headings and CTAs.
- Uppercase is common for navigation categories and store selectors: “STORE”, “NEW”, “NEW SHOP BY CATEGORY”, “BESTSELLERS”, “BACK IN STOCK”.

## Color Palette (primary, secondary, accent, neutrals, semantic — with hex + oklch when possible)
KILLSTAR’s palette is predominantly monochrome with red promotional energy. The extracted palette varies by page, but the stable customer-facing system is black/off-white with red sale emphasis.

Primary colors:
- Ink Black: #141414, oklch(0.21 0 0). Main text, primary buttons, dark foregrounds.
- Pure Black: #000000, oklch(0 0 0). Inputs and deepest UI surfaces.
- Bone White: #FAFAFA, oklch(0.985 0 0). Main page background.
- White: #FFFFFF, oklch(1 0 0). Button text, input text, inverted UI.

Brand / promotional colors:
- Blood Red: #AB0000, oklch(0.45 0.18 29). Sale and urgent promotional emphasis.
- Flame Orange: #FF4500, oklch(0.65 0.24 34). Secondary promotional highlight observed on the homepage extraction.

Utility / semantic colors observed:
- Success / link green: #198754, oklch(0.55 0.14 150). Extracted as link/accent color; likely Bootstrap success utility.
- Info cyan: #0DCAF0, oklch(0.78 0.13 218). Extracted on blog as a secondary utility color.
- Secondary grey: #D6D6D6, oklch(0.87 0 0). Secondary button background.

Neutral scale:
- #000000 — deepest black / input background.
- #141414 — primary text and primary CTA background.
- #D6D6D6 — secondary action background.
- #FAFAFA — page background.
- #FFFFFF — inverse text and borders on dark inputs.

Usage rules:
- Use #141414 for primary CTAs, headers, core text, and high-priority commerce controls.
- Use #AB0000 sparingly for sale messaging, discount tags, urgency strips, and price reductions.
- Use #FAFAFA as the default canvas rather than pure white to maintain the soft high-fashion editorial feel.
- Use #198754 only where inherited utility semantics or links require it; avoid making it a dominant brand color.

## Spacing & Layout (base unit, scale, container widths, grid)
The extracted storefront uses a Bootstrap-based implementation with a 4px base spacing unit. The visual density is high: navigation menus, sale ribbons, store selectors, wishlist/cart links, and mega-menu lists are compact.

Base unit:
- 4px

Recommended spacing scale:
- 0: 0px
- 1: 4px
- 2: 8px
- 3: 12px
- 4: 16px
- 5: 24px
- 6: 32px
- 7: 48px
- 8: 64px
- 9: 96px

Layout patterns:
- Framework: Bootstrap-style grid and utilities.
- Header: stacked announcement bars above main navigation.
- Navigation: offcanvas mobile menu, logo centered/visible, cart and wishlist utility links.
- Store selector: explicit regional links for UK, US, EU.
- Mega menu: category columns grouped by headings, e.g. “NEW SHOP BY CATEGORY” and “NEW SHOP BY EDIT”.
- Content container: use Bootstrap-like responsive max widths: 540px, 720px, 960px, 1140px, 1320px.
- Product/category grids: use 2 columns on mobile, 3–4 on tablet/desktop, with compact gaps around 8–16px and larger editorial gaps around 24px.

## Radii, Shadows, Borders
The observed UI is angular and sharp. Buttons and inputs have 0px radius, while global extraction reports a Bootstrap default radius of 4px. In practice, action controls are square-edged.

Radii:
- Control radius: 0px for buttons and inputs.
- System fallback radius: 4px for generic Bootstrap components if required.
- Card radius: 0px recommended for product/editorial cards to preserve the stark gothic retail aesthetic.

Borders:
- Inputs: dark #000000 background with #FFFFFF border and #FFFFFF text.
- Primary buttons: #141414 background, #141414 border, #FFFFFF text.
- Secondary buttons: #D6D6D6 background, #D6D6D6 or transparent border, #141414 text.
- Use 1px borders for forms, selectors, and utility panels.

Shadows:
- Observed button/input shadows: none.
- Recommended elevation: avoid shadows; use contrast, borders, spacing, and photography instead.

## Components (buttons, cards, inputs, nav, hero — with observed variants)
Buttons:
- Primary button: black rectangle, #141414 background, #FFFFFF text, #141414 border, 0px radius, no shadow. Observed CTA text: “Shop Now”. Use for sale banners, hero CTAs, product add-to-cart, and high-priority actions.
- Secondary button: light grey rectangle, #D6D6D6 background, #141414 text, 0px radius, no shadow. Observed CTA text: “SUBSCRIBE”. Use for newsletter and lower-priority actions.
- Promotional link CTA: embedded in announcement copy, e.g. “⟡ Birthday Sale ⟡ Up To 50% Off Almost Everything - Shop Now”.

Inputs:
- Background: #000000.
- Text: #FFFFFF.
- Border: #FFFFFF.
- Radius: 0px.
- Shadow: none.
- Best suited for newsletter signup and dark footer modules.

Cards:
- Product/editorial cards should be image-first, square-edged, minimal chrome.
- Text hierarchy: product name or article title in #141414, price/sale state with red #AB0000 when discounted, secondary metadata in neutral grey/black.
- Avoid heavy outlines and drop shadows.

Navigation:
- Header begins with repeated announcement/promo ribbon messaging.
- Utility links include “My Wishlist”, cart count, skip-to-content, and store selector.
- Mobile/offcanvas trigger is labeled “Menu”.
- Logo links to homepage and appears in black wordmark form.
- Store selector lists UK, US, EU with region-specific redirect links.
- Mega-menu headings are uppercase and grouped, e.g. “NEW SHOP BY CATEGORY”, “NEW SHOP BY EDIT”.

Hero / promo strips:
- Announcement bars are high repetition, high urgency, and sale-led.
- Use decorative star glyphs: “⟡”.
- Promo copy alternates between sale and shipping messages: “Birthday Sale” and “Free Shipping On Orders Over $175”.
- Hero sections should combine large dark fashion imagery with bold black/white CTAs and red sale accents.

## Page Structure & Sections (nav → hero → ... → footer patterns observed)
Observed storefront page structure:
1. Wishlist utility link and count: “My Wishlist 0”.
2. Geo redirect/store detection notice: “We've detected your location & redirected you to our US store. To change which store you're shopping from, use the store selector.”
3. Accessibility link: “Skip to content”.
4. Repeating announcement carousel/ribbon: “⟡ Birthday Sale ⟡ Up To 50% Off Almost Everything - Shop Now”.
5. Shipping promise strip: “Free Shipping On Orders Over $175”.
6. Main header: menu trigger, compact logo, cart count, full logo.
7. Store selector: “STORE” with UK, US, EU links.
8. Primary navigation / mega menu: “NEW” leading into grouped columns.
9. Mega menu sections: “NEW SHOP BY CATEGORY”, “NEW SHOP BY EDIT”, “NEW ARRIVALS”.
10. Page content: blog listing, 404 content, collection/product content depending on route.
11. Newsletter/footer area likely uses dark inputs and a secondary “SUBSCRIBE” button based on extracted component classification.

## Copy Tone & Voice (with 3-5 real headline/CTA examples pulled from the site, grouped by section type)
The copy is direct, promotional, and identity-led. It combines gothic brand language with clear commerce CTAs.

Brand / metadata:
- “Gothic & Alternative Clothing | In Goth We Trust”
- “Clothing & Lifestyle company with a twist of darkness, channeling emotional power and raw energy into every thread.”

Announcement / promotion:
- “⟡ Birthday Sale ⟡ Up To 50% Off Almost Everything - Shop Now”
- “Free Shipping On Orders Over $175”

Navigation / shopping taxonomy:
- “NEW”
- “NEW SHOP BY CATEGORY”
- “BESTSELLERS”
- “BACK IN STOCK”
- “SUMMER GOTH EDIT”

Store utility:
- “STORE”
- “Switch to UK store”
- “Switch to US store”
- “Switch to EU store”

CTA examples:
- “Shop Now”
- “SUBSCRIBE”
- “Menu”

Voice principles:
- Keep promotional language short and emphatic.
- Use uppercase for navigation, category labels, and utility actions.
- Lean into dark alternative identity without sacrificing shopping clarity.
- Decorative glyphs such as “⟡” can be used in sale banners and campaign lines, not in core form labels.

## Imagery & Iconography style
Imagery is brand-led and fashion-focused: dark styling, alternative silhouettes, gothic wardrobe categories, and high-contrast product/editorial photography. Product data confirms black as a dominant colorway and highlights gothic fashion categories such as dresses, skater silhouettes, trad goth, dark romance, festival edit, corporate goth, and occasionwear.

Iconography and UI marks:
- Wordmark logo is black on light background.
- Favicon uses a compact “K” brand mark.
- Decorative star glyph “⟡” is used in promotional sale banners.
- Store flag icon appears in geo redirect messaging for the US store.
- Wishlist and cart utilities are compact and count-based.

Imagery rules:
- Prefer high-contrast fashion photography with black wardrobe dominance.
- Let product imagery carry visual richness; keep UI chrome minimal.
- Use monochrome UI around images to maintain the gothic premium retail feel.
- Use red only for sale/urgency and price reductions, not as a general background system color.