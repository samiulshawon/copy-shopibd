# Design Rules (extracted from https://www.killstar.com/)

These rules define the required visual direction for this project. Build a stark, monochrome, gothic-commerce-inspired interface: sharp rectangles, dense layouts, black typography, off-white canvas, red promotional emphasis, compact navigation, image-first cards, and minimal UI chrome.

## Non-negotiables (top 5 rules that MUST be followed)

1. **MUST use the monochrome foundation.**  
   Use `#FAFAFA` as the default page background, `#141414` as the primary text/control color, `#000000` for deepest surfaces such as dark inputs, and `#FFFFFF` for inverse text and input borders.

2. **MUST keep all controls sharp and rectangular.**  
   Buttons, inputs, cards, nav panels, promo strips, and product tiles MUST use `border-radius: 0px`. NEVER use pill buttons, rounded cards, bubbly controls, or soft SaaS-style corners.

3. **MUST use “Be Vietnam Pro” for all customer-facing UI text.**  
   Headings, body, navigation, buttons, form labels, and captions MUST use:
   `Be Vietnam Pro, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji`.

4. **MUST use red only for urgency, sale, discount, or promotional emphasis.**  
   Use Blood Red `#AB0000` sparingly for sale prices, discount labels, urgent banners, and markdown messaging. NEVER use red as a general brand background or decorative filler.

5. **MUST avoid decorative elevation.**  
   Use no shadows on buttons, cards, inputs, nav, or panels. Create hierarchy with contrast, spacing, typography, borders, and imagery instead.

---

## Color usage (which token for which purpose, forbidden colors)

### Required color tokens

Define and use these tokens consistently:

| Token | Hex | Usage |
|---|---:|---|
| `--color-primary` | `#141414` | Primary text, primary buttons, nav text, high-priority foreground |
| `--color-primary-deep` | `#000000` | Input backgrounds, deepest surfaces, dark footer modules |
| `--color-secondary` | `#AB0000` | Sale messaging, discount emphasis, urgent promotions |
| `--color-secondary-warm` | `#FF4500` | Rare promotional highlight only |
| `--color-accent` | `#198754` | Utility success/link color only when semantically required |
| `--color-info` | `#0DCAF0` | Informational utility only when semantically required |
| `--color-background` | `#FAFAFA` | Default page canvas |
| `--color-surface` | `#FFFFFF` | Inverse text, clean surfaces, dark-input borders |
| `--color-neutral-grey` | `#D6D6D6` | Secondary buttons, muted utility surfaces |
| `--color-text-primary` | `#141414` | Main readable text |
| `--color-text-inverse` | `#FFFFFF` | Text on black/dark controls |
| `--color-border-light` | `#FFFFFF` | Borders on dark inputs |

### Color rules

- ALWAYS use `#FAFAFA` for the main app/page background.
- ALWAYS use `#141414` for normal text, headings, nav labels, and primary CTAs.
- ALWAYS use `#FFFFFF` for text on black buttons and dark surfaces.
- MUST use `#000000` for newsletter-style input backgrounds and deepest contrast blocks.
- MUST use `#D6D6D6` for secondary button backgrounds.
- MUST use `#AB0000` only for:
  - sale labels
  - discount badges
  - reduced prices
  - urgency strips
  - promotional sale text
- MAY use `#FF4500` only as an occasional campaign highlight. Do not make it a core color.
- MAY use `#198754` and `#0DCAF0` only for utility states such as success/info alerts if unavoidable.

### Forbidden colors

NEVER introduce the following unless explicitly approved:

- Pastel palettes
- Purple gradients
- Blue SaaS primary buttons
- Neon rainbow accents
- Warm beige luxury palettes
- Glassmorphism tints
- Soft pink ecommerce themes
- Bright green as a brand color
- Generic Tailwind defaults like `blue-500`, `indigo-600`, `purple-600`, or `emerald-500` for primary UI

---

## Typography (families, weights, sizes — with Tailwind class or CSS var mapping suggestions)

### Font family

ALWAYS use:

```css
--font-primary: "Be Vietnam Pro", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
```

Tailwind mapping suggestion:

```js
fontFamily: {
  sans: ['Be Vietnam Pro', 'sans-serif'],
  primary: ['Be Vietnam Pro', 'sans-serif'],
}
```

NEVER use serif fonts for storefront UI.  
NEVER use playful display fonts.  
NEVER use generic Inter/SF-only SaaS typography unless `Be Vietnam Pro` is unavailable during loading.

### Font sizes

Use this scale:

| Token | Size | Tailwind suggestion | Usage |
|---|---:|---|---|
| `caption` | `10px` | `text-[10px]` | Tiny labels, legal, utility metadata |
| `utility` | `11px` | `text-[11px]` | Announcement details, helper text |
| `bodyCompact` | `12.375px` | `text-[12.375px]` | Product metadata, dense commerce UI |
| `body` | `14px` | `text-sm` or `text-[14px]` | Body copy, descriptions |
| `nav` | `15px` | `text-[15px]` | Main nav, menu headings |
| `h6` | `15px` | `text-[15px]` | Small headings |
| `h5` | `18px` | `text-lg` | Subsection headings |
| `h4` | `24px` | `text-2xl` | Section headings |
| `h3` | `30px` | `text-[30px]` | Large section headings |
| `h2` | `37.5px` | `text-[37.5px]` | Page headings |
| `h1` | `37.5px` | `text-[37.5px]` | Main page headings |

### Font weights

Use:

- `400` for body copy.
- `500` for compact utility emphasis.
- `600` for navigation labels, product names, and promo snippets.
- `700` for page headings and CTAs.

Tailwind mapping:

- `font-normal` = `400`
- `font-medium` = `500`
- `font-semibold` = `600`
- `font-bold` = `700`

### Line heights

Use:

| Token | Value | Usage |
|---|---:|---|
| `tight` | `1.1` | Hero headings, compact page titles |
| `heading` | `1.2` | Section headings |
| `body` | `1.5` | Descriptive copy |
| `utility` | `1.3` | Nav, captions, promo bars |

### Casing rules

- ALWAYS use uppercase for nav category labels, store selectors, and utility headings.
- Use uppercase for labels like:
  - `STORE`
  - `NEW`
  - `BESTSELLERS`
  - `BACK IN STOCK`
  - `NEW SHOP BY CATEGORY`
  - `NEW SHOP BY EDIT`
- CTA casing may be title case or uppercase depending on context:
  - Primary commerce CTA: `Shop Now`
  - Newsletter CTA: `SUBSCRIBE`
- NEVER use whimsical sentence-case labels for primary navigation.

---

## Spacing & Layout (grid, container, gaps)

### Base spacing

Use a `4px` base unit.

Required spacing scale:

| Token | Value | Tailwind equivalent |
|---|---:|---|
| `0` | `0px` | `0` |
| `1` | `4px` | `1` |
| `2` | `8px` | `2` |
| `3` | `12px` | `3` |
| `4` | `16px` | `4` |
| `5` | `24px` | `6` |
| `6` | `32px` | `8` |
| `7` | `48px` | `12` |
| `8` | `64px` | `16` |
| `9` | `96px` | `24` |

### Container widths

Use Bootstrap-style responsive max widths:

| Breakpoint | Max width |
|---|---:|
| `sm` | `540px` |
| `md` | `720px` |
| `lg` | `960px` |
| `xl` | `1140px` |
| `xxl` | `1320px` |

Tailwind mapping suggestion:

```js
container: {
  center: true,
  screens: {
    sm: '540px',
    md: '720px',
    lg: '960px',
    xl: '1140px',
    '2xl': '1320px',
  },
}
```

### Grid rules

- MUST use a Bootstrap-style `12` column grid.
- Product/category grids MUST be dense:
  - Mobile: `2` columns
  - Tablet: `3` columns
  - Desktop: `4` columns where content allows
- Use compact grid gaps:
  - Compact product grid: `8px`
  - Default layout gap: `16px`
  - Editorial feature gap: `24px`
- NEVER use oversized airy gaps that feel like generic portfolio templates.
- NEVER center all content in isolated cards with large shadows.
- ALWAYS let imagery dominate product/editorial grids.

### Layout density

- Header and navigation MUST feel compact and commerce-oriented.
- Promo bars MUST sit tightly above the main header.
- Mega menus MUST use grouped columns with uppercase headings.
- Footer forms MUST be compact, high contrast, and rectangular.

---

## Components (buttonPrimary, buttonSecondary, card, input, nav — with concrete CSS/Tailwind guidance)

### `buttonPrimary`

Primary buttons MUST be black rectangular CTAs.

Required styles:

```css
background: #141414;
color: #FFFFFF;
border: 1px solid #141414;
border-radius: 0px;
box-shadow: none;
font-family: "Be Vietnam Pro", sans-serif;
font-weight: 700;
padding: 12px 24px;
```

Tailwind guidance:

```html
class="inline-flex items-center justify-center bg-[#141414] text-white border border-[#141414] rounded-none shadow-none px-6 py-3 font-bold text-[14px]"
```

Rules:

- Use for hero CTAs, sale banners, checkout actions, add-to-cart-style actions, and primary form submits.
- CTA examples:
  - `Shop Now`
  - `View Collection`
  - `Add To Cart`
- NEVER use gradient primary buttons.
- NEVER use rounded-full.
- NEVER add hover shadows.
- Hover MAY invert or slightly darken, but MUST remain monochrome and sharp.

### `buttonSecondary`

Secondary buttons MUST be light grey rectangular CTAs.

Required styles:

```css
background: #D6D6D6;
color: #141414;
border: 1px solid #D6D6D6;
border-radius: 0px;
box-shadow: none;
font-family: "Be Vietnam Pro", sans-serif;
font-weight: 700;
padding: 12px 24px;
```

Tailwind guidance:

```html
class="inline-flex items-center justify-center bg-[#D6D6D6] text-[#141414] border border-[#D6D6D6] rounded-none shadow-none px-6 py-3 font-bold text-[14px]"
```

Rules:

- Use for newsletter signup, secondary actions, filter resets, and lower-priority controls.
- CTA example:
  - `SUBSCRIBE`
- NEVER use transparent ghost buttons as the default secondary style unless the design context is explicitly dark and high contrast.

### `card`

Cards MUST be image-first, square-edged, minimal, and shadowless.

Required styles:

```css
background: transparent; /* or #FAFAFA */
color: #141414;
border: 0;
border-radius: 0px;
box-shadow: none;
padding: 0;
gap: 8px;
```

Tailwind guidance:

```html
class="bg-transparent text-[#141414] border-0 rounded-none shadow-none p-0 space-y-2"
```

Rules:

- Product/editorial cards MUST put the image first.
- Images MUST be square-edged.
- Use product or feature title in `#141414`.
- Use sale or discount text in `#AB0000`.
- Use compact metadata in `12.375px` or `14px`.
- NEVER wrap cards in rounded white panels with shadows.
- NEVER use hover lift effects.
- Image hover MAY use subtle opacity or image swap only.

### `input`

Inputs MUST use the dark newsletter-style treatment unless a specific page requires a light utility input.

Required dark input styles:

```css
background: #000000;
color: #FFFFFF;
placeholder-color: #D6D6D6;
border: 1px solid #FFFFFF;
border-radius: 0px;
box-shadow: none;
font-family: "Be Vietnam Pro", sans-serif;
font-size: 12.375px;
padding: 12px 16px;
```

Tailwind guidance:

```html
class="bg-black text-white placeholder-[#D6D6D6] border border-white rounded-none shadow-none px-4 py-3 text-[12.375px] font-normal"
```

Rules:

- Use dark inputs for newsletter signup, footer forms, promo forms, and high-contrast modules.
- Placeholder text MUST be `#D6D6D6`.
- Focus state MUST remain sharp:
  - white border
  - no glow
  - no blue browser ring unless replaced with a monochrome accessible outline
- NEVER use rounded inputs.
- NEVER use soft grey SaaS input backgrounds as the main form style.

### `nav`

Navigation MUST mimic a compact alternative fashion storefront structure.

Required structure:

1. Utility strip
2. Geo/store notice if needed
3. Accessibility skip link
4. Repeating announcement/promo bar
5. Shipping promise strip
6. Main header
7. Store selector
8. Primary nav / mega menu

Rules:

- Main nav labels MUST be uppercase.
- Use `15px`, `600–700` weight for nav labels.
- Use compact spacing: `8px–16px` between nav items.
- Header background SHOULD be `#FAFAFA` or `#FFFFFF`.
- Text MUST be `#141414`.
- Use a black wordmark-style text/logo treatment for the project identity.
- Include compact utility actions such as:
  - Wishlist/favorites count
  - Cart count
  - Store/region selector
  - Menu trigger
- Mobile menu trigger SHOULD be labeled `Menu`.
- Mega menu headings MUST be uppercase and grouped in columns.
- Example headings:
  - `NEW`
  - `NEW SHOP BY CATEGORY`
  - `NEW SHOP BY EDIT`
  - `BESTSELLERS`
  - `BACK IN STOCK`
- NEVER use floating translucent nav bars.
- NEVER use rounded nav pills.
- NEVER use colorful icon-heavy app navigation.

---

## Section patterns (hero, feature grid, footer — structure to mimic)

### Hero

Hero sections MUST combine dark, high-contrast imagery with stark typography and rectangular CTAs.

Required hero structure:

1. Optional promo strip above hero
2. Large image or editorial visual
3. Bold heading
4. Short promotional or identity-led subcopy
5. Primary CTA
6. Optional red sale detail

Hero rules:

- Use `#FAFAFA` page background or full-bleed dark imagery.
- Headings MUST use `Be Vietnam Pro`, `700`, tight line height.
- Use heading sizes from `30px` to `37.5px`.
- CTA MUST be `buttonPrimary`.
- Red text `#AB0000` MAY appear for urgency, sale, or discount only.
- Decorative glyph `⟡` MAY be used in promo copy.
- NEVER use pastel gradient hero backgrounds.
- NEVER use generic abstract blobs.
- NEVER use rounded hero image masks.

Example hero copy pattern:

- `⟡ Limited Drop ⟡ Up To 50% Off - Shop Now`
- `New Arrivals`
- `Dark essentials. Sharp silhouettes. Built for the night.`

### Announcement / promo strips

Promo strips MUST be direct, repetitive, and commerce-led.

Rules:

- Use compact height.
- Use `11px–14px` text.
- Use black/white or red/white emphasis.
- Copy MUST be short and urgent.
- Decorative glyph `⟡` MAY be used.
- Example:
  - `⟡ Birthday Sale ⟡ Up To 50% Off Almost Everything - Shop Now`
  - `Free Shipping On Orders Over $175`

### Feature grid

Feature grids MUST be image-led and dense.

Required structure:

1. Section heading
2. Optional short intro
3. 2/3/4-column responsive grid
4. Square-edged imagery
5. Compact title
6. Optional CTA or metadata

Rules:

- Mobile MUST use `2` columns where possible.
- Desktop SHOULD use `4` columns for product/category grids.
- Gap MUST be `8px–16px`; use `24px` only for editorial layouts.
- Titles MUST be compact, `14px–15px`, `600–700`.
- NEVER place each item in a large rounded card.
- NEVER add drop shadows.
- NEVER use colorful badges except red sale/discount badges.

### Footer

Footer SHOULD use a high-contrast commerce/newsletter pattern.

Required footer structure:

1. Newsletter or signup block
2. Dark input
3. Secondary `SUBSCRIBE` button
4. Utility links
5. Store/region selector where relevant
6. Compact legal/caption text

Footer rules:

- Inputs MUST use `#000000` background, `#FFFFFF` text, `#FFFFFF` border.
- Subscribe button SHOULD use `buttonSecondary`.
- Footer may use `#141414` or `#000000` background with inverse text.
- Footer text MUST remain compact.
- NEVER use soft rounded newsletter cards.
- NEVER use pastel subscription modules.

---

## Copy voice (dos/donts with examples)

### Voice principles

- ALWAYS write short, direct, promotional copy.
- ALWAYS keep shopping actions clear.
- ALWAYS use uppercase for nav, categories, and utility labels.
- MUST lean into dark, alternative, high-energy language.
- MUST balance identity with clarity.
- MAY use decorative glyphs like `⟡` in promo banners.
- NEVER use cute, whimsical, cozy, or overly friendly startup copy.
- NEVER use vague AI-generated marketing filler.

### Do

Use direct ecommerce language:

- `Shop Now`
- `SUBSCRIBE`
- `NEW`
- `BESTSELLERS`
- `BACK IN STOCK`
- `Free Shipping On Orders Over $175`
- `⟡ Birthday Sale ⟡ Up To 50% Off Almost Everything - Shop Now`

Use dark/alternative identity language when appropriate:

- `Built for the night.`
- `Dark essentials.`
- `Sharp silhouettes.`
- `In shadow, in style.`
- `Raw energy. Clean lines. No compromise.`

Use compact campaign language:

- `Limited Drop`
- `New Arrivals`
- `Final Markdowns`
- `Sale Ends Soon`
- `Up To 50% Off`

### Don’t

NEVER write generic AI slop such as:

- `Discover a world of possibilities`
- `Elevate your experience`
- `Designed with you in mind`
- `Seamlessly transform your workflow`
- `Unlock your potential`
- `Where innovation meets elegance`

NEVER use soft lifestyle copy such as:

- `Cozy vibes for every day`
- `A delightful experience`
- `Brighten your journey`
- `Made with love and joy`

NEVER overuse gothic clichés to the point of parody. Avoid excessive copy like:

- `Summon your inner demon with our cursed offerings of eternal darkness`
- `Blood moon rituals for your soul`
- `Witchy spooky vibes only`

Keep the tone sharp, commercial, and controlled.

---

## Forbidden patterns (things NOT to do — generic AI slop, wrong gradients, etc.)

### Visual patterns NEVER allowed

- NEVER use rounded-full buttons.
- NEVER use soft rounded cards.
- NEVER use card shadows, hover lift shadows, or neumorphism.
- NEVER use glassmorphism.
- NEVER use pastel gradients.
- NEVER use rainbow gradients.
- NEVER use blue/purple SaaS gradients.
- NEVER use default Tailwind blue primary actions.
- NEVER use heavy colorful illustrations as the main aesthetic.
- NEVER use bubbly icons.
- NEVER use large empty whitespace that weakens the compact storefront feel.
- NEVER use overly airy editorial layouts for product grids.
- NEVER use beige luxury minimalism.
- NEVER use playful DTC wellness styling.
- NEVER use Apple-style translucent panels.
- NEVER use pill nav tabs.
- NEVER use rounded search bars.
- NEVER use soft grey form fields as the default.

### Component patterns NEVER allowed

- NEVER add `box-shadow` to buttons, inputs, cards, nav, or product tiles.
- NEVER set button radius above `0px`.
- NEVER set input radius above `0px`.
- NEVER create product cards with padded white containers and shadows.
- NEVER use red for normal buttons unless the button is explicitly a sale/urgency action.
- NEVER use green as a brand accent.
- NEVER use cyan except for true informational utility states.
- NEVER use orange except as a rare campaign highlight.
- NEVER create low-contrast grey text on grey backgrounds.
- NEVER rely on decorative chrome instead of strong imagery.

### Typography patterns NEVER allowed

- NEVER use serif headings.
- NEVER use script fonts.
- NEVER use playful display fonts.
- NEVER use oversized bubbly typography.
- NEVER use ultra-light font weights for core commerce UI.
- NEVER use all-lowercase nav labels.
- NEVER use long paragraph-style promo banners.

### Copy patterns NEVER allowed

- NEVER write vague marketing copy.
- NEVER write long, abstract hero paragraphs.
- NEVER hide the CTA.
- NEVER use unclear button labels like:
  - `Learn More` as the primary commerce CTA
  - `Explore` without context
  - `Continue` when a concrete action is available
- NEVER use decorative glyphs in form labels, accessibility labels, or critical instructions.

### Brand/IP caution for unrelated projects

- MUST follow the extracted visual system.
- MUST NOT use the KILLSTAR name, logo, favicon, exact brand tagline, or proprietary assets unless explicitly authorized.
- MUST create project-specific naming, imagery, and content while preserving the same visual rules: monochrome base, sharp controls, compact commerce layout, red sale emphasis, and dark editorial energy.