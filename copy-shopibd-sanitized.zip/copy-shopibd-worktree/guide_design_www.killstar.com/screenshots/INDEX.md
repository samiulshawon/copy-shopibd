# Screenshots

- **
      
        Gothic & Alternative Clothing | In Goth We Trust
        
        
        | Killstar
      
    ** — `screenshots/home.png` (https://www.killstar.com)
- **https://killstar.com/products.json** — `screenshots/products-json.png` (https://killstar.com/products.json)
- **https://www.killstar.com/agents.md** — `screenshots/agents-md.png` (https://www.killstar.com/agents.md)
- **
      
        News
        
        
        | Killstar
      
    ** — `screenshots/blogs-news.png` (https://www.killstar.com/blogs/news)
- **
      
        404 Not Found
        
        
        | Killstar
      
    ** — `screenshots/pages-about.png` (https://www.killstar.com/pages/about)