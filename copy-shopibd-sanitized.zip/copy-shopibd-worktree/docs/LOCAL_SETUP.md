# ShopiBD — Local Development Setup (Phase 0)

> **TL;DR:**
> ```bash
> cp .env.example .env                 # repo root
> cp frontend/.env.example frontend/.env.local
> docker compose -f docker-compose.dev.yml up -d --build
> python backend/scripts/check_ports.py --write    # align frontend port
> cd frontend && npx next dev -p $(grep FRONTEND_PORT ../.env | cut -d= -f2) -H 127.0.0.1
> ```

## What Phase 0 changed
- All service ports are now configurable via env vars (`BACKEND_PORT`, `FRONTEND_PORT`, `DB_PORT`, `REDIS_PORT`, `MINIO_PORT`, `MINIO_CONSOLE_PORT`).
- `docker-compose.dev.yml` reads these from the repo-root `.env` (defaults provided).
- The Docker backend container now runs **`uvicorn` with `--reload`** against the mounted `./backend` source, replacing the old `sleep infinity` placeholder.
- `backend/scripts/check_ports.py` probes the actual OS for bindable ports and prints (or writes) ready-to-use snippets — essential on Windows where the 3000–3020 range is reserved by default.

## Prerequisites
- Docker Desktop (with WSL2 backend on Windows).
- Python 3.11+ and Node.js 20+ for running scripts and the frontend locally.
- `make`/PowerShell — examples below use bash on Windows (Git Bash or WSL).

## Step 1 — Configure env
```bash
cp .env.example .env
cp frontend/.env.example frontend/.env.local
```
Edit `.env` and set port values appropriate to your machine. Keep `BACKEND_PORT` and `frontend/.env.local`'s `NEXT_PUBLIC_API_URL` port in sync — see step 3.

## Step 2 — Pick the right ports
Windows often reserves 3000–3020 and a stale WSL listener can claim 8000. Run the port checker to find what binds on your machine:
```bash
python backend/scripts/check_ports.py            # prints snippets
python backend/scripts/check_ports.py --write    # also writes frontend/.env.local
```
Paste the printed `BACKEND_PORT=…` / `FRONTEND_PORT=…` lines into your repo-root `.env`.

## Step 3 — Start the dev stack
```bash
docker compose -f docker-compose.dev.yml up -d --build
```
This brings up:
| Service    | Container                  | Mapped to       | Healthcheck |
|------------|----------------------------|------------------|-------------|
| Postgres   | `shopibd-db-dev`           | `${DB_PORT:-5434}:5432`            | `pg_isready` |
| Redis      | `shopibd-redis-dev`        | `${REDIS_PORT:-6380}:6379`         | `redis-cli ping` |
| MinIO      | `shopibd-minio-dev`        | `${MINIO_PORT:-9000}/9001:{9001}`  | — |
| Backend    | `shopibd-backend-dev`      | `${BACKEND_PORT:-8080}:8080`       | `GET /health` |

Wait for `shopibd-backend-dev` to report `(healthy)` (`docker ps`), then:
```bash
docker exec shopibd-backend-dev python -m scripts.seed    # one-time seed
```

## Step 4 — Start the frontend
```bash
cd frontend
npx next dev -p 4100 -H 127.0.0.1
```
Replace `4100` with whatever `FRONTEND_PORT` is set to in your `.env`.

## Step 5 — Verify
- Backend health: `curl http://localhost:8080/health` → `{"status":"healthy",...}`
- Login page: open `http://localhost:4100/auth/login`
- Super-admin login: `sawan@shopibd.com` / `12345678`
- Seeded store: `http://localhost:4100/shop/sawan-shop`

## Troubleshooting
- **`EACCES` binding a port** — your OS is reserving it. Re-run `check_ports.py` and update `.env`.
- **Stale listener on 8080 (Windows WSL)** — try a different `BACKEND_PORT` (e.g. 8081) via the checker.
- **`SECRET_KEY` rejected on startup** — Phase 1 will harden this. For now, set a unique value in `.env`.
- **Browser CORS error** — make sure `frontend/.env.local`'s `NEXT_PUBLIC_API_URL` port matches `BACKEND_PORT`.

## What this does NOT cover (next phases)
- Phase 1: refresh tokens + secret-key fail-fast
- Phase 4: CI/tests in GitHub Actions
- Phase 5: `/metrics` and request-ID
…see `enhancement-roadmap-2026` spec for the full roadmap.
