# ShopiBD Development Stopper (PowerShell)
Write-Host "Stopping ShopiBD development servers..." -ForegroundColor Yellow

# Stop backend job
$backendJob = Get-Job -Name "ShopiBD-Backend" -ErrorAction SilentlyContinue
if ($backendJob) {
    Stop-Job $backendJob
    Remove-Job $backendJob
    Write-Host "       Backend stopped." -ForegroundColor Green
}

# Stop frontend job
$frontendJob = Get-Job -Name "ShopiBD-Frontend" -ErrorAction SilentlyContinue
if ($frontendJob) {
    Stop-Job $frontendJob
    Remove-Job $frontendJob
    Write-Host "       Frontend stopped." -ForegroundColor Green
}

# Also kill any lingering uvicorn/node processes
Get-Process | Where-Object { $_.ProcessName -match "^python$|^node$" } | ForEach-Object {
    try {
        Stop-Process $_ -Force -ErrorAction SilentlyContinue
    } catch {}
}

Write-Host "All stopped." -ForegroundColor Green
