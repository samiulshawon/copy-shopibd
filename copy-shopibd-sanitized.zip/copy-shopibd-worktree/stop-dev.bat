@echo off
title ShopiBD Development Stopper
cd /d "%~dp0"

echo ========================================
echo   Stopping ShopiBD Development Servers
echo ========================================
echo.

:: Stop backend
echo Stopping Backend...
taskkill /F /FI "WINDOWTITLE eq ShopiBD-Backend" /T 2>nul

:: Stop frontend
echo Stopping Frontend...
taskkill /F /FI "WINDOWTITLE eq ShopiBD-Frontend" /T 2>nul

echo.
echo All servers stopped.
echo.
