# ShopiBD Development Starter (PowerShell)
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  ShopiBD Development Starter" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Step 1: Check Docker
Write-Host "[1/5] Checking Docker..." -ForegroundColor Yellow
try {
    $null = docker info 2>&1
    Write-Host "       Docker is running." -ForegroundColor Green
} catch {
    Write-Host "ERROR: Docker is not running. Start Docker Desktop first." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

# Step 2: Start PostgreSQL if not running
Write-Host "[2/5] Starting PostgreSQL..." -ForegroundColor Yellow
$containers = docker ps --format "{{.Names}}" 2>$null
if ($containers -notcontains "shopibd-db-dev") {
    Write-Host "       Container not found. Starting with Docker Compose..."
    docker compose -f .\docker-compose.dev.yml up -d
    Write-Host "       Waiting for PostgreSQL to be ready..." -ForegroundColor Yellow
    Start-Sleep -Seconds 5
} else {
    Write-Host "       PostgreSQL already running." -ForegroundColor Green
}

# Step 3: Clear frontend cache
Write-Host "[3/5] Clearing frontend cache..." -ForegroundColor Yellow
$nextDir = Join-Path $PSScriptRoot "frontend\.next"
if (Test-Path $nextDir) {
    Remove-Item -Path $nextDir -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "       Cache cleared." -ForegroundColor Green
} else {
    Write-Host "       No cache to clear." -ForegroundColor Gray
}

# Step 4: Start backend
Write-Host "[4/5] Starting backend on :8080..." -ForegroundColor Yellow
$backendDir = Join-Path $PSScriptRoot "backend"
$uvicorn = Join-Path $backendDir "venv\Scripts\uvicorn.exe"

if (Test-Path $uvicorn) {
    $sb = {
        param($dir)
        Set-Location $dir
        & "venv\Scripts\uvicorn.exe" app.main:app --reload --port 8080
    }
    Start-Job -Name "ShopiBD-Backend" -ScriptBlock $sb -ArgumentList $backendDir | Out-Null
    Write-Host "       Backend starting on http://localhost:8080" -ForegroundColor Green
} else {
    Write-Host "       WARNING: Virtual env not found. Run: python -m venv venv then pip install -r requirements.txt" -ForegroundColor Red
}

# Step 5: Start frontend
Write-Host "[5/5] Starting frontend on :3001..." -ForegroundColor Yellow
$frontendDir = Join-Path $PSScriptRoot "frontend"
$sb2 = {
    param($dir)
    Set-Location $dir
    npm run dev
}
Start-Job -Name "ShopiBD-Frontend" -ScriptBlock $sb2 -ArgumentList $frontendDir | Out-Null

Start-Sleep -Seconds 3
Write-Host "       Frontend starting on http://localhost:3001" -ForegroundColor Green

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Ready!" -ForegroundColor Green
Write-Host "  Frontend: http://localhost:3001" -ForegroundColor White
Write-Host "  Backend:  http://localhost:8080" -ForegroundColor White
Write-Host "  API Docs: http://localhost:8080/docs" -ForegroundColor White
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "To stop: .\stop-dev.ps1" -ForegroundColor Yellow
