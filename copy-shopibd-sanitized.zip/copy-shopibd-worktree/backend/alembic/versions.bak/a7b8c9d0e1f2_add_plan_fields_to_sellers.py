"""add plan fields to sellers

Revision ID: a7b8c9d0e1f2
Revises: 436f48a80d28
Create Date: 2025-01-15 10:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "a7b8c9d0e1f2"
down_revision: Union[str, None] = "436f48a80d28"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("sellers", sa.Column("plan", sa.String(), server_default="free", nullable=False))
    op.add_column("sellers", sa.Column("max_products", sa.Integer(), server_default="50", nullable=False))
    op.add_column("sellers", sa.Column("max_orders", sa.Integer(), server_default="200", nullable=False))


def downgrade() -> None:
    op.drop_column("sellers", "max_orders")
    op.drop_column("sellers", "max_products")
    op.drop_column("sellers", "plan")