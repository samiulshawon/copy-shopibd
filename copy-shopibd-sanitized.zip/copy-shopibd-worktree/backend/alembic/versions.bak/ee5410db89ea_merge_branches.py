"""merge_branches

Revision ID: ee5410db89ea
Revises: a7b8c9d0e1f2, 06cbfe125b2f
Create Date: 2026-07-06 01:55:53.301950

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'ee5410db89ea'
down_revision: Union[str, None] = ('a7b8c9d0e1f2', '06cbfe125b2f')
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
