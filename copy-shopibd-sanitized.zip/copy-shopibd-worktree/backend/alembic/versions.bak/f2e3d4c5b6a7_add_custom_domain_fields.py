"""add_custom_domain_fields

Revision ID: f2e3d4c5b6a7
Revises: f0e1d2c3b4a5
Create Date: 2026-07-06 14:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "f2e3d4c5b6a7"
down_revision: Union[str, None] = "f0e1d2c3b4a5"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("shops", sa.Column("custom_domain", sa.String(), nullable=True))
    op.add_column("shops", sa.Column("subdomain", sa.String(), nullable=True))
    op.add_column(
        "shops", sa.Column("domain_verified", sa.Boolean(), nullable=False, server_default=sa.text("false"))
    )
    op.add_column(
        "shops", sa.Column("domain_verified_at", sa.DateTime(), nullable=True)
    )
    op.add_column(
        "shops", sa.Column("ssl_provisioned", sa.Boolean(), nullable=False, server_default=sa.text("false"))
    )
    op.add_column("shops", sa.Column("branding_settings", sa.JSON(), nullable=True))
    op.add_column(
        "shops", sa.Column("hide_branding", sa.Boolean(), nullable=False, server_default=sa.text("false"))
    )
    op.create_unique_constraint("uq_shops_custom_domain", "shops", ["custom_domain"])
    op.create_unique_constraint("uq_shops_subdomain", "shops", ["subdomain"])


def downgrade() -> None:
    op.drop_constraint("uq_shops_subdomain", "shops", type_="unique")
    op.drop_constraint("uq_shops_custom_domain", "shops", type_="unique")
    op.drop_column("shops", "hide_branding")
    op.drop_column("shops", "branding_settings")
    op.drop_column("shops", "ssl_provisioned")
    op.drop_column("shops", "domain_verified_at")
    op.drop_column("shops", "domain_verified")
    op.drop_column("shops", "subdomain")
    op.drop_column("shops", "custom_domain")
