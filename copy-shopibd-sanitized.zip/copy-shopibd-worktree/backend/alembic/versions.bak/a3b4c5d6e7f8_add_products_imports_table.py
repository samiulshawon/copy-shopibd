"""add_products_imports_table

Revision ID: a3b4c5d6e7f8
Revises: f2e3d4c5b6a7
Create Date: 2026-07-06 15:00:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "a3b4c5d6e7f8"
down_revision: Union[str, None] = "f2e3d4c5b6a7"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "products_imports",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("seller_id", sa.Integer(), nullable=False),
        sa.Column("shop_id", sa.Integer(), nullable=False),
        sa.Column("filename", sa.String(255), nullable=True),
        sa.Column("total_rows", sa.Integer(), nullable=False, server_default=sa.text("0")),
        sa.Column("created_count", sa.Integer(), nullable=False, server_default=sa.text("0")),
        sa.Column("failed_count", sa.Integer(), nullable=False, server_default=sa.text("0")),
        sa.Column("errors", sa.Text(), nullable=True),
        sa.Column(
            "imported_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("(CURRENT_TIMESTAMP)"),
            nullable=True,
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_products_imports_id"), "products_imports", ["id"], unique=False)
    op.create_index(
        op.f("ix_products_imports_seller_id"),
        "products_imports",
        ["seller_id"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index(op.f("ix_products_imports_seller_id"), table_name="products_imports")
    op.drop_index(op.f("ix_products_imports_id"), table_name="products_imports")
    op.drop_table("products_imports")
