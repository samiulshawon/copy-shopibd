"""add_shop_payment_columns

Revision ID: c1d2e3f4a5b6
Revises: f2e3d4c5b6a7
Create Date: 2026-07-17 03:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "c1d2e3f4a5b6"
down_revision: Union[str, None] = "f2e3d4c5b6a7"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("shops", sa.Column("rocket_number", sa.String(), nullable=True))
    op.add_column(
        "shops", sa.Column("delivery_settings", sa.JSON(), nullable=True, server_default=sa.text("'{}'"))
    )


def downgrade() -> None:
    op.drop_column("shops", "delivery_settings")
    op.drop_column("shops", "rocket_number")
