"""
Add coupons and coupon_usages tables.

Revision ID: add_coupons_and_coupon_usages
Revises: ee5410db89ea
Create Date: 2026-01-01 12:00:00.000000
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "add_coupons_and_coupon_usages"
down_revision: Union[str, None] = "ee5410db89ea"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # --- coupons ---
    op.create_table(
        "coupons",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("seller_id", sa.Integer(), sa.ForeignKey("sellers.id"), nullable=False),
        sa.Column("shop_id", sa.Integer(), sa.ForeignKey("shops.id"), nullable=True),
        sa.Column("code", sa.String(length=50), nullable=False, index=True),
        sa.Column("discount_type", sa.String(length=20), nullable=False),
        sa.Column("discount_value", sa.Numeric(precision=10, scale=2), nullable=False),
        sa.Column("min_order_amount", sa.Numeric(precision=10, scale=2), nullable=True),
        sa.Column("max_discount", sa.Numeric(precision=10, scale=2), nullable=True),
        sa.Column("usage_limit", sa.Integer(), nullable=True),
        sa.Column("usage_count", sa.Integer(), server_default="0", nullable=True),
        sa.Column("per_customer_limit", sa.Integer(), server_default="1", nullable=True),
        sa.Column("applies_to", sa.String(length=30), server_default="all", nullable=True),
        sa.Column("product_ids", sa.Text(), nullable=True),
        sa.Column("category_ids", sa.Text(), nullable=True),
        sa.Column("is_active", sa.Boolean(), server_default="1", nullable=True),
        sa.Column("starts_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=True,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=True,
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_coupons_code_seller", "coupons", ["code", "seller_id"], unique=True)

    # --- coupon_usages ---
    op.create_table(
        "coupon_usages",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("coupon_id", sa.Integer(), sa.ForeignKey("coupons.id"), nullable=False),
        sa.Column("order_id", sa.Integer(), sa.ForeignKey("orders.id"), nullable=False),
        sa.Column("customer_phone", sa.String(length=20), nullable=False),
        sa.Column("discount_amount", sa.Numeric(precision=10, scale=2), nullable=False),
        sa.Column(
            "used_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=True,
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_coupon_usages_coupon_id", "coupon_usages", ["coupon_id"])
    op.create_index("ix_coupon_usages_order_id", "coupon_usages", ["order_id"])


def downgrade() -> None:
    op.drop_table("coupon_usages")
    op.drop_table("coupons")
