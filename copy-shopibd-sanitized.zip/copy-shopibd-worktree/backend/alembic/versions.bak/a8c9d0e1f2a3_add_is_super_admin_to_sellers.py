"""add is_super_admin to sellers

Revision ID: a8c9d0e1f2a3
Revises: ee5410db89ea
Create Date: 2026-07-17 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "a8c9d0e1f2a3"
down_revision: Union[str, None] = "ee5410db89ea"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "sellers",
        sa.Column("is_super_admin", sa.Boolean(), server_default=sa.false(), nullable=False),
    )


def downgrade() -> None:
    op.drop_column("sellers", "is_super_admin")
