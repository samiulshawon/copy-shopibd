"""Phase 6: subscription downgrade grace period + event outbox.

Revision ID: p6_downgrade_grace
Revises: p5_scheduler_runs
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "p6_downgrade_grace"
down_revision: Union[str, None] = "p5_scheduler_runs"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Grace window for custom-domain routing after a downgrade.
    with op.batch_alter_table("shops") as batch_op:
        batch_op.add_column(sa.Column("custom_domain_grace_until", sa.DateTime(), nullable=True))

    # Durable event outbox for domain events (Phase 6: subscription.downgraded).
    op.create_table(
        "event_outbox",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("event_type", sa.String(length=80), nullable=False),
        sa.Column("payload", sa.Text(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("processed_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_event_outbox_event_type", "event_outbox", ["event_type"])


def downgrade() -> None:
    op.drop_index("ix_event_outbox_event_type", table_name="event_outbox")
    op.drop_table("event_outbox")
    with op.batch_alter_table("shops") as batch_op:
        batch_op.drop_column("custom_domain_grace_until")
