"""Phase 10.3: abandoned-cart recovery tracking fields on orders.

Revision ID: p10_order_recovery
Revises: p8_role_is_staff
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "p10_order_recovery"
down_revision: Union[str, None] = "p8_role_is_staff"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table("orders") as batch_op:
        batch_op.add_column(
            sa.Column("recovery_sent_at", sa.DateTime(timezone=True), nullable=True)
        )
        batch_op.add_column(
            sa.Column("recovered_at", sa.DateTime(timezone=True), nullable=True)
        )


def downgrade() -> None:
    with op.batch_alter_table("orders") as batch_op:
        batch_op.drop_column("recovered_at")
        batch_op.drop_column("recovery_sent_at")
