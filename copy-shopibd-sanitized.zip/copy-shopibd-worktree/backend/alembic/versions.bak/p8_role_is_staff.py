"""Phase 8: add Seller.is_staff to separate admin from verified.

Revision ID: p8_role_is_staff
Revises: p7_ssl_columns
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "p8_role_is_staff"
down_revision: Union[str, None] = "p7_ssl_columns"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table("sellers") as batch_op:
        batch_op.add_column(
            sa.Column("is_staff", sa.Boolean(), nullable=False, server_default=sa.false())
        )

    # Backfill in-migration too: any existing super-admin is staff by definition.
    op.execute("UPDATE sellers SET is_staff = true WHERE is_super_admin = true")


def downgrade() -> None:
    with op.batch_alter_table("sellers") as batch_op:
        batch_op.drop_column("is_staff")
