"""add_deliveries_table

Revision ID: f0e1d2c3b4a5
Revises: 1a2b3c4d5e6f
Create Date: 2026-07-06 12:00:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "f0e1d2c3b4a5"
down_revision: Union[str, None] = "1a2b3c4d5e6f"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "deliveries",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("order_id", sa.Integer(), nullable=False),
        sa.Column("seller_id", sa.Integer(), nullable=False),
        sa.Column(
            "courier_name",
            sa.Enum(
                "steadfast",
                "ecourier",
                "pathao",
                "redx",
                "manual",
                name="couriername",
            ),
            nullable=False,
        ),
        sa.Column("tracking_number", sa.String(), nullable=True),
        sa.Column(
            "shipment_status",
            sa.Enum(
                "pending",
                "picked_up",
                "in_transit",
                "delivered",
                "returned",
                "failed",
                name="shipmentstatus",
            ),
            nullable=False,
        ),
        sa.Column("pickup_address", sa.Text(), nullable=False),
        sa.Column("delivery_address", sa.Text(), nullable=False),
        sa.Column("weight_kg", sa.Numeric(10, 3), nullable=True),
        sa.Column("cod_amount", sa.Numeric(10, 2), nullable=True),
        sa.Column("shipping_cost", sa.Numeric(10, 2), nullable=True),
        sa.Column("estimated_delivery_date", sa.Date(), nullable=True),
        sa.Column("delivered_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            onupdate=sa.func.now(),
        ),
        sa.ForeignKeyConstraint(
            ["order_id"],
            ["orders.id"],
        ),
        sa.ForeignKeyConstraint(
            ["seller_id"],
            ["sellers.id"],
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        op.f("ix_deliveries_id"), "deliveries", ["id"], unique=False
    )
    op.create_index(
        op.f("ix_deliveries_order_id"),
        "deliveries",
        ["order_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_deliveries_seller_id"),
        "deliveries",
        ["seller_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_deliveries_tracking_number"),
        "deliveries",
        ["tracking_number"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index(
        op.f("ix_deliveries_tracking_number"), table_name="deliveries"
    )
    op.drop_index(
        op.f("ix_deliveries_seller_id"), table_name="deliveries"
    )
    op.drop_index(
        op.f("ix_deliveries_order_id"), table_name="deliveries"
    )
    op.drop_index(op.f("ix_deliveries_id"), table_name="deliveries")
    op.drop_table("deliveries")
    # Drop the ENUM types (PostgreSQL only; SQLite ignores this)
    op.execute("DROP TYPE IF EXISTS couriername")
    op.execute("DROP TYPE IF EXISTS shipmentstatus")
