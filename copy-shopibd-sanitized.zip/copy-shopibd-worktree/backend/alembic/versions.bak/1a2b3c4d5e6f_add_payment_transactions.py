"""add_payment_transactions

Revision ID: 1a2b3c4d5e6f
Revises: bc46747e92b8
Create Date: 2026-07-06 02:30:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "1a2b3c4d5e6f"
down_revision: Union[str, None] = "bc46747e92b8"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "payment_transactions",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("order_id", sa.Integer(), nullable=True),
        sa.Column("seller_id", sa.Integer(), nullable=False),
        sa.Column("shop_id", sa.Integer(), nullable=False),
        sa.Column("amount", sa.Numeric(10, 2), nullable=False),
        sa.Column("currency", sa.String(), nullable=True, server_default="BDT"),
        sa.Column(
            "payment_method",
            sa.Enum("bkash", "nagad", "rocket", "cod", "bank", name="paymentmethod"),
            nullable=False,
        ),
        sa.Column("sender_phone", sa.String(), nullable=True),
        sa.Column(
            "reference",
            sa.String(),
            nullable=True,
            comment="bKash/Nagad transaction ID",
        ),
        sa.Column(
            "status",
            sa.Enum(
                "pending", "verified", "mismatched", "unmatched", name="paymentstatus"
            ),
            nullable=False,
            server_default="pending",
        ),
        sa.Column("matched_order_id", sa.Integer(), nullable=True),
        sa.Column("raw_sms_text", sa.Text(), nullable=True),
        sa.Column(
            "verified_by",
            sa.String(),
            nullable=True,
            comment='"manual" / "sms_parse" / "api"',
        ),
        sa.Column("verified_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("(CURRENT_TIMESTAMP)"),
            nullable=True,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("(CURRENT_TIMESTAMP)"),
            nullable=True,
        ),
        sa.ForeignKeyConstraint(
            ["order_id"],
            ["orders.id"],
        ),
        sa.ForeignKeyConstraint(
            ["seller_id"],
            ["sellers.id"],
        ),
        sa.ForeignKeyConstraint(
            ["shop_id"],
            ["shops.id"],
        ),
        sa.ForeignKeyConstraint(
            ["matched_order_id"],
            ["orders.id"],
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        op.f("ix_payment_transactions_id"),
        "payment_transactions",
        ["id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_payment_transactions_order_id"),
        "payment_transactions",
        ["order_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_payment_transactions_seller_id"),
        "payment_transactions",
        ["seller_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_payment_transactions_shop_id"),
        "payment_transactions",
        ["shop_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_payment_transactions_matched_order_id"),
        "payment_transactions",
        ["matched_order_id"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index(
        op.f("ix_payment_transactions_matched_order_id"),
        table_name="payment_transactions",
    )
    op.drop_index(
        op.f("ix_payment_transactions_shop_id"), table_name="payment_transactions"
    )
    op.drop_index(
        op.f("ix_payment_transactions_seller_id"), table_name="payment_transactions"
    )
    op.drop_index(
        op.f("ix_payment_transactions_order_id"), table_name="payment_transactions"
    )
    op.drop_index(
        op.f("ix_payment_transactions_id"), table_name="payment_transactions"
    )
    op.drop_table("payment_transactions")
    op.execute("DROP TYPE IF EXISTS paymentmethod")
    op.execute("DROP TYPE IF EXISTS paymentstatus")
