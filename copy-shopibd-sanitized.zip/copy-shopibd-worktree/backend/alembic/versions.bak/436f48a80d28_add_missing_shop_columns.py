"""add_missing_shop_columns

Revision ID: 436f48a80d28
Revises: abdfde14e79f
Create Date: 2026-07-04 04:32:15.594394

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '436f48a80d28'
down_revision: Union[str, None] = 'abdfde14e79f'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column('shops', sa.Column('banner_url', sa.String(), nullable=True))
    op.add_column('shops', sa.Column('contact_phone', sa.String(), nullable=False, server_default=''))
    op.add_column('shops', sa.Column('bkash_number', sa.String(), nullable=True))
    op.add_column('shops', sa.Column('nagad_number', sa.String(), nullable=True))


def downgrade() -> None:
    op.drop_column('shops', 'nagad_number')
    op.drop_column('shops', 'bkash_number')
    op.drop_column('shops', 'contact_phone')
    op.drop_column('shops', 'banner_url')
