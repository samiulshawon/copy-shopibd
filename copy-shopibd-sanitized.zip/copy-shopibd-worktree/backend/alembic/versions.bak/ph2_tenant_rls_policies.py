"""Phase 2: tenant RLS policies (optional defense-in-depth)

Revision ID: ph2_tenant_rls
Revises: a8c9d0e1f2a3
Create Date: 2026-07-18 13:00:00.000000

Adds Row-Level Security policies on tenant-scoped tables keyed on
``current_setting('app.current_seller_id')`` so a forgotten WHERE filter in
application code cannot leak data across tenants. Super-admin connections
are exempted via ``app.current_seller_role = 'super_admin'``.

The policies are ALWAYS created when this migration runs on PostgreSQL; in
SQLite-based test/CI environments the entire migration is a no-op.
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "ph2_tenant_rls"
down_revision: Union[str, None] = "a8c9d0e1f2a3"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


# Tables whose rows are scoped to a single seller via ``seller_id``.
# Each policy checks: ``seller_id::text = current_setting('app.current_seller_id')``.
TENANT_TABLES = [
    "shops",
    "products",
    "product_images",
    "orders",
    "order_items",
    "customers",
    "categories",
    "staff",
    "coupons",
    "coupon_usages",
    "deliveries",
    "reviews",
    "stock_movements",
    "payments",
    "payment_transactions",
    "audit_logs",
]


def _is_postgres() -> bool:
    bind = op.get_bind()
    return bind.dialect.name == "postgresql"


def upgrade() -> None:
    if not _is_postgres():
        # SQLite cannot express these (test/CI). No-op.
        return

    # Grant BYPASSRLS to the role typically used by the app so super-admin
    # connections (role='super_admin') aren't accidentally filtered.
    # We can't grant BYPASSRLS unless we own the role, so this is wrapped
    # in a "best-effort" DO block.
    op.execute(
        """
        DO $$
        BEGIN
            BEGIN
                ALTER ROLE CURRENT_USER WITH BYPASSRLS;
            EXCEPTION WHEN insufficient_privilege OR feature_not_supported THEN
                NULL;
            END;
        END$$;
        """
    )

    for table in TENANT_TABLES:
        # Enable RLS
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY;")
        # Drop any prior policy with the same name so this migration is idempotent.
        op.execute(f"DROP POLICY IF EXISTS tenant_isolation ON {table};")
        # Key policy on app.current_seller_id; super-admin role bypasses via
        # BYPASSRLS above. The seller_id column is NOT NULL on all tenant
        # tables; we use the column's actual type cast to text for comparison.
        op.execute(
            f"""
            CREATE POLICY tenant_isolation ON {table}
                USING (
                    current_setting('app.current_seller_role', true) = 'super_admin'
                    OR seller_id::text = current_setting('app.current_seller_id', true)
                )
                WITH CHECK (
                    current_setting('app.current_seller_role', true) = 'super_admin'
                    OR seller_id::text = current_setting('app.current_seller_id', true)
                );
            """
        )


def downgrade() -> None:
    if not _is_postgres():
        return
    for table in TENANT_TABLES:
        op.execute(f"DROP POLICY IF EXISTS tenant_isolation ON {table};")
        op.execute(f"ALTER TABLE {table} DISABLE ROW LEVEL SECURITY;")
