"""Phase 5: persist scheduler execution visibility.

Revision ID: p5_scheduler_runs
Revises: ph2_tenant_rls
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "p5_scheduler_runs"
down_revision: Union[str, None] = "ph2_tenant_rls"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "scheduler_runs",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("task_name", sa.String(length=100), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("result", sa.JSON(), nullable=True),
        sa.Column("error", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_scheduler_runs_task_name", "scheduler_runs", ["task_name"])
    op.create_index("ix_scheduler_runs_status", "scheduler_runs", ["status"])


def downgrade() -> None:
    op.drop_index("ix_scheduler_runs_status", table_name="scheduler_runs")
    op.drop_index("ix_scheduler_runs_task_name", table_name="scheduler_runs")
    op.drop_table("scheduler_runs")
