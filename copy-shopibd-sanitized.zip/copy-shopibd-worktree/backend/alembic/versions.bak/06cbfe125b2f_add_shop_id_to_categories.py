"""add_shop_id_to_categories

Revision ID: 06cbfe125b2f
Revises: 436f48a80d28
Create Date: 2026-07-04 04:40:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '06cbfe125b2f'
down_revision: Union[str, None] = '436f48a80d28'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column('categories', sa.Column('shop_id', sa.Integer(), nullable=False, server_default='2'))
    op.create_index(op.f('ix_categories_shop_id'), 'categories', ['shop_id'], unique=False)
    op.create_foreign_key('fk_categories_shop_id_shops', 'categories', 'shops', ['shop_id'], ['id'])


def downgrade() -> None:
    op.drop_constraint('fk_categories_shop_id_shops', 'categories', type_='foreignkey')
    op.drop_index(op.f('ix_categories_shop_id'), table_name='categories')
    op.drop_column('categories', 'shop_id')
