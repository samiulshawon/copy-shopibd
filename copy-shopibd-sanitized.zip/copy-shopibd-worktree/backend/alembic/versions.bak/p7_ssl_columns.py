"""Phase 7: Shop SSL status + expiry columns.

Revision ID: p7_ssl_columns
Revises: p6_downgrade_grace
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "p7_ssl_columns"
down_revision: Union[str, None] = "p6_downgrade_grace"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table("shops") as batch_op:
        batch_op.add_column(
            sa.Column("ssl_status", sa.String(), nullable=False, server_default="none")
        )
        batch_op.add_column(sa.Column("ssl_expires_at", sa.DateTime(), nullable=True))


def downgrade() -> None:
    with op.batch_alter_table("shops") as batch_op:
        batch_op.drop_column("ssl_expires_at")
        batch_op.drop_column("ssl_status")
