from pydantic import BaseModel, HttpUrl  
from typing import Optional  
class Test(BaseModel):  
    url: Optional[HttpUrl] = None  
t = Test(url=None)  
print(t)  
