from fastapi import FastAPI, Depends
from fastapi.testclient import TestClient
from app.core.database import SessionLocal, get_db
from app.models.shop import Shop
from app.models.product import Product
from app.models.category import Category
from app.schemas.shop import ShopPublic

app = FastAPI()

@app.get('/test')
def test(db: SessionLocal = Depends(get_db)):
    shop = db.query(Shop).filter(Shop.slug == 'sawan-shop', Shop.is_active == True).first()
    products = db.query(Product).filter(Product.shop_id == shop.id, Product.is_active == True).order_by(Product.name).all()
    categories = db.query(Category).filter(Category.shop_id == shop.id, Category.is_active == True).order_by(Category.sort_order).all()
    return ShopPublic(
        id=shop.id,
        name=shop.name,
        slug=shop.slug,
        description=shop.description,
        logo_url=shop.logo_url,
        is_active=shop.is_active,
        products=[
            {
                'id': p.id,
                'name': p.name,
                'description': p.description,
                'price': float(p.price),
                'stock': p.stock,
                'sku': p.sku,
            }
            for p in products
        ],
        banner_url=shop.banner_url,
        contact_phone=shop.contact_phone,
        bkash_number=shop.bkash_number,
        nagad_number=shop.nagad_number,
        categories=[
            {
                'id': c.id,
                'name_bn': c.name_bn,
                'name_en': c.name_en,
                'description': c.description,
                'sort_order': c.sort_order,
                'is_active': c.is_active,
            }
            for c in categories
        ],
    )

client = TestClient(app)
r = client.get('/test')
print('Status:', r.status_code)
print('Body:', r.text)
