import os
import time
from typing import Dict, List

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response, JSONResponse

from app.core.config import settings
from app.core.log import get_logger
from app.services.redis_client import is_redis_available, sliding_window_add
from app.services.metrics import increment_redis_down

logger = get_logger(__name__)


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Per-IP rate limiting using a sliding window.

    Uses Redis when available (shared across replicas, survives restarts);
    otherwise falls back to an in-process dict so local dev and CI still work.
    """

    def __init__(self, app, requests_per_minute: int = 60):
        super().__init__(app)
        self.requests_per_minute = requests_per_minute
        self.window_seconds = 60
        # In-memory fallback used only when Redis is unavailable.
        self.ips: Dict[str, List[float]] = {}

    async def dispatch(self, request: Request, call_next):
        # Skip rate limiting in test environments to avoid false 429s during
        # test runs (TestClient makes many rapid requests).
        if settings.DEBUG or os.getenv("PYTEST_CURRENT_TEST") or os.getenv("TESTING"):
            return await call_next(request)

        # Get client IP (respect X-Forwarded-For when behind a proxy).
        forwarded = request.headers.get("X-Forwarded-For")
        if forwarded:
            ip = forwarded.split(",")[0].strip()
        else:
            ip = request.client.host if request.client else "unknown"

        # Phase 3 observability: detect whether Redis is unavailable for this
        # request so we can increment ``ratelimit_redis_down_total`` on the
        # fallback path. We sample once per request and cache the boolean so
        # the limiter logic below stays unchanged.
        redis_was_available = is_redis_available()

        allowed, _count = sliding_window_add(
            f"rate_limit:{ip}", self.window_seconds, self.requests_per_minute
        )

        if not allowed:
            # Redis path denied the request.
            return JSONResponse(
                status_code=429,
                content={"detail": "Rate limit exceeded. Try again later."},
            )

        # In-memory fallback (Redis unavailable, OR belt-and-braces second
        # tier alongside Redis). When Redis was unavailable, count this
        # request against the fallback so the Phase 3 metric reflects real
        # Redis trouble.
        now = time.time()
        window_start = now - self.window_seconds
        hits = self.ips.setdefault(ip, [])
        hits[:] = [t for t in hits if t > window_start]
        if len(hits) >= self.requests_per_minute:
            return JSONResponse(
                status_code=429,
                content={"detail": "Rate limit exceeded. Try again later."},
            )
        hits.append(now)

        if not redis_was_available:
            # Count the fallback hit so operators can alert on Redis trouble.
            try:
                increment_redis_down()
            except Exception:  # noqa: BLE001 — never break a request on metric failure
                logger.exception("Failed to increment ratelimit_redis_down_total")

        return await call_next(request)