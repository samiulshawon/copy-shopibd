# Core modules: config, database, security, logging
