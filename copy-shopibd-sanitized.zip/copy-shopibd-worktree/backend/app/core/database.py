from sqlalchemy import create_engine, event
from sqlalchemy.orm import Session, declarative_base, sessionmaker

from app.core.config import settings

engine = create_engine(
    settings.DATABASE_URL,
    pool_pre_ping=True,
)


class ShopibdSession(Session):
    """Session subclass carrying an optional ``_shopibd_role`` attribute so
    the tenant-context hook can discriminate super-admin connections."""


SessionLocal = sessionmaker(
    autocommit=False, autoflush=False, bind=engine, class_=ShopibdSession
)

Base = declarative_base()


# ---------------------------------------------------------------------------
# Per-connection tenant context (Phase 2)
# ---------------------------------------------------------------------------
# On every checkout from the pool, set ``app.current_seller_id`` to whatever
# the request-scoped context var holds.  This is what enables the optional
# RLS policies added in Phase 2 (Task 2.2): they reference
# ``current_setting('app.current_seller_id')`` to filter rows.  Super-admin
# connections set ``app.current_seller_role = 'super_admin'`` and bypass RLS
# via the ``bypassrls`` attribute granted at policy-creation time.

DEFAULT_SELLER_ROLE = "seller"


@event.listens_for(engine, "connect")
def _set_default_tenant_on_connect(dbapi_connection, connection_record):
    """Initialize the tenant GUCs on a brand-new raw DBAPI connection."""
    try:
        with dbapi_connection.cursor() as cursor:
            # initialise so the variable exists even if no auth has happened
            cursor.execute(
                "SELECT set_config('app.current_seller_id', '', false)"
            )
            cursor.execute(
                f"SELECT set_config('app.current_seller_role', '{DEFAULT_SELLER_ROLE}', false)"
            )
        dbapi_connection.commit()
    except Exception:  # noqa: BLE001 — SQLite (tests) doesn't support GUCs
        pass


@event.listens_for(engine, "begin")
def _apply_tenant_context_on_begin(dbapi_connection):
    """At the start of every transaction, push the request-scoped seller id
    into ``app.current_seller_id`` (and the role for super-admins) so the
    optional Phase 2 RLS policies filter rows correctly."""
    try:
        from app.core.context import get_current_seller_id_or_default

        seller_id = get_current_seller_id_or_default(default=0) or 0
        cursor = dbapi_connection.cursor()
        cursor.execute(
            "SELECT set_config('app.current_seller_id', %s, true)",
            (str(seller_id),),
        )
        cursor.execute(
            "SELECT set_config('app.current_seller_role', %s, true)",
            (DEFAULT_SELLER_ROLE,),
        )
        cursor.close()
    except Exception:  # noqa: BLE001 — SQLite (tests) doesn't support GUCs
        # Tests use SQLite via StaticPool; RLS is Postgres-only so safe to
        # ignore.  Production PostgreSQL will succeed.
        pass


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
