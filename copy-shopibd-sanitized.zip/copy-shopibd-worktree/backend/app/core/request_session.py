"""Shared SQLAlchemy session lifecycle for HTTP middleware."""

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

from app.core.database import SessionLocal


class RequestSessionMiddleware(BaseHTTPMiddleware):
    """Create one request-scoped session and close it after the response."""

    async def dispatch(self, request: Request, call_next):
        db = SessionLocal()
        request.state.db = db
        try:
            return await call_next(request)
        finally:
            db.close()
