"""
Structured JSON logging for ShopiBD.

Provides a configured logger that outputs JSON-formatted log records with
request IDs for tracing requests across services.
"""

from __future__ import annotations

import json
import logging
import sys
import uuid
from typing import Any

from fastapi import Request

from app.core.request_context import (
    get_request_id as get_context_request_id,
    set_request_id,
)


# ---------------------------------------------------------------------------
# Custom JSON Formatter
# ---------------------------------------------------------------------------


class JSONFormatter(logging.Formatter):
    """
    Format log records as JSON objects.

    Produces output like:
    {"timestamp": "2025-01-25T10:30:00.123Z", "level": "INFO", "logger": "app", "message": "...", ...}
    """

    def format(self, record: logging.LogRecord) -> str:
        log_entry: dict[str, Any] = {
            "timestamp": self.formatTime(record, "%Y-%m-%dT%H:%M:%S.%fZ"),
            "level": record.levelname,
            "logger": record.name,
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
            "message": record.getMessage(),
        }

        request_id = get_context_request_id()
        if request_id:
            log_entry["request_id"] = request_id

        # Include exception info if present
        if record.exc_info and record.exc_info[0] is not None:
            log_entry["exception"] = self.formatException(record.exc_info)

        # Include extra fields passed to the logger
        for key, value in getattr(record, "extra", {}).items():
            log_entry[key] = value

        return json.dumps(log_entry, default=str)


# ---------------------------------------------------------------------------
# Request ID helpers
# ---------------------------------------------------------------------------


def get_request_id(request: Request) -> str:
    """
    Extract or generate a request ID for tracing.

    Checks the X-Request-ID header first; falls back to generating a new UUID.
    """
    request_id = request.headers.get("X-Request-ID")
    if not request_id:
        request_id = str(uuid.uuid4())
    return request_id


async def add_request_id_middleware(request: Request, call_next):
    """
    FastAPI middleware that attaches a request_id to request.state
    for use in log records throughout the request lifecycle.
    """
    request.state.request_id = get_request_id(request)
    set_request_id(request.state.request_id)
    logger = get_logger(__name__)
    try:
        response = await call_next(request)
        response.headers["X-Request-ID"] = request.state.request_id
        # One access line per request so every request_id is traceable in
        # any log sink (JSON formatter re-adds it from context as well).
        logger.info(
            "%s %s -> %s",
            request.method,
            request.url.path,
            getattr(response, "status_code", 0),
            extra={"request_id": request.state.request_id},
        )
        return response
    finally:
        set_request_id(None)


# ---------------------------------------------------------------------------
# Logger configuration
# ---------------------------------------------------------------------------


def setup_logging(log_level: str = "INFO") -> None:
    """
    Configure the root logger to output JSON-formatted logs.

    Call this once at application startup.

    Args:
        log_level: One of DEBUG, INFO, WARNING, ERROR, CRITICAL.
    """
    root_logger = logging.getLogger()

    # Remove existing handlers
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JSONFormatter())
    root_logger.addHandler(handler)
    root_logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))

    # Silence noisy third-party loggers
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
    logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger with the given name.

    Usage:
        logger = get_logger(__name__)
        logger.info("Order created", extra={"order_id": 123})
    """
    return logging.getLogger(name)
