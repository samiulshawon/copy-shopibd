from typing import Any, List

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    APP_NAME: str = "ShopiBD"
    APP_ENV: str = "development"
    APP_VERSION: str = "0.1.0"
    DEBUG: bool = True

    PROJECT_NAME: str = "ShopiBD"
    VERSION: str = "0.1.0"
    API_V1_STR: str = "/api/v1"

    # Service ports — all configurable so the dev environment works on
    # machines that reserve the default ports (e.g. Windows reserves 3000-3020
    # and 8000 may be shadowed by a stale WSL listener).
    BACKEND_PORT: int = 8000   # API listen port inside the backend container
    FRONTEND_PORT: int = 3001  # Next.js dev port
    DB_PORT: int = 5434        # Postgres mapped from container 5432
    REDIS_PORT: int = 6380     # Redis mapped from container 6379
    MINIO_PORT: int = 9000     # MinIO S3 API
    MINIO_CONSOLE_PORT: int = 9001

    DOMAIN: str = "shopibd.com"

    # When True (or DOMAIN is localhost/127.0.0.1), shop URLs are served via
    # path-based previews (e.g. /shop/<subdomain>) instead of host-based
    # subdomains/custom domains, so the platform works without owning a domain.
    # Set DOMAIN to your real apex (e.g. "shopibd.com") and configure DNS to go live.
    LOCAL_DOMAIN_MODE: bool = False

    # Security — MUST be set via environment. A random default would silently
    # invalidate all issued JWTs on every process restart.
    SECRET_KEY: str
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 8
    ALGORITHM: str = "HS256"
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    RATE_LIMIT_FAIL_CLOSED: bool = False  # when True, deny on Redis outage

    @model_validator(mode="after")
    def _check_required_secrets(self) -> "Settings":
        if not self.SECRET_KEY:
            raise ValueError(
                "SECRET_KEY must be set via environment variable or .env.local. "
                "Generate one with: python -c \"import secrets; print(secrets.token_urlsafe(32))\""
            )
        # Phase 0: nothing to validate yet beyond presence; Phase 1 will add
        # a production-time reject for the dev default secret.
        _DEFAULT_DEV_SECRET = "dev-secret-key-change-in-production-min-32-chars"
        if (
            self.APP_ENV.lower() in ("production", "prod")
            and self.SECRET_KEY == _DEFAULT_DEV_SECRET
        ):
            raise ValueError(
                "SECRET_KEY is the dev default; refusing to start in "
                f"APP_ENV={self.APP_ENV}. Set a unique SECRET_KEY in your "
                "environment or secret store."
            )
        if self.DOMAIN in ("localhost", "127.0.0.1", "localhost:8000"):
            self.LOCAL_DOMAIN_MODE = True
        return self

    # Database — defaults to PostgreSQL (local dev).
    # Override via .env.local or environment variables.
    # PostgreSQL setup: create a database named 'shopibd' on localhost:5434
    # with user 'shopibd' and password 'shopibd'.
    DATABASE_URL: str = "postgresql+psycopg2://shopibd:shopibd@localhost:5434/shopibd"

    # CORS - allow all origins in dev for Docker network compatibility
    BACKEND_CORS_ORIGINS: List[Any] = ["*"]

    # SMS/WhatsApp
    SMS_PROVIDER: str = "mock"
    WHATSAPP_PROVIDER: str = "mock"

    # Admin panel credentials (tenant admin)
    ADMIN_EMAIL: str = "admin@mail.com"
    ADMIN_USERNAME: str = "admin@mail.com"
    ADMIN_PASSWORD: str = "admin123"

    # Phase 9: SQLAdmin (DB admin UI) centralized config. Single source of
    # truth for the /sqladmin Basic-auth gate, session lifetime, and CSRF.
    SQLADMIN_ENABLED: bool = True
    SQLADMIN_USERNAME: str = "admin"
    SQLADMIN_PASSWORD: str = "admin123"
    SQLADMIN_SESSION_TIMEOUT_MINUTES: int = 30
    SQLADMIN_CSRF_SECRET: str = ""

    # Phase 10: courier webhook secrets (HMAC-SHA256 verification)
    STEADFAST_WEBHOOK_SECRET: str = ""

    # Phase 10: payment provider sandbox/integration test scaffolding (R10.1).
    # When *_SANDBOX is True, the provider uses its test/playground endpoint
    # and avoids real charges. Integration tests require these creds or are
    # skipped (marked integration). Real calls are never made unless the
    # caller explicitly opts in via APP_ENV=production + sandbox=False.
    BKASH_SANDBOX: bool = True
    BKASH_APP_KEY: str = ""
    BKASH_APP_SECRET: str = ""
    BKASH_USERNAME: str = ""
    BKASH_PASSWORD: str = ""
    NAGAD_SANDBOX: bool = True
    NAGAD_BASE_URL_SANDBOX: str = "https://sandbox.mynagad.com:10001"
    NAGAD_MERCHANT_ID: str = ""
    NAGAD_MERCHANT_NUMBER: str = ""
    NAGAD_PUB_KEY: str = ""
    NAGAD_PRIVATE_KEY: str = ""
    SSLCOMMERZ_SANDBOX: bool = True
    SSLCOMMERZ_STORE_ID: str = ""
    SSLCOMMERZ_STORE_PASSWORD: str = ""

    # Base URL for callback/webhook URLs
    API_BASE_URL: str = "http://localhost:8000"

    # Frontend URL for redirects
    FRONTEND_URL: str = "http://localhost:4000"

    # Redis
    REDIS_URL: str = ""

    # Observability: when set, /metrics requires "Authorization: Bearer <token>".
    # Leave empty in development; always set behind a reverse proxy in production.
    METRICS_TOKEN: str = ""

    # Subscription billing lifecycle scheduler (seconds between runs)
    SUBSCRIPTION_TASK_INTERVAL_SECONDS: int = 3600

    # Storage (local disk now, S3/MinIO-ready)
    STORAGE_BACKEND: str = "local"          # "local" | "s3"
    MEDIA_ROOT: str = "media"               # relative to backend cwd; served at /media
    MEDIA_URL: str = "/media"
    AWS_S3_BUCKET: str = ""
    AWS_S3_REGION: str = ""
    AWS_S3_ENDPOINT_URL: str = ""           # MinIO compatible
    AWS_ACCESS_KEY_ID: str = ""
    AWS_SECRET_ACCESS_KEY: str = ""

    # Payment
    PAYMENT_PROVIDER: str = "manual"

    # bKash API credentials
    BKASH_APP_KEY: str = ""
    BKASH_APP_SECRET: str = ""
    BKASH_USERNAME: str = ""
    BKASH_PASSWORD: str = ""
    BKASH_BASE_URL: str = "https://tokenized.sandbox.bka.sh/v1.2.0-beta"

    # SSLCommerz credentials
    SSLCOMMERZ_STORE_ID: str = ""
    SSLCOMMERZ_STORE_PASSWORD: str = ""
    SSLCOMMERZ_SANDBOX: bool = True

    # Nagad API credentials
    NAGAD_MERCHANT_ID: str = ""
    NAGAD_PRIVATE_KEY: str = ""
    NAGAD_PUB_KEY: str = ""
    NAGAD_BASE_URL: str = "https://sandbox.mynagad.com:10001"

    # Phase 7 — SSL / ACME provisioning for custom domains
    # "stub" = succeed with a synthetic cert (tests/dev); "certbot" = shell
    # out to the certbot sidecar for real Let's Encrypt certificates.
    SSL_BACKEND: str = "certbot"
    SSL_CERT_DIR: str = "/var/www/ssl"
    CERTBOT_BIN: str = "certbot"
    ACME_EMAIL: str = "admin@shopibd.com"
    ACME_DIRECTORY_URL_STAGING: str = (
        "https://acme-staging-v02.api.letsencrypt.org/directory"
    )
    ACME_DIRECTORY_URL_PROD: str = "https://acme-v02.api.letsencrypt.org/directory"

    model_config = SettingsConfigDict(
        case_sensitive=True,
        env_file=".env.local",
        env_file_encoding="utf-8",
    )


settings = Settings()
