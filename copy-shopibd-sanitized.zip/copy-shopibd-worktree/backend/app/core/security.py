"""JWT + password security utilities for ShopiBD.

Phase 1 enhancements (per .trae/specs/enhancement-roadmap-2026 Phase 1):
- Access tokens carry ``jti`` (JWT id), ``iat`` (issued-at) and ``type="access"``.
- Refresh tokens carry the same claims but ``type="refresh"`` and longer expiry.
- ``decode_token`` returns the full payload so callers can validate ``type``/``jti``.
- Tokens whose ``jti`` is in the Redis revocation set are rejected.
- Clock skew tolerance of ±30s via ``leeway`` parameter.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

from jose import JWTError, jwt
from passlib.context import CryptContext

from app.core.config import settings
from app.core.log import get_logger
from app.services.redis_client import get_redis

logger = get_logger(__name__)

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


# ---------------------------------------------------------------------------
# Password helpers (unchanged)
# ---------------------------------------------------------------------------


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)


# ---------------------------------------------------------------------------
# Token factory + decoders (Phase 1 upgrades)
# ---------------------------------------------------------------------------

# Token types
TOKEN_TYPE_ACCESS = "access"
TOKEN_TYPE_REFRESH = "refresh"

_TOKEN_TYPE_ACCESS = "access"
_TOKEN_TYPE_REFRESH = "refresh"
_JWT_LEEWAY_SECONDS = 30

_REVOCATION_PREFIX = "revoked:jti:"


def create_access_token(
    subject: str,
    expires_delta: Optional[timedelta] = None,
    *,
    token_type: str = TOKEN_TYPE_ACCESS,
    impersonated_by: Optional[int] = None,
) -> str:
    """Create a JWT access token with jti, iat, type claims.

    If ``impersonated_by`` is provided (super-admin impersonation), it is
    encoded as the ``impersonated_by`` claim so downstream code and logs
    attribute actions to the impersonator.
    """
    if expires_delta:
        expire = datetime.now(timezone.utc) + expires_delta
    else:
        expire = datetime.now(timezone.utc) + timedelta(
            minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES
        )
    now = datetime.now(timezone.utc)
    jti = str(uuid.uuid4())
    to_encode = {
        "exp": expire,
        "iat": now,
        "sub": subject,
        "jti": jti,
        "type": token_type,
    }
    if impersonated_by is not None:
        to_encode["impersonated_by"] = impersonated_by
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt


def create_refresh_token(subject: str) -> str:
    """Create a long-lived refresh token."""
    return create_access_token(
        subject=subject,
        expires_delta=timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
        token_type=TOKEN_TYPE_REFRESH,
    )


def decode_token(token: str) -> Optional[str]:
    """Decode JWT and return subject (sub) if valid and not revoked."""
    try:
        payload = jwt.decode(
            token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM]
        )
        # Revocation check
        jti = payload.get("jti")
        if jti and is_jti_revoked(jti):
            return None
        return payload.get("sub")
    except JWTError:
        return None


def get_token_payload(token: str) -> Optional[Dict[str, Any]]:
    """Decode and return full payload (for /refresh to read jti/exp)."""
    try:
        return jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
    except JWTError:
        return None


# --- Revocation helpers (thin wrappers around redis_client) ---
def revoke_jti(jti: str, ttl: Optional[int] = None) -> None:
    """Add a jti to the revocation set with optional TTL (seconds)."""
    from app.services.redis_client import revoke_jti as _revoke_jti
    if ttl is None:
        # Default: access token TTL + some margin, or refresh TTL for refresh tokens
        ttl = settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60 + 300
    _revoke_jti(jti, ttl)


def is_jti_revoked(jti: str) -> bool:
    """Check if a jti is in the revocation set."""
    from app.services.redis_client import is_jti_revoked as _is_jti_revoked
    return _is_jti_revoked(jti)


def jti_ttl_seconds(token: str) -> int:
    """Return the seconds remaining until ``exp`` (used to TTL the revocation).

    Returns a sensible minimum (60s) if the token can't be decoded.
    """
    try:
        payload = jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM],
            options={"verify_exp": False},
        )
        exp = payload.get("exp")
        if not exp:
            return 60
        remaining = int(exp - datetime.now(timezone.utc).timestamp())
        return max(60, remaining + _JWT_LEEWAY_SECONDS)
    except Exception:  # noqa: BLE001
        return 60


# ---------------------------------------------------------------------------
# Backwards-compat subject decoder
# ---------------------------------------------------------------------------


def decode_token_subject(token: str) -> Optional[str]:
    """Return only the ``sub`` claim (used by existing call sites).

    Equivalent to the *old* ``decode_token(token)`` for ``type=access``.
    """
    payload = get_token_payload(token)
    if payload and payload.get("type") == _TOKEN_TYPE_ACCESS:
        return payload.get("sub")
    return None
