"""Request-scoped tenant context for ShopiBD.

Provides a thread-safe context-var that exposes the current authenticated
seller id (when set) and supporting helpers. Consumed by the audit log,
downgrade notifications, and the optional PostgreSQL RLS policy that
keys on ``current_setting('app.current_seller_id')``.

Phase 2 contract:
- ``set_current_seller_id(id_or_none)`` MUST be called by ``get_current_seller``
  (with the verified seller id) or cleared on unauthenticated requests.
- ``get_current_seller_id()`` raises ``LookupError`` if invoked outside a
  request without a fallback — pass ``default=None`` for tolerant access.
"""
from __future__ import annotations

from contextvars import ContextVar
from typing import Optional


_seller_id_var: ContextVar[Optional[int]] = ContextVar(
    "app_current_seller_id", default=None
)


def set_current_seller_id(seller_id: Optional[int]) -> None:
    """Bind the authenticated seller id to this request context."""
    _seller_id_var.set(seller_id)


def get_current_seller_id() -> Optional[int]:
    """Return the authenticated seller id for this request, or None."""
    return _seller_id_var.get()


def get_current_seller_id_or_default(default: Optional[int] = None) -> Optional[int]:
    """Tolerant access: never raises, returns ``default`` when unset."""
    try:
        return _seller_id_var.get()
    except LookupError:  # pragma: no cover — contextvar always has default
        return default
