from typing import Optional

from sqlalchemy import Boolean, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


class Seller(Base):
    __tablename__ = "sellers"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String, nullable=False)
    email: Mapped[str] = mapped_column(String, unique=True, index=True, nullable=False)
    phone: Mapped[str] = mapped_column(String, unique=True, index=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    is_super_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    # Phase 8: explicit staff/admin flag, separate from verified status.
    # ``get_current_admin_seller`` gates on this, not ``is_verified``.
    is_staff: Mapped[bool] = mapped_column(Boolean, default=False)

    # Plan / subscription fields
    plan: Mapped[str] = mapped_column(String, default="free")
    max_products: Mapped[int] = mapped_column(Integer, default=50)
    max_orders: Mapped[int] = mapped_column(Integer, default=200)

    shops: Mapped[list["Shop"]] = relationship("Shop", back_populates="seller")
    staff: Mapped[list["Staff"]] = relationship("Staff", back_populates="seller")
    categories: Mapped[list["Category"]] = relationship("Category", back_populates="seller")
    stock_movements: Mapped[list["StockMovement"]] = relationship("StockMovement", back_populates="seller")
    subscription: Mapped[Optional["Subscription"]] = relationship("Subscription", back_populates="seller", uselist=False)
