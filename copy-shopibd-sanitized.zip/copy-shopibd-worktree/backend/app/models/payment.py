from sqlalchemy import Column, DateTime, Enum, ForeignKey, Integer, Numeric, String, Text, func
from sqlalchemy.orm import relationship

from app.core.database import Base

import enum


class PaymentMethod(str, enum.Enum):
    BKASH = "bkash"
    NAGAD = "nagad"
    ROCKET = "rocket"
    COD = "cod"
    BANK = "bank"


class PaymentStatus(str, enum.Enum):
    PENDING = "pending"
    VERIFIED = "verified"
    MISMATCHED = "mismatched"
    UNMATCHED = "unmatched"


class PaymentTransaction(Base):
    __tablename__ = "payment_transactions"

    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(Integer, ForeignKey("orders.id"), nullable=True, index=True)
    seller_id = Column(Integer, ForeignKey("sellers.id"), nullable=False, index=True)
    shop_id = Column(Integer, ForeignKey("shops.id"), nullable=False, index=True)

    amount = Column(Numeric(10, 2), nullable=False)
    currency = Column(String, default="BDT")

    payment_method = Column(
        Enum(PaymentMethod),
        nullable=False,
    )

    sender_phone = Column(String, nullable=True)
    reference = Column(String, nullable=True, comment="bKash/Nagad transaction ID")

    status = Column(
        Enum(PaymentStatus),
        default=PaymentStatus.PENDING,
        nullable=False,
    )

    matched_order_id = Column(
        Integer, ForeignKey("orders.id"), nullable=True, index=True
    )
    raw_sms_text = Column(Text, nullable=True)

    verified_by = Column(
        String,
        nullable=True,
        comment='"manual" / "sms_parse" / "api"',
    )
    verified_at = Column(DateTime(timezone=True), nullable=True)
    notes = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    # Relationships
    seller = relationship("Seller", backref="payment_transactions")
    shop = relationship("Shop", backref="payment_transactions")
    order = relationship(
        "Order", backref="payment_transactions", foreign_keys=[order_id]
    )
    matched_order = relationship(
        "Order", backref="matched_payments", foreign_keys=[matched_order_id]
    )
