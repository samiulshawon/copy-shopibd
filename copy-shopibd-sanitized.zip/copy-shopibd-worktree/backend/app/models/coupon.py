"""
Coupon / Discount model for ShopiBD.

Each coupon belongs to a seller and optionally to a specific shop.
"""
from datetime import datetime

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    Numeric,
    String,
    Text,
    func,
)
from sqlalchemy.orm import relationship

from app.core.database import Base


class Coupon(Base):
    __tablename__ = "coupons"

    id = Column(Integer, primary_key=True, index=True)
    seller_id = Column(Integer, ForeignKey("sellers.id"), nullable=False)
    shop_id = Column(Integer, ForeignKey("shops.id"), nullable=True)
    code = Column(String(50), nullable=False, index=True)
    discount_type = Column(String(20), nullable=False)  # "percentage" or "fixed"
    discount_value = Column(Numeric(10, 2), nullable=False)
    min_order_amount = Column(Numeric(10, 2), nullable=True)
    max_discount = Column(Numeric(10, 2), nullable=True)  # For percentage type only
    usage_limit = Column(Integer, nullable=True)
    usage_count = Column(Integer, default=0)
    per_customer_limit = Column(Integer, default=1)
    applies_to = Column(String(30), default="all")  # all / specific_products / specific_categories
    product_ids = Column(Text, nullable=True)  # JSON list of product IDs
    category_ids = Column(Text, nullable=True)  # JSON list of category IDs
    is_active = Column(Boolean, default=True)
    starts_at = Column(DateTime(timezone=True), nullable=True)
    expires_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    seller = relationship("Seller")
    shop = relationship("Shop")
    usages = relationship("CouponUsage", back_populates="coupon", cascade="all, delete-orphan")
