from datetime import datetime

from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Integer, String, Text, JSON
from sqlalchemy.orm import relationship

from app.core.database import Base


class Shop(Base):
    __tablename__ = "shops"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    slug = Column(String, unique=True, index=True, nullable=False)
    description = Column(Text, nullable=True)
    logo_url = Column(String, nullable=True)
    banner_url = Column(String, nullable=True)
    contact_phone = Column(String, nullable=False, default="")
    bkash_number = Column(String, nullable=True)
    nagad_number = Column(String, nullable=True)
    rocket_number = Column(String, nullable=True)
    delivery_settings = Column(JSON, nullable=True, default=dict)
    is_active = Column(Boolean, default=True)
    seller_id = Column(Integer, ForeignKey("sellers.id"), nullable=False)

    # White-label / custom domain fields
    custom_domain = Column(String, unique=True, nullable=True)
    subdomain = Column(String, unique=True, nullable=True)
    domain_verified = Column(Boolean, default=False)
    domain_verified_at = Column(DateTime, nullable=True)
    ssl_provisioned = Column(Boolean, default=False)
    branding_settings = Column(JSON, nullable=True)
    hide_branding = Column(Boolean, default=False)

    # Phase 7: ACME SSL provisioning state for the custom domain.
    # ssl_status: "none" | "provisioning" | "provisioned" | "failed" | "expiring"
    ssl_status = Column(String, nullable=False, default="none")
    ssl_expires_at = Column(DateTime, nullable=True)

    # Phase 6: grace window during which a downgraded shop's custom domain
    # keeps routing after losing the capability (e.g. Enterprise -> Business).
    custom_domain_grace_until = Column(DateTime, nullable=True)

    seller = relationship("Seller", back_populates="shops")
    products = relationship("Product", back_populates="shop")
    orders = relationship("Order", back_populates="shop")
    categories = relationship("Category", back_populates="shop")
