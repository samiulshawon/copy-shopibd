"""
Audit log model for ShopiBD.

Tracks all state-changing API calls with actor, action, resource, and timestamp.
"""

from sqlalchemy import JSON as SQLA_JSON
from sqlalchemy import Column, DateTime, ForeignKey, Integer, String, Text, func

from app.core.database import Base


class AuditLog(Base):
    """Record of a state-changing operation for audit/compliance."""

    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    seller_id = Column(Integer, ForeignKey("sellers.id"), nullable=True, index=True)
    actor_email = Column(String, nullable=True, comment="Email of the actor who performed the action")
    action = Column(String, nullable=False, index=True, comment="e.g. order.status_update, product.create, payment.refund")
    entity_type = Column(String, nullable=False, comment="e.g. order, product, payment, shop")
    entity_id = Column(String, nullable=True, comment="String ID of the affected entity")
    old_values = Column(SQLA_JSON, nullable=True, comment="Previous state of the entity (JSON)")
    new_values = Column(SQLA_JSON, nullable=True, comment="New state of the entity (JSON)")
    ip_address = Column(String, nullable=True, comment="Client IP address")
    user_agent = Column(String, nullable=True, comment="Client user-agent string")
    extra_data = Column(SQLA_JSON, nullable=True, comment="Additional context (JSON)")
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False, index=True)

    def __repr__(self) -> str:
        return f"<AuditLog id={self.id} action={self.action} entity={self.entity_type}:{self.entity_id}>"
