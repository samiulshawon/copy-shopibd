import enum

from sqlalchemy import Column, Date, DateTime, Enum, ForeignKey, Integer, Numeric, String, Text, func
from sqlalchemy.orm import relationship

from app.core.database import Base


class CourierName(str, enum.Enum):
    STEADFAST = "steadfast"
    ECOURIER = "ecourier"
    PATHAO = "pathao"
    REDX = "redx"
    MANUAL = "manual"


class ShipmentStatus(str, enum.Enum):
    PENDING = "pending"
    PICKED_UP = "picked_up"
    IN_TRANSIT = "in_transit"
    DELIVERED = "delivered"
    RETURNED = "returned"
    FAILED = "failed"


class Delivery(Base):
    __tablename__ = "deliveries"

    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(Integer, ForeignKey("orders.id"), nullable=False, index=True)
    seller_id = Column(Integer, ForeignKey("sellers.id"), nullable=False, index=True)

    courier_name = Column(Enum(CourierName), nullable=False, default=CourierName.MANUAL)
    tracking_number = Column(String, nullable=True, index=True)
    shipment_status = Column(
        Enum(ShipmentStatus),
        nullable=False,
        default=ShipmentStatus.PENDING,
    )

    pickup_address = Column(Text, nullable=False)
    delivery_address = Column(Text, nullable=False)

    weight_kg = Column(Numeric(10, 3), nullable=True)
    cod_amount = Column(Numeric(10, 2), nullable=True)
    shipping_cost = Column(Numeric(10, 2), nullable=True)

    estimated_delivery_date = Column(Date, nullable=True)
    delivered_at = Column(DateTime(timezone=True), nullable=True)

    notes = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    # Relationships
    order = relationship("Order", back_populates="delivery")
    seller = relationship("Seller", backref="deliveries")
