from fastapi import FastAPI, Request, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse, Response, RedirectResponse
import secrets
from sqlalchemy import select
from sqlalchemy.orm import Session
import asyncio
from contextlib import asynccontextmanager

from app.api.v1 import router as v1_router
from app.core.config import settings
from app.core.log import add_request_id_middleware, get_logger
from app.core.middleware import RateLimitMiddleware
from app.core.request_session import RequestSessionMiddleware
from app.admin.setup import setup_admin
from app.models.shop import Shop
from app.core.database import engine, SessionLocal, get_db
from app.services.subscription_tasks import run_all_subscription_tasks
from app.services.storage import get_storage_service
from app.services.plan_capabilities import can_use_custom_domain
from app.services.metrics import refresh_operational_metrics, render_prometheus
from app.models.scheduler_run import SchedulerRun

from urllib.parse import urlparse

logger = get_logger(__name__)


# Subscription scheduler background task
_subscription_scheduler_task: asyncio.Task | None = None


async def _subscription_scheduler() -> None:
    """Periodically run subscription lifecycle tasks (expiry, rollover, etc.)."""
    while True:
        try:
            await asyncio.sleep(settings.SUBSCRIPTION_TASK_INTERVAL_SECONDS)
            db = SessionLocal()
            try:
                result = run_all_subscription_tasks(db=db)
                logger.info("Subscription scheduler run complete: %s", result)
            except Exception:
                logger.exception("Subscription scheduler task failed")
            finally:
                db.close()
        except asyncio.CancelledError:
            logger.info("Subscription scheduler cancelled")
            break
        except Exception:
            logger.exception("Unexpected error in subscription scheduler loop")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events."""
    global _subscription_scheduler_task

    # Startup

    # Auto-create S3/MinIO bucket on startup
    if settings.STORAGE_BACKEND == "s3":
        from app.services.storage import S3StorageService
        try:
            svc = S3StorageService()
            try:
                svc.client.head_bucket(Bucket=svc.bucket)
                logger.info("S3 bucket '%s' already exists", svc.bucket)
            except Exception:
                svc.client.create_bucket(Bucket=svc.bucket)
                logger.info("S3 bucket '%s' created", svc.bucket)
        except Exception as exc:
            logger.warning("Could not verify/create S3 bucket: %s", exc)

    logger.info("Starting subscription scheduler (interval: %ss)", settings.SUBSCRIPTION_TASK_INTERVAL_SECONDS)
    _subscription_scheduler_task = asyncio.create_task(_subscription_scheduler())
    yield
    # Shutdown
    if _subscription_scheduler_task:
        _subscription_scheduler_task.cancel()
        try:
            await _subscription_scheduler_task
        except asyncio.CancelledError:
            pass
        logger.info("Subscription scheduler stopped")


app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    openapi_url=f"{settings.API_V1_STR}/openapi.json",
    lifespan=lifespan,
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request tracing middleware.
app.middleware("http")(add_request_id_middleware)

# Rate limiting middleware
app.add_middleware(RateLimitMiddleware, requests_per_minute=60)

# Include all v1 routes via the aggregated router
app.include_router(v1_router)

# Serve uploaded media (product images) from local disk when using the
# local storage backend. S3/MinIO serves files directly from the bucket/CDN,
# so no local mount is needed.
if settings.STORAGE_BACKEND == "local":
    import os

    from fastapi.staticfiles import StaticFiles

    media_dir = settings.MEDIA_ROOT
    os.makedirs(media_dir, exist_ok=True)
    app.mount(settings.MEDIA_URL, StaticFiles(directory=media_dir), name="media")


@app.get("/health")
def health_check(db: Session = Depends(get_db)):
    """Report dependency probes and the most recent scheduler outcome."""
    from sqlalchemy import text as sa_text
    from app.services.redis_client import get_redis

    status = "healthy"
    checks = {}
    scheduler = {"last_run": None, "status": "never"}
    try:
        db.execute(sa_text("SELECT 1"))
        checks["database"] = "ok"
        latest_run = db.execute(
            select(SchedulerRun).order_by(SchedulerRun.started_at.desc()).limit(1)
        ).scalar_one_or_none()
        if latest_run:
            scheduler = {
                "last_run": latest_run.finished_at or latest_run.started_at,
                "status": latest_run.status,
            }
    except Exception as exc:
        checks["database"] = str(exc)
        status = "unhealthy"

    if settings.REDIS_URL:
        try:
            redis_client = get_redis()
            if redis_client is None:
                raise RuntimeError("Redis unavailable")
            redis_client.ping()
            checks["redis"] = "ok"
        except Exception as exc:
            checks["redis"] = str(exc)
            if status == "healthy":
                status = "degraded"

    # Phase 7: surface SSL provisioning health for custom domains.
    ssl: dict = {}
    try:
        from app.services.ssl_renewal import ssl_health_summary

        ssl = ssl_health_summary(db)
    except Exception as exc:  # noqa: BLE001
        ssl = {"error": str(exc)}

    return {
        "status": status,
        "checks": checks,
        "scheduler": scheduler,
        "ssl": ssl,
        "version": settings.VERSION,
    }


@app.get("/metrics", include_in_schema=False)
def metrics(request: Request, db: Session = Depends(get_db)):
    """Expose internal Prometheus text metrics for the monitoring network.

    When METRICS_TOKEN is configured, the scraper must present it as
    "Authorization: Bearer <token>" — the endpoint leaks operational detail
    (DB pool, subscription counts) and must not be public in production.
    """
    expected = settings.METRICS_TOKEN
    if expected:
        auth = request.headers.get("authorization", "")
        if not secrets.compare_digest(auth, f"Bearer {expected}"):
            raise HTTPException(status_code=401, detail="Unauthorized")
    refresh_operational_metrics(db)
    return PlainTextResponse(render_prometheus())


# ---------------------------------------------------------------------------
# Custom domain / subdomain routing middleware
# ---------------------------------------------------------------------------
# Reads the Host header from incoming requests and looks up the shop by
# custom domain or subdomain. If a match is found, the request is
# internally "routed" to that shop's storefront by rewriting the path.
# ---------------------------------------------------------------------------


@app.middleware("http")
async def custom_domain_middleware(request: Request, call_next):
    """
    Intercept requests based on the Host header.

    - If the Host matches a shop's ``custom_domain``, serve that shop's
      storefront by redirecting to /shop/<slug>.
    - If the Host matches ``<subdomain>.shopibd.com``, similarly route to
      that shop's storefront.
    - Otherwise pass the request through unchanged.
    """
    host = request.headers.get("host", "").lower().strip()

    # Strip port if present
    if ":" in host:
        host = host.split(":")[0]

    # Determine the base domain from settings (fallback to shopibd.com)
    base_domain = getattr(settings, "DOMAIN", "shopibd.com").lower()

    # Only process requests that are NOT already going to the API or admin
    path = request.url.path
    if (
        path.startswith("/api")
        or path.startswith("/admin")
        or path.startswith("/health")
        or path.startswith("/metrics")
        or path.startswith("/sqladmin")
    ):
        return await call_next(request)

    # Skip if Host is our own base domain or localhost
    if host in (base_domain, "localhost", "127.0.0.1"):
        return await call_next(request)

    # Check if this is a subdomain request (e.g. rina.shopibd.com)
    subdomain = None
    domain_match = None
    if host.endswith(f".{base_domain}"):
        subdomain = host[: -len(f".{base_domain}")]
    else:
        # Treat the host as a potential custom domain
        domain_match = host

    db = request.state.db
    shop = None
    try:
        if subdomain:
            stmt = select(Shop).where(Shop.subdomain == subdomain)
            shop = db.execute(stmt).scalar_one_or_none()
        elif domain_match:
            stmt = select(Shop).where(Shop.custom_domain == domain_match)
            shop = db.execute(stmt).scalar_one_or_none()
            # Edge-check: if the seller's plan no longer permits a custom
            # domain (e.g. downgraded enterprise -> business), stop routing
            # to it. The record is retained but inactive for routing.
            if shop is not None:
                from app.models.seller import Seller as _Seller
                from datetime import datetime as _dt
                seller = db.execute(
                    select(_Seller).where(_Seller.id == shop.seller_id)
                ).scalar_one_or_none()
                if seller is None or not can_use_custom_domain(seller.plan):
                    # Phase 6: honour a 7-day grace window so a downgraded
                    # shop's custom domain keeps routing while the client
                    # is notified and has a chance to upgrade back.
                    grace_until = getattr(shop, "custom_domain_grace_until", None)
                    in_grace = (
                        grace_until is not None
                        and _dt.utcnow() < grace_until
                    )
                    if not in_grace:
                        shop = None

        if shop is not None and shop.is_active:
            # Route to the storefront
            storefront_path = f"/shop/{shop.slug}"
            # Preserve the original path after the domain
            remaining_path = path
            if remaining_path.startswith("/"):
                remaining_path = remaining_path[1:]
            if remaining_path:
                storefront_path += f"/{remaining_path}"

            # Rebuild query string
            query = request.url.query
            if query:
                storefront_path += f"?{query}"

            return RedirectResponse(url=storefront_path)
    finally:
        pass

    return await call_next(request)


@app.middleware("http")
async def storefront_path_middleware(request: Request, call_next):
    """
    In local/test mode, resolve /shop/<key> by subdomain first, then slug,
    so storefronts are reachable without DNS. In production the host-based
    routing in custom_domain_middleware handles subdomains; this is a
    no-op for non-/shop paths and simply passes through.
    """
    path = request.url.path
    if path.startswith("/shop/"):
        key = path[len("/shop/"):].split("/")[0]
        if key:
            db = request.state.db
            try:
                shop = db.execute(
                    select(Shop).where(Shop.subdomain == key)
                ).scalar_one_or_none()
                if shop is None:
                    shop = db.execute(
                        select(Shop).where(Shop.slug == key)
                    ).scalar_one_or_none()
                if shop is not None and shop.is_active:
                    # Already at the canonical storefront path; let it through.
                    return await call_next(request)
            finally:
                pass
    return await call_next(request)


# Phase 9: SQLAdmin access is driven by centralized config (single source of
# truth). Credentials, session timeout, and CSRF all come from settings so
# they can be rotated via env without a code change.
_sqladmin_username = settings.SQLADMIN_USERNAME
_sqladmin_password = settings.SQLADMIN_PASSWORD
_sqladmin_session_timeout = settings.SQLADMIN_SESSION_TIMEOUT_MINUTES * 60


def _sqladmin_csrf_token() -> str:
    """Derive a stable CSRF token for SQLAdmin form posts.

    Falls back to the app SECRET_KEY when ``SQLADMIN_CSRF_SECRET`` is unset
    so the protection is always on without requiring extra configuration.
    """
    import hashlib

    seed = settings.SQLADMIN_CSRF_SECRET or settings.SECRET_KEY
    return hashlib.sha256(f"sqladmin-csrf::{seed}".encode()).hexdigest()


@app.middleware("http")
async def admin_auth_middleware(request: Request, call_next):
    # Guard only the SQLAdmin mount (/sqladmin). The Next.js super-admin
    # frontend is served under /admin/* by a separate origin and must NOT
    # be intercepted by this Basic-auth check.
    if not settings.SQLADMIN_ENABLED and request.url.path.startswith("/sqladmin"):
        return Response(status_code=404, content="SQLAdmin is disabled")

    if request.url.path.startswith("/sqladmin"):
        auth_header = request.headers.get("Authorization")
        if not auth_header or not auth_header.startswith("Basic "):
            return Response(
                status_code=401,
                content="Unauthorized",
                headers={"WWW-Authenticate": "Basic"},
            )
        try:
            import base64
            decoded = base64.b64decode(auth_header[6:]).decode("utf-8")
            username, password = decoded.split(":", 1)
            if not (secrets.compare_digest(username, _sqladmin_username) and
                    secrets.compare_digest(password, _sqladmin_password)):
                raise ValueError("Invalid credentials")
        except Exception:
            return Response(
                status_code=401,
                content="Unauthorized",
                headers={"WWW-Authenticate": "Basic"},
            )

        # Phase 9: CSRF protection for SQLAdmin writes. Two valid paths:
        #   1. Programmatic clients send the X-SQLAdmin-CSRF header matching
        #      _sqladmin_csrf_token().
        #   2. Browser form posts are validated by SAME-ORIGIN (Origin/Referer
        #      host must equal the request Host). Browsers always attach Origin
        #      on cross-site state-changing requests, while non-browser clients
        #      are not susceptible to CSRF at all. Requiring the custom token on
        #      every form post made the SQLAdmin UI write-locked (its own forms
        #      never carry X-SQLAdmin-CSRF).
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            header_token = request.headers.get("X-SQLAdmin-CSRF")
            if not (
                header_token
                and secrets.compare_digest(str(header_token), _sqladmin_csrf_token())
            ):
                request_host = request.headers.get("host", "").split(":")[0].lower()

                def _source_host(header_value: str) -> str:
                    try:
                        return urlparse(header_value).netloc.split(":")[0].lower()
                    except Exception:  # noqa: BLE001
                        return ""

                origin = request.headers.get("origin", "")
                referer = request.headers.get("referer", "")
                source_host = _source_host(origin) or _source_host(referer)
                if source_host != request_host:
                    return Response(
                        status_code=403,
                        content="CSRF check failed: cross-origin form post",
                    )

    response = await call_next(request)

    # Phase 9: apply a session timeout hint via Cache-Control so admin
    # sessions don't outlive the configured window on cached pages.
    if request.url.path.startswith("/sqladmin"):
        response.headers["Cache-Control"] = (
            f"private, max-age=0, must-revalidate, stale-while-revalidate=0"
        )
        response.headers["X-SQLAdmin-Session-Timeout"] = str(_sqladmin_session_timeout)
    return response


setup_admin(app, engine)

# Request-scoped DB session lifecycle. MUST be registered LAST so it sits
# OUTERMOST in Starlette's middleware stack and runs BEFORE the
# @app.middleware("http") handlers defined above (custom_domain /
# storefront_path / admin_auth), which read request.state.db. Registered
# any earlier, those handlers hit AttributeError: 'State' object has no
# attribute 'db' on non-API paths from non-localhost hosts.
app.add_middleware(RequestSessionMiddleware)