from sqladmin import Admin, ModelView
from app.models.seller import Seller
from app.models.shop import Shop
from app.models.subscription import Subscription
from app.models.audit_log import AuditLog


class SellerAdmin(ModelView, model=Seller):
    # Super-admin owned view: client accounts only (hide the owner themselves)
    column_list = [Seller.id, Seller.name, Seller.email, Seller.phone, Seller.plan, Seller.is_active, Seller.is_verified]
    column_searchable_list = [Seller.name, Seller.email, Seller.phone]


class ShopAdmin(ModelView, model=Shop):
    column_list = [Shop.id, Shop.name, Shop.slug, Shop.is_active]
    column_searchable_list = [Shop.name, Shop.slug]


class SubscriptionAdmin(ModelView, model=Subscription):
    column_list = [
        Subscription.id,
        Subscription.seller_id,
        Subscription.plan,
        Subscription.status,
        Subscription.current_period_end,
        Subscription.auto_renew,
    ]
    column_searchable_list = [Subscription.seller_id]


class AuditLogAdmin(ModelView, model=AuditLog):
    column_list = [
        AuditLog.id,
        AuditLog.action,
        AuditLog.entity_type,
        AuditLog.entity_id,
        AuditLog.actor_email,
        AuditLog.created_at,
    ]
    column_searchable_list = [AuditLog.action, AuditLog.entity_type, AuditLog.actor_email]


def setup_admin(app, engine):
    """
    SQLAdmin panel for the platform super admin (product owner).

    Mounted at /sqladmin (NOT /admin) so it does not collide with the
    Next.js super-admin frontend, which is served under /admin/*.

    Only platform-level entities are exposed here. Tenant-operational data
    (Products, Orders, Staff) is intentionally excluded — that belongs to each
    seller's own dashboard, not the super-admin panel.
    """
    admin = Admin(app, engine, base_url="/sqladmin")
    admin.add_view(SellerAdmin)
    admin.add_view(ShopAdmin)
    admin.add_view(SubscriptionAdmin)
    admin.add_view(AuditLogAdmin)
    return admin
