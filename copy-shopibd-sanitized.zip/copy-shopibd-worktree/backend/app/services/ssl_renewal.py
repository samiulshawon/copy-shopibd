"""
Phase 7 — SSL certificate renewal job for ShopiBD.

Renews custom-domain certificates that are within the ``RENEWAL_THRESHOLD_DAYS``
window of expiry. Intended to be invoked by the scheduler (e.g. daily) and by
the ``/health`` probe so operators can see expiring certs.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import SessionLocal
from app.models.shop import Shop
from app.services.domain_verifier import needs_renewal, renew_ssl_cert

logger = logging.getLogger(__name__)

# Renew certs that expire within this many days.
RENEWAL_THRESHOLD_DAYS = 30


def _renew_one(db: Session, shop: Shop) -> dict:
    """Attempt to renew one shop's cert. Returns a summary dict."""
    domain = shop.custom_domain
    if not domain:
        return {"shop_id": shop.id, "skipped": "no custom domain"}

    if not needs_renewal(shop.ssl_expires_at, threshold_days=RENEWAL_THRESHOLD_DAYS):
        return {"shop_id": shop.id, "skipped": "not within threshold"}

    result = renew_ssl_cert(domain)
    if result.success:
        shop.ssl_status = "provisioned"
        shop.ssl_provisioned = True
        shop.ssl_expires_at = result.expires_at
        return {"shop_id": shop.id, "domain": domain, "renewed": True}
    shop.ssl_status = "failed"
    logger.warning(
        "SSL renewal failed for shop %s (%s): %s",
        shop.id,
        domain,
        result.error,
    )
    return {
        "shop_id": shop.id,
        "domain": domain,
        "renewed": False,
        "error": result.error,
    }


def run_ssl_renewal(db: Session | None = None) -> dict:
    """Scan all shops with a custom domain and renew certs < 30 days from expiry."""
    own_session = db is None
    session = db or SessionLocal()
    try:
        shops = (
            session.execute(
                select(Shop).where(Shop.custom_domain.isnot(None))
            )
            .scalars()
            .all()
        )

        renewed = 0
        failed = 0
        skipped = 0
        details: list[dict] = []
        for shop in shops:
            outcome = _renew_one(session, shop)
            details.append(outcome)
            if outcome.get("renewed"):
                renewed += 1
            elif outcome.get("error"):
                failed += 1
            else:
                skipped += 1
        # Always commit: callers that pass a session expect renewal
        # bookkeeping to be persisted immediately.
        session.commit()
        return {
            "checked": len(shops),
            "renewed": renewed,
            "failed": failed,
            "skipped": skipped,
            "checked_at": datetime.now(timezone.utc).isoformat(),
            "details": details,
        }
    finally:
        if own_session:
            session.close()


def ssl_health_summary(db: Session) -> dict:
    """Return a compact SSL summary for the ``/health`` endpoint."""
    shops = (
        db.execute(
            select(Shop).where(Shop.custom_domain.isnot(None))
        )
        .scalars()
        .all()
    )
    total = len(shops)
    provisioned = sum(1 for s in shops if s.ssl_status == "provisioned")
    expiring = sum(
        1
        for s in shops
        if s.ssl_expires_at is not None
        and (s.ssl_expires_at - datetime.utcnow()) <= timedelta(days=RENEWAL_THRESHOLD_DAYS)
    )
    failed = sum(1 for s in shops if s.ssl_status == "failed")
    return {
        "total_custom_domains": total,
        "provisioned": provisioned,
        "expiring_within_30d": expiring,
        "failed": failed,
    }
