"""
Storage service abstraction for ShopiBD.

Provides a backend-agnostic interface for saving and deleting uploaded files.
The default implementation writes to local disk (served via the ``/media``
static route). An S3/MinIO implementation can be enabled via
``STORAGE_BACKEND=s3`` once credentials are configured — the interface is
identical so callers don't change.
"""

import io
import mimetypes
import os
import uuid
from abc import ABC, abstractmethod
from typing import List

import boto3
from botocore.exceptions import ClientError
from fastapi import UploadFile

from app.core.config import settings

# Allowed image extensions and max upload size (5 MB, matching CSV cap).
ALLOWED_EXTENSIONS: set[str] = {".jpg", ".jpeg", ".png", ".webp", ".gif"}
MAX_IMAGE_BYTES = 5 * 1024 * 1024  # 5 MB


class StorageError(Exception):
    """Raised when a file cannot be stored or validated."""


class StorageService(ABC):
    """Abstract storage backend. ``save`` returns a public URL."""

    @abstractmethod
    async def save(self, file: UploadFile, folder: str) -> str:
        ...

    @abstractmethod
    async def delete(self, url: str) -> None:
        ...


def _validate(file: UploadFile) -> str:
    """Validate extension + size; return the lower-cased extension (with dot)."""
    filename = file.filename or ""
    ext = os.path.splitext(filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise StorageError(
            f"Unsupported image type '{ext or 'unknown'}'. "
            f"Allowed: {', '.join(sorted(ALLOWED_EXTENSIONS))}"
        )
    # Read size without consuming the stream for the caller's later use is
    # tricky across backends; we rely on UploadFile.size when available and
    # fall back to a stream peek.
    size = getattr(file, "size", None)
    if size is not None and size > MAX_IMAGE_BYTES:
        raise StorageError("Image exceeds the 5 MB limit.")
    return ext


class LocalStorageService(StorageService):
    """Stores files on local disk under ``MEDIA_ROOT``."""

    def __init__(self) -> None:
        self.root = settings.MEDIA_ROOT
        os.makedirs(self.root, exist_ok=True)

    def _path_for(self, url: str) -> str:
        # url looks like "/media/products/1/uuid.png" -> strip MEDIA_URL prefix
        rel = url
        if rel.startswith(settings.MEDIA_URL):
            rel = rel[len(settings.MEDIA_URL):]
        rel = rel.lstrip("/")
        return os.path.join(self.root, rel)

    async def save(self, file: UploadFile, folder: str) -> str:
        ext = _validate(file)
        dest_dir = os.path.join(self.root, folder)
        os.makedirs(dest_dir, exist_ok=True)

        unique_name = f"{uuid.uuid4().hex}{ext}"
        dest_path = os.path.join(dest_dir, unique_name)

        content = await file.read()
        if len(content) > MAX_IMAGE_BYTES:
            raise StorageError("Image exceeds the 5 MB limit.")
        with open(dest_path, "wb") as f:
            f.write(content)

        # Return a public URL relative to MEDIA_URL
        public_url = f"{settings.MEDIA_URL.rstrip('/')}/{folder}/{unique_name}"
        return public_url.replace("\\", "/")

    async def delete(self, url: str) -> None:
        path = self._path_for(url)
        try:
            if os.path.exists(path):
                os.remove(path)
        except OSError:
            # Best-effort cleanup; ignore missing files.
            pass


class S3StorageService(StorageService):
    """S3/MinIO-backed storage.

    Uses boto3 to upload/delete files. Works with AWS S3 or any S3-compatible
    object store (MinIO, DigitalOcean Spaces, etc.) endpoint.
    """

    def __init__(self) -> None:
        if not settings.AWS_S3_BUCKET:
            raise StorageError(
                "S3 storage selected but AWS_S3_BUCKET is not configured."
            )
        self.bucket = settings.AWS_S3_BUCKET
        self.endpoint_url = settings.AWS_S3_ENDPOINT_URL or None
        self.region = settings.AWS_S3_REGION or None
        self.access_key = settings.AWS_ACCESS_KEY_ID or None
        self.secret_key = settings.AWS_SECRET_ACCESS_KEY or None

        # Build a public URL base — for MinIO this is the endpoint + bucket,
        # for AWS S3 it's the standard virtual-hosted-style URL.
        if self.endpoint_url:
            self.public_url_base = f"{self.endpoint_url.rstrip('/')}/{self.bucket}"
        elif self.region:
            self.public_url_base = (
                f"https://{self.bucket}.s3.{self.region}.amazonaws.com"
            )
        else:
            self.public_url_base = f"https://{self.bucket}.s3.amazonaws.com"

        self.client = boto3.client(
            "s3",
            region_name=self.region,
            endpoint_url=self.endpoint_url,
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key,
        )

    def _url_to_key(self, url: str) -> str:
        """Extract the S3 object key from a public URL."""
        # Strip the public URL base prefix
        prefix = self.public_url_base.rstrip("/") + "/"
        if url.startswith(prefix):
            return url[len(prefix):]
        # Fallback: assume it's just a key
        return url.lstrip("/")

    @staticmethod
    def _get_content_type(ext: str) -> str:
        """Map file extension to MIME type."""
        return mimetypes.types_map.get(ext, "application/octet-stream")

    async def save(self, file: UploadFile, folder: str) -> str:
        ext = _validate(file)
        content = await file.read()
        if len(content) > MAX_IMAGE_BYTES:
            raise StorageError("Image exceeds the 5 MB limit.")

        key = f"{folder}/{uuid.uuid4().hex}{ext}"
        content_type = self._get_content_type(ext)

        try:
            self.client.put_object(
                Bucket=self.bucket,
                Key=key,
                Body=content,
                ContentType=content_type,
                ACL="public-read",
            )
        except ClientError as exc:
            raise StorageError(
                f"Failed to upload to S3/MinIO: {exc}"
            ) from exc

        return f"{self.public_url_base.rstrip('/')}/{key}"

    async def delete(self, url: str) -> None:
        key = self._url_to_key(url)
        try:
            self.client.delete_object(Bucket=self.bucket, Key=key)
        except ClientError:
            # Best-effort cleanup; the object may already be gone
            pass


def get_storage_service() -> StorageService:
    """Return the configured storage backend."""
    backend = (settings.STORAGE_BACKEND or "local").lower()
    if backend == "s3":
        return S3StorageService()
    return LocalStorageService()


__all__: List[str] = [
    "StorageService",
    "LocalStorageService",
    "S3StorageService",
    "get_storage_service",
    "StorageError",
    "ALLOWED_EXTENSIONS",
    "MAX_IMAGE_BYTES",
]
