"""
Subscription periodic tasks for ShopiBD.

Handles subscription renewal, expiry checks, and plan limit updates.
Can be run as a scheduled job (cron, APScheduler, or manual).
"""

from datetime import datetime, timezone
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import SessionLocal
from app.models.scheduler_run import SchedulerRun
from app.models.seller import Seller
from app.models.shop import Shop
from app.models.subscription import Subscription, SubscriptionPlan, SubscriptionStatus
from app.schemas.subscription import PLANS
from app.services.events import publish as publish_event

# Plan ranking used to detect a downgrade (higher number = higher tier).
PLAN_RANK: dict[str, int] = {
    "free": 0,
    "starter": 1,
    "business": 2,
    "enterprise": 3,
}

# How long a downgraded shop keeps custom-domain routing after a downgrade.
DOWNGRADE_GRACE_DAYS = 7


def _is_downgrade(old_plan: str, new_plan: str) -> bool:
    """True when ``new_plan`` is a strictly lower tier than ``old_plan``."""
    return PLAN_RANK.get(new_plan, 0) < PLAN_RANK.get(old_plan, 0)


def _lost_custom_domain(old_plan: str, new_plan: str) -> bool:
    """True if the downgrade removes custom-domain capability."""
    from app.services.plan_capabilities import can_use_custom_domain

    return can_use_custom_domain(old_plan) and not can_use_custom_domain(new_plan)


def record_downgrade(
    db: Session,
    seller: Seller,
    old_plan: str,
    new_plan: str,
    reason: str = "subscription_change",
) -> None:
    """Emit ``subscription.downgraded`` and stamp the shop grace window.

    Called from the expiry task, the cancel endpoint, and the super-admin
    override path whenever the new plan is strictly lower than the old one.
    The grace timestamp lets ``custom_domain_middleware`` keep routing for
    ``DOWNGRADE_GRACE_DAYS`` days even though the plan no longer permits it.
    """
    if not _is_downgrade(old_plan, new_plan):
        return

    shop = db.execute(
        select(Shop).where(Shop.seller_id == seller.id).limit(1)
    ).scalar_one_or_none()

    grace_until: datetime | None = None
    lost_custom_domain = _lost_custom_domain(old_plan, new_plan)
    if shop is not None and lost_custom_domain and shop.custom_domain:
        grace_until = datetime.now(timezone.utc).replace(
            tzinfo=None
        ) + __import__("datetime").timedelta(days=DOWNGRADE_GRACE_DAYS)
        shop.custom_domain_grace_until = grace_until
        db.flush()

    publish_event(
        db,
        "subscription.downgraded",
        {
            "seller_id": seller.id,
            "seller_email": seller.email,
            "old_plan": old_plan,
            "new_plan": new_plan,
            "reason": reason,
            "lost_custom_domain": lost_custom_domain,
            "grace_until": grace_until.isoformat() if grace_until else None,
        },
    )


# ---------------------------------------------------------------------------
# Phase 6.3 — notification subscriber for ``subscription.downgraded``
# ---------------------------------------------------------------------------


def _on_subscription_downgraded(payload: dict) -> None:
    """In-process handler that sends the client a WhatsApp notice.

    Registered below at import time. Failures are logged inside the
    notification helper and never re-raised, so they cannot break the
    downgrade transaction.
    """
    import asyncio

    from app.services.notification import send_subscription_downgrade_notification

    seller_id = payload.get("seller_id")
    if not seller_id:
        return
    from app.core.database import SessionLocal as _SL
    from app.models.seller import Seller as _Seller

    session = _SL()
    try:
        seller = session.get(_Seller, seller_id)
        if seller is None:
            return
        grace_until = payload.get("grace_until")
        try:
            asyncio.get_event_loop().run_until_complete(
                send_subscription_downgrade_notification(
                    seller=seller,
                    old_plan=payload.get("old_plan", ""),
                    new_plan=payload.get("new_plan", ""),
                    grace_until=grace_until,
                    lost_custom_domain=bool(payload.get("lost_custom_domain")),
                )
            )
        except RuntimeError:
            # No running loop in this context — fire-and-forget a task.
            loop = asyncio.new_event_loop()
            try:
                loop.run_until_complete(
                    send_subscription_downgrade_notification(
                        seller=seller,
                        old_plan=payload.get("old_plan", ""),
                        new_plan=payload.get("new_plan", ""),
                        grace_until=grace_until,
                        lost_custom_domain=bool(payload.get("lost_custom_domain")),
                    )
                )
            finally:
                loop.close()
    finally:
        session.close()


from app.services.events import subscribe as _subscribe  # noqa: E402

_subscribe("subscription.downgraded", _on_subscription_downgraded)


def check_and_expire_subscriptions(db: Session) -> dict:
    """
    Check for expired subscriptions and update their status.

    - Subscriptions past their current_period_end are marked as EXPIRED
    - If auto_renew is True and payment method exists, attempt renewal
    - Update seller plan fields to Free plan limits when expired/canceled
    """
    now = datetime.now(timezone.utc)

    # Find active subscriptions that have expired
    expired_subs = db.execute(
        select(Subscription).where(
            Subscription.status == SubscriptionStatus.ACTIVE,
            Subscription.current_period_end.isnot(None),
            Subscription.current_period_end < now,
        )
    ).scalars().all()

    expired_count = 0
    renewed_count = 0

    for sub in expired_subs:
        if sub.auto_renew:
            # TODO: Attempt to charge saved payment method
            # For now, just extend the period (in production, integrate with payment provider)
            sub.current_period_start = now
            from dateutil.relativedelta import relativedelta
            sub.current_period_end = now + relativedelta(months=1)
            renewed_count += 1
        else:
            # Mark as expired and downgrade to free
            old_plan = sub.plan.value if sub.plan else "free"
            sub.status = SubscriptionStatus.EXPIRED
            sub.plan = SubscriptionPlan.FREE
            sub.auto_renew = False

            # Update seller to free plan
            seller = db.execute(
                select(Seller).where(Seller.id == sub.seller_id)
            ).scalar_one_or_none()
            if seller:
                free_plan = PLANS["free"]
                seller.plan = "free"
                seller.max_products = free_plan.max_products
                seller.max_orders = free_plan.max_orders
                record_downgrade(
                    db, seller, old_plan, "free", reason="expired"
                )

            expired_count += 1

    if expired_count > 0 or renewed_count > 0:
        db.commit()

    return {
        "expired": expired_count,
        "renewed": renewed_count,
        "checked_at": now.isoformat(),
    }


def check_past_due_subscriptions(db: Session) -> dict:
    """
    Check for subscriptions that are past due (payment failed).

    - Subscriptions in PAST_DUE status can be retried
    - After grace period, mark as EXPIRED
    """
    # For now, just return status
    # In production, implement retry logic with payment provider
    past_due = db.execute(
        select(Subscription).where(
            Subscription.status == SubscriptionStatus.PAST_DUE,
        )
    ).scalars().all()

    return {
        "past_due_count": len(past_due),
        "checked_at": datetime.now(timezone.utc).isoformat(),
    }


def sync_seller_plan_fields(db: Session) -> dict:
    """
    Sync seller plan fields with their subscription.

    Ensures seller.max_products and seller.max_orders match the current plan.
    """
    sellers = db.execute(select(Seller)).scalars().all()

    synced = 0
    for seller in sellers:
        subscription = db.execute(
            select(Subscription).where(Subscription.seller_id == seller.id)
        ).scalar_one_or_none()

        if subscription and subscription.status == SubscriptionStatus.ACTIVE:
            plan_key = subscription.plan.value if subscription.plan else "free"
        else:
            plan_key = seller.plan or "free"

        plan_info = PLANS.get(plan_key, PLANS["free"])

        if seller.max_products != plan_info.max_products or seller.max_orders != plan_info.max_orders:
            seller.max_products = plan_info.max_products
            seller.max_orders = plan_info.max_orders
            seller.plan = plan_key
            synced += 1

    if synced > 0:
        db.commit()

    return {
        "synced": synced,
        "checked_at": datetime.now(timezone.utc).isoformat(),
    }


def _run_subscription_tasks(db: Session) -> dict:
    results = {}
    results["expire_check"] = check_and_expire_subscriptions(db)
    results["past_due_check"] = check_past_due_subscriptions(db)
    results["sync"] = sync_seller_plan_fields(db)
    return results


def run_all_subscription_tasks(db: Session | None = None) -> dict:
    """Run subscription maintenance tasks and persist the run outcome."""
    own_session = db is None
    session = db or SessionLocal()
    started_at = datetime.now(timezone.utc)
    run = SchedulerRun(status="running", started_at=started_at)
    session.add(run)
    session.flush()

    try:
        results = _run_subscription_tasks(session)
        run.status = "ok"
        run.result = results
        run.finished_at = datetime.now(timezone.utc)
        session.commit()
        return results
    except Exception as exc:
        session.rollback()
        failed_run = SchedulerRun(
            status="error",
            started_at=started_at,
            finished_at=datetime.now(timezone.utc),
            error=str(exc),
        )
        session.add(failed_run)
        session.commit()
        raise
    finally:
        if own_session:
            session.close()