"""
SMS parsing service for ShopiBD Payment Reconciliation.

Parses bKash and Nagad SMS messages to extract transaction details
such as amount, sender phone, transaction ID, and balance.
"""

import re
from typing import Optional


def parse_bkash_sms(sms_text: str) -> Optional[dict]:
    """
    Parse a bKash SMS message.

    Expected format:
        "BDT 1,200 received from 017XXXXXXXX. TrxID: ABC123. Balance: BDT 5,000"

    Returns a dict with keys:
        provider, amount, sender_phone, trx_id, balance, raw_text
    or None if parsing fails.
    """
    if not sms_text:
        return None

    text = sms_text.strip()

    # Extract amount: "BDT 1,200" or "BDT 1200"
    amount_match = re.search(
        r"(?:BDT|TK|টাকা)?\s*([\d,]+(?:\.\d{2})?)\s*(?:received|received|প্রাপ্ত)",
        text,
        re.IGNORECASE,
    )
    if not amount_match:
        # Try simpler pattern: BDT X,XXX
        amount_match = re.search(
            r"BDT\s+([\d,]+(?:\.\d{2})?)", text, re.IGNORECASE
        )

    amount = None
    if amount_match:
        amount_str = amount_match.group(1).replace(",", "")
        try:
            amount = float(amount_str)
        except ValueError:
            amount = None

    # Extract sender phone: 01XXXXXXXXX
    phone_match = re.search(r"(?:from|from|থেকে)\s*(?:\+?88)?(01[3-9]\d{8})", text)
    if not phone_match:
        # Try standalone 11-digit number starting with 01
        phone_match = re.search(r"(01[3-9]\d{8})", text)

    sender_phone = phone_match.group(1) if phone_match else None

    # Extract transaction ID: TrxID: ABC123 or similar
    trx_match = re.search(
        r"(?:TrxID|TRX|Trx|ট্রাআইডি|TrxId)[:\s]*([A-Za-z0-9]+)", text
    )

    trx_id = trx_match.group(1) if trx_match else None

    # Extract balance
    balance_match = re.search(
        r"(?:Balance|balance|ব্যালেন্স)[:\s]*(?:BDT|TK)?\s*([\d,]+(?:\.\d{2})?)",
        text,
        re.IGNORECASE,
    )
    balance = None
    if balance_match:
        balance_str = balance_match.group(1).replace(",", "")
        try:
            balance = float(balance_str)
        except ValueError:
            balance = None

    if not amount and not trx_id:
        return None

    return {
        "provider": "bkash",
        "amount": amount,
        "sender_phone": sender_phone,
        "trx_id": trx_id,
        "balance": balance,
        "raw_text": sms_text,
    }


def parse_nagad_sms(sms_text: str) -> Optional[dict]:
    """
    Parse a Nagad SMS message.

    Expected format:
        "TK 500 received from 017XXXXXXXX. Ref: ABC123. Balance: TK 2000"

    Returns a dict with keys:
        provider, amount, sender_phone, trx_id, balance, raw_text
    or None if parsing fails.
    """
    if not sms_text:
        return None

    text = sms_text.strip()

    # Extract amount
    amount_match = re.search(
        r"(?:TK|টাকা|BDT)?\s*([\d,]+(?:\.\d{2})?)\s*(?:received|received|প্রাপ্ত)",
        text,
        re.IGNORECASE,
    )
    if not amount_match:
        amount_match = re.search(
            r"(?:TK|BDT)\s+([\d,]+(?:\.\d{2})?)", text, re.IGNORECASE
        )

    amount = None
    if amount_match:
        amount_str = amount_match.group(1).replace(",", "")
        try:
            amount = float(amount_str)
        except ValueError:
            amount = None

    # Extract sender phone
    phone_match = re.search(r"(?:from|from|থেকে)\s*(?:\+?88)?(01[3-9]\d{8})", text)
    if not phone_match:
        phone_match = re.search(r"(01[3-9]\d{8})", text)

    sender_phone = phone_match.group(1) if phone_match else None

    # Extract reference / transaction ID
    ref_match = re.search(
        r"(?:Ref|Reference|TrxID|TRX)[:\s]*([A-Za-z0-9]+)", text
    )
    trx_id = ref_match.group(1) if ref_match else None

    # Extract balance
    balance_match = re.search(
        r"(?:Balance|balance|ব্যালেন্স)[:\s]*(?:TK|BDT)?\s*([\d,]+(?:\.\d{2})?)",
        text,
        re.IGNORECASE,
    )
    balance = None
    if balance_match:
        balance_str = balance_match.group(1).replace(",", "")
        try:
            balance = float(balance_str)
        except ValueError:
            balance = None

    if not amount and not trx_id:
        return None

    return {
        "provider": "nagad",
        "amount": amount,
        "sender_phone": sender_phone,
        "trx_id": trx_id,
        "balance": balance,
        "raw_text": sms_text,
    }


def parse_sms(sms_text: str) -> Optional[dict]:
    """
    Detect the payment provider (bKash/Nagad) from the SMS text and
    call the appropriate parser.

    Detection heuristic:
        - Contains "bKash" or "bKash" OR "TrxID" -> bKash
        - Contains "Nagad" or "Nagad" OR "Ref:" (without TrxID) -> Nagad
        - Otherwise try bKash first, then Nagad
    """
    if not sms_text:
        return None

    text_lower = sms_text.lower()

    if "bkash" in text_lower or "bKash" in sms_text:
        return parse_bkash_sms(sms_text)
    elif "nagad" in text_lower or "Nagad" in sms_text:
        return parse_nagad_sms(sms_text)
    elif "trxid" in text_lower:
        return parse_bkash_sms(sms_text)
    elif "ref:" in text_lower:
        return parse_nagad_sms(sms_text)

    # Try both and return the one that produces a better result
    bkash_result = parse_bkash_sms(sms_text)
    if bkash_result and bkash_result.get("amount") and bkash_result.get("trx_id"):
        return bkash_result

    nagad_result = parse_nagad_sms(sms_text)
    if nagad_result and nagad_result.get("amount") and nagad_result.get("trx_id"):
        return nagad_result

    # Return whatever we got
    return bkash_result or nagad_result
