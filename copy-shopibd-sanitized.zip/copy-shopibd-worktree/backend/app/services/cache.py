"""
Caching service for ShopiBD.

Provides a unified interface for caching with Redis when available,
falling back to an in-memory dictionary store for development/testing.
"""

from __future__ import annotations

import json
import time
from typing import Any, Callable, Optional

from app.core.config import settings


# ---------------------------------------------------------------------------
# In-memory store (fallback when Redis is not configured)
# ---------------------------------------------------------------------------

_memory_store: dict[str, tuple[float, str]] = {}  # {key: (expires_at, value_json)}


def _get_from_memory(key: str) -> Optional[str]:
    """Get a value from the in-memory store if not expired."""
    entry = _memory_store.get(key)
    if entry is None:
        return None
    expires_at, value = entry
    if expires_at is not None and time.time() > expires_at:
        del _memory_store[key]
        return None
    return value


def _set_in_memory(key: str, value: str, ttl: Optional[int] = None) -> None:
    """Set a value in the in-memory store with optional TTL (seconds)."""
    expires_at = (time.time() + ttl) if ttl is not None else None
    _memory_store[key] = (expires_at, value)


def _invalidate_memory(key: str) -> None:
    """Remove a key from the in-memory store."""
    _memory_store.pop(key, None)


def _invalidate_pattern_memory(pattern: str) -> None:
    """Remove all keys matching a glob-style pattern."""
    import fnmatch
    keys_to_delete = [k for k in _memory_store if fnmatch.fnmatch(k, pattern)]
    for k in keys_to_delete:
        _memory_store.pop(k, None)


# ---------------------------------------------------------------------------
# Redis-based store (used when REDIS_URL is set)
# ---------------------------------------------------------------------------

_redis_client: Optional[Any] = None


def _get_redis_client() -> Optional[Any]:
    """Lazy-init Redis client if REDIS_URL is configured."""
    global _redis_client
    if _redis_client is None:
        redis_url = getattr(settings, "REDIS_URL", None)
        if redis_url:
            try:
                import redis.asyncio as aioredis
                _redis_client = aioredis.from_url(redis_url, decode_responses=True)
            except ImportError:
                pass  # Fall back to memory store
    return _redis_client


async def get_cached(key: str) -> Optional[str]:
    """
    Retrieve a cached value by key.

    Returns the value as a string, or None if not found / expired.
    """
    client = _get_redis_client()
    if client is not None:
        try:
            return await client.get(key)
        except Exception:
            return _get_from_memory(key)
    return _get_from_memory(key)


async def set_cached(key: str, value: str, ttl: Optional[int] = None) -> None:
    """
    Store a value in the cache.

    Args:
        key: Cache key.
        value: Value to store (string).
        ttl: Time-to-live in seconds. If None, the value never expires.
    """
    client = _get_redis_client()
    if client is not None:
        try:
            if ttl is not None:
                await client.setex(key, ttl, value)
            else:
                await client.set(key, value)
            return
        except Exception:
            _set_in_memory(key, value, ttl)
    _set_in_memory(key, value, ttl)


async def invalidate(key: str) -> None:
    """Remove a specific key from the cache."""
    client = _get_redis_client()
    if client is not None:
        try:
            await client.delete(key)
            return
        except Exception:
            _invalidate_memory(key)
    _invalidate_memory(key)


async def invalidate_pattern(pattern: str) -> None:
    """
    Remove all keys matching a glob-style pattern.

    Example: ``invalidate_pattern("product:*")`` clears all product cache keys.
    """
    client = _get_redis_client()
    if client is not None:
        try:
            cursor = 0
            while True:
                cursor, keys = await client.scan(cursor=cursor, match=pattern, count=100)
                if keys:
                    await client.delete(*keys)
                if cursor == 0:
                    break
            return
        except Exception:
            _invalidate_pattern_memory(pattern)
    _invalidate_pattern_memory(pattern)


async def get_or_set(
    key: str,
    factory: Callable[[], Any],
    ttl: Optional[int] = None,
    serialize: Callable[[Any], str] = json.dumps,
    deserialize: Callable[[str], Any] = json.loads,
) -> Any:
    """
    Get a cached value, or compute and cache it if missing.

    Args:
        key: Cache key.
        factory: Callable that returns the value to cache.
        ttl: TTL in seconds.
        serialize: Function to convert value to string for storage.
        deserialize: Function to convert stored string back to value.

    Returns:
        The cached or freshly-computed value.
    """
    cached = await get_cached(key)
    if cached is not None:
        try:
            return deserialize(cached)
        except (json.JSONDecodeError, TypeError, ValueError):
            return cached

    value = factory()
    serialized = serialize(value) if not isinstance(value, str) else value
    await set_cached(key, serialized, ttl)
    return value
