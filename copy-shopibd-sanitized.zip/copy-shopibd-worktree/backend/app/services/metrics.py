"""Process-local Prometheus-compatible observability metrics."""
from __future__ import annotations

import threading
from typing import Dict, List

_lock = threading.Lock()
_registry: Dict[str, "_Metric"] = {}


class _Metric:
    kind = "untyped"

    def __init__(self, name: str, help_text: str):
        self.name = name
        self.help = help_text
        with _lock:
            _registry[name] = self

    def _description(self) -> str:
        return f"# HELP {self.name} {self.help}\n# TYPE {self.name} {self.kind}"

    def render(self) -> List[str]:
        raise NotImplementedError


class Counter(_Metric):
    kind = "counter"

    def __init__(self, name: str, help_text: str):
        super().__init__(name, help_text)
        self._value = 0.0

    def inc(self, amount: float = 1.0) -> None:
        with _lock:
            self._value += amount

    def value(self) -> float:
        return self._value

    def reset(self) -> None:
        with _lock:
            self._value = 0.0

    def render(self) -> List[str]:
        return [self._description(), f"{self.name} {self._value}"]


class Gauge(Counter):
    kind = "gauge"

    def set(self, value: float) -> None:
        with _lock:
            self._value = float(value)

    def dec(self, amount: float = 1.0) -> None:
        self.inc(-amount)


RATELIMIT_REDIS_DOWN_TOTAL = Counter(
    "ratelimit_redis_down_total",
    "Rate-limit requests served by the in-process fallback because Redis was unavailable.",
)
SHOPIBD_REDIS_HITS_TOTAL = Counter("shopibd_redis_hits_total", "Successful Redis operations.")
SHOPIBD_REDIS_MISSES_TOTAL = Counter("shopibd_redis_misses_total", "Unavailable or failed Redis operations.")
SHOPIBD_DB_POOL_CHECKED_OUT = Gauge("shopibd_db_pool_checked_out", "Database connections checked out from the pool.")
SHOPIBD_SUBDOMAINS_TOTAL = Gauge("shopibd_subdomains_total", "Active shops with a subdomain.")
SHOPIBD_CUSTOM_DOMAINS_TOTAL = Gauge("shopibd_custom_domains_total", "Active shops with a custom domain.")
SHOPIBD_ACTIVE_SUBSCRIPTIONS_TOTAL = Gauge("shopibd_active_subscriptions_total", "Active subscriptions.")


def increment_redis_down(amount: float = 1.0) -> None:
    RATELIMIT_REDIS_DOWN_TOTAL.inc(amount)


def refresh_operational_metrics(db) -> None:
    """Refresh gauges that are derived from current database state."""
    from sqlalchemy import func, select
    from app.models.shop import Shop
    from app.models.subscription import Subscription, SubscriptionStatus

    bind = db.get_bind()
    pool = getattr(bind, "pool", None)
    if pool is not None and hasattr(pool, "checkedout"):
        SHOPIBD_DB_POOL_CHECKED_OUT.set(pool.checkedout())
    SHOPIBD_SUBDOMAINS_TOTAL.set(
        db.scalar(select(func.count()).select_from(Shop).where(Shop.is_active.is_(True), Shop.subdomain.isnot(None))) or 0
    )
    SHOPIBD_CUSTOM_DOMAINS_TOTAL.set(
        db.scalar(select(func.count()).select_from(Shop).where(Shop.is_active.is_(True), Shop.custom_domain.isnot(None))) or 0
    )
    SHOPIBD_ACTIVE_SUBSCRIPTIONS_TOTAL.set(
        db.scalar(select(func.count()).select_from(Subscription).where(Subscription.status == SubscriptionStatus.ACTIVE)) or 0
    )


def render_prometheus() -> str:
    with _lock:
        metrics = list(_registry.values())
    lines: List[str] = []
    for metric in metrics:
        lines.extend(metric.render())
    return "\n".join(lines) + "\n"


def reset_all() -> None:
    # Snapshot first: Counter.reset() re-acquires _lock, and threading.Lock
    # is non-reentrant, so resetting while holding the lock would deadlock.
    with _lock:
        metrics = list(_registry.values())
    for metric in metrics:
        metric.reset()


def get_counter(name: str) -> Counter:
    metric = _registry.get(name)
    if metric is None or not isinstance(metric, Counter):
        raise KeyError(name)
    return metric
