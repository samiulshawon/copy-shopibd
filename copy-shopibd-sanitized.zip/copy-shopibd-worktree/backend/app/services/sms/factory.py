from app.core.config import settings
from app.services.sms.base import SMSServiceBase
from app.services.sms.mock import MockSMSService


def get_sms_service() -> SMSServiceBase:
    provider = settings.SMS_PROVIDER
    
    if provider == "mock":
        return MockSMSService()
    
    # Future providers: twilio, nexmo, etc.
    return MockSMSService()