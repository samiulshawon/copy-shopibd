import re
from app.services.sms.base import SMSServiceBase


class MockSMSService(SMSServiceBase):
    async def send_sms(self, to: str, message: str) -> bool:
        # Mock implementation - just log the message
        print(f"[MOCK SMS] To: {to}, Message: {message}")
        return True

    def validate_phone(self, phone: str) -> bool:
        # Basic Bangladesh phone validation
        pattern = r"^01[0-9]{9}$"
        return bool(re.match(pattern, phone))