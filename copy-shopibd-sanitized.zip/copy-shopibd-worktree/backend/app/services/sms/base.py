from abc import ABC, abstractmethod


class SMSServiceBase(ABC):
    @abstractmethod
    async def send_sms(self, to: str, message: str) -> bool:
        pass

    @abstractmethod
    def validate_phone(self, phone: str) -> bool:
        pass