"""
Subscription Payment Service for ShopiBD.

Handles creating subscription payments and activating subscriptions after
payment confirmation.
"""

from datetime import datetime, timezone
from decimal import Decimal
from typing import Optional

from dateutil.relativedelta import relativedelta
from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.seller import Seller
from app.models.shop import Shop
from app.models.subscription import Subscription, SubscriptionPlan, SubscriptionStatus
from app.services.payment.factory import get_payment_verifier


async def create_subscription_payment(
    db: Session,
    seller: Seller,
    subscription: Subscription,
    return_url: Optional[str] = None,
) -> dict:
    """
    Create a subscription payment with the configured payment provider.

    Args:
        db: Database session
        seller: The seller subscribing
        subscription: The subscription record (should be in TRIALING status)
        return_url: Optional URL to redirect after payment

    Returns:
        dict with 'payment_url', 'payment_id', 'payment_method', 'amount'
    """
    if subscription.status != SubscriptionStatus.TRIALING:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Subscription is not in trialing status: {subscription.status.value}",
        )

    plan_key = subscription.plan.value if subscription.plan else "free"
    if plan_key == "free":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot create payment for free plan",
        )

    # Get plan pricing from PLANS
    from app.schemas.subscription import PLANS
    plan_info = PLANS.get(plan_key)
    if not plan_info:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unknown plan: {plan_key}",
        )

    amount_bdt = plan_info.price_bdt
    if amount_bdt <= 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid plan price",
        )

    # Get seller's shop for context
    shop = db.execute(
        select(Shop).where(Shop.seller_id == seller.id)
    ).scalar_one_or_none()

    if not shop:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Seller must have a shop to subscribe",
        )

    # Create order number for this subscription payment
    subscription_order_number = f"SUB-{seller.id}-{int(datetime.now(timezone.utc).timestamp())}"

    # Get payment provider — prefer the gateway chosen by the seller at plan selection
    provider_name = subscription.payment_gateway or settings.PAYMENT_PROVIDER
    if provider_name == "manual":
        # For manual, we just return a mock URL
        return {
            "payment_url": f"{settings.FRONTEND_URL}/dashboard/subscription?manual=true&plan={plan_key}",
            "payment_id": subscription_order_number,
            "payment_method": "manual",
            "amount": int(amount_bdt),
        }

    # Get the appropriate payment provider for the chosen gateway
    provider = get_payment_verifier(provider_name)

    # Build callback URL
    callback_url = return_url or f"{settings.API_BASE_URL}/api/v1/payment-webhook/subscription"

    try:
        # Create payment with the provider
        result = await provider.create_payment(
            order_id=subscription_order_number,
            amount=int(amount_bdt),
            callback_url=callback_url,
        )

        # Store the payment gateway subscription ID
        subscription.payment_gateway_subscription_id = result.get("paymentID") or result.get("payment_ref_id") or subscription_order_number
        subscription.payment_gateway = provider_name
        db.commit()

        return {
            "payment_url": result.get("payment_url"),
            "payment_id": result.get("paymentID") or result.get("payment_ref_id") or subscription_order_number,
            "payment_method": provider_name,
            "amount": int(amount_bdt),
        }

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create subscription payment: {str(e)}",
        )


async def activate_subscription(
    db: Session,
    seller_id: int,
    plan_key: str,
    payment_gateway: str,
    payment_gateway_subscription_id: str,
    auto_renew: bool = True,
) -> Subscription:
    """
    Activate a subscription after successful payment.

    Called from payment webhook after payment is verified.

    Args:
        db: Database session
        seller_id: The seller's ID
        plan_key: The plan that was purchased
        payment_gateway: The payment provider used (bkash, nagad, sslcommerz, manual)
        payment_gateway_subscription_id: The payment gateway's subscription/transaction ID
        auto_renew: Whether to enable auto-renewal

    Returns:
        The activated Subscription object
    """
    from app.schemas.subscription import PLANS

    seller = db.execute(
        select(Seller).where(Seller.id == seller_id)
    ).scalar_one_or_none()

    if not seller:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Seller not found",
        )

    # Find or create subscription
    subscription = db.execute(
        select(Subscription).where(Subscription.seller_id == seller_id)
    ).scalar_one_or_none()

    if subscription is None:
        subscription = Subscription(
            seller_id=seller_id,
            plan=SubscriptionPlan(plan_key),
            status=SubscriptionStatus.TRIALING,
            current_period_start=datetime.now(timezone.utc),
            auto_renew=auto_renew,
        )
        db.add(subscription)
        db.flush()

    # Update subscription with activation details
    subscription.plan = SubscriptionPlan(plan_key)
    subscription.status = SubscriptionStatus.ACTIVE
    subscription.payment_gateway = payment_gateway
    subscription.payment_gateway_subscription_id = payment_gateway_subscription_id
    subscription.auto_renew = auto_renew
    subscription.current_period_start = datetime.now(timezone.utc)

    # Set period end (1 month from now)
    from dateutil.relativedelta import relativedelta
    subscription.current_period_end = datetime.now(timezone.utc) + relativedelta(months=1)

    # Update seller's plan fields for limit enforcement
    plan_info = PLANS.get(plan_key, PLANS["free"])
    seller.plan = plan_key
    seller.max_products = plan_info.max_products
    seller.max_orders = plan_info.max_orders

    db.commit()
    db.refresh(subscription)

    return subscription