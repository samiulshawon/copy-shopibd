"""Build reachable storefront URLs for a shop in either local or live mode."""
from app.core.config import settings
from app.models.shop import Shop


def shop_preview_url(shop: Shop, base_url: str | None = None) -> str:
    """
    Return a URL where the shop storefront can be opened.

    - Local mode (LOCAL_DOMAIN_MODE or DOMAIN is localhost): path-based
      ``/shop/<subdomain>`` (falls back to slug if no subdomain).
    - Live mode: host-based ``https://<subdomain>.<DOMAIN>`` or
      ``https://<custom_domain>`` when set.
    """
    local = settings.LOCAL_DOMAIN_MODE or settings.DOMAIN in (
        "localhost", "127.0.0.1",
    )
    key = shop.subdomain or shop.slug
    if local:
        prefix = (base_url or "").rstrip("/")
        return f"{prefix}/shop/{key}"
    if shop.custom_domain:
        return f"https://{shop.custom_domain}"
    return f"https://{shop.subdomain}.{settings.DOMAIN}"
