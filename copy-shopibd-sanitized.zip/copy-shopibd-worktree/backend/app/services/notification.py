"""
WhatsApp notification service for ShopiBD.

Provides helper functions that compose Bangla messages and dispatch
them via the configured WhatsApp provider.
"""

import logging

from app.models.order import Order, OrderItem
from app.models.product import Product
from app.models.seller import Seller
from app.models.shop import Shop
from app.services.whatsapp.factory import get_whatsapp_service

logger = logging.getLogger(__name__)


def _format_items(items: list[OrderItem]) -> str:
    """Return a multi-line Bangla summary of order items."""
    if not items:
        return ""
    lines: list[str] = []
    for item in items:
        lines.append(
            f"   - {item.product_name} × {item.quantity} = ৳{float(item.subtotal):.2f}"
        )
    return "\n".join(lines)


async def send_order_confirmation_to_buyer(order: Order, shop: Shop) -> None:
    """
    Send a WhatsApp message to the buyer confirming their order.

    Args:
        order: The newly created order.
        shop: The shop from which the order was placed.
    """
    try:
        service = get_whatsapp_service()
        to = order.customer_phone

        # Normalise phone: remove leading +880, keep 01xxxxxxxxx
        if to.startswith("+880"):
            to = "0" + to[4:]

        items = order.items or []
        items_text = _format_items(items)

        message = (
            f"✅ অর্ডার নিশ্চিতকরণ — {shop.name}\n"
            f"\n"
            f"অর্ডার নং: {order.order_number}\n"
            f"প্রিয় গ্রাহক {order.customer_name},\n"
            f"আপনার অর্ডারটি সফলভাবে গ্রহণ করা হয়েছে।\n"
            f"\n"
            f"-------- অর্ডার বিবরণ --------\n"
            f"{items_text}\n"
            f"\n"
            f"মোট মূল্য: ৳{float(order.total_amount):.2f}\n"
            f"পরিশোধের অবস্থা: {order.payment_status}\n"
            f"ঠিকানা: {order.customer_address}\n"
            f"\n"
            f"দোকানের যোগাযোগ: {shop.contact_phone or 'N/A'}\n"
            f"বিকাশ: {shop.bkash_number or 'N/A'} | নগদ: {shop.nagad_number or 'N/A'}\n"
            f"\n"
            f"অর্ডার ট্র্যাক করতে ভিজিট করুন: https://shopibd.com\n"
            f"ধন্যবাদ 🙏"
        )

        await service.send_message(to, message)
    except Exception as exc:
        logger.error(
            "Failed to send order confirmation to buyer %s for order %s: %s",
            order.customer_phone,
            order.order_number,
            exc,
        )


async def send_new_order_alert_to_seller(order: Order, shop: Shop) -> None:
    """
    Send a WhatsApp alert to the seller about a new order.

    Args:
        order: The newly created order.
        shop: The shop that received the order.
    """
    try:
        service = get_whatsapp_service()
        seller: Seller = shop.seller
        if not seller or not seller.phone:
            logger.warning(
                "Seller phone not available for shop %s (id=%d)", shop.name, shop.id
            )
            return

        to = seller.phone
        if to.startswith("+880"):
            to = "0" + to[4:]

        items = order.items or []
        items_text = _format_items(items)

        message = (
            f"🆕 নতুন অর্ডার এসেছে!\n"
            f"\n"
            f"অর্ডার নং: {order.order_number}\n"
            f"গ্রাহক: {order.customer_name}\n"
            f"ফোন: {order.customer_phone}\n"
            f"\n"
            f"-------- পণ্য বিবরণ --------\n"
            f"{items_text}\n"
            f"\n"
            f"মোট মূল্য: ৳{float(order.total_amount):.2f}\n"
            f"পরিশোধের অবস্থা: {order.payment_status}\n"
            f"গ্রাহকের ঠিকানা: {order.customer_address}\n"
            f"\n"
            f"অনুগ্রহ করে অর্ডারটি যাচাই করুন এবং স্ট্যাটাস আপডেট করুন।"
        )

        await service.send_message(to, message)
    except Exception as exc:
        logger.error(
            "Failed to send new order alert to seller %s for order %s: %s",
            seller.phone if seller else "unknown",
            order.order_number,
            exc,
        )


async def send_status_update_notification(order: Order, shop: Shop) -> None:
    """
    Notify the buyer when their order status changes.

    Args:
        order: The order whose status changed.
        shop: The shop fulfilling the order.
    """
    try:
        service = get_whatsapp_service()
        to = order.customer_phone
        if to.startswith("+880"):
            to = "0" + to[4:]

        status_emoji_map = {
            "pending": "⏳",
            "confirmed": "✅",
            "shipped": "🚚",
            "delivered": "📦",
            "cancelled": "❌",
        }
        emoji = status_emoji_map.get(order.status, "ℹ️")

        status_bn = {
            "pending": "অপেক্ষমাণ",
            "confirmed": "নিশ্চিত করা হয়েছে",
            "shipped": "পাঠানো হয়েছে",
            "delivered": "ডেলিভারি সম্পন্ন",
            "cancelled": "বাতিল করা হয়েছে",
        }
        status_bn_text = status_bn.get(order.status, order.status)

        message = (
            f"{emoji} অর্ডার স্ট্যাটাস আপডেট\n"
            f"\n"
            f"প্রিয় {order.customer_name},\n"
            f"আপনার অর্ডার {order.order_number}-এর স্ট্যাটাস পরিবর্তন হয়েছে:\n"
            f"\n"
            f"বর্তমান স্ট্যাটাস: {status_bn_text}\n"
            f"\n"
            f"-------- অর্ডার বিবরণ --------\n"
            f"মোট মূল্য: ৳{float(order.total_amount):.2f}\n"
            f"দোকান: {shop.name}\n"
            f"দোকানের ফোন: {shop.contact_phone or 'N/A'}\n"
            f"\n"
            f"আপনার অর্ডার ট্র্যাক করুন: https://shopibd.com\n"
            f"ধন্যবাদ 🙏"
        )

        await service.send_message(to, message)
    except Exception as exc:
        logger.error(
            "Failed to send status update to buyer %s for order %s: %s",
            order.customer_phone,
            order.order_number,
            exc,
        )


async def send_low_stock_alert(seller: Seller, product: Product) -> None:
    """
    Send a WhatsApp alert to the seller when a product's stock is low.

    Args:
        seller: The seller who owns the product.
        product: The product with low stock.
    """
    try:
        service = get_whatsapp_service()
        if not seller.phone:
            logger.warning(
                "Seller phone not available for alert (seller id=%d)", seller.id
            )
            return

        to = seller.phone
        if to.startswith("+880"):
            to = "0" + to[4:]

        message = (
            f"⚠️ স্টক কমেছে — {product.name}\n"
            f"\n"
            f"প্রিয় বিক্রেতা,\n"
            f"\n"
            f"পণ্য: {product.name}\n"
            f"বর্তমান স্টক: {product.stock} ইউনিট\n"
            f"\n"
            f"অনুগ্রহ করে শীঘ্রই স্টক যোগ করুন।\n"
            f"প্রয়োজনে নতুন অর্ডার দিন বা সরবরাহকারীর সাথে যোগাযোগ করুন।\n"
            f"\n"
            f"— ShopiBD"
        )

        await service.send_message(to, message)
    except Exception as exc:
        logger.error(
            "Failed to send low stock alert to seller %s for product %s: %s",
            seller.phone,
            product.name,
            exc,
        )


async def send_subscription_downgrade_notification(
    seller: Seller,
    old_plan: str,
    new_plan: str,
    grace_until=None,
    lost_custom_domain: bool = False,
) -> None:
    """
    Notify a client that their subscription was downgraded.

    Phase 6 — fired by the ``subscription.downgraded`` event handler. Uses
    the configured WhatsApp provider and degrades gracefully if the phone
    is unavailable so a notification failure never breaks the downgrade
    flow.
    """
    try:
        service = get_whatsapp_service()
        if not seller.phone:
            logger.warning(
                "Seller phone not available for downgrade notice (seller id=%d)",
                seller.id,
            )
            return

        to = seller.phone
        if to.startswith("+880"):
            to = "0" + to[4:]

        plan_bn = {
            "free": "ফ্রি",
            "starter": "স্টার্টার",
            "business": "বিজনেস",
            "enterprise": "এন্টারপ্রাইজ",
        }
        old_bn = plan_bn.get(old_plan, old_plan)
        new_bn = plan_bn.get(new_plan, new_plan)

        grace_line = ""
        if grace_until is not None:
            try:
                grace_date = grace_until if hasattr(grace_until, "date") else __import__("datetime").datetime.fromisoformat(str(grace_until))
                grace_line = (
                    f"\nআপনার কাস্টম ডোমেইন আরও {7} দিন কাজ করবে (গ্রেস শেষ {grace_date.date()})।\n"
                )
            except Exception:  # noqa: BLE001
                pass

        domain_line = ""
        if lost_custom_domain:
            domain_line = "⚠️ কাস্টম ডোমেইন সুবিধা এই প্ল্যানে নেই।\n"

        message = (
            f"📉 সাবস্ক্রিপশন পরিবর্তন\n"
            f"\n"
            f"প্রিয় {seller.name},\n"
            f"আপনার প্ল্যান পরিবর্তন হয়েছে:\n"
            f"{old_bn} → {new_bn}\n"
            f"\n"
            f"{domain_line}"
            f"{grace_line}"
            f"আবার আপগ্রেড করতে ড্যাশবোর্ডে লগইন করুন।\n"
            f"\n"
            f"— ShopiBD"
        )

        await service.send_message(to, message)
    except Exception as exc:
        logger.error(
            "Failed to send downgrade notice to seller %s: %s",
            getattr(seller, "phone", None),
            exc,
        )
