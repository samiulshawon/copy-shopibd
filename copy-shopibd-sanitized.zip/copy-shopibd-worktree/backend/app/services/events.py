"""
Lightweight event bus for ShopiBD.

Phase 6 introduces the ``subscription.downgraded`` event. We use a durable
DB outbox so events survive restarts and can be consumed idempotently,
without adding a hard dependency on Redis Streams (which may be down —
see Phase 3 fallback). Publishers append a row to ``event_outbox`` and a
worker (or the publishing transaction itself) dispatches to in-process
subscribers. Redis pub/sub is used opportunistically for fan-out when
available.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any, Callable, Optional

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import Base
from app.core.log import get_logger
from app.services.redis_client import get_redis

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Outbox model (declared here so the bus is self-contained; migration adds
# the table alongside the Shop grace-period column in p6_downgrade_grace).
# ---------------------------------------------------------------------------


try:
    from sqlalchemy import Column, DateTime, Integer, String, Text, func
except Exception:  # pragma: no cover
    pass


class EventOutbox(Base):
    """Append-only outbox row for domain events."""

    __tablename__ = "event_outbox"

    id = Column(Integer, primary_key=True, index=True)
    event_type = Column(String(80), nullable=False, index=True)
    payload = Column(Text, nullable=False)  # JSON-encoded
    created_at = Column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    processed_at = Column(DateTime(timezone=True), nullable=True)


# ---------------------------------------------------------------------------
# In-process subscribers (registered at import / startup)
# ---------------------------------------------------------------------------

_subscribers: dict[str, list[Callable[[dict], None]]] = {}


def subscribe(event_type: str, handler: Callable[[dict], None]) -> None:
    """Register an in-process handler for ``event_type``."""
    _subscribers.setdefault(event_type, []).append(handler)


def _dispatch_inprocess(event_type: str, payload: dict) -> None:
    for handler in _subscribers.get(event_type, []):
        try:
            handler(payload)
        except Exception:  # noqa: BLE001 — never let one handler break others
            logger.exception("Event handler for %s failed", event_type)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def publish(db: Session, event_type: str, payload: dict) -> EventOutbox:
    """Persist ``event_type`` to the outbox and dispatch in-process.

    Redis pub/sub is attempted opportunistically; failures are logged and
    swallowed because the outbox is the source of truth.
    """
    row = EventOutbox(
        event_type=event_type,
        payload=json.dumps(payload, default=str),
    )
    db.add(row)
    db.flush()
    _dispatch_inprocess(event_type, payload)
    try:
        redis_client = get_redis()
        if redis_client is not None:
            redis_client.publish(
                f"events:{event_type}", json.dumps(payload, default=str)
            )
    except Exception:  # noqa: BLE001
        logger.warning("Redis pub/sub for %s failed (non-fatal)", event_type)
    return row


def unread_events(db: Session, event_type: Optional[str] = None) -> list[EventOutbox]:
    """Return unprocessed outbox rows (for a worker replay loop)."""
    stmt = select(EventOutbox).where(EventOutbox.processed_at.is_(None))
    if event_type:
        stmt = stmt.where(EventOutbox.event_type == event_type)
    return list(db.execute(stmt.order_by(EventOutbox.id.asc()).limit(100)).scalars().all())


def mark_processed(db: Session, event_id: int) -> None:
    row = db.get(EventOutbox, event_id)
    if row is not None:
        row.processed_at = datetime.now(timezone.utc)
        db.commit()


def parse_payload(row: EventOutbox) -> dict[str, Any]:
    return json.loads(row.payload) if row.payload else {}
