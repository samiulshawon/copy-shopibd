"""Plan capability checks — single source of truth for URL entitlements."""
import re
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.schemas.subscription import PLANS


def _plan_info(plan: str):
    return PLANS.get(str(plan).lower())


def can_use_subdomain(plan: str) -> bool:
    info = _plan_info(plan)
    return bool(info and info.allow_subdomain)


def can_use_custom_domain(plan: str) -> bool:
    info = _plan_info(plan)
    return bool(info and info.allow_custom_domain)


def slugify_base(text: str) -> str:
    """Lowercase, trim, replace non-alphanumerics with single hyphens."""
    s = text.lower().strip()
    s = re.sub(r"[^a-z0-9]+", "-", s)
    return s.strip("-") or "shop"


def reserve_subdomain(db: Session, base: str, max_len: int = 40) -> str:
    """
    Return a unique subdomain derived from ``base``.

    Tries ``slugify_base(base)``, then ``base-2``, ``base-3`` … until an
    unused subdomain is found (avoids unique-constraint collisions on
    concurrent creates).
    """
    from app.models.shop import Shop

    candidate = slugify_base(base)[:max_len]
    if not candidate:
        candidate = "shop"
    n = 2
    while True:
        existing = db.execute(
            select(Shop).where(Shop.subdomain == candidate)
        ).scalar_one_or_none()
        if existing is None:
            return candidate
        suffix = f"-{n}"
        candidate = (slugify_base(base)[: max_len - len(suffix)]) + suffix
        n += 1
