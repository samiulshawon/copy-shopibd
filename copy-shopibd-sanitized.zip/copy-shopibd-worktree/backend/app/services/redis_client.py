"""Thin Redis client wrapper with graceful degradation.

Redis is optional. When ``settings.REDIS_URL`` is empty or Redis is
unreachable, all helpers return ``None`` / fall back so callers can use an
in-memory alternative. This lets the platform run in local dev and CI
without Redis, while using Redis for shared state in production.
"""
from typing import List, Optional, Tuple

import redis

from app.core.config import settings
from app.core.log import get_logger

logger = get_logger(__name__)

_client: Optional["redis.Redis"] = None
_checked: bool = False


def get_redis() -> Optional["redis.Redis"]:
    """Return a connected Redis client, or ``None`` if unavailable.

    The connection is lazy and cached. Any connection error returns ``None``
    without raising so callers can fall back to in-memory state.
    """
    global _client, _checked
    if _checked:
        return _client

    _checked = True
    if not settings.REDIS_URL:
        return None

    try:
        _client = redis.Redis.from_url(
            settings.REDIS_URL,
            decode_responses=True,
            socket_connect_timeout=2,
            socket_timeout=2,
        )
        # Probe the connection.
        _client.ping()
    except Exception as exc:  # noqa: BLE001 - degrade gracefully
        logger.warning("Redis unavailable, falling back to in-memory: %s", exc)
        _client = None
    return _client


def is_redis_available() -> bool:
    """Return ``True`` if a working Redis connection is available."""
    return get_redis() is not None


def reset_client() -> None:
    """Reset the cached client (used in tests or config reload)."""
    global _client, _checked
    _client = None
    _checked = False


def sliding_window_count(key: str, window_seconds: int) -> int:
    """Count entries for ``key`` within the last ``window_seconds``.

    Uses a Redis sorted set with timestamps as scores. Returns 0 when Redis
    is unavailable (caller should use its own in-memory fallback).
    """
    r = get_redis()
    if r is None:
        return 0

    now = __import__("time").time()
    cutoff = now - window_seconds
    try:
        # Drop expired entries, then count what remains.
        r.zremrangebyscore(key, 0, cutoff)
        return int(r.zcard(key))
    except Exception:  # noqa: BLE001
        return 0


def sliding_window_add(key: str, window_seconds: int, max_entries: int) -> Tuple[bool, int]:
    """Add an entry to the sliding window and report if it is allowed.

    Returns ``(allowed, current_count)``. ``allowed`` is ``False`` when the
    count would exceed ``max_entries``. When Redis is unavailable, always
    returns ``(True, 0)`` so callers fall back to their own limiter.
    """
    r = get_redis()
    if r is None:
        return True, 0

    now = __import__("time").time()
    cutoff = now - window_seconds
    try:
        pipe = r.pipeline()
        pipe.zremrangebyscore(key, 0, cutoff)
        pipe.zadd(key, {str(now): now})
        pipe.zcard(key)
        pipe.expire(key, window_seconds)
        _, _, count, _ = pipe.execute()
        count = int(count)
        allowed = count <= max_entries
        return allowed, count
    except Exception:  # noqa: BLE001
        return True, 0


def revoke_jti(jti: str, ttl: int) -> None:
    """Add a jti to the revoked set with TTL (seconds)."""
    r = get_redis()
    if r is None:
        # If Redis is down, we can't persist revocation. Log warning.
        logger.warning("Redis unavailable; cannot revoke jti %s", jti)
        return
    try:
        r.setex(f"revoked_jti:{jti}", ttl, "1")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to revoke jti %s: %s", jti, exc)


def is_jti_revoked(jti: str) -> bool:
    """Return True if jti is in the revoked set."""
    r = get_redis()
    if r is None:
        return False
    try:
        return r.exists(f"revoked_jti:{jti}") > 0
    except Exception:  # noqa: BLE001
        return False
