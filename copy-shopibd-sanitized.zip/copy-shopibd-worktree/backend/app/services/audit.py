"""
Audit logging service for ShopiBD.

Provides a convenience function to create AuditLog records from anywhere
in the application (API endpoints, background tasks, etc.).
"""

from __future__ import annotations

import json
from typing import Any, Optional

from sqlalchemy.orm import Session

from app.models.audit_log import AuditLog


def log_action(
    db: Session,
    action: str,
    entity_type: str,
    entity_id: Optional[str] = None,
    seller_id: Optional[int] = None,
    actor_email: Optional[str] = None,
    old_values: Optional[dict[str, Any] | str] = None,
    new_values: Optional[dict[str, Any] | str] = None,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None,
    extra_data: Optional[dict[str, Any]] = None,
) -> AuditLog:
    """
    Create an audit log entry.

    Args:
        db: SQLAlchemy session.
        action: Short description of the action (e.g. 'order.status_update').
        entity_type: Type of entity affected (e.g. 'order', 'product').
        entity_id: String identifier of the entity.
        seller_id: ID of the seller who performed the action (nullable for system actions).
        actor_email: Email of the actor.
        old_values: Previous state as dict or JSON string.
        new_values: New state as dict or JSON string.
        ip_address: Client IP address.
        user_agent: Client user-agent string.
        metadata: Additional context dict.

    Returns:
        The created AuditLog instance.
    """
    # Serialize dict values to JSON if needed
    if isinstance(old_values, dict):
        old_values = json.dumps(old_values)
    if isinstance(new_values, dict):
        new_values = json.dumps(new_values)

    entry = AuditLog(
        seller_id=seller_id,
        actor_email=actor_email,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        old_values=old_values,
        new_values=new_values,
        ip_address=ip_address,
        user_agent=user_agent,
        extra_data=extra_data,
    )
    db.add(entry)
    db.flush()  # Don't commit — caller manages transaction
    return entry
