"""
Invoice/PDF generation service for ShopiBD.

Generates downloadable PDF invoices for orders using reportlab.
"""

from __future__ import annotations

import io
from datetime import datetime, timezone

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm, cm
from reportlab.platypus import (
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from app.models.order import Order, OrderItem
from app.models.shop import Shop


def generate_invoice_pdf(order: Order, shop: Shop) -> bytes:
    """
    Generate a PDF invoice for the given order.

    Returns the PDF as raw bytes, ready for an HTTP response.
    """
    buf = io.BytesIO()

    doc = SimpleDocTemplate(
        buf,
        pagesize=A4,
        topMargin=2 * cm,
        bottomMargin=2 * cm,
        leftMargin=2 * cm,
        rightMargin=2 * cm,
    )

    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(
        name="InvoiceTitle",
        fontSize=22,
        leading=26,
        spaceAfter=6,
        textColor=colors.HexColor("#1a1a2e"),
        fontName="Helvetica-Bold",
    ))
    styles.add(ParagraphStyle(
        name="SectionHeader",
        fontSize=10,
        leading=14,
        spaceBefore=14,
        spaceAfter=4,
        textColor=colors.HexColor("#555555"),
        fontName="Helvetica-Bold",
    ))
    styles.add(ParagraphStyle(
        name="BodySmall",
        fontSize=9,
        leading=13,
        textColor=colors.HexColor("#333333"),
        fontName="Helvetica",
    ))

    elements: list = []

    # ── Header ────────────────────────────────────────────────────────
    elements.append(Paragraph("INVOICE", styles["InvoiceTitle"]))
    elements.append(Spacer(1, 2 * mm))

    # ── Shop / Seller info ────────────────────────────────────────────
    shop_lines = [
        f"<b>{shop.name}</b>",
    ]
    if shop.description:
        shop_lines.append(shop.description)
    if shop.contact_phone:
        shop_lines.append(f"Phone: {shop.contact_phone}")
    elements.append(Paragraph("<br/>".join(shop_lines), styles["BodySmall"]))
    elements.append(Spacer(1, 6 * mm))

    # ── Invoice meta table ────────────────────────────────────────────
    created = order.created_at
    date_str = created.strftime("%d %b %Y, %I:%M %p") if created else "N/A"

    meta_data = [
        ["Invoice #", f"INV-{order.order_number}"],
        ["Order #", order.order_number],
        ["Date", date_str],
        ["Payment Status", order.payment_status.upper()],
        ["Order Status", order.status.upper()],
    ]
    meta_table = Table(meta_data, colWidths=[100, 280])
    meta_table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("TEXTCOLOR", (0, 0), (0, -1), colors.HexColor("#555555")),
        ("TEXTCOLOR", (1, 0), (1, -1), colors.HexColor("#333333")),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"),
    ]))
    elements.append(meta_table)
    elements.append(Spacer(1, 4 * mm))

    # ── Buyer info ────────────────────────────────────────────────────
    elements.append(Paragraph("BILL TO", styles["SectionHeader"]))
    buyer_lines = [
        f"<b>{order.customer_name}</b>",
        order.customer_phone,
        order.customer_address,
    ]
    elements.append(Paragraph("<br/>".join(buyer_lines), styles["BodySmall"]))
    elements.append(Spacer(1, 6 * mm))

    # ── Line items table ──────────────────────────────────────────────
    elements.append(Paragraph("ORDER ITEMS", styles["SectionHeader"]))
    elements.append(Spacer(1, 2 * mm))

    header = [["#", "Product", "Qty", "Unit Price", "Total"]]
    rows = []
    for i, item in enumerate(order.items or [], start=1):
        rows.append([
            str(i),
            item.product_name,
            str(item.quantity),
            f"৳{float(item.unit_price):,.2f}",
            f"৳{float(item.subtotal):,.2f}",
        ])

    line_table = Table(
        header + rows,
        colWidths=[24, 200, 40, 70, 70],
    )
    line_table.setStyle(TableStyle([
        # Header row
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a1a2e")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, 0), 9),
        # Body rows
        ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 1), (-1, -1), 9),
        ("ALIGN", (2, 1), (-1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        # Grid
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cccccc")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f9f9f9")]),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    elements.append(line_table)
    elements.append(Spacer(1, 6 * mm))

    # ── Totals ────────────────────────────────────────────────────────
    total = float(order.total_amount)
    total_data = [
        ["Subtotal", f"৳{total:,.2f}"],
        ["Total", f"৳{total:,.2f}"],
    ]
    total_table = Table(total_data, colWidths=[380, 70])
    total_table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (0, -1), "Helvetica"),
        ("FONTNAME", (1, 0), (1, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("LINEABOVE", (0, -1), (-1, -1), 1, colors.HexColor("#1a1a2e")),
        ("FONTNAME", (0, -1), (0, -1), "Helvetica-Bold"),
    ]))
    elements.append(total_table)

    # ── Payment method ────────────────────────────────────────────────
    if order.payment_method:
        elements.append(Spacer(1, 4 * mm))
        elements.append(Paragraph(
            f"Payment Method: <b>{order.payment_method.upper()}</b>",
            styles["BodySmall"],
        ))

    # ── Footer ────────────────────────────────────────────────────────
    elements.append(Spacer(1, 15 * mm))
    elements.append(Paragraph(
        f"Generated by ShopiBD on {datetime.now(timezone.utc).strftime('%d %b %Y at %I:%M %p')}",
        ParagraphStyle(
            "Footer",
            fontSize=8,
            leading=10,
            textColor=colors.HexColor("#999999"),
            fontName="Helvetica",
            alignment=1,  # center
        ),
    ))

    # Build PDF
    doc.build(elements)
    return buf.getvalue()
