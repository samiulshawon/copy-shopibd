"""
Abstract base class for courier service integrations.

Each courier provider (Steadfast, eCourier, Pathao, Redx, manual)
must implement the abstract methods defined here.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict


class CourierError(Exception):
    """Raised when a courier API call fails."""

    def __init__(self, message: str, status_code: int = 500):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)


class CourierService(ABC):
    """Abstract interface for courier delivery providers."""

    @abstractmethod
    def create_shipment(self, order: Any, pickup_address: str, **kwargs) -> Dict[str, Any]:
        """
        Create a shipment for the given order.

        Args:
            order: The Order model instance.
            pickup_address: Pickup location address.
            **kwargs: Additional provider-specific options (weight, cod_amount, etc.).

        Returns:
            dict with at least:
                - tracking_number (str)
                - estimated_delivery_date (str | None)
                - shipping_cost (float | None)
        """
        ...

    @abstractmethod
    def get_tracking_status(self, tracking_number: str) -> Dict[str, Any]:
        """
        Retrieve the current tracking status from the courier.

        Args:
            tracking_number: The courier's tracking identifier.

        Returns:
            dict with at least:
                - status (str) — normalised to: pending/picked_up/in_transit/delivered/returned/failed
                - delivery_date (str | None)
                - location (str | None)
                - details (str | None)
        """
        ...

    @abstractmethod
    def cancel_shipment(self, tracking_number: str) -> bool:
        """
        Request cancellation of a shipment.

        Args:
            tracking_number: The courier's tracking identifier.

        Returns:
            True if cancellation was successful.
        """
        ...
