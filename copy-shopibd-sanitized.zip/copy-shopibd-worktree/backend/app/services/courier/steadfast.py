"""
Steadfast Courier API integration for ShopiBD.

API documentation: https://steadfast.com.bd/api/v1
"""

import logging
from datetime import date, datetime
from typing import Any, Dict, Optional

import requests

from app.core.config import settings
from app.services.courier.base import CourierError, CourierService

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration helpers
# ---------------------------------------------------------------------------

STEADFAST_BASE_URL = "https://portal.steadfast.com.bd/api/v1"


def _get_api_key() -> str:
    """Return the Steadfast API key from settings."""
    return getattr(settings, "STEADFAST_API_KEY", "")


def _get_secret_key() -> str:
    """Return the Steadfast secret key from settings."""
    return getattr(settings, "STEADFAST_SECRET_KEY", "")


def _headers() -> Dict[str, str]:
    """Build the required authentication headers for Steadfast API."""
    return {
        "Api-Key": _get_api_key(),
        "Secret-Key": _get_secret_key(),
        "Content-Type": "application/json",
    }


# ---------------------------------------------------------------------------
# Error handling helper
# ---------------------------------------------------------------------------


def _raise_on_error(response: requests.Response) -> None:
    """Check the response and raise CourierError on failure."""
    if response.status_code >= 400:
        try:
            detail = response.json()
        except Exception:
            detail = response.text
        raise CourierError(
            message=f"Steadfast API error ({response.status_code}): {detail}",
            status_code=response.status_code,
        )


# ---------------------------------------------------------------------------
# Service implementation
# ---------------------------------------------------------------------------


class SteadfastCourierService(CourierService):
    """Courier service that integrates with the Steadfast API."""

    def create_shipment(
        self, order: Any, pickup_address: str, **kwargs
    ) -> Dict[str, Any]:
        """
        Create an order/shipment in Steadfast.

        Expected Steadfast POST /create_order payload:
            - invoice (order_number)
            - recipient_name
            - recipient_phone
            - recipient_address
            - cod_amount
            - note
            - weight (optional)
        """
        payload = {
            "invoice": order.order_number,
            "recipient_name": order.customer_name,
            "recipient_phone": order.customer_phone,
            "recipient_address": order.customer_address,
            "cod_amount": kwargs.get("cod_amount", 0) or float(order.total_amount),
            "note": getattr(order, "notes", "") or "",
        }

        weight = kwargs.get("weight_kg")
        if weight is not None:
            payload["weight"] = float(weight)

        logger.info("Creating Steadfast shipment for order %s", order.order_number)

        try:
            resp = requests.post(
                f"{STEADFAST_BASE_URL}/create_order",
                json=payload,
                headers=_headers(),
                timeout=30,
            )
            _raise_on_error(resp)
            data = resp.json()
        except requests.RequestException as exc:
            raise CourierError(f"Steadfast connection error: {exc}") from exc

        tracking_number = data.get("tracking_code") or data.get("consignment_id", "")

        return {
            "tracking_number": str(tracking_number),
            "estimated_delivery_date": data.get("expected_delivery"),
            "shipping_cost": data.get("delivery_charge"),
        }

    def get_tracking_status(self, tracking_number: str) -> Dict[str, Any]:
        """
        Retrieve tracking status from Steadfast.

        Uses GET /status_by_invoice/:invoice or /status_by_consignment/:id.
        """
        logger.info("Checking Steadfast status for tracking %s", tracking_number)

        try:
            resp = requests.get(
                f"{STEADFAST_BASE_URL}/status_by_invoice/{tracking_number}",
                headers=_headers(),
                timeout=30,
            )
            if resp.status_code == 404:
                # Try consignment-based lookup
                resp = requests.get(
                    f"{STEADFAST_BASE_URL}/status_by_consignment/{tracking_number}",
                    headers=_headers(),
                    timeout=30,
                )

            _raise_on_error(resp)
            data = resp.json()
        except requests.RequestException as exc:
            raise CourierError(f"Steadfast connection error: {exc}") from exc

        # Normalise Steadfast statuses to our enum
        steadfast_status = (data.get("status") or "").lower()
        normalised = self._normalise_status(steadfast_status)

        return {
            "status": normalised,
            "delivery_date": data.get("delivery_date"),
            "location": data.get("current_location"),
            "details": data.get("status_note", data.get("delivery_status", "")),
        }

    def cancel_shipment(self, tracking_number: str) -> bool:
        """
        Cancel a shipment in Steadfast.

        Typically a POST to /cancel_order with the invoice/consignment ID.
        """
        logger.info("Cancelling Steadfast shipment %s", tracking_number)

        try:
            resp = requests.post(
                f"{STEADFAST_BASE_URL}/cancel_order",
                json={"invoice": tracking_number},
                headers=_headers(),
                timeout=30,
            )
            _raise_on_error(resp)
            data = resp.json()
            return data.get("status", "").lower() == "success"
        except requests.RequestException as exc:
            raise CourierError(f"Steadfast connection error: {exc}") from exc

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # Webhook signature verification (Phase 10.2, R10.2)
    # ------------------------------------------------------------------

    @staticmethod
    def verify_webhook_signature(payload: bytes, signature: str) -> bool:
        """Verify the HMAC-SHA256 signature of an inbound webhook.

        Steadfast signs webhooks with ``HMAC-SHA256(secret_key, raw_body)``
        (hex). Verifying prevents spoofed shipment-status updates. When no
        secret key is configured (dev/tests), verification is skipped and the
        call returns ``True`` so local flows still work.
        """
        secret = getattr(settings, "STEADFAST_WEBHOOK_SECRET", "") or _get_secret_key()
        if not secret:
            return True
        import hashlib
        import hmac

        expected = hmac.new(
            secret.encode("utf-8"), payload, hashlib.sha256
        ).hexdigest()
        return hmac.compare_digest(expected, (signature or "").strip())

    @staticmethod
    def _normalise_status(steadfast_status: str) -> str:
        """Map Steadfast status strings to our ShipmentStatus values."""
        mapping = {
            "pending": "pending",
            "pending_for_pickup": "pending",
            "pickup_assigned": "picked_up",
            "picked": "picked_up",
            "picked_up": "picked_up",
            "in_transit": "in_transit",
            "transit": "in_transit",
            "delivered": "delivered",
            "delivered_success": "delivered",
            "returned": "returned",
            "return_to_seller": "returned",
            "cancelled": "failed",
            "cancel": "failed",
            "failed_delivery": "failed",
            "failed": "failed",
        }
        return mapping.get(steadfast_status, "pending")
