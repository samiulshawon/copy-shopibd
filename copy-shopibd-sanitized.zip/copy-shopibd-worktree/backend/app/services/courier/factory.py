"""
Courier service factory.

Returns the appropriate CourierService implementation based on
the courier name string.  Falls back to a manual courier that
generates a local tracking number without calling any external API.
"""

import logging
from typing import Optional

from app.services.courier.base import CourierService
from app.services.courier.steadfast import SteadfastCourierService

logger = logging.getLogger(__name__)


class ManualCourierService(CourierService):
    """
    Manual / offline courier implementation.

    Generates a local tracking number and simulates status tracking
    without integrating with any real courier API.
    """

    def create_shipment(self, order, pickup_address: str, **kwargs) -> dict:
        tracking_number = f"SHOPIBD-{order.id}-{order.order_number}"
        return {
            "tracking_number": tracking_number,
            "estimated_delivery_date": None,
            "shipping_cost": None,
        }

    def get_tracking_status(self, tracking_number: str) -> dict:
        return {
            "status": "pending",
            "delivery_date": None,
            "location": None,
            "details": "Manual courier – tracking information is not available.",
        }

    def cancel_shipment(self, tracking_number: str) -> bool:
        return True


# ---------------------------------------------------------------------------
# Registry of available courier services
# ---------------------------------------------------------------------------

_COURIER_REGISTRY: dict[str, type[CourierService]] = {
    "steadfast": SteadfastCourierService,
    "ecourier": SteadfastCourierService,  # placeholder – same shape
    "pathao": SteadfastCourierService,    # placeholder – same shape
    "redx": SteadfastCourierService,      # placeholder – same shape
    "manual": ManualCourierService,
}


def get_courier_service(courier_name: Optional[str] = None) -> CourierService:
    """
    Return a ``CourierService`` instance for the given courier name.

    Args:
        courier_name: One of ``steadfast``, ``ecourier``, ``pathao``,
                      ``redx``, or ``manual``.  Defaults to ``manual``.

    Returns:
        An instantiated courier service.
    """
    name = (courier_name or "manual").lower()
    cls = _COURIER_REGISTRY.get(name)

    if cls is None:
        logger.warning(
            "Unknown courier '%s', falling back to manual courier.", name
        )
        cls = ManualCourierService

    logger.info("Using courier service: %s", cls.__name__)
    return cls()
