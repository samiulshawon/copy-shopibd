"""
Plan limit enforcement service for ShopiBD.

Provides utilities to check and enforce subscription plan limits
for products and orders.
"""

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.models.product import Product
from app.models.order import Order
from app.models.seller import Seller
from app.schemas.subscription import PLANS


class PlanLimitExceeded(HTTPException):
    """Exception raised when a plan limit is exceeded."""

    def __init__(self, limit_type: str, limit: int, current: int, plan_name: str, upgrade_url: str = "/dashboard/subscription"):
        self.limit_type = limit_type
        self.limit = limit
        self.current = current
        self.plan_name = plan_name
        self.upgrade_url = upgrade_url

        detail = {
            "error": "plan_limit_exceeded",
            "message": f"Your {plan_name} plan allows a maximum of {limit} {limit_type}. You currently have {current}.",
            "limit_type": limit_type,
            "limit": limit,
            "current": current,
            "plan": plan_name,
            "upgrade_url": upgrade_url,
        }
        super().__init__(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail=detail,
            headers={"X-Upgrade-Required": "true"},
        )


def _get_current_plan(seller: Seller) -> str:
    """Get the current plan ID for a seller."""
    # Check subscription first
    if seller.subscription and seller.subscription.plan:
        return seller.subscription.plan.value
    # Fall back to seller.plan field
    return seller.plan or "free"


def _get_plan_limits(seller: Seller):
    """Get the PlanInfo for the seller's current plan."""
    plan_id = _get_current_plan(seller)
    return PLANS.get(plan_id, PLANS["free"])


def check_product_limit(db: Session, seller: Seller) -> None:
    """
    Check if the seller can create another product.

    Raises PlanLimitExceeded (402) if the product limit is reached.
    """
    plan_info = _get_plan_limits(seller)

    # Count active products across all seller's shops
    current_count = (
        db.query(Product)
        .join(Product.shop)
        .filter(Product.shop.has(seller_id=seller.id), Product.is_active == True)
        .count()
    )

    if current_count >= plan_info.max_products:
        raise PlanLimitExceeded(
            limit_type="products",
            limit=plan_info.max_products,
            current=current_count,
            plan_name=plan_info.name,
        )


def check_bulk_product_limit(db: Session, seller: Seller, additional_count: int) -> None:
    """
    Check if the seller can create multiple additional products.

    Raises PlanLimitExceeded (402) if the product limit would be exceeded.
    """
    plan_info = _get_plan_limits(seller)

    current_count = (
        db.query(Product)
        .join(Product.shop)
        .filter(Product.shop.has(seller_id=seller.id), Product.is_active == True)
        .count()
    )

    if current_count + additional_count > plan_info.max_products:
        raise PlanLimitExceeded(
            limit_type="products",
            limit=plan_info.max_products,
            current=current_count + additional_count,
            plan_name=plan_info.name,
        )


def get_current_product_count(db: Session, seller: Seller) -> int:
    """Return the number of active products the seller currently has."""
    return (
        db.query(Product)
        .join(Product.shop)
        .filter(Product.shop.has(seller_id=seller.id), Product.is_active == True)
        .count()
    )


def get_current_order_count(
    db: Session, seller: Seller, subscription: "Subscription | None" = None
) -> int:
    """
    Return the number of orders in the seller's current billing period.

    Uses the subscription's current_period_start/end when present, otherwise
    falls back to the current calendar month. Mirrors ``check_order_limit``.
    """
    from datetime import datetime, timezone

    if subscription and subscription.current_period_start and subscription.current_period_end:
        period_start = subscription.current_period_start
        period_end = subscription.current_period_end
    else:
        now = datetime.now(timezone.utc)
        period_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        period_end = None

    query = (
        db.query(Order)
        .join(Order.shop)
        .filter(
            Order.shop.has(seller_id=seller.id),
            Order.created_at >= period_start,
        )
    )
    if period_end is not None:
        query = query.filter(Order.created_at <= period_end)

    return query.count()


def check_order_limit(db: Session, seller: Seller) -> None:
    """
    Check if the seller can receive another order in the current billing period.

    Raises PlanLimitExceeded (402) if the order limit is reached.

    Uses the subscription's current_period_start/current_period_end when set;
    falls back to the current calendar month if no billing period is defined.
    """
    plan_info = _get_plan_limits(seller)

    from datetime import datetime, timezone
    from sqlalchemy import func

    # Prefer the subscription billing window if present
    subscription = seller.subscription
    if subscription and subscription.current_period_start and subscription.current_period_end:
        period_start = subscription.current_period_start
        period_end = subscription.current_period_end
    else:
        # Fallback: current calendar month
        now = datetime.now(timezone.utc)
        period_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        period_end = None

    query = (
        db.query(Order)
        .join(Order.shop)
        .filter(
            Order.shop.has(seller_id=seller.id),
            Order.created_at >= period_start,
        )
    )
    if period_end is not None:
        query = query.filter(Order.created_at <= period_end)

    current_count = query.count()

    if current_count >= plan_info.max_orders:
        raise PlanLimitExceeded(
            limit_type="orders per billing period",
            limit=plan_info.max_orders,
            current=current_count,
            plan_name=plan_info.name,
        )