"""Audit log helper for super-admin / system actions.

Centralises the call to ``AuditLog`` so the admin endpoints don't sprinkle
``AuditLog(...)`` constructions across the codebase and so the field usage
stays consistent.
"""
from __future__ import annotations

from typing import Any, Optional

from sqlalchemy.orm import Session

from app.core.context import get_current_seller_id_or_default
from app.models.audit_log import AuditLog
from app.models.seller import Seller


def log_admin_action(
    db: Session,
    actor: Seller,
    action: str,
    entity_type: str,
    entity_id: Optional[str] = None,
    old_values: Optional[dict[str, Any]] = None,
    new_values: Optional[dict[str, Any]] = None,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None,
    extra_data: Optional[dict[str, Any]] = None,
) -> AuditLog:
    """Persist an audit entry.

    ``seller_id`` on the audit row is the *target* (if known); the active
    request context supplies the id of the actor *being impersonated* (if
    any), so this helper pinned to ``actor.id`` — the actual super-admin
    person — for traceability.
    """
    entry = AuditLog(
        seller_id=entity_type.lower() == "seller"
            and (int(entity_id) if entity_id and entity_id.isdigit() else None),
        actor_email=actor.email if actor else None,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        old_values=old_values,
        new_values=new_values,
        ip_address=ip_address,
        user_agent=user_agent,
        extra_data=extra_data,
    )
    db.add(entry)
    db.flush()  # so id is populated; caller does final commit

    # Suppress unused import warning for context — kept for callers/tests.
    _ = get_current_seller_id_or_default

    return entry
