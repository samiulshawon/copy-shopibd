import json
import os
from typing import Dict, Optional

_LOCALE_CACHE: Dict[str, Dict[str, str]] = {}
_LOCALES_DIR = os.path.join(os.path.dirname(__file__), "locales")


def _load_locale(locale: str) -> Dict[str, str]:
    """Load a locale JSON file and cache it in memory."""
    if locale in _LOCALE_CACHE:
        return _LOCALE_CACHE[locale]

    file_path = os.path.join(_LOCALES_DIR, f"{locale}.json")
    if not os.path.exists(file_path):
        return {}

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            translations = json.load(f)
        _LOCALE_CACHE[locale] = translations
        return translations
    except (json.JSONDecodeError, IOError):
        return {}


def get_translation(key: str, locale: str = "bn") -> str:
    """Get a translated string for the given key and locale.

    Falls back to English if the key is not found in the requested locale.
    Falls back to the key itself if not found in either locale.
    """
    # Try requested locale first
    translations = _load_locale(locale)
    if key in translations:
        return translations[key]

    # Fall back to English
    if locale != "en":
        en_translations = _load_locale("en")
        if key in en_translations:
            return en_translations[key]

    # Fall back to the key itself
    return key