# Internationalization config
from app.services.i18n.translation import get_translation

__all__ = ["get_translation"]
