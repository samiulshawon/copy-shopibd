from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class CountryConfig:
    code: str
    name: str
    phone_prefix: str
    currency: str
    currency_symbol: str
    address_fields: List[str] = field(default_factory=list)
    date_format: str = "dd/mm/yyyy"
    language: str = "en"


# Country configurations
_COUNTRY_CONFIGS: dict[str, CountryConfig] = {
    "BD": CountryConfig(
        code="BD",
        name="Bangladesh",
        phone_prefix="+880",
        currency="BDT",
        currency_symbol="৳",
        address_fields=[
            "street_address",
            "area",
            "city",
            "district",
            "division",
        ],
        date_format="dd/mm/yyyy",
        language="bn",
    ),
    "IN": CountryConfig(
        code="IN",
        name="India",
        phone_prefix="+91",
        currency="INR",
        currency_symbol="₹",
        address_fields=["street_address", "city", "state", "pincode"],
        date_format="dd/mm/yyyy",
        language="hi",
    ),
}


def default_country_config() -> CountryConfig:
    """Return the default country configuration (Bangladesh)."""
    return _COUNTRY_CONFIGS["BD"]


def get_country_config(country_code: str) -> CountryConfig:
    """Get configuration for a specific country code.

    Falls back to Bangladesh config if the country code is not found.
    """
    return _COUNTRY_CONFIGS.get(country_code.upper(), default_country_config())
