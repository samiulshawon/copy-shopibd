"""
Phase 10.3 — Abandoned cart / order recovery job for ShopiBD.

Scans pending orders that have been untouched for longer than
``ABANDONED_CART_HOURS`` (default 1 hour), sends the buyer a WhatsApp
recovery nudge, and records the send so we don't spam. When the same order
is later paid, ``mark_recovered`` is called (e.g. from the payment-confirm
path) so recovery can be measured.

The job reuses the seller-scoped reminder notification that already exists
for the abandoned-orders dashboard, but runs platform-wide on a schedule.
"""
from __future__ import annotations

import asyncio
import inspect
import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import SessionLocal
from app.models.order import Order, OrderStatus
from app.services.whatsapp.factory import get_whatsapp_service

logger = logging.getLogger(__name__)

# Orders pending for this many hours with no payment are "abandoned".
ABANDONED_CART_HOURS = 1


def _is_abandoned(order: Order, *, hours: int) -> bool:
    if order.status != OrderStatus.PENDING.value:
        return False
    if order.payment_status == "paid":
        return False
    # Already nudged recently -> not actionable again.
    if order.recovery_sent_at is not None:
        return False
    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    created = order.created_at
    if created.tzinfo is None:
        created = created.replace(tzinfo=timezone.utc)
    return created < cutoff


def _recover_message(order: Order) -> str:
    return (
        f"🛒 আপনার অর্ডারটি এখনও সম্পূর্ণ হয়নি!\n\n"
        f"অর্ডার নম্বর: {order.order_number}\n"
        f"পরিমাণ: ৳{order.total_amount}\n\n"
        f"পেমেন্ট করে আপনার দোকানটি চালু করুন।\n"
        f"লিংক: https://shopibd.com/checkout/{order.order_number}\n\n"
        f"— ShopiBD"
    )


def run_abandoned_cart_reminders(db: Session | None = None, *, hours: int = ABANDONED_CART_HOURS) -> dict:
    """Scan pending orders and nudge buyers who abandoned checkout.

    Returns a summary with counts and per-order detail.
    """
    own_session = db is None
    session = db or SessionLocal()
    try:
        orders = (
            session.execute(
                select(Order).where(Order.status == OrderStatus.PENDING.value)
            )
            .scalars()
            .all()
        )

        candidates = [o for o in orders if _is_abandoned(o, hours=hours)]
        nudged = 0
        skipped = 0
        failed = 0
        details: list[dict] = []

        for order in candidates:
            order.recovery_sent_at = datetime.now(timezone.utc)
            if own_session:
                session.add(order)
            try:
                phone = order.customer_phone
                if phone:
                    if phone.startswith("+880"):
                        phone = "0" + phone[4:]
                    service = get_whatsapp_service()
                    result = service.send_message(phone, _recover_message(order))
                    # The WhatsApp interface is async; this job runs sync.
                    if inspect.isawaitable(result):
                        asyncio.run(result)
                nudged += 1
                details.append({"order_id": order.id, "nudged": True})
            except Exception as exc:  # noqa: BLE001
                failed += 1
                details.append({"order_id": order.id, "nudged": False, "error": str(exc)})

        # Always commit: callers that pass a session expect the nudge
        # bookkeeping to be persisted immediately (mirrors mark_recovered).
        session.commit()

        return {
            "checked": len(orders),
            "candidates": len(candidates),
            "nudged": nudged,
            "failed": failed,
            "skipped": len(orders) - len(candidates),
            "ran_at": datetime.now(timezone.utc).isoformat(),
            "details": details,
        }
    finally:
        if own_session:
            session.close()


def mark_recovered(db: Session, order: Order) -> None:
    """Mark an order as recovered (called from payment-confirm path).

    Recovery is only meaningful if we previously nudged the buyer.
    """
    if order.recovery_sent_at is not None and order.recovered_at is None:
        order.recovered_at = datetime.now(timezone.utc)
        db.add(order)
        db.commit()
        logger.info("Order %s marked recovered", order.id)
