"""
bKash Payment Provider for ShopiBD.

Implements the PaymentVerifier ABC using bKash Tokenized Checkout API v1.2.0-beta.
Supports token grant/refresh, payment creation, execution, and status query.
"""

from __future__ import annotations

import json
import time
from decimal import Decimal
from typing import Any, Optional

import httpx

from app.core.config import settings
from app.services.payment.base import PaymentResult, PaymentVerifier


class BKashPaymentProvider(PaymentVerifier):
    """bKash Tokenized Checkout payment provider."""

    BASE_URL: str = ""
    APP_KEY: str = ""
    APP_SECRET: str = ""
    USERNAME: str = ""
    PASSWORD: str = ""

    _access_token: Optional[str] = None
    _refresh_token: Optional[str] = None
    _token_expires_at: float = 0.0

    def __init__(self) -> None:
        self.BASE_URL = settings.BKASH_BASE_URL.rstrip("/")
        self.APP_KEY = settings.BKASH_APP_KEY
        self.APP_SECRET = settings.BKASH_APP_SECRET
        self.USERNAME = settings.BKASH_USERNAME
        self.PASSWORD = settings.BKASH_PASSWORD

    # ------------------------------------------------------------------
    # Public API — PaymentVerifier ABC
    # ------------------------------------------------------------------

    async def verify_payment(self, payment_id: int, **kwargs: Any) -> PaymentResult:
        """
        Verify a payment by its internal ID (order_id or transaction_id).

        Queries bKash for the paymentID stored on the transaction record.
        """
        provider_data: Optional[dict] = kwargs.get("provider_data")
        if not provider_data or "paymentID" not in provider_data:
            return PaymentResult(
                success=False,
                message="No bKash paymentID provided for verification",
            )

        payment_id_str = provider_data["paymentID"]
        status_data = await self.query_payment(payment_id_str)

        if status_data.get("transactionStatus") == "Completed":
            return PaymentResult(
                success=True,
                transaction_id=status_data.get("trxID"),
                message="Payment verified via bKash API",
                amount=Decimal(str(status_data.get("amount", "0"))),
                provider_data=status_data,
            )

        return PaymentResult(
            success=False,
            message=status_data.get("statusMessage", "Payment not completed"),
            provider_data=status_data,
        )

    async def create_payment(
        self,
        order_id: str,
        amount: int,
        callback_url: str,
        **kwargs: Any,
    ) -> dict:
        """
        Create a bKash payment intent.

        Args:
            order_id: The merchant invoice number (order number).
            amount: Amount in BDT (integer, e.g. 1000 = ৳1000).
            callback_url: HTTPS URL for bKash callback after payment.

        Returns:
            dict with 'payment_url' (redirect URL) and 'paymentID'.
        """
        token = await self._get_token()
        url = f"{self.BASE_URL}/tokenized/checkout/create"

        payload = {
            "mode": "0011",
            "payerReference": "01",
            "callbackURL": callback_url,
            "amount": str(amount),
            "currency": "BDT",
            "intent": "sale",
            "merchantInvoiceNumber": order_id,
        }

        headers = {
            "Authorization": token,
            "X-APP-Key": self.APP_KEY,
            "Content-Type": "application/json",
        }

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(url, json=payload, headers=headers)

        data = resp.json()

        if resp.status_code != 200 or data.get("statusCode") != "0000":
            raise ValueError(
                f"bKash create payment failed: {data.get('statusMessage', resp.text)}"
            )

        return {
            "payment_url": data["bkashURL"],
            "paymentID": data["paymentID"],
            "merchantInvoiceNumber": data.get("merchantInvoiceNumber"),
            "amount": data.get("amount"),
        }

    async def execute_payment(self, payment_id: str) -> dict:
        """
        Execute/confirm a bKash payment after callback.

        Args:
            payment_id: The bKash paymentID received via callback.

        Returns:
            dict with transaction details (trxID, status, amount).
        """
        token = await self._get_token()
        url = f"{self.BASE_URL}/tokenized/checkout/execute"

        payload = {"paymentID": payment_id}
        headers = {
            "Authorization": token,
            "X-APP-Key": self.APP_KEY,
            "Content-Type": "application/json",
        }

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(url, json=payload, headers=headers)

        data = resp.json()

        if resp.status_code != 200:
            raise ValueError(
                f"bKash execute payment failed: {data.get('statusMessage', resp.text)}"
            )

        return data

    async def query_payment(self, payment_id: str) -> dict:
        """
        Query the status of a bKash payment.

        Args:
            payment_id: The bKash paymentID.

        Returns:
            dict with current payment status.
        """
        token = await self._get_token()
        url = f"{self.BASE_URL}/tokenized/checkout/status"

        payload = {"paymentID": payment_id}
        headers = {
            "Authorization": token,
            "X-APP-Key": self.APP_KEY,
            "Content-Type": "application/json",
        }

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(url, json=payload, headers=headers)

        data = resp.json()

        if resp.status_code != 200:
            raise ValueError(
                f"bKash query payment failed: {data.get('statusMessage', resp.text)}"
            )

        return data

    # ------------------------------------------------------------------
    # Token Management (3.4.3)
    # ------------------------------------------------------------------

    async def _get_token(self) -> str:
        """
        Return a valid access token, refreshing it if necessary.
        """
        if self._access_token and time.time() < self._token_expires_at:
            return self._access_token

        # Try refresh first if we have a refresh token
        if self._refresh_token:
            try:
                return await self._refresh_token_grant()
            except Exception:
                # Refresh failed, do full grant
                pass

        return await self._grant_token()

    async def _grant_token(self) -> str:
        """
        Grant a new access token from bKash.
        """
        url = f"{self.BASE_URL}/tokenized/checkout/token/grant"

        payload = {
            "app_key": self.APP_KEY,
            "app_secret": self.APP_SECRET,
        }

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(url, json=payload)

        data = resp.json()

        if resp.status_code != 200 or "id_token" not in data:
            raise ValueError(
                f"bKash token grant failed: {data.get('statusMessage', resp.text)}"
            )

        token_type = data.get("token_type", "Bearer")
        self._access_token = f"{token_type} {data['id_token']}"
        self._refresh_token = data.get("refresh_token")
        expires_in = data.get("expires_in", 3600)
        self._token_expires_at = time.time() + expires_in - 60  # 1 min buffer

        return self._access_token

    async def _refresh_token_grant(self) -> str:
        """
        Refresh an existing token.
        """
        url = f"{self.BASE_URL}/tokenized/checkout/token/refresh"

        payload = {
            "app_key": self.APP_KEY,
            "app_secret": self.APP_SECRET,
            "refresh_token": self._refresh_token,
        }

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(url, json=payload)

        data = resp.json()

        if resp.status_code != 200 or "id_token" not in data:
            raise ValueError(
                f"bKash token refresh failed: {data.get('statusMessage', resp.text)}"
            )

        token_type = data.get("token_type", "Bearer")
        self._access_token = f"{token_type} {data['id_token']}"
        self._refresh_token = data.get("refresh_token")
        expires_in = data.get("expires_in", 3600)
        self._token_expires_at = time.time() + expires_in - 60

        return self._access_token
