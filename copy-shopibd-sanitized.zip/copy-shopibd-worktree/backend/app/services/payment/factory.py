from typing import Optional

from app.core.config import settings
from app.services.payment.base import PaymentVerifier
from app.services.payment.manual import ManualPaymentService
from app.services.payment.bkash import BKashPaymentProvider
from app.services.payment.nagad import NagadPaymentProvider
from app.services.payment.sslcommerz import SSLCommerzPaymentProvider


def get_payment_verifier(provider: Optional[str] = None) -> PaymentVerifier:
    """Return the appropriate payment verifier.

    If `provider` is provided, use that gateway. Otherwise fall back to
    the provider configured via settings.PAYMENT_PROVIDER.
    """
    provider = provider or settings.PAYMENT_PROVIDER

    if provider == "manual":
        return ManualPaymentService()

    if provider == "bkash":
        return BKashPaymentProvider()

    if provider == "nagad":
        return NagadPaymentProvider()

    if provider == "sslcommerz":
        return SSLCommerzPaymentProvider()

    raise ValueError(f"Unknown payment provider: {provider}")
