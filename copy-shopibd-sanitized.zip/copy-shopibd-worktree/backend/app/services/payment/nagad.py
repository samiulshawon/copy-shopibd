"""
Nagad Payment Provider for ShopiBD.

Implements the PaymentVerifier ABC using Nagad Merchant API.
Nagad uses a different auth flow based on RSA key pairs and sensitive data encoding.
"""

from __future__ import annotations

import base64
import hashlib
import json
import time
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, Optional

import httpx
from cryptography.hazmat.primitives import hashes, padding, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding as asym_padding

from app.core.config import settings
from app.services.payment.base import PaymentResult, PaymentVerifier


class NagadPaymentProvider(PaymentVerifier):
    """
    Nagad Merchant API payment provider.

    Nagad's flow:
    1. Generate a merchant-sensitive key pair (RSA 2048).
    2. Encode request data with the public key.
    3. Initialize a payment session -> get a callback URL.
    4. After buyer approves, receive callback with payment_ref_id.
    5. Verify/complete payment via status check.
    """

    BASE_URL: str = ""
    MERCHANT_ID: str = ""
    PRIVATE_KEY: str = ""
    PUB_KEY: str = ""  # Nagad's public key

    def __init__(self) -> None:
        self.BASE_URL = settings.NAGAD_BASE_URL.rstrip("/")
        self.MERCHANT_ID = settings.NAGAD_MERCHANT_ID
        self.PRIVATE_KEY = settings.NAGAD_PRIVATE_KEY
        self.PUB_KEY = settings.NAGAD_PUB_KEY

    # ------------------------------------------------------------------
    # Public API — PaymentVerifier ABC
    # ------------------------------------------------------------------

    async def verify_payment(self, payment_id: int, **kwargs: Any) -> PaymentResult:
        """
        Verify a Nagad payment by its internal ID.

        Uses provider_data containing payment_ref_id from callback.
        """
        provider_data: Optional[dict] = kwargs.get("provider_data")
        if not provider_data or "payment_ref_id" not in provider_data:
            return PaymentResult(
                success=False,
                message="No Nagad payment_ref_id provided for verification",
            )

        payment_ref_id = provider_data["payment_ref_id"]
        status_data = await self.query_payment(payment_ref_id)

        if status_data.get("status") == "Success":
            return PaymentResult(
                success=True,
                transaction_id=status_data.get("trxID"),
                message="Payment verified via Nagad API",
                amount=Decimal(str(status_data.get("amount", "0"))),
                provider_data=status_data,
            )

        return PaymentResult(
            success=False,
            message=status_data.get("message", "Payment not completed"),
            provider_data=status_data,
        )

    async def create_payment(
        self,
        order_id: str,
        amount: int,
        callback_url: str,
        **kwargs: Any,
    ) -> dict:
        """
        Create a Nagad payment session.

        Nagad flow:
        1. Generate a timestamp and encode sensitive data.
        2. POST to /checkout/initialize with merchant info.
        3. Receive callbackURL for redirecting the buyer.

        Args:
            order_id: Merchant invoice number.
            amount: Amount in BDT (integer, e.g. 1000).
            callback_url: URL for post-payment callback.

        Returns:
            dict with 'payment_url' for redirect.
        """
        timestamp = self._get_timestamp()
        merchant_id = self.MERCHANT_ID
        invoice_no = order_id

        # --- Sensitive data encoding ---
        sensitive_data = {
            "merchantId": merchant_id,
            "invoiceNo": invoice_no,
            "amount": str(amount),
            "currency": "BDT",
            "callbackUrl": callback_url,
        }
        sensitive_data_json = json.dumps(sensitive_data, separators=(",", ":"))
        encoded_data = self._rsa_encrypt(sensitive_data_json)

        # --- Signature generation ---
        data_to_sign = f"{merchant_id}{invoice_no}{encoded_data}{timestamp}"
        signature = self._generate_signature(data_to_sign)

        # --- Request body ---
        request_body = {
            "merchantId": merchant_id,
            "invoiceNo": invoice_no,
            "timestamp": timestamp,
            "sensitiveData": encoded_data,
            "signature": signature,
        }

        url = f"{self.BASE_URL}/api/checkout/initialize"

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(url, json=request_body)

        data = resp.json()

        if resp.status_code != 200 or "callbackURL" not in data:
            raise ValueError(
                f"Nagad create payment failed: {data.get('message', resp.text)}"
            )

        return {
            "payment_url": data["callbackURL"],
            "payment_ref_id": data.get("paymentRefId"),
            "invoice_no": invoice_no,
        }

    async def execute_payment(self, payment_id: str) -> dict:
        """
        Verify/complete a Nagad payment after callback.

        Nagad uses a status check with the payment_ref_id to verify payment.
        This effectively confirms the payment.

        Args:
            payment_id: The Nagad payment_ref_id received via callback.

        Returns:
            dict with payment verification details.
        """
        return await self.query_payment(payment_id)

    async def query_payment(self, payment_ref_id: str) -> dict:
        """
        Query the status of a Nagad payment.

        Args:
            payment_ref_id: Nagad payment reference ID from callback.

        Returns:
            dict with current payment status.
        """
        timestamp = self._get_timestamp()
        merchant_id = self.MERCHANT_ID

        # Generate signature for this request
        data_to_sign = f"{merchant_id}{payment_ref_id}{timestamp}"
        signature = self._generate_signature(data_to_sign)

        url = f"{self.BASE_URL}/api/checkout/complete/{payment_ref_id}"

        headers = {
            "X-Merchant-Id": merchant_id,
            "X-Signature": signature,
            "X-Timestamp": timestamp,
            "Content-Type": "application/json",
        }

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.get(url, headers=headers)

        data = resp.json()

        if resp.status_code != 200:
            raise ValueError(
                f"Nagad query payment failed: {data.get('message', resp.text)}"
            )

        return data

    # ------------------------------------------------------------------
    # Helper methods
    # ------------------------------------------------------------------

    def _get_timestamp(self) -> str:
        """Generate ISO 8601 timestamp for Nagad requests."""
        return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"

    def _rsa_encrypt(self, plaintext: str) -> str:
        """
        RSA encrypt sensitive data using Nagad's public key.

        Uses OAEP with SHA-256.
        """
        pub_key_pem = f"-----BEGIN PUBLIC KEY-----\n{self.PUB_KEY}\n-----END PUBLIC KEY-----"

        public_key = serialization.load_pem_public_key(pub_key_pem.encode())

        encrypted = public_key.encrypt(
            plaintext.encode(),
            asym_padding.OAEP(
                mgf=asym_padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None,
            ),
        )
        return base64.b64encode(encrypted).decode()

    def _generate_signature(self, data: str) -> str:
        """
        Generate an RSA signature using the merchant's private key.

        The signature is used to authenticate requests to Nagad.
        """
        priv_key_pem = f"-----BEGIN RSA PRIVATE KEY-----\n{self.PRIVATE_KEY}\n-----END RSA PRIVATE KEY-----"

        private_key = serialization.load_pem_private_key(
            priv_key_pem.encode(),
            password=None,
        )

        signature = private_key.sign(
            data.encode(),
            asym_padding.PKCS1v15(),
            hashes.SHA256(),
        )
        return base64.b64encode(signature).decode()
