from typing import Any, Optional

from app.services.payment.base import PaymentResult, PaymentVerifier


class ManualPaymentService(PaymentVerifier):
    """Manual/offline payment verification handled by admin/staff."""

    def __init__(self):
        self.supported_methods = ["cash", "bank_transfer", "mobile_banking"]

    async def create_payment(
        self,
        order_id: str,
        amount: int,
        callback_url: str,
        **kwargs: Any,
    ) -> dict:
        """
        Create a manual payment intent.

        Args:
            order_id: The order identifier.
            amount: Amount in BDT (integer).
            callback_url: URL to redirect after payment (unused for manual).
            **kwargs: Additional params like 'method', 'reference'.

        Returns:
            Dict with 'payment_url' (redirects to callback_url) and 'paymentID'.
        """
        method = kwargs.get("method", "cash")
        reference = kwargs.get("reference")

        if method not in self.supported_methods:
            raise ValueError(f"Unsupported payment method: {method}")

        return {
            "payment_url": callback_url,
            "paymentID": f"manual_{order_id}",
            "order_id": order_id,
            "amount": amount,
            "method": method,
            "reference": reference,
            "status": "pending_verification",
        }

    async def verify_payment(self, payment_id: int, **kwargs) -> PaymentResult:
        # Manual verification - would be done by admin/staff
        return PaymentResult(
            success=True,
            transaction_id=str(payment_id),
            message="Payment verified manually",
        )

    def get_instructions(self, method: str) -> str:
        instructions = {
            "cash": "Collect cash from customer upon delivery.",
            "bank_transfer": "Ask customer to transfer to the provided bank account.",
            "mobile_banking": "Ask customer to send money to the provided mobile banking number.",
        }
        return instructions.get(method, "Contact support for payment instructions.")