from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from decimal import Decimal
from typing import Optional


@dataclass
class PaymentResult:
    success: bool
    transaction_id: Optional[str] = None
    message: str = ""
    amount: Optional[Decimal] = None
    currency: str = "BDT"
    provider_data: Optional[dict] = None


class PaymentVerifier(ABC):
    """Abstract base for payment verification services."""

    @abstractmethod
    async def verify_payment(self, payment_id: int, **kwargs) -> PaymentResult:
        """Verify a payment and return the result."""
        ...

    @abstractmethod
    async def create_payment(self, order_id: str, amount: int, callback_url: str) -> dict:
        """
        Initiate a payment and return redirect/payment identifiers.

        Args:
            order_id: The internal order identifier (e.g., order_number).
            amount: Amount in minor units (poisa/cents).
            callback_url: Webhook/callback URL for payment confirmation.

        Returns:
            Dict with at least "payment_url" (redirect URL for the buyer)
            and "paymentID" (provider's transaction reference).
        """
        ...