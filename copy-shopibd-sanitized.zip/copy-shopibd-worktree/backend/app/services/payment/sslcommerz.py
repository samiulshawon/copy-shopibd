"""
SSLCommerz Payment Provider for ShopiBD.

Implements the PaymentVerifier ABC using SSLCommerz API v3.
Supports session initialization, IPN verification, and refunds.
"""

from __future__ import annotations

import hashlib
import json
from decimal import Decimal
from typing import Any, Optional

import httpx

from app.core.config import settings
from app.services.payment.base import PaymentResult, PaymentVerifier


class SSLCommerzPaymentProvider(PaymentVerifier):
    """SSLCommerz payment gateway provider."""

    BASE_URL: str = ""
    STORE_ID: str = ""
    STORE_PASSWORD: str = ""
    SANDBOX: bool = True

    def __init__(self) -> None:
        self.STORE_ID = settings.SSLCOMMERZ_STORE_ID
        self.STORE_PASSWORD = settings.SSLCOMMERZ_STORE_PASSWORD
        self.SANDBOX = settings.SSLCOMMERZ_SANDBOX
        if self.SANDBOX:
            self.BASE_URL = "https://sandbox.sslcommerz.com"
        else:
            self.BASE_URL = "https://secure.sslcommerz.com"

    # ------------------------------------------------------------------
    # Public API — PaymentVerifier ABC
    # ------------------------------------------------------------------

    async def verify_payment(self, payment_id: int, **kwargs: Any) -> PaymentResult:
        """
        Verify a payment by its transaction ID using SSLCommerz API.
        """
        transaction_id: Optional[str] = kwargs.get("transaction_id")
        if not transaction_id:
            return PaymentResult(
                success=False,
                message="No SSLCommerz transaction ID provided for verification",
            )

        status_data = await self._query_transaction(transaction_id)

        if status_data.get("status") == "VALID":
            return PaymentResult(
                success=True,
                transaction_id=transaction_id,
                message="Payment verified via SSLCommerz API",
                amount=Decimal(str(status_data.get("amount", "0"))),
                provider_data=status_data,
            )

        return PaymentResult(
            success=False,
            message=status_data.get("status", "Payment not completed"),
            provider_data=status_data,
        )

    async def create_payment(
        self,
        order_id: str,
        amount: int,
        callback_url: str,
        **kwargs: Any,
    ) -> dict:
        """
        Initialize an SSLCommerz payment session.

        Args:
            order_id: The merchant invoice number.
            amount: Amount in BDT.
            callback_url: The success/cancel/fail URL for redirect.

        Returns:
            dict with 'payment_url' (redirect URL) and 'session_key'.
        """
        url = f"{self.BASE_URL}/gwprocess/v3/api.php"

        customer_name = kwargs.get("customer_name", "Buyer")
        customer_phone = kwargs.get("customer_phone", "01711111111")
        customer_email = kwargs.get("customer_email", "buyer@example.com")
        customer_address = kwargs.get("customer_address", "Dhaka")
        cancel_url = kwargs.get("cancel_url", callback_url)
        fail_url = kwargs.get("fail_url", callback_url)

        payload = {
            "store_id": self.STORE_ID,
            "store_passwd": self.STORE_PASSWORD,
            "total_amount": str(amount),
            "currency": "BDT",
            "tran_id": order_id,
            "success_url": callback_url,
            "fail_url": fail_url,
            "cancel_url": cancel_url,
            "ipn_url": callback_url.replace("success", "ipn"),
            "cus_name": customer_name,
            "cus_phone": customer_phone,
            "cus_email": customer_email,
            "cus_add1": customer_address,
            "cus_country": "Bangladesh",
            "shipping_method": "NO",
            "product_name": "Order",
            "product_category": "General",
            "product_profile": "general",
        }

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(url, data=payload)

        data = resp.json()

        if resp.status_code != 200 or data.get("status") != "SUCCESS":
            raise ValueError(
                f"SSLCommerz session creation failed: {data.get('failedreason', resp.text)}"
            )

        return {
            "payment_url": data["GatewayPageURL"],
            "session_key": data.get("sessionkey", ""),
            "tran_id": order_id,
        }

    async def _query_transaction(self, transaction_id: str) -> dict:
        """
        Query SSLCommerz for transaction status.
        """
        url = f"{self.BASE_URL}/validator/api/merchantTransIDvalidationAPI.php"
        payload = {
            "store_id": self.STORE_ID,
            "store_passwd": self.STORE_PASSWORD,
            "merchant_trans_id": transaction_id,
        }
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.get(url, params=payload)
        return resp.json()

    async def validate_payment(self, payment_id: str) -> dict:
        """
        Validate a payment by its transaction ID (used by webhook).

        Returns a dict with 'valid' boolean. Wrapper around verify_payment.
        """
        result = await self.verify_payment(payment_id, transaction_id=payment_id)
        return {"valid": result.success, "message": result.message, "tran_id": result.transaction_id}

    async def initiate_refund(
        self,
        transaction_id: str,
        amount: Decimal,
        refund_id: str,
    ) -> dict:
        """
        Initiate a refund through SSLCommerz.
        """
        url = f"{self.BASE_URL}/gwprocess/v3/api.php"
        payload = {
            "store_id": self.STORE_ID,
            "store_passwd": self.STORE_PASSWORD,
            "refund_amount": str(amount),
            "refund_ref_id": refund_id,
            "bank_tran_id": transaction_id,
        }
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(url, data=payload)
        return resp.json()
