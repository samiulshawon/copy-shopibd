"""
CSV parsing service for ShopiBD product bulk import.

Supports comma-separated and tab-separated files,
handles Bangla (Unicode) text, and validates required columns.
"""

import csv
import io
import re
from typing import Any

REQUIRED_COLUMNS = {"name", "price"}
VALID_COLUMNS = {"name", "description", "price", "stock", "category", "sku"}


def _detect_delimiter(headers: str) -> str:
    """Detect whether the file uses comma or tab as delimiter."""
    if "\t" in headers:
        return "\t"
    return ","


def _normalise_column_name(name: str) -> str:
    """Normalise column name to lowercase and strip whitespace."""
    return name.strip().lower().replace("-", "_").replace(" ", "_")


def parse_products_csv(file_content: str) -> list[dict[str, Any]]:
    """
    Parse a CSV string containing product data.

    Args:
        file_content: Raw string content of the CSV file.

    Returns:
        A list of dictionaries, each representing a parsed product row.

    Raises:
        ValueError: If required columns are missing or the file is empty.
    """
    # Remove BOM if present
    if file_content.startswith("\ufeff"):
        file_content = file_content[1:]

    lines = file_content.splitlines()
    if not lines:
        raise ValueError("CSV file is empty")

    headers_line = lines[0]
    delimiter = _detect_delimiter(headers_line)

    reader = csv.DictReader(lines, delimiter=delimiter)

    # Normalise headers
    normalised_fieldnames = {
        _normalise_column_name(h): h for h in (reader.fieldnames or [])
    }

    # Check required columns
    provided = set(normalised_fieldnames.keys())
    missing = REQUIRED_COLUMNS - provided
    if missing:
        raise ValueError(
            f"Missing required columns: {', '.join(sorted(missing))}. "
            f"Provided columns: {', '.join(provided)}"
        )

    products: list[dict[str, Any]] = []
    for row_index, row in enumerate(reader, start=2):  # start=2 because header is row 1
        # Build a clean product dict using normalised keys
        product: dict[str, Any] = {}
        for raw_col, raw_val in row.items():
            if raw_col is None:
                continue
            col = _normalise_column_name(raw_col)
            if col not in VALID_COLUMNS:
                continue
            val = raw_val.strip() if raw_val else ""

            if col == "price":
                # Remove any currency symbols, commas, and whitespace
                val_clean = re.sub(r"[^\d.]", "", val)
                try:
                    product[col] = float(val_clean) if val_clean else 0.0
                except ValueError:
                    product[col] = 0.0
            elif col == "stock":
                try:
                    product[col] = int(val) if val else 0
                except ValueError:
                    product[col] = 0
            else:
                product[col] = val if val else None

        # Ensure required fields are present
        if not product.get("name"):
            product["name"] = f"Unnamed Product (Row {row_index})"

        if "price" not in product or product["price"] is None:
            product["price"] = 0.0

        if "stock" not in product or product["stock"] is None:
            product["stock"] = 0

        products.append(product)

    return products
