"""
Domain verification service for ShopiBD white-label / custom domain feature.

Provides utilities for verifying DNS records (CNAME, TXT) and a stub for
Let's Encrypt SSL provisioning.
"""

from __future__ import annotations

import logging
import socket
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# Default target hostname that shop subdomains should CNAME to
SHOPIBD_TARGET = "shopibd.com"


# ---------------------------------------------------------------------------
# DNS lookup helpers
# ---------------------------------------------------------------------------


def _resolve_cname(domain: str) -> Optional[str]:
    """Resolve the CNAME record for *domain*.

    Returns the canonical target hostname if a CNAME exists, or *None*.
    Uses the system resolver (socket.getaddrinfo fallback) and a simple
    textual DNS query via the `socket` module when possible.
    """
    try:
        # Try a simple textual approach using getaddrinfo with AI_CANONNAME
        infos = socket.getaddrinfo(domain, 80, type=socket.SOCK_STREAM)
        for info in infos:
            canonname = info[3]  # (host, port) -> canonname is at index 3
            if canonname and canonname != domain:
                return canonname.rstrip(".")
    except (socket.gaierror, OSError):
        pass
    return None


def _resolve_txt(domain: str) -> List[str]:
    """Resolve TXT records for *domain*.

    Returns a list of TXT record values (strings).
    Uses a basic socket-based DNS query.
    """
    results: List[str] = []
    try:
        infos = socket.getaddrinfo(domain, 80, type=socket.SOCK_STREAM)
        # On most systems, getaddrinfo doesn't return TXT records reliably.
        # This is a best-effort stub; in production consider using dnspython.
        pass
    except (socket.gaierror, OSError):
        pass
    return results


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def verify_cname(domain: str, target: str) -> bool:
    """Check if *domain* has a CNAME record pointing to *target*.

    Args:
        domain: The domain to check (e.g. ``"rina.shopibd.com"``).
        target: The expected CNAME target (e.g. ``"shopibd.com"``).

    Returns:
        ``True`` if the CNAME matches, ``False`` otherwise.
    """
    actual = _resolve_cname(domain)
    if actual is None:
        logger.info("No CNAME record found for %s", domain)
        return False
    result = actual.rstrip(".") == target.rstrip(".")
    logger.info(
        "CNAME check for %s: expected=%s actual=%s matched=%s",
        domain,
        target,
        actual,
        result,
    )
    return result


def verify_txt_record(domain: str, expected_value: str) -> bool:
    """Check if *domain* has a TXT record matching *expected_value*.

    Args:
        domain: The domain to check (e.g. ``"shopibd.com"``).
        expected_value: The expected TXT record value.

    Returns:
        ``True`` if a matching TXT record exists, ``False`` otherwise.
    """
    records = _resolve_txt(domain)
    for record in records:
        if record.strip('"') == expected_value.strip('"'):
            logger.info(
                "TXT record matched for %s: %s", domain, expected_value
            )
            return True
    logger.info(
        "No matching TXT record for %s (expected=%s, found=%s)",
        domain,
        expected_value,
        records,
    )
    return False


def get_required_dns_records(
    domain: str,
    subdomain: Optional[str] = None,
) -> List[Dict[str, str]]:
    """Return the list of DNS records the user must add.

    Args:
        domain: The custom domain to configure.
        subdomain: Optional subdomain (e.g. ``"rina"``).

    Returns:
        A list of dicts with keys ``type``, ``name``, ``value``, ``description``.
    """
    records: List[Dict[str, str]] = []

    if subdomain:
        # Subdomain setup: CNAME from subdomain.shopibd.com
        records.append(
            {
                "type": "CNAME",
                "name": subdomain,
                "value": SHOPIBD_TARGET,
                "description": (
                    f"Create a CNAME record for '{subdomain}' pointing to "
                    f"'{SHOPIBD_TARGET}' so that "
                    f"https://{subdomain}.shopibd.com serves your shop."
                ),
            }
        )

    # Custom domain setup
    records.append(
        {
            "type": "CNAME",
            "name": domain,
            "value": SHOPIBD_TARGET,
            "description": (
                f"Create a CNAME record for '{domain}' pointing to "
                f"'{SHOPIBD_TARGET}' so that https://{domain} serves "
                f"your shop."
            ),
        }
    )

    # Verification TXT record
    records.append(
        {
            "type": "TXT",
            "name": f"_shopibd-verify.{domain}",
            "value": f"shopibd-domain-verify={domain}",
            "description": (
                f"Add this TXT record to prove you own '{domain}'. "
                f"ShopiBD will check for this record to verify ownership."
            ),
        }
    )

    return records


def provision_ssl(domain: str) -> bool:
    """Stub for Let's Encrypt / ACME SSL certificate provisioning.

    In production this would call Certbot, the ACME protocol, or a
    cloud-provider API (e.g. AWS Certificate Manager).

    Args:
        domain: The domain to provision SSL for.

    Returns:
        ``True`` if provisioning succeeded (stub always returns ``True``).
    """
    logger.info("SSL provisioning stub called for %s", domain)
    # TODO: Replace with actual Let's Encrypt integration
    return True


# ---------------------------------------------------------------------------
# Phase 7 — ACME SSL provisioning
# ---------------------------------------------------------------------------
#
# The real provisioning path talks to an ACME-compatible issuer (Let's
# Encrypt by default; ``ACME_DIRECTORY_URL_STAGING`` is used first to avoid
# the 50-certs/domain/week production rate limit during development). The
# implementation is backend-pluggable: the default ``CertbotBackend`` shells
# out to the certbot sidecar container (see docker-compose.dev.yml), and a
# ``StubBackend`` is used in tests/sandbox where certbot is unavailable.
#
# Certificates are stored on disk under ``SSL_CERT_DIR`` (mounted volume
# shared with the reverse proxy) and the expiry timestamp is returned so
# the Shop row can record ``ssl_expires_at``.

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone as _tz
import os
import subprocess
import json as _json


@dataclass
class ProvisionResult:
    """Outcome of an SSL provisioning attempt."""

    success: bool
    expires_at: datetime | None = None
    error: str | None = None


class _StubBackend:
    """Used when no ACME backend is available (tests, sandbox, dev).

    Returns a 90-day certificate-equivalent result so the rest of the
    pipeline (Shop status, /health, renewal job) can be exercised without
    hitting Let's Encrypt.
    """

    name = "stub"

    def provision(self, domain: str, staging: bool) -> ProvisionResult:
        logger.info("SSL provisioning (stub) for %s (staging=%s)", domain, staging)
        return ProvisionResult(
            success=True,
            expires_at=datetime.now(_tz.utc).replace(tzinfo=None) + timedelta(days=90),
        )

    def renew(self, domain: str, staging: bool) -> ProvisionResult:
        return self.provision(domain, staging)


class _CertbotBackend:
    """Shell out to the certbot sidecar to issue/renew a cert.

    Expects a certbot container or binary reachable via the
    ``CERTBOT_BIN`` config (default ``certbot``). Certificates land in
    ``SSL_CERT_DIR`` (default ``/var/www/ssl``) which the reverse proxy
    also mounts.
    """

    name = "certbot"

    def __init__(self) -> None:
        from app.core.config import settings

        self._bin = getattr(settings, "CERTBOT_BIN", "certbot")
        self._cert_dir = getattr(settings, "SSL_CERT_DIR", "/var/www/ssl")
        self._email = getattr(settings, "ACME_EMAIL", "admin@shopibd.com")
        self._staging_url = getattr(
            settings,
            "ACME_DIRECTORY_URL_STAGING",
            "https://acme-staging-v02.api.letsencrypt.org/directory",
        )
        self._prod_url = getattr(
            settings,
            "ACME_DIRECTORY_URL_PROD",
            "https://acme-v02.api.letsencrypt.org/directory",
        )

    def _run(self, domain: str, staging: bool, renew: bool) -> ProvisionResult:
        directory = self._staging_url if staging else self._prod_url
        cmd = [self._bin, "certonly", "--non-interactive", "--agree-tos"]
        cmd += ["--email", self._email, "--directory-url", directory]
        cmd += ["--webroot", "-w", self._cert_dir, "-d", domain]
        if renew:
            cmd = [self._bin, "renew", "--cert-name", domain, "--non-interactive"]
        try:
            subprocess.run(cmd, check=True, capture_output=True, timeout=120)
        except FileNotFoundError as exc:
            return ProvisionResult(success=False, error=f"certbot not found: {exc}")
        except subprocess.CalledProcessError as exc:
            stderr = (exc.stderr or b"").decode("utf-8", errors="replace")
            return ProvisionResult(success=False, error=stderr.strip() or str(exc))
        except subprocess.TimeoutExpired:
            return ProvisionResult(success=False, error="certbot timed out")

        expires_at = _read_cert_expiry(domain, self._cert_dir)
        return ProvisionResult(success=True, expires_at=expires_at)

    def provision(self, domain: str, staging: bool) -> ProvisionResult:
        return self._run(domain, staging, renew=False)

    def renew(self, domain: str, staging: bool) -> ProvisionResult:
        return self._run(domain, staging, renew=True)


def _read_cert_expiry(domain: str, cert_dir: str) -> datetime | None:
    """Best-effort read of the cert's notAfter via openssl; None on failure."""
    cert_path = os.path.join(cert_dir, "live", domain, "fullchain.pem")
    if not os.path.exists(cert_path):
        return None
    try:
        out = subprocess.check_output(
            ["openssl", "x509", "-in", cert_path, "-noout", "-enddate"],
            stderr=subprocess.DEVNULL,
            timeout=10,
        ).decode("utf-8", errors="replace").strip()
        # notAfter=May 18 12:00:00 2026 GMT
        if "=" in out:
            out = out.split("=", 1)[1]
        return datetime.strptime(out, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=None)
    except Exception:  # noqa: BLE001
        return None


def _get_backend():
    """Pick the SSL backend based on config (``SSL_BACKEND``).

    - ``stub``  : always succeed (tests/sandbox)
    - ``certbot`` (default): shell out to certbot sidecar
    """
    from app.core.config import settings

    name = getattr(settings, "SSL_BACKEND", "certbot").lower()
    if name == "stub":
        return _StubBackend()
    return _CertbotBackend()


def provision_ssl_cert(domain: str, *, staging: bool | None = None) -> ProvisionResult:
    """Provision (or re-provision) an SSL cert for *domain*.

    Args:
        domain: Verified custom domain.
        staging: If True use the Let's Encrypt staging directory; if None,
            default to staging unless ``APP_ENV=production``.

    Returns:
        ``ProvisionResult`` with ``success``, ``expires_at``, ``error``.
    """
    from app.core.config import settings

    if staging is None:
        staging = getattr(settings, "APP_ENV", "development") != "production"
    backend = _get_backend()
    return backend.provision(domain, staging)


def renew_ssl_cert(domain: str, *, staging: bool | None = None) -> ProvisionResult:
    """Renew an existing cert for *domain* (called by the renewal job)."""
    from app.core.config import settings

    if staging is None:
        staging = getattr(settings, "APP_ENV", "development") != "production"
    backend = _get_backend()
    return backend.renew(domain, staging)


def needs_renewal(expires_at: datetime | None, *, threshold_days: int = 30) -> bool:
    """True if *expires_at* is within ``threshold_days`` of now (or missing)."""
    if expires_at is None:
        return True
    return expires_at - datetime.utcnow() <= timedelta(days=threshold_days)
