import re
from app.services.whatsapp.base import WhatsAppServiceBase


class MockWhatsAppService(WhatsAppServiceBase):
    async def send_message(self, to: str, message: str) -> bool:
        # Mock implementation - just log the message
        print(f"[MOCK WhatsApp] To: {to}, Message: {message}")
        return True

    def validate_phone(self, phone: str) -> bool:
        # Basic Bangladesh phone validation
        pattern = r"^01[0-9]{9}$"
        return bool(re.match(pattern, phone))