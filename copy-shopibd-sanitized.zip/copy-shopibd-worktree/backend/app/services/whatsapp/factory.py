from app.core.config import settings
from app.services.whatsapp.base import WhatsAppServiceBase
from app.services.whatsapp.mock import MockWhatsAppService


def get_whatsapp_service() -> WhatsAppServiceBase:
    provider = settings.WHATSAPP_PROVIDER

    if provider == "mock":
        return MockWhatsAppService()

    # Future providers: twilio, meta (WhatsApp Cloud API), etc.
    return MockWhatsAppService()