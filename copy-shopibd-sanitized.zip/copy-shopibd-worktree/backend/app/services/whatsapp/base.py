from abc import ABC, abstractmethod


class WhatsAppServiceBase(ABC):
    @abstractmethod
    async def send_message(self, to: str, message: str) -> bool:
        pass

    @abstractmethod
    def validate_phone(self, phone: str) -> bool:
        pass