from datetime import datetime
from typing import Any, Dict, Optional

from pydantic import BaseModel, ConfigDict, EmailStr


class SellerBase(BaseModel):
    name: str
    email: EmailStr
    phone: str


class SellerCreate(SellerBase):
    password: str
    shop_name: Optional[str] = None
    subdomain: Optional[str] = None
    custom_domain: Optional[str] = None


class SellerUpdate(BaseModel):
    name: Optional[str] = None
    phone: Optional[str] = None
    is_active: Optional[bool] = None


class SubscriptionOverride(BaseModel):
    """Super-admin override of a client's subscription plan (bypasses payment)."""
    plan: str
    auto_renew: Optional[bool] = True


class SellerSettingsUpdate(BaseModel):
    """Settings that update the seller's shop payment & delivery config."""
    bkash_number: Optional[str] = None
    nagad_number: Optional[str] = None
    rocket_number: Optional[str] = None
    delivery_settings: Optional[Dict[str, Any]] = None


class SellerInDBBase(SellerBase):
    id: int
    is_active: bool
    is_verified: bool
    is_super_admin: bool = False
    plan: str = "free"
    max_products: int = 50
    max_orders: int = 200
    shop_subdomain: Optional[str] = None
    # Phase 6: surfaced by admin endpoints for the downgrade warning banner.
    shop_custom_domain: Optional[str] = None
    custom_domain_grace_until: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


class Seller(SellerInDBBase):
    pass


class SellerLogin(BaseModel):
    email: EmailStr
    password: str


class Token(BaseModel):
    """OAuth2 token response returned by /auth/login and /auth/refresh."""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class TokenRefresh(BaseModel):
    """Request body for /auth/refresh."""
    refresh_token: str
