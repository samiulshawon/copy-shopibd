from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, field_validator


class StockMovementResponse(BaseModel):
    """Schema returned when reading a stock movement."""

    id: int
    product_id: int
    variant_id: Optional[int] = None
    movement_type: str
    quantity_change: int
    previous_quantity: int
    new_quantity: int
    reference_type: Optional[str] = None
    reference_id: Optional[int] = None
    note: Optional[str] = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class StockMovementCreate(BaseModel):
    """Schema for recording a new stock movement (adjustment only)."""

    product_id: int
    movement_type: str = "adjustment"
    quantity_change: int
    note: Optional[str] = None
    reference_type: Optional[str] = None
    reference_id: Optional[int] = None

    @field_validator("movement_type")
    @classmethod
    def validate_movement_type(cls, v: str) -> str:
        allowed = {"adjustment"}
        if v.lower() not in allowed:
            raise ValueError(
                f"movement_type must be one of {allowed} for manual entries. "
                f"Sale/return/purchase movements are handled by their respective systems."
            )
        return v.lower()

    @field_validator("quantity_change")
    @classmethod
    def validate_quantity_change(cls, v: int) -> int:
        if v == 0:
            raise ValueError("quantity_change must not be zero")
        return v


class StockMovementListResponse(BaseModel):
    """Paginated list of stock movements."""

    items: list[StockMovementResponse]
    total: int