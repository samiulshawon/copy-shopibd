from datetime import datetime
from decimal import Decimal
from typing import Optional

from pydantic import BaseModel, computed_field


# ---------------------------------------------------------------------------
# Plan definitions (pricing config, kept in code)
# ---------------------------------------------------------------------------

class PlanInfo(BaseModel):
    """Public plan info returned by the API."""
    id: str
    name: str
    price_bdt: Decimal
    max_products: int
    max_orders: int
    features: list[str]

    @computed_field
    @property
    def allow_subdomain(self) -> bool:
        # Every paid-or-free storefront tier gets a subdomain.
        # "Custom domain & whitelabel" is the only thing gated to enterprise.
        return True  # Free/Starter/Business/Enterprise all get a subdomain

    @computed_field
    @property
    def allow_custom_domain(self) -> bool:
        return any(
            "custom domain" in f.lower() for f in self.features
        )


# Reference plan catalog — used for seeding and API responses
PLANS: dict[str, PlanInfo] = {
    "free": PlanInfo(
        id="free",
        name="Free",
        price_bdt=Decimal("0"),
        max_products=50,
        max_orders=200,
        features=[
            "Up to 50 products",
            "Up to 200 orders/month",
            "Basic storefront",
            "Email support",
        ],
    ),
    "starter": PlanInfo(
        id="starter",
        name="Starter",
        price_bdt=Decimal("499"),
        max_products=200,
        max_orders=1000,
        features=[
            "Up to 200 products",
            "Up to 1,000 orders/month",
            "Coupon management",
            "Staff accounts (up to 3)",
            "Email & chat support",
        ],
    ),
    "business": PlanInfo(
        id="business",
        name="Business",
        price_bdt=Decimal("999"),
        max_products=1000,
        max_orders=5000,
        features=[
            "Up to 1,000 products",
            "Up to 5,000 orders/month",
            "Everything in Starter",
            "Advanced analytics",
            "Abandoned cart recovery",
            "Priority support",
        ],
    ),
    "enterprise": PlanInfo(
        id="enterprise",
        name="Enterprise",
        price_bdt=Decimal("2999"),
        max_products=99999,
        max_orders=99999,
        features=[
            "Unlimited products",
            "Unlimited orders",
            "Everything in Business",
            "Custom domain & whitelabel",
            "Dedicated account manager",
            "API access",
        ],
    ),
}


# ---------------------------------------------------------------------------
# Subscription schemas
# ---------------------------------------------------------------------------

class SubscriptionBase(BaseModel):
    plan: str = "free"
    auto_renew: bool = False


class SubscriptionCreate(SubscriptionBase):
    """Used when selecting/changing a plan (before payment)."""
    payment_gateway: Optional[str] = None


class SubscriptionUpdate(BaseModel):
    plan: Optional[str] = None
    auto_renew: Optional[bool] = None


class SubscriptionResponse(SubscriptionBase):
    id: int
    seller_id: int
    status: str
    current_period_start: datetime
    current_period_end: Optional[datetime] = None
    trial_end: Optional[datetime] = None
    canceled_at: Optional[datetime] = None
    payment_gateway: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class SubscriptionWithPlanResponse(SubscriptionResponse):
    """Subscription response including the resolved PlanInfo."""
    plan_info: PlanInfo
    current_products: int = 0
    current_orders: int = 0
