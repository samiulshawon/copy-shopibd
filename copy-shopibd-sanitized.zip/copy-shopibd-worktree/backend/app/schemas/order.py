from typing import Optional
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class OrderBase(BaseModel):
    customer_name: str
    customer_phone: str
    customer_address: str
    total_amount: float
    notes: Optional[str] = None


class OrderCreate(OrderBase):
    pass


class OrderUpdate(BaseModel):
    status: Optional[str] = None
    payment_status: Optional[str] = None
    notes: Optional[str] = None


class OrderInDBBase(OrderBase):
    id: int
    order_number: str
    status: str
    payment_status: str
    shop_id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class Order(OrderInDBBase):
    pass


# ---------------------------------------------------------------------------
# Storefront / buyer-facing schemas
# ---------------------------------------------------------------------------

class BuyerAddress(BaseModel):
    division: str
    district: str
    area: str
    details: str


class OrderItemCreate(BaseModel):
    product_id: int
    quantity: int


class OrderCreatePublic(BaseModel):
    """Request body for public order creation."""
    buyer_name: str
    buyer_phone: str
    buyer_address: BuyerAddress
    product_id: int
    quantity: int
    notes: Optional[str] = None
    coupon_code: Optional[str] = None
    payment_method: Optional[str] = None  # bkash / nagad / manual / cod


class OrderItemPublic(BaseModel):
    id: int
    product_id: int
    product_name: str
    quantity: int
    unit_price: float
    subtotal: float

    model_config = ConfigDict(from_attributes=True)


class OrderPublic(BaseModel):
    """Public order details for buyer."""
    id: int
    order_number: str
    customer_name: str
    customer_phone: str
    customer_address: str
    total_amount: float
    status: str
    payment_status: str
    notes: Optional[str] = None
    shop_id: int
    created_at: datetime
    items: list[OrderItemPublic] = []
    payment_method: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)


class OrderConfirmation(OrderPublic):
    """Order confirmation response with payment details."""
    shop_name: str
    shop_contact_phone: str
    bkash_number: Optional[str] = None
    nagad_number: Optional[str] = None
    coupon_code: Optional[str] = None
    discount_amount: Optional[float] = None
    payment_instructions: str = "Please send the exact amount to the number above and click 'I've Paid'. Our team will verify and confirm your order."
    payment_url: Optional[str] = None  # For bkash/nagad redirect
    paymentID: Optional[str] = None  # bKash payment ID for reference
