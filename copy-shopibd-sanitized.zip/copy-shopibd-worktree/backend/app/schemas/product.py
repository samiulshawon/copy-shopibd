from typing import List, Optional

from pydantic import BaseModel, ConfigDict


class ProductBase(BaseModel):
    name: str
    description: Optional[str] = None
    price: float
    stock: int = 0
    sku: Optional[str] = None
    is_active: bool = True


class ProductCreate(ProductBase):
    pass


class ProductUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    price: Optional[float] = None
    stock: Optional[int] = None
    sku: Optional[str] = None
    is_active: Optional[bool] = None


class ProductImageSchema(BaseModel):
    id: int
    image_url: str
    is_primary: bool
    sort_order: int

    model_config = ConfigDict(from_attributes=True)


class ProductInDBBase(ProductBase):
    id: int
    shop_id: int
    images: List[ProductImageSchema] = []

    model_config = ConfigDict(from_attributes=True)


class Product(ProductInDBBase):
    pass
