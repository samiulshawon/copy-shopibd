"""
Pydantic schemas for Coupon management.
"""
from datetime import datetime
from decimal import Decimal
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


# ---------------------------------------------------------------------------
# Base / Create
# ---------------------------------------------------------------------------

class CouponBase(BaseModel):
    code: str = Field(..., min_length=1, max_length=50, description="Coupon code")
    discount_type: str = Field(..., pattern=r"^(percentage|fixed)$")
    discount_value: Decimal = Field(..., gt=0)
    min_order_amount: Optional[Decimal] = None
    max_discount: Optional[Decimal] = None
    usage_limit: Optional[int] = None
    per_customer_limit: int = 1
    applies_to: str = "all"
    product_ids: Optional[str] = None  # JSON list
    category_ids: Optional[str] = None  # JSON list
    is_active: bool = True
    starts_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None


class CouponCreate(CouponBase):
    shop_id: Optional[int] = None


# ---------------------------------------------------------------------------
# Update
# ---------------------------------------------------------------------------

class CouponUpdate(BaseModel):
    code: Optional[str] = None
    discount_type: Optional[str] = None
    discount_value: Optional[Decimal] = None
    min_order_amount: Optional[Decimal] = None
    max_discount: Optional[Decimal] = None
    usage_limit: Optional[int] = None
    per_customer_limit: Optional[int] = None
    applies_to: Optional[str] = None
    product_ids: Optional[str] = None
    category_ids: Optional[str] = None
    is_active: Optional[bool] = None
    starts_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None


# ---------------------------------------------------------------------------
# Response
# ---------------------------------------------------------------------------

class CouponResponse(CouponBase):
    id: int
    seller_id: int
    shop_id: Optional[int] = None
    usage_count: int = 0
    created_at: datetime
    updated_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


# ---------------------------------------------------------------------------
# Validate
# ---------------------------------------------------------------------------

class CouponValidateRequest(BaseModel):
    code: str
    shop_id: Optional[int] = None
    shop_slug: Optional[str] = None
    total_amount: Decimal = Field(..., gt=0)
    product_ids: Optional[list[int]] = None
    customer_phone: Optional[str] = None


class CouponValidateResponse(BaseModel):
    valid: bool
    discount_amount: Decimal = Decimal("0.00")
    message: str = ""
    coupon: Optional[CouponResponse] = None


# ---------------------------------------------------------------------------
# List
# ---------------------------------------------------------------------------

class CouponListResponse(BaseModel):
    items: list[CouponResponse]
    total: int
