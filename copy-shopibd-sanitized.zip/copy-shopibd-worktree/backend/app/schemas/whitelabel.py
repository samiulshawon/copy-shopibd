"""
White-label / custom domain Pydantic schemas for ShopiBD.

These schemas are used by the whitelabel API endpoints for domain
verification and branding settings management.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field


# ---------------------------------------------------------------------------
# Branding settings
# ---------------------------------------------------------------------------


class BrandingSettings(BaseModel):
    """Custom branding appearance for a seller shop."""

    primary_color: str = Field(
        default="#1a73e8",
        description="Primary brand color (hex)",
        pattern="^#[0-9a-fA-F]{6}$",
    )
    secondary_color: str = Field(
        default="#34a853",
        description="Secondary brand color (hex)",
        pattern="^#[0-9a-fA-F]{6}$",
    )
    font_family: str = Field(
        default="Inter, sans-serif",
        description="Font family for the storefront",
    )
    logo_url: Optional[str] = Field(
        default=None,
        description="Custom logo image URL",
    )
    favicon_url: Optional[str] = Field(
        default=None,
        description="Custom favicon image URL",
    )
    custom_css: Optional[str] = Field(
        default=None,
        description="Custom CSS injected into the storefront",
    )


# ---------------------------------------------------------------------------
# Domain requests & verification
# ---------------------------------------------------------------------------


class DomainRequest(BaseModel):
    """Request to set a custom domain for a shop."""

    domain: str = Field(
        ...,
        description="Custom domain name (e.g. rinascollection.com)",
        min_length=1,
        max_length=255,
    )


class DomainVerifyResponse(BaseModel):
    """Response returned when verification status is checked or initiated."""

    verified: bool = Field(
        default=False,
        description="Whether the domain has been successfully verified",
    )
    dns_records: List[Dict[str, str]] = Field(
        default_factory=list,
        description="DNS records the user must add to their domain",
    )
    message: str = Field(
        default="",
        description="Human-readable status message",
    )


# ---------------------------------------------------------------------------
# Subdomain request
# ---------------------------------------------------------------------------


class SubdomainRequest(BaseModel):
    """Request to set a custom subdomain for a shop."""

    subdomain: str = Field(
        ...,
        description="Desired subdomain (e.g. 'rina' for rina.shopibd.com)",
        min_length=1,
        max_length=63,
        pattern=r"^[a-z0-9]([a-z0-9-]*[a-z0-9])?$",
    )


# ---------------------------------------------------------------------------
# White-label status (combined response)
# ---------------------------------------------------------------------------


class WhiteLabelStatus(BaseModel):
    """Full white-label and custom domain status for the seller's shop."""

    custom_domain: Optional[str] = Field(
        default=None,
        description="Currently set custom domain (if any)",
    )
    subdomain: Optional[str] = Field(
        default=None,
        description="Currently set subdomain (if any)",
    )
    domain_verified: bool = Field(
        default=False,
        description="Whether the custom domain has been verified",
    )
    domain_verified_at: Optional[datetime] = Field(
        default=None,
        description="When the domain was verified",
    )
    ssl_provisioned: bool = Field(
        default=False,
        description="Whether SSL has been provisioned for the domain",
    )
    branding: Optional[BrandingSettings] = Field(
        default=None,
        description="Current branding settings",
    )
    hide_branding: bool = Field(
        default=False,
        description="Whether 'Powered by ShopiBD' is hidden",
    )

    model_config = ConfigDict(from_attributes=True)
