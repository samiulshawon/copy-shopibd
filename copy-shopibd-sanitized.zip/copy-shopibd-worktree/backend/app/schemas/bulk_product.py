"""Pydantic schemas for bulk product operations."""

from typing import Optional

from pydantic import BaseModel


class BulkProductItem(BaseModel):
    """A single product within a bulk-create request."""

    name: str
    description: Optional[str] = None
    price: float = 0.0
    stock: int = 0
    sku: Optional[str] = None
    category_id: Optional[int] = None
    is_active: bool = True


class BulkCreateRequest(BaseModel):
    """Request body for POST /products/bulk."""

    products: list[BulkProductItem]


class BulkCreateResult(BaseModel):
    """Result of a bulk-create operation."""

    created: int
    failed: list[dict]


class BulkStockItem(BaseModel):
    """A product ID and its new stock value."""

    id: int
    stock: int


class BulkStockUpdateRequest(BaseModel):
    """Request body for PUT /products/bulk/stock."""

    products: list[BulkStockItem]


class BulkStockUpdateResult(BaseModel):
    """Result of a bulk stock update."""

    updated: int


class BulkPriceUpdateRequest(BaseModel):
    """Request body for PUT /products/bulk/price.

    - type: "fixed" adds value to current price.
    - type: "percentage" multiplies price by (1 + value/100).
    - product_ids: optional list of product IDs to update (None = all).
    """

    type: str  # "fixed" or "percentage"
    value: float
    product_ids: Optional[list[int]] = None


class BulkPriceUpdateResult(BaseModel):
    """Result of a bulk price update."""

    updated: int


class ImportResult(BaseModel):
    """Result of a CSV import operation."""

    total: int
    created: int
    failed: list[dict]


class ExportProductRow(BaseModel):
    """A single row in the CSV export."""

    name: str
    description: Optional[str] = None
    price: float
    stock: int
    category: Optional[str] = None
    sku: Optional[str] = None
