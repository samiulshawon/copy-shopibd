from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class ReviewCreate(BaseModel):
    product_id: int
    buyer_name: str
    buyer_phone: str
    rating: int = Field(..., ge=1, le=5)
    title: Optional[str] = None
    body: str


class ReviewPublic(BaseModel):
    id: int
    product_id: int
    buyer_name: str
    rating: int
    title: Optional[str] = None
    body: str
    reply_text: Optional[str] = None
    created_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


class ReviewResponse(BaseModel):
    id: int
    product_id: int
    order_id: Optional[int] = None
    buyer_name: str
    buyer_phone: str
    rating: int
    title: Optional[str] = None
    body: str
    is_approved: bool
    is_replied: bool
    reply_text: Optional[str] = None
    reply_date: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


class ReviewReject(BaseModel):
    rejection_reason: Optional[str] = None
