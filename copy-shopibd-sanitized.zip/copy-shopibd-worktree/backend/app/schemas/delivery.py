from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from enum import Enum
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field

from app.schemas.common import PaginatedResponse


class CourierEnum(str, Enum):
    STEADFAST = "steadfast"
    ECOURIER = "ecourier"
    PATHAO = "pathao"
    REDX = "redx"
    MANUAL = "manual"


class ShipmentStatusEnum(str, Enum):
    PENDING = "pending"
    PICKED_UP = "picked_up"
    IN_TRANSIT = "in_transit"
    DELIVERED = "delivered"
    RETURNED = "returned"
    FAILED = "failed"


# ---------------------------------------------------------------------------
# Create / Update schemas
# ---------------------------------------------------------------------------


class DeliveryCreate(BaseModel):
    order_id: int = Field(..., description="Order ID to create shipment for")
    courier_name: CourierEnum = Field(
        ..., description="Courier service provider"
    )
    pickup_address: str = Field(
        ..., description="Pickup address for the courier"
    )
    weight_kg: Optional[float] = Field(
        None, description="Package weight in kilograms"
    )
    cod_amount: Optional[float] = Field(
        None, description="Cash on delivery amount"
    )


class DeliveryStatusUpdate(BaseModel):
    status: ShipmentStatusEnum = Field(
        ..., description="New shipment status"
    )
    tracking_number: Optional[str] = Field(
        None, description="Tracking number provided by courier"
    )
    notes: Optional[str] = Field(None, description="Additional notes")


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class DeliveryResponse(BaseModel):
    id: int
    order_id: int
    seller_id: int
    courier_name: CourierEnum
    tracking_number: Optional[str] = None
    shipment_status: ShipmentStatusEnum
    pickup_address: str
    delivery_address: str
    weight_kg: Optional[float] = None
    cod_amount: Optional[float] = None
    shipping_cost: Optional[float] = None
    estimated_delivery_date: Optional[date] = None
    delivered_at: Optional[datetime] = None
    notes: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


class DeliveryListItem(BaseModel):
    id: int
    order_id: int
    courier_name: CourierEnum
    tracking_number: Optional[str] = None
    shipment_status: ShipmentStatusEnum
    cod_amount: Optional[float] = None
    shipping_cost: Optional[float] = None
    estimated_delivery_date: Optional[date] = None
    created_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


# ---------------------------------------------------------------------------
# Paginated response
# ---------------------------------------------------------------------------


class DeliveryListResponse(PaginatedResponse[DeliveryListItem]):
    pass
