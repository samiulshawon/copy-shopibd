"""Pydantic schemas for Customer CRM."""

from datetime import datetime
from decimal import Decimal
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class CustomerListItem(BaseModel):
    id: int
    name: str
    phone: str
    total_orders: int
    total_spent: float
    segment: str
    last_order_date: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


class CustomerResponse(BaseModel):
    id: int
    name: str
    phone: str
    email: Optional[str] = None
    total_orders: int
    total_spent: float
    last_order_date: Optional[datetime] = None
    tags: Optional[str] = None
    notes: Optional[str] = None
    segment: str
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class CustomerUpdate(BaseModel):
    notes: Optional[str] = None
    tags: Optional[str] = None
    segment: Optional[str] = None


class CustomerListResponse(BaseModel):
    items: list[CustomerListItem]
    total: int
    page: int
    page_size: int
    total_pages: int


class BroadcastRequest(BaseModel):
    segment: str = Field(..., description="Target customer segment")
    message: str = Field(..., min_length=1, max_length=4096, description="WhatsApp message text")


class BroadcastResponse(BaseModel):
    message: str
    total_customers: int
    messages_sent: int
