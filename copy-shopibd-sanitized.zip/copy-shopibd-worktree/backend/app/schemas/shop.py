from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, HttpUrl


class ShopBase(BaseModel):
    name: str
    description: Optional[str] = None
    logo_url: Optional[HttpUrl] = None
    is_active: bool = True


class ShopCreate(ShopBase):
    slug: Optional[str] = None  # Auto-generated from name if not provided
    contact_phone: Optional[str] = None
    bkash_number: Optional[str] = None
    nagad_number: Optional[str] = None


class ShopUpdate(BaseModel):
    name: Optional[str] = None
    slug: Optional[str] = None
    description: Optional[str] = None
    logo_url: Optional[HttpUrl] = None
    is_active: Optional[bool] = None
    contact_phone: Optional[str] = None
    bkash_number: Optional[str] = None
    nagad_number: Optional[str] = None
    rocket_number: Optional[str] = None
    delivery_settings: Optional[Dict[str, Any]] = None


class ShopResponse(ShopBase):
    id: int
    slug: str
    seller_id: int
    contact_phone: str = ""
    bkash_number: Optional[str] = None
    nagad_number: Optional[str] = None
    rocket_number: Optional[str] = None
    delivery_settings: Optional[Dict[str, Any]] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


class ProductPublic(BaseModel):
    """Storefront-facing product data."""

    id: int
    name: str
    description: Optional[str] = None
    price: float
    stock: int
    sku: Optional[str] = None
    is_active: bool = True
    primary_image_url: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)


class CategoryPublic(BaseModel):
    """Storefront-facing category data."""

    id: int
    name_bn: str
    name_en: Optional[str] = None
    description: Optional[str] = None
    sort_order: int = 0
    is_active: bool = True

    model_config = ConfigDict(from_attributes=True)


class ShopPublic(BaseModel):
    """Storefront-facing shop data (no seller info)."""

    id: int
    name: str
    slug: str
    description: Optional[str] = None
    logo_url: Optional[HttpUrl] = None
    is_active: bool = True
    products: List[ProductPublic] = []
    banner_url: Optional[str] = None
    contact_phone: str = ""
    bkash_number: Optional[str] = None
    nagad_number: Optional[str] = None
    categories: List[CategoryPublic] = []

    model_config = ConfigDict(from_attributes=True)
