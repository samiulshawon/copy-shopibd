from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class PaymentMethodEnum(str, Enum):
    BKASH = "bkash"
    NAGAD = "nagad"
    ROCKET = "rocket"
    COD = "cod"
    BANK = "bank"


class PaymentStatusEnum(str, Enum):
    PENDING = "pending"
    VERIFIED = "verified"
    MISMATCHED = "mismatched"
    UNMATCHED = "unmatched"


# ---------------------------------------------------------------------------
# Parse SMS
# ---------------------------------------------------------------------------


class SmsParseRequest(BaseModel):
    raw_sms_text: str = Field(
        ..., description="Raw SMS text pasted by the seller", min_length=1
    )


class ParsedSmsData(BaseModel):
    provider: Optional[str] = Field(None, description="bkash / nagad / unknown")
    amount: Optional[float] = Field(None, description="Extracted amount")
    sender_phone: Optional[str] = Field(None, description="Sender phone number")
    trx_id: Optional[str] = Field(None, description="Transaction ID")
    balance: Optional[float] = Field(None, description="Remaining balance")
    raw_text: str = Field(..., description="Original SMS text")


# ---------------------------------------------------------------------------
# Create / Response
# ---------------------------------------------------------------------------


class PaymentTransactionCreate(BaseModel):
    raw_sms_text: Optional[str] = Field(None, description="Raw SMS text")
    amount: Optional[float] = Field(None, description="Transaction amount")
    sender_phone: Optional[str] = Field(None, description="Sender phone number")
    reference: Optional[str] = Field(None, description="Transaction reference/ID")
    payment_method: PaymentMethodEnum = Field(
        ..., description="Payment method (bkash/nagad/rocket/cod/bank)"
    )
    notes: Optional[str] = Field(None, description="Optional notes")


class PaymentTransactionResponse(BaseModel):
    id: int
    order_id: Optional[int] = None
    seller_id: int
    shop_id: int
    amount: Optional[float] = None
    currency: str = "BDT"
    payment_method: PaymentMethodEnum
    sender_phone: Optional[str] = None
    reference: Optional[str] = None
    status: PaymentStatusEnum
    matched_order_id: Optional[int] = None
    raw_sms_text: Optional[str] = None
    verified_by: Optional[str] = None
    verified_at: Optional[datetime] = None
    notes: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


class PaymentTransactionListItem(BaseModel):
    id: int
    amount: Optional[float] = None
    currency: str = "BDT"
    payment_method: PaymentMethodEnum
    sender_phone: Optional[str] = None
    reference: Optional[str] = None
    status: PaymentStatusEnum
    matched_order_id: Optional[int] = None
    verified_by: Optional[str] = None
    created_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


# ---------------------------------------------------------------------------
# Match / Unmatch
# ---------------------------------------------------------------------------


class PaymentMatchRequest(BaseModel):
    transaction_id: int = Field(..., description="Payment transaction ID")
    order_id: int = Field(..., description="Order ID to match against")


class PaymentUnmatchRequest(BaseModel):
    transaction_id: int = Field(..., description="Payment transaction ID")


# ---------------------------------------------------------------------------
# Reconciliation
# ---------------------------------------------------------------------------


class ReconciliationSummary(BaseModel):
    total_transactions: int = 0
    total_amount: float = 0
    matched: int = 0
    matched_amount: float = 0
    unmatched: int = 0
    unmatched_amount: float = 0
    pending: int = 0
    pending_amount: float = 0


# ---------------------------------------------------------------------------
# Auto-match suggestions
# ---------------------------------------------------------------------------


class MatchSuggestion(BaseModel):
    transaction_id: int
    transaction_amount: float
    transaction_reference: Optional[str] = None
    transaction_method: PaymentMethodEnum
    transaction_created_at: Optional[datetime] = None
    order_id: int
    order_number: str
    order_amount: float
    customer_name: str
    customer_phone: str
    confidence: float = Field(
        ..., ge=0, le=100, description="Match confidence score (0-100)"
    )
    match_reasons: list[str] = Field(
        default_factory=list, description="Why this match is suggested"
    )
