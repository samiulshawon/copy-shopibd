"""Pydantic schemas for analytics endpoints."""

from pydantic import BaseModel


class DashboardStats(BaseModel):
    """Aggregated dashboard metrics for the authenticated seller."""

    today_orders: int = 0
    today_revenue: float = 0.0
    pending_orders: int = 0
    low_stock_count: int = 0
    total_products: int = 0
    total_orders: int = 0


class SalesDataPoint(BaseModel):
    """Daily sales data point for charting."""

    date: str
    revenue: float
    orders: int


class SalesChartResponse(BaseModel):
    """Response wrapper for sales chart data."""

    period: str
    data: list[SalesDataPoint]


class TopProduct(BaseModel):
    """Top-selling product summary."""

    product_id: int
    product_name: str
    total_quantity: int
    total_revenue: float
    order_count: int


class TopProductsResponse(BaseModel):
    """Response wrapper for top products."""

    items: list[TopProduct]


class StatusBreakdown(BaseModel):
    """Order count grouped by status."""

    status: str
    count: int