"""
Category management endpoints for ShopiBD.

Supports full CRUD with seller-scoped filtering, pagination, and
parent-child category relationships.
"""

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.seller import Seller
from app.models.category import Category
from app.api.v1.dependencies import get_current_seller
from app.schemas.category import (
    CategoryCreate,
    CategoryResponse,
    CategoryUpdate,
)
from app.schemas.common import PaginatedResponse

router = APIRouter(prefix="/categories", tags=["categories"])


@router.get("/", response_model=PaginatedResponse[CategoryResponse])
async def list_categories(
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(
        20, ge=1, le=100, description="Items per page"
    ),
    seller_id: int | None = Query(
        None, description="Filter by seller ID"
    ),
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    List categories with pagination.

    If the requesting seller is not a super-admin, results are
    automatically scoped to their own categories.  Admins may pass
    an optional ``seller_id`` to filter by a specific seller.
    """
    # Build the base query
    base_query = select(Category)

    # Scope to current seller unless they are an admin (is_verified)
    if seller_id is not None and current_seller.is_verified:
        base_query = base_query.where(Category.seller_id == seller_id)
    else:
        base_query = base_query.where(
            Category.seller_id == current_seller.id
        )

    # Count total
    count_stmt = select(func.count()).select_from(base_query.subquery())
    total = db.execute(count_stmt).scalar() or 0

    # Paginate
    offset = (page - 1) * page_size
    stmt = base_query.order_by(Category.sort_order, Category.name_bn).offset(
        offset
    ).limit(page_size)
    items = db.execute(stmt).scalars().all()

    return PaginatedResponse(
        items=items,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=(total + page_size - 1) // page_size if total else 0,
    )


@router.post("/", response_model=CategoryResponse, status_code=status.HTTP_201_CREATED)
async def create_category(
    payload: CategoryCreate,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> Category:
    """
    Create a new category for the authenticated seller.

    Optionally link to a parent category via ``parent_id``.  The
    parent must belong to the same seller.
    """
    # Validate parent if provided
    if payload.parent_id is not None:
        parent_stmt = select(Category).where(
            Category.id == payload.parent_id,
            Category.seller_id == current_seller.id,
        )
        parent = db.execute(parent_stmt).scalar_one_or_none()
        if parent is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Parent category not found or does not belong to you",
            )

    category = Category(
        seller_id=current_seller.id,
        **payload.model_dump(),
    )
    db.add(category)
    db.commit()
    db.refresh(category)
    return category


@router.get("/{category_id}", response_model=CategoryResponse)
async def get_category(
    category_id: int,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> Category:
    """
    Retrieve a single category by its ID.

    The category must belong to the authenticated seller (or the
    seller must be a verified admin).
    """
    stmt = select(Category).where(Category.id == category_id)
    category = db.execute(stmt).scalar_one_or_none()
    if category is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Category not found",
        )

    # Ownership check
    if category.seller_id != current_seller.id and not current_seller.is_verified:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have access to this category",
        )

    return category


@router.put("/{category_id}", response_model=CategoryResponse)
async def update_category(
    category_id: int,
    payload: CategoryUpdate,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> Category:
    """
    Update an existing category.

    Only the category owner can modify it.  When changing ``parent_id``
    the new parent must belong to the same seller and cannot be the
    category itself (circular reference protection).
    """
    stmt = select(Category).where(
        Category.id == category_id,
        Category.seller_id == current_seller.id,
    )
    category = db.execute(stmt).scalar_one_or_none()
    if category is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Category not found or does not belong to you",
        )

    # Validate new parent
    if payload.parent_id is not None:
        if payload.parent_id == category.id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="A category cannot be its own parent",
            )
        parent_stmt = select(Category).where(
            Category.id == payload.parent_id,
            Category.seller_id == current_seller.id,
        )
        parent = db.execute(parent_stmt).scalar_one_or_none()
        if parent is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Parent category not found or does not belong to you",
            )

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(category, field, value)

    db.commit()
    db.refresh(category)
    return category


@router.delete("/{category_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_category(
    category_id: int,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> None:
    """
    Delete a category by its ID.

    Only the category owner can delete it.  Child categories that
    reference this one as their parent will have their ``parent_id``
    set to ``NULL`` (cascade set-null).
    """
    stmt = select(Category).where(
        Category.id == category_id,
        Category.seller_id == current_seller.id,
    )
    category = db.execute(stmt).scalar_one_or_none()
    if category is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Category not found or does not belong to you",
        )

    # Orphan children before deleting
    children_stmt = select(Category).where(
        Category.parent_id == category.id
    )
    children = db.execute(children_stmt).scalars().all()
    for child in children:
        child.parent_id = None

    db.delete(category)
    db.commit()
