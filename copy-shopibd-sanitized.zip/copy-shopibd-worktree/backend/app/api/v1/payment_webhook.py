"""
Payment webhook endpoints for ShopiBD.

Handles callbacks from bKash and Nagad after a buyer completes (or cancels)
a payment on the mobile app.
"""

from __future__ import annotations

import json
import logging
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.order import Order
from app.models.payment import PaymentMethod, PaymentStatus, PaymentTransaction
from app.models.seller import Seller
from app.models.subscription import Subscription, SubscriptionStatus
from app.services.payment.bkash import BKashPaymentProvider
from app.services.payment.nagad import NagadPaymentProvider
from app.services.payment.sslcommerz import SSLCommerzPaymentProvider
from app.services.subscription_payments import activate_subscription as activate_sub

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/payment-webhook", tags=["payment-webhook"])


# ---------------------------------------------------------------------------
# POST /payment-webhook/bkash
# ---------------------------------------------------------------------------


@router.post("/bkash")
async def bkash_webhook(
    request: Request,
    db: Session = Depends(get_db),
):
    """
    Handle bKash payment callback.

    bKash calls this URL (as POST) after the buyer completes payment
    on the bKash app. The body contains paymentID and status.

    Flow:
    1. Receive callback with paymentID
    2. Call bKash execute API to confirm payment
    3. Update PaymentTransaction and Order records
    4. Return 200 to bKash
    """
    body: dict = await request.json()
    logger.info("bKash webhook received: %s", body)

    payment_id: Optional[str] = body.get("paymentID")
    status_val: Optional[str] = body.get("status", "").lower()

    if not payment_id:
        logger.warning("bKash webhook missing paymentID")
        return {"statusCode": "4001", "statusMessage": "Missing paymentID"}

    # If cancelled or failed, mark accordingly
    if status_val in ("cancel", "failure"):
        logger.info("bKash payment %s was %s", payment_id, status_val)
        return {"statusCode": "0000", "statusMessage": "Accepted"}

    try:
        provider = BKashPaymentProvider()

        # Execute the payment on bKash side
        exec_result = await provider.execute_payment(payment_id)

        if exec_result.get("transactionStatus") != "Completed":
            logger.warning(
                "bKash execute returned non-completed: %s",
                exec_result.get("statusMessage"),
            )
            return {"statusCode": "0000", "statusMessage": "Accepted"}

        trx_id = exec_result.get("trxID", payment_id)
        amount = Decimal(str(exec_result.get("amount", "0")))
        merchant_invoice = exec_result.get("merchantInvoiceNumber", "")

        # Find the order by invoice number
        order = _find_order_by_invoice(db, merchant_invoice)

        if order is None:
            logger.warning(
                "Order not found for invoice %s. Creating orphan transaction.",
                merchant_invoice,
            )
            # Create an unmatched transaction
            tx = PaymentTransaction(
                seller_id=0,  # Will need manual matching
                shop_id=0,
                amount=amount,
                currency="BDT",
                payment_method=PaymentMethod.BKASH,
                reference=trx_id,
                status=PaymentStatus.PENDING,
                verified_by="api",
                notes=f"bKash callback: {json.dumps(exec_result)}",
            )
            db.add(tx)
            db.commit()
        else:
            # Update order payment status
            order.payment_status = "paid"

            # Create a verified payment transaction
            tx = PaymentTransaction(
                order_id=order.id,
                seller_id=order.shop.seller_id if order.shop else 0,
                shop_id=order.shop_id,
                amount=amount,
                currency="BDT",
                payment_method=PaymentMethod.BKASH,
                reference=trx_id,
                status=PaymentStatus.VERIFIED,
                verified_by="api",
                notes=f"bKash auto-verified: {trx_id}",
            )
            db.add(tx)
            db.commit()

        logger.info("bKash payment %s processed successfully. trxID=%s", payment_id, trx_id)

    except Exception as exc:
        logger.exception("bKash webhook processing failed: %s", exc)
        # Still return 200 to prevent bKash from retrying excessively
        return {"statusCode": "0000", "statusMessage": "Accepted"}

    return {"statusCode": "0000", "statusMessage": "Successful"}


# ---------------------------------------------------------------------------
# GET /payment-webhook/bkash  (also handle GET callbacks)
# ---------------------------------------------------------------------------


@router.get("/bkash")
async def bkash_webhook_get(
    paymentID: Optional[str] = None,
    status: Optional[str] = None,
    db: Session = Depends(get_db),
):
    """
    Handle bKash GET callback (some bKash versions use GET).

    Query params:
      - paymentID: bKash payment ID
      - status: success / failure / cancel
    """
    logger.info("bKash webhook GET: paymentID=%s status=%s", paymentID, status)

    if not paymentID:
        return {"statusCode": "4001", "statusMessage": "Missing paymentID"}

    if status and status.lower() in ("cancel", "failure"):
        return {"statusCode": "0000", "statusMessage": "Accepted"}

    try:
        provider = BKashPaymentProvider()
        exec_result = await provider.execute_payment(paymentID)

        if exec_result.get("transactionStatus") == "Completed":
            trx_id = exec_result.get("trxID", paymentID)
            amount = Decimal(str(exec_result.get("amount", "0")))
            merchant_invoice = exec_result.get("merchantInvoiceNumber", "")

            order = _find_order_by_invoice(db, merchant_invoice)

            if order:
                order.payment_status = "paid"
                tx = PaymentTransaction(
                    order_id=order.id,
                    seller_id=order.shop.seller_id if order.shop else 0,
                    shop_id=order.shop_id,
                    amount=amount,
                    currency="BDT",
                    payment_method=PaymentMethod.BKASH,
                    reference=trx_id,
                    status=PaymentStatus.VERIFIED,
                    verified_by="api",
                    notes=f"bKash auto-verified (GET): {trx_id}",
                )
                db.add(tx)
                db.commit()

    except Exception as exc:
        logger.exception("bKash GET webhook failed: %s", exc)

    return {"statusCode": "0000", "statusMessage": "Successful"}


# ---------------------------------------------------------------------------
# POST /payment-webhook/nagad
# ---------------------------------------------------------------------------


@router.post("/nagad")
async def nagad_webhook(
    request: Request,
    db: Session = Depends(get_db),
):
    """
    Handle Nagad payment callback.

    Nagad sends a POST with payment_ref_id and status after the buyer
    completes payment on the Nagad app.
    """
    body: dict = await request.json()
    logger.info("Nagad webhook received: %s", body)

    payment_ref_id: Optional[str] = body.get("payment_ref_id")
    status_val: Optional[str] = body.get("status", "").lower()

    if not payment_ref_id:
        logger.warning("Nagad webhook missing payment_ref_id")
        return {"statusCode": "4001", "statusMessage": "Missing payment_ref_id"}

    if status_val in ("cancel", "failure"):
        logger.info("Nagad payment %s was %s", payment_ref_id, status_val)
        return {"statusCode": "0000", "statusMessage": "Accepted"}

    try:
        provider = NagadPaymentProvider()
        verify_result = await provider.query_payment(payment_ref_id)

        if verify_result.get("status") == "Success":
            trx_id = verify_result.get("trxID", payment_ref_id)
            amount = Decimal(str(verify_result.get("amount", "0")))
            invoice_no = verify_result.get("merchantInvoiceNumber", "")

            order = _find_order_by_invoice(db, invoice_no)

            if order:
                order.payment_status = "paid"
                tx = PaymentTransaction(
                    order_id=order.id,
                    seller_id=order.shop.seller_id if order.shop else 0,
                    shop_id=order.shop_id,
                    amount=amount,
                    currency="BDT",
                    payment_method=PaymentMethod.NAGAD,
                    reference=trx_id,
                    status=PaymentStatus.VERIFIED,
                    verified_by="api",
                    notes=f"Nagad auto-verified: {trx_id}",
                )
                db.add(tx)
                db.commit()
                logger.info("Nagad payment %s processed. trxID=%s", payment_ref_id, trx_id)
            else:
                logger.warning("Order not found for invoice %s", invoice_no)

    except Exception as exc:
        logger.exception("Nagad webhook processing failed: %s", exc)

    return {"statusCode": "0000", "statusMessage": "Successful"}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _find_order_by_invoice(db: Session, invoice: str) -> Optional[Order]:
    """Find an order by its order_number (merchant invoice number)."""
    if not invoice:
        return None
    stmt = select(Order).where(Order.order_number == invoice.strip())
    return db.execute(stmt).scalar_one_or_none()


# ---------------------------------------------------------------------------
# POST /payment-webhook/subscription
# ---------------------------------------------------------------------------


@router.post("/subscription")
async def subscription_webhook(
    request: Request,
    db: Session = Depends(get_db),
):
    """
    Handle subscription payment callbacks from all payment providers.

    The webhook receives payment confirmation and activates the subscription.
    Expected query/body params:
    - payment_gateway: bkash/nagad/sslcommerz/manual
    - payment_id: The payment ID from the provider
    - status: success/failed/cancelled
    - seller_id: The seller's ID (optional, can be derived from payment)

    For bKash/Nagad/SSLCommerz, the payment gateway sends specific callbacks.
    This endpoint handles the generic case and can be extended for each provider.
    """
    body = await request.json()
    logger.info("Subscription webhook received: %s", body)

    payment_gateway = body.get("payment_gateway") or body.get("provider")
    payment_id = body.get("payment_id") or body.get("paymentID") or body.get("payment_ref_id")
    status_val = body.get("status", "").lower()
    seller_id = body.get("seller_id")
    plan_key = body.get("plan")

    if not payment_gateway:
        logger.warning("Subscription webhook missing payment_gateway")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Missing payment_gateway",
        )

    if not payment_id:
        logger.warning("Subscription webhook missing payment_id")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Missing payment_id",
        )

    if status_val in ("cancel", "cancelled", "failure", "failed"):
        logger.info("Subscription payment %s was %s", payment_id, status_val)
        return {"statusCode": "0000", "statusMessage": "Accepted"}

    # Find seller if not provided
    if not seller_id:
        # Try to find by payment_gateway_subscription_id
        stmt = select(Subscription).where(
            Subscription.payment_gateway == payment_gateway,
            Subscription.payment_gateway_subscription_id == payment_id,
            Subscription.status == SubscriptionStatus.TRIALING,
        )
        subscription = db.execute(stmt).scalar_one_or_none()
        if subscription:
            seller_id = subscription.seller_id

    if not seller_id:
        logger.warning("Could not determine seller_id for subscription payment %s", payment_id)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Could not identify seller for subscription",
        )

    # Determine plan from subscription if not in body
    if not plan_key:
        stmt = select(Subscription).where(
            Subscription.seller_id == seller_id,
            Subscription.status == SubscriptionStatus.TRIALING,
        )
        subscription = db.execute(stmt).scalar_one_or_none()
        if subscription and subscription.plan:
            plan_key = subscription.plan.value

    if not plan_key:
        logger.warning("Could not determine plan for subscription payment %s", payment_id)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Could not determine subscription plan",
        )

    # Verify payment with the provider
    try:
        if payment_gateway == "bkash":
            provider = BKashPaymentProvider()
            exec_result = await provider.execute_payment(payment_id)
            if exec_result.get("transactionStatus") != "Completed":
                logger.warning("bKash subscription payment not completed: %s", exec_result.get("statusMessage"))
                return {"statusCode": "0000", "statusMessage": "Accepted"}
            payment_gateway_subscription_id = exec_result.get("trxID", payment_id)

        elif payment_gateway == "nagad":
            provider = NagadPaymentProvider()
            verify_result = await provider.query_payment(payment_id)
            if verify_result.get("status") != "Success":
                logger.warning("Nagad subscription payment not successful: %s", verify_result.get("message"))
                return {"statusCode": "0000", "statusMessage": "Accepted"}
            payment_gateway_subscription_id = verify_result.get("trxID", payment_id)

        elif payment_gateway == "sslcommerz":
            provider = SSLCommerzPaymentProvider()
            verify_result = await provider.validate_payment(payment_id)
            if not verify_result.get("valid"):
                logger.warning("SSLCommerz subscription payment not valid: %s", verify_result.get("message"))
                return {"statusCode": "0000", "statusMessage": "Accepted"}
            payment_gateway_subscription_id = verify_result.get("tran_id", payment_id)

        elif payment_gateway == "manual":
            # Manual payment - just activate
            payment_gateway_subscription_id = payment_id

        else:
            logger.warning("Unknown payment gateway for subscription: %s", payment_gateway)
            return {"statusCode": "0000", "statusMessage": "Accepted"}

        # Activate the subscription
        await activate_sub(
            db=db,
            seller_id=seller_id,
            plan_key=plan_key,
            payment_gateway=payment_gateway,
            payment_gateway_subscription_id=payment_gateway_subscription_id,
            auto_renew=True,
        )

        logger.info("Subscription activated for seller %s, plan %s", seller_id, plan_key)
        return {"statusCode": "0000", "statusMessage": "Successful"}

    except Exception as exc:
        logger.exception("Subscription webhook processing failed: %s", exc)
        # Return 200 to prevent retries for non-retryable errors
        return {"statusCode": "0000", "statusMessage": "Accepted"}


# Provider-specific subscription webhooks (optional, can redirect to generic)


@router.post("/subscription/bkash")
async def bkash_subscription_webhook(
    request: Request,
    db: Session = Depends(get_db),
):
    """Handle bKash subscription payment callback specifically."""
    body = await request.json()
    body["payment_gateway"] = "bkash"
    return await subscription_webhook(request, db)


@router.post("/subscription/nagad")
async def nagad_subscription_webhook(
    request: Request,
    db: Session = Depends(get_db),
):
    """Handle Nagad subscription payment callback specifically."""
    body = await request.json()
    body["payment_gateway"] = "nagad"
    return await subscription_webhook(request, db)


@router.post("/subscription/sslcommerz")
async def sslcommerz_subscription_webhook(
    request: Request,
    db: Session = Depends(get_db),
):
    """Handle SSLCommerz subscription payment callback specifically."""
    body = await request.json()
    body["payment_gateway"] = "sslcommerz"
    return await subscription_webhook(request, db)


