"""
Admin-only endpoints for ShopiBD.

All routes in this module require the requesting seller to be a
verified administrator (``is_verified == True``).

Provides seller management, cross-seller order listing, and a
review moderation workflow.
"""

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.context import get_current_seller_id_or_default, set_current_seller_id
from app.core.database import get_db
from app.core.security import (
    create_access_token,
    get_password_hash,
    verify_password,
)
from app.models.audit_log import AuditLog
from app.models.order import Order
from app.models.seller import Seller
from app.models.shop import Shop
from app.models.subscription import (
    Subscription,
    SubscriptionPlan,
    SubscriptionStatus,
)
from app.schemas.subscription import PLANS
from app.api.v1.dependencies import get_current_admin_seller, get_current_super_admin
from app.schemas.seller import (
    Seller as SellerSchema,
    SellerCreate,
    SellerUpdate,
    SubscriptionOverride,
)
from app.services.audit_helper import log_admin_action
from app.services.plan_capabilities import (
    can_use_custom_domain,
    can_use_subdomain,
    reserve_subdomain,
    slugify_base,
)
from app.schemas.order import Order as OrderSchema

router = APIRouter(prefix="/admin", tags=["admin"])


# ──────────────────────────────────────────────
#  Seller management
# ──────────────────────────────────────────────


@router.get("/sellers", response_model=list[SellerSchema])
async def list_all_sellers(
    admin_seller: Seller = Depends(get_current_admin_seller),
    db: Session = Depends(get_db),
):
    """
    List all registered sellers.

    Accessible only by verified administrators.
    """
    stmt = select(Seller).order_by(Seller.id)
    sellers = db.execute(stmt).scalars().all()
    for s in sellers:
        _attach_shop_subdomain(s, db)
    return sellers


def _attach_shop_subdomain(seller: Seller, db: Session) -> None:
    """Populate ``shop_subdomain`` on the seller from its first shop (read-only)."""
    from app.models.shop import Shop

    shop = db.execute(
        select(Shop).where(Shop.seller_id == seller.id).limit(1)
    ).scalars().first()
    if shop is not None:
        seller.shop_subdomain = shop.subdomain
        # Phase 6: surface custom-domain grace info for the admin warning banner.
        seller.shop_custom_domain = shop.custom_domain
        seller.custom_domain_grace_until = shop.custom_domain_grace_until


@router.get("/sellers/{seller_id}", response_model=SellerSchema)
async def get_seller(
    seller_id: int,
    admin_seller: Seller = Depends(get_current_admin_seller),
    db: Session = Depends(get_db),
) -> Seller:
    """
    Retrieve a specific seller by ID.

    Accessible only by verified administrators.
    """
    stmt = select(Seller).where(Seller.id == seller_id)
    seller = db.execute(stmt).scalar_one_or_none()
    if seller is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Seller not found",
        )
    _attach_shop_subdomain(seller, db)
    return seller


@router.put("/sellers/{seller_id}/verify")
async def verify_seller_trade_license(
    seller_id: int,
    admin_seller: Seller = Depends(get_current_admin_seller),
    db: Session = Depends(get_db),
):
    """
    Verify (approve) a seller's trade license.

    Sets the seller's ``is_verified`` flag to ``True``.

    Accessible only by verified administrators.
    """
    stmt = select(Seller).where(Seller.id == seller_id)
    seller = db.execute(stmt).scalar_one_or_none()
    if seller is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Seller not found",
        )

    if seller.is_verified:
        return {
            "message": "Seller is already verified",
            "seller_id": seller.id,
        }

    seller.is_verified = True
    db.commit()
    db.refresh(seller)

    return {
        "message": "Seller trade license verified successfully",
        "seller_id": seller.id,
        "is_verified": seller.is_verified,
    }


# ──────────────────────────────────────────────
#  Cross-seller orders
# ──────────────────────────────────────────────


@router.get("/orders", response_model=list[OrderSchema])
async def list_all_orders(
    shop_id: int | None = None,
    status_filter: str | None = None,
    admin_seller: Seller = Depends(get_current_admin_seller),
    db: Session = Depends(get_db),
):
    """
    List all orders across every seller on the platform.

    Optional query parameters:
    - ``shop_id``      — filter by a specific shop
    - ``status_filter`` — filter by order status (pending, confirmed, etc.)

    Accessible only by verified administrators.
    """
    stmt = select(Order).order_by(Order.created_at.desc())

    if shop_id is not None:
        stmt = stmt.where(Order.shop_id == shop_id)
    if status_filter is not None:
        stmt = stmt.where(Order.status == status_filter)

    orders = db.execute(stmt).scalars().all()
    return orders


# ──────────────────────────────────────────────
#  Super-admin: platform overview
# ──────────────────────────────────────────────


@router.get("/stats", tags=["super-admin"])
async def platform_stats(
    admin_seller: Seller = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    """
    Platform-level summary for the super admin dashboard.

    Returns counts of clients, active shops, plan distribution, total
    revenue (all paid/completed orders), and new signups in the last 7 days.
    """
    total_sellers = db.execute(
        select(func.count(Seller.id)).where(Seller.is_super_admin == False)  # noqa: E712
    ).scalar() or 0

    active_sellers = db.execute(
        select(func.count(Seller.id)).where(
            Seller.is_super_admin == False, Seller.is_active == True  # noqa: E712
        )
    ).scalar() or 0

    total_shops = db.execute(select(func.count(Shop.id))).scalar() or 0
    active_shops = db.execute(
        select(func.count(Shop.id)).where(Shop.is_active == True)  # noqa: E712
    ).scalar() or 0

    # New signups in last 7 days (based on subscription creation, which is
    # created together with each seller)
    since = datetime.now(timezone.utc) - timedelta(days=7)
    new_signups = db.execute(
        select(func.count(Subscription.id)).where(Subscription.created_at >= since)
    ).scalar() or 0

    # Total revenue across all paid/completed orders
    total_revenue = float(
        db.execute(
            select(func.coalesce(func.sum(Order.total_amount), 0)).where(
                Order.payment_status.in_(["paid", "completed"])
            )
        ).scalar()
        or 0
    )

    # Plan distribution (exclude super admins)
    plan_rows = db.execute(
        select(Seller.plan, func.count(Seller.id))
        .where(Seller.is_super_admin == False)  # noqa: E712
        .group_by(Seller.plan)
    ).all()
    plan_distribution = {plan: count for plan, count in plan_rows}

    return {
        "total_sellers": total_sellers,
        "active_sellers": active_sellers,
        "total_shops": total_shops,
        "active_shops": active_shops,
        "new_signups_7d": new_signups,
        "total_revenue": total_revenue,
        "plan_distribution": plan_distribution,
    }


@router.get("/activity", tags=["super-admin"])
async def platform_activity(
    admin_seller: Seller = Depends(get_current_super_admin),
    limit: int = 20,
    db: Session = Depends(get_db),
):
    """
    Recent platform activity feed (audit logs), newest first.
    """
    stmt = select(AuditLog).order_by(AuditLog.created_at.desc()).limit(limit)
    logs = db.execute(stmt).scalars().all()
    return [
        {
            "id": log.id,
            "action": log.action,
            "entity_type": log.entity_type,
            "entity_id": log.entity_id,
            "actor_email": log.actor_email,
            "created_at": log.created_at,
        }
        for log in logs
    ]


def _ensure_actor_session_role(db: Session, role: str) -> None:
    """Set the Postgres ``app.current_seller_role`` GUC on the next transaction.

    Used by super-admin endpoints to bypass RLS (after ``BYPASSRLS`` has been
    granted).  On SQLite (tests) this is a silent no-op.
    """
    try:
        db.execute(
            func.current_setting(  # noqa: F821 (falls back on sqlite)
                "app.current_seller_role", true=True  # type: ignore
            ),
        )
    except Exception:  # noqa: BLE001
        pass
    setattr(db, "_shopibd_role", role)


# ──────────────────────────────────────────────
#  Super-admin: client (seller) management
# ──────────────────────────────────────────────


@router.post(
    "/sellers",
    response_model=SellerSchema,
    status_code=status.HTTP_201_CREATED,
    tags=["super-admin"],
)
async def create_seller(
    payload: SellerCreate,
    admin_seller: Seller = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    """
    Create a new client (seller) as the super admin.

    Auto-creates a FREE-tier subscription for the new seller. The seller
    can later be upgraded via PUT /admin/sellers/{id}/subscription.
    """
    existing = db.execute(
        select(Seller).where(
            (Seller.email == payload.email) | (Seller.phone == payload.phone)
        )
    ).scalar_one_or_none()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email or phone already registered",
        )

    seller = Seller(
        name=payload.name,
        email=payload.email,
        phone=payload.phone,
        password_hash=get_password_hash(payload.password),
        is_active=True,
        is_verified=True,
        is_super_admin=False,
    )
    db.add(seller)
    db.flush()

    # Auto-create a free subscription
    subscription = Subscription(
        seller_id=seller.id,
        plan=SubscriptionPlan.FREE,
        status=SubscriptionStatus.ACTIVE,
        current_period_start=datetime.now(timezone.utc),
        auto_renew=False,
    )
    db.add(subscription)
    db.flush()

    # Auto-create a Shop for the new seller (plan-gated URL assignment)
    shop_name = payload.shop_name or f"{payload.name}'s Shop"

    # Slug — unique, slugified, with -{n} suffix on collision.
    slug = slugify_base(shop_name)[:40]
    if not slug:
        slug = "shop"
    n = 2
    while db.execute(select(Shop).where(Shop.slug == slug)).scalar_one_or_none():
        suffix = f"-{n}"
        slug = (slugify_base(shop_name)[: 40 - len(suffix)]) + suffix
        n += 1

    # Subdomain — every plan (incl. free) is entitled to one.
    subdomain = None
    if can_use_subdomain(seller.plan):
        if payload.subdomain:
            subdomain = slugify_base(payload.subdomain)[:40]
            m = 2
            while db.execute(
                select(Shop).where(Shop.subdomain == subdomain)
            ).scalar_one_or_none():
                suffix = f"-{m}"
                subdomain = (
                    slugify_base(payload.subdomain)[: 40 - len(suffix)]
                ) + suffix
                m += 1
        else:
            subdomain = reserve_subdomain(db, base=shop_name)

    # Custom domain — only Enterprise (and only when explicitly requested).
    custom_domain = None
    if payload.custom_domain:
        if not can_use_custom_domain(seller.plan):
            raise HTTPException(
                status_code=status.HTTP_402_PAYMENT_REQUIRED,
                detail="Custom domain requires an Enterprise plan",
            )
        custom_domain = payload.custom_domain.lower().strip()

    shop = Shop(
        name=shop_name,
        slug=slug,
        description="",
        seller_id=seller.id,
        is_active=True,
        subdomain=subdomain,
        custom_domain=custom_domain,
        domain_verified=False,
    )
    db.add(shop)
    db.flush()
    # Audit log before commit so the row exists with the new seller.
    seller_id_for_audit = seller.id
    log_admin_action(
        db=db,
        actor=admin_seller,
        action="client.create",
        entity_type="seller",
        entity_id=str(seller.id),
        extra_data={
            "plan": seller.plan,
            "shop_slug": slug,
            "subdomain": subdomain,
            "custom_domain": custom_domain,
        },
    )
    db.commit()
    db.refresh(seller)
    # Re-attach shop subdomain for the response shape.
    _ = seller_id_for_audit
    _attach_shop_subdomain(seller, db)
    return seller


@router.put("/sellers/{seller_id}", response_model=SellerSchema, tags=["super-admin"])
async def update_seller(
    seller_id: int,
    payload: SellerUpdate,
    admin_seller: Seller = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    """
    Edit a client's profile (name, phone, active status).
    """
    seller = db.execute(
        select(Seller).where(Seller.id == seller_id)
    ).scalar_one_or_none()
    if seller is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Seller not found")
    if seller.is_super_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cannot edit a super admin account",
        )

    old_values = {"name": seller.name, "phone": seller.phone, "is_active": seller.is_active}
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(seller, field, value)
    new_values = {
        k: v
        for k, v in {
            "name": seller.name,
            "phone": seller.phone,
            "is_active": seller.is_active,
        }.items()
        if old_values.get(k) != v
    }
    log_admin_action(
        db=db,
        actor=admin_seller,
        action="client.update",
        entity_type="seller",
        entity_id=str(seller.id),
        old_values=old_values,
        new_values=new_values or None,
    )
    db.commit()
    db.refresh(seller)
    return seller


@router.post("/sellers/{seller_id}/activate", response_model=SellerSchema, tags=["super-admin"])
async def activate_seller(
    seller_id: int,
    admin_seller: Seller = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    """Activate a client account."""
    seller = db.execute(select(Seller).where(Seller.id == seller_id)).scalar_one_or_none()
    if seller is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Seller not found")
    seller.is_active = True
    log_admin_action(
        db=db,
        actor=admin_seller,
        action="client.activate",
        entity_type="seller",
        entity_id=str(seller.id),
    )
    db.commit()
    db.refresh(seller)
    return seller


@router.post("/sellers/{seller_id}/deactivate", response_model=SellerSchema, tags=["super-admin"])
async def deactivate_seller(
    seller_id: int,
    admin_seller: Seller = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    """Deactivate (suspend) a client account."""
    seller = db.execute(select(Seller).where(Seller.id == seller_id)).scalar_one_or_none()
    if seller is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Seller not found")
    if seller.is_super_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cannot deactivate a super admin account",
        )
    seller.is_active = False
    log_admin_action(
        db=db,
        actor=admin_seller,
        action="client.deactivate",
        entity_type="seller",
        entity_id=str(seller.id),
    )
    db.commit()
    db.refresh(seller)
    return seller


@router.put("/sellers/{seller_id}/subscription", response_model=dict, tags=["super-admin"])
async def override_subscription(
    seller_id: int,
    payload: SubscriptionOverride,
    admin_seller: Seller = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    """
    Super-admin override of a client's subscription plan.

    Directly sets the plan + status (ACTIVE) and updates the seller's
    plan-limit fields. Bypasses payment — intended for internal/manual
    operations (e.g. granting a plan, trial extensions).
    """
    seller = db.execute(select(Seller).where(Seller.id == seller_id)).scalar_one_or_none()
    if seller is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Seller not found")

    # Use a dedicated field from payload if provided; fall back to a query param.
    plan_key = getattr(payload, "plan", None)
    if plan_key is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Plan must be provided in the request body as 'plan'.",
        )
    if plan_key not in PLANS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid plan '{plan_key}'. Valid plans: {', '.join(PLANS.keys())}",
        )

    subscription = db.execute(
        select(Subscription).where(Subscription.seller_id == seller.id)
    ).scalar_one_or_none()
    if subscription is None:
        subscription = Subscription(seller_id=seller.id)
        db.add(subscription)
        db.flush()

    old_plan = subscription.plan.value if subscription.plan else None
    subscription.plan = SubscriptionPlan(plan_key)
    subscription.status = SubscriptionStatus.ACTIVE
    subscription.current_period_start = datetime.now(timezone.utc)
    subscription.current_period_end = datetime.now(timezone.utc) + timedelta(days=30)
    subscription.auto_renew = True

    # Sync seller plan-limit fields
    plan_info = PLANS[plan_key]
    seller.plan = plan_key
    seller.max_products = plan_info.max_products
    seller.max_orders = plan_info.max_orders

    log_admin_action(
        db=db,
        actor=admin_seller,
        action="client.subscription_override",
        entity_type="seller",
        entity_id=str(seller.id),
        old_values={"plan": old_plan},
        new_values={"plan": plan_key},
    )

    # Phase 6: if the override is a downgrade, emit the event + grace window.
    if old_plan and old_plan != plan_key:
        from app.services.subscription_tasks import record_downgrade

        record_downgrade(db, seller, old_plan, plan_key, reason="admin_override")

    db.commit()
    db.refresh(subscription)
    return {
        "seller_id": seller.id,
        "plan": subscription.plan.value,
        "status": subscription.status.value,
        "current_period_end": subscription.current_period_end,
        "max_products": seller.max_products,
        "max_orders": seller.max_orders,
    }


# ──────────────────────────────────────────────
#  Super-admin: impersonation
# ──────────────────────────────────────────────


class ImpersonateRequest(BaseModel):
    """Payload for the impersonation endpoint."""
    reason: str | None = None  # optional human note for the audit log


class ImpersonateResponse(BaseModel):
    access_token: str
    expires_in_seconds: int
    seller_id: int
    seller_email: str
    seller_name: str
    impersonated_by: int
    note: str


@router.post(
    "/sellers/{seller_id}/impersonate",
    response_model=ImpersonateResponse,
    tags=["super-admin"],
)
async def impersonate_seller(
    seller_id: int,
    payload: ImpersonateRequest | None = None,
    admin_seller: Seller = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    """
    Issue a short-lived access token that authenticates as the given client.

    The token's JWT carries an ``impersonated_by`` claim equal to the acting
    super-admin's id so downstream code and logs attribute the action to
    the actor, not the impersonated seller. Token expires in 15 minutes.
    """
    seller = db.execute(select(Seller).where(Seller.id == seller_id)).scalar_one_or_none()
    if seller is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Seller not found")
    if seller.id == admin_seller.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot impersonate yourself.",
        )
    if not seller.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot impersonate an inactive seller.",
        )

    expires = timedelta(minutes=15)

    # Issue an access token with extra claim ``impersonated_by`` so logs/UI
    # can flag impersonation traffic.
    token = create_access_token(
        subject=str(seller.id), expires_delta=expires, impersonated_by=admin_seller.id
    )

    reason = (payload.reason if payload else None) or "super-admin support"
    log_admin_action(
        db=db,
        actor=admin_seller,
        action="client.impersonate",
        entity_type="seller",
        entity_id=str(seller.id),
        extra_data={"reason": reason, "expires_in_seconds": int(expires.total_seconds())},
    )
    db.commit()

    return ImpersonateResponse(
        access_token=token,
        expires_in_seconds=int(expires.total_seconds()),
        seller_id=seller.id,
        seller_email=seller.email,
        seller_name=seller.name,
        impersonated_by=admin_seller.id,
        note=f"Issued by {admin_seller.email}; expires in 15 minutes.",
    )


# ──────────────────────────────────────────────
#  Super-admin: own settings (profile + password)
# ──────────────────────────────────────────────


class PasswordChange(BaseModel):
    current_password: str
    new_password: str


@router.get("/settings", response_model=dict, tags=["super-admin"])
async def get_admin_settings(
    admin_seller: Seller = Depends(get_current_super_admin),
):
    """
    Return the super admin's own profile fields (name, email, phone).
    """
    return {
        "name": admin_seller.name,
        "email": admin_seller.email,
        "phone": admin_seller.phone,
    }


@router.put("/settings/profile", response_model=dict, tags=["super-admin"])
async def update_admin_profile(
    payload: SellerUpdate,
    admin_seller: Seller = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    """
    Update the super admin's own name and/or phone.
    """
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(admin_seller, field, value)
    db.commit()
    db.refresh(admin_seller)
    return {
        "name": admin_seller.name,
        "email": admin_seller.email,
        "phone": admin_seller.phone,
    }


@router.put("/settings/password", response_model=dict, tags=["super-admin"])
async def change_admin_password(
    payload: PasswordChange,
    admin_seller: Seller = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    """
    Change the super admin's password.  Requires old password for verification.

    Request body: {"current_password": "...", "new_password": "..."}
    """
    if not verify_password(payload.current_password, admin_seller.password_hash):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Current password is incorrect.",
        )
    if len(payload.new_password) < 8:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="New password must be at least 8 characters.",
        )
    admin_seller.password_hash = get_password_hash(payload.new_password)
    db.commit()
    return {"detail": "Password changed successfully."}
