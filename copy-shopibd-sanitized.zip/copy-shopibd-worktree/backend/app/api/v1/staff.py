"""
Staff management endpoints for ShopiBD.

Allows sellers to invite, list, update, and remove staff members.
The shop owner (role = "owner") cannot be deleted through this API.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import get_password_hash
from app.models.seller import Seller
from app.models.staff import Staff
from app.api.v1.dependencies import get_current_seller
from app.schemas.staff import (
    StaffInvite,
    StaffResponse,
    StaffUpdate,
    StaffRole,
)

router = APIRouter(prefix="/staff", tags=["staff"])


@router.post("/invite", response_model=StaffResponse, status_code=status.HTTP_201_CREATED)
async def invite_staff(
    payload: StaffInvite,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> Staff:
    """
    Invite a new staff member.

    Creates a staff record tied to the current seller's account.
    A temporary password is generated; in a production system this
    would be sent via email/SMS.
    """
    # Prevent duplicate email within the same seller scope
    existing_stmt = select(Staff).where(
        Staff.email == payload.email,
        Staff.seller_id == current_seller.id,
    )
    existing = db.execute(existing_stmt).scalar_one_or_none()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A staff member with this email already exists for your account",
        )

    # Generate a random temporary password
    import secrets
    temp_password = secrets.token_urlsafe(12)

    staff = Staff(
        name=payload.name,
        email=payload.email,
        phone=payload.phone,
        role=payload.role.value,
        password_hash=get_password_hash(temp_password),
        is_active=True,
        seller_id=current_seller.id,
    )
    db.add(staff)
    db.commit()
    db.refresh(staff)

    # In production, send the temp_password via email/SMS here.
    return staff


@router.get("/", response_model=list[StaffResponse])
async def list_staff(
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    List all staff members belonging to the current seller.
    """
    stmt = (
        select(Staff)
        .where(Staff.seller_id == current_seller.id)
        .order_by(Staff.role, Staff.name)
    )
    staff_members = db.execute(stmt).scalars().all()
    return staff_members


@router.get("/{staff_id}", response_model=StaffResponse)
async def get_staff(
    staff_id: int,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> Staff:
    """
    Retrieve a single staff member by ID.

    The staff member must belong to the current seller.
    """
    stmt = select(Staff).where(
        Staff.id == staff_id,
        Staff.seller_id == current_seller.id,
    )
    staff = db.execute(stmt).scalar_one_or_none()
    if staff is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Staff member not found",
        )
    return staff


@router.put("/{staff_id}", response_model=StaffResponse)
async def update_staff(
    staff_id: int,
    payload: StaffUpdate,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> Staff:
    """
    Update a staff member's name, email, phone, role, or active status.

    The owner role cannot be changed to anything else, and you cannot
    demote the last owner of a shop.  Attempting to deactivate an owner
    will raise a 403 error.
    """
    stmt = select(Staff).where(
        Staff.id == staff_id,
        Staff.seller_id == current_seller.id,
    )
    staff = db.execute(stmt).scalar_one_or_none()
    if staff is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Staff member not found",
        )

    # Prevent changing owner role
    if staff.role == StaffRole.OWNER.value:
        if payload.role is not None and payload.role.value != StaffRole.OWNER.value:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Cannot change the role of the shop owner",
            )
        if payload.is_active is False:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Cannot deactivate the shop owner",
            )

    for field, value in payload.model_dump(exclude_unset=True).items():
        # Convert enum to string for role
        if field == "role" and value is not None:
            value = value.value
        setattr(staff, field, value)

    db.commit()
    db.refresh(staff)
    return staff


@router.delete("/{staff_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_staff(
    staff_id: int,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> None:
    """
    Remove a staff member.

    The shop owner cannot be deleted.  Only the owner (or an admin)
    can delete staff.
    """
    stmt = select(Staff).where(
        Staff.id == staff_id,
        Staff.seller_id == current_seller.id,
    )
    staff = db.execute(stmt).scalar_one_or_none()
    if staff is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Staff member not found",
        )

    if staff.role == StaffRole.OWNER.value:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="The shop owner cannot be deleted",
        )

    db.delete(staff)
    db.commit()
