"""
Payment reconciliation endpoints for ShopiBD.

Provides SMS parsing, transaction management, order matching, and
reconciliation summaries — all scoped to the authenticated seller.
"""

from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.api.v1.dependencies import get_current_seller
from app.core.database import get_db
from app.models.order import Order
from app.models.payment import PaymentMethod, PaymentStatus, PaymentTransaction
from app.models.seller import Seller
from app.models.shop import Shop
from app.schemas.common import PaginatedResponse
from app.schemas.payment import (
    MatchSuggestion,
    ParsedSmsData,
    PaymentMatchRequest,
    PaymentTransactionCreate,
    PaymentTransactionListItem,
    PaymentTransactionResponse,
    ReconciliationSummary,
    SmsParseRequest,
)
from app.services.sms_parser import parse_sms

router = APIRouter(prefix="/payments", tags=["payments"])


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_seller_shop_ids(db: Session, seller_id: int) -> list[int]:
    stmt = select(Shop.id).where(Shop.seller_id == seller_id)
    result = db.execute(stmt).scalars().all()
    return list(result)


def _get_payment_or_404(
    db: Session, transaction_id: int, seller_id: int
) -> PaymentTransaction:
    stmt = select(PaymentTransaction).where(
        PaymentTransaction.id == transaction_id,
        PaymentTransaction.seller_id == seller_id,
    )
    tx = db.execute(stmt).scalar_one_or_none()
    if not tx:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Payment transaction not found",
        )
    return tx


def _get_order_or_404(
    db: Session, order_id: int, shop_ids: list[int]
) -> Order:
    stmt = select(Order).where(
        Order.id == order_id, Order.shop_id.in_(shop_ids)
    )
    order = db.execute(stmt).scalar_one_or_none()
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found",
        )
    return order


# ---------------------------------------------------------------------------
# POST /payments/parse-sms
# ---------------------------------------------------------------------------


@router.post("/parse-sms", response_model=ParsedSmsData)
def parse_sms_endpoint(
    body: SmsParseRequest,
    current_seller: Seller = Depends(get_current_seller),
):
    """
    Accept raw SMS text and return parsed data (amount, sender, trxID, etc.).
    Detects bKash / Nagad automatically.
    """
    result = parse_sms(body.raw_sms_text)
    if result is None:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Could not parse SMS. Please check the text and try again.",
        )
    return ParsedSmsData(
        provider=result.get("provider"),
        amount=result.get("amount"),
        sender_phone=result.get("sender_phone"),
        trx_id=result.get("trx_id"),
        balance=result.get("balance"),
        raw_text=result.get("raw_text", body.raw_sms_text),
    )


# ---------------------------------------------------------------------------
# POST /payments/transactions
# ---------------------------------------------------------------------------


@router.post(
    "/transactions",
    response_model=PaymentTransactionResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_transaction(
    body: PaymentTransactionCreate,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Create a new payment transaction. If raw_sms_text is provided, the system
    attempts to auto-parse it and fill in amount / sender_phone / reference.
    """
    shop_ids = _get_seller_shop_ids(db, current_seller.id)
    if not shop_ids:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="You must create a shop before adding payment transactions.",
        )

    # Default shop_id to the first shop
    shop_id = shop_ids[0]

    amount = body.amount
    sender_phone = body.sender_phone
    reference = body.reference
    raw_sms_text = body.raw_sms_text
    verified_by = None

    # Try to parse SMS if raw text is provided and fields are missing
    if raw_sms_text and (amount is None or sender_phone is None or reference is None):
        parsed = parse_sms(raw_sms_text)
        if parsed:
            if amount is None:
                amount = parsed.get("amount")
            if sender_phone is None:
                sender_phone = parsed.get("sender_phone")
            if reference is None:
                reference = parsed.get("trx_id")
            verified_by = "sms_parse"

    if amount is None:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Amount is required (either directly or via SMS parsing).",
        )

    tx = PaymentTransaction(
        seller_id=current_seller.id,
        shop_id=shop_id,
        amount=Decimal(str(amount)),
        currency="BDT",
        payment_method=PaymentMethod(body.payment_method.value),
        sender_phone=sender_phone,
        reference=reference,
        status=PaymentStatus.PENDING,
        raw_sms_text=raw_sms_text,
        verified_by=verified_by,
        notes=body.notes,
    )
    db.add(tx)
    db.commit()
    db.refresh(tx)
    return tx


# ---------------------------------------------------------------------------
# GET /payments/transactions
# ---------------------------------------------------------------------------


@router.get("/transactions", response_model=PaginatedResponse[PaymentTransactionListItem])
def list_transactions(
    page: int = Query(1, ge=1, description="Page number"),
    limit: int = Query(20, ge=1, le=100, description="Items per page"),
    status_filter: Optional[str] = Query(
        None, alias="status", description="Filter by payment status"
    ),
    payment_method: Optional[str] = Query(
        None, description="Filter by payment method"
    ),
    search: Optional[str] = Query(
        None, description="Search by reference or sender phone"
    ),
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """List payment transactions for the current seller (paginated + filterable)."""
    shop_ids = _get_seller_shop_ids(db, current_seller.id)
    if not shop_ids:
        return PaginatedResponse(
            items=[], total=0, page=page, page_size=limit, total_pages=0
        )

    stmt = select(PaymentTransaction).where(
        PaymentTransaction.seller_id == current_seller.id
    )

    if status_filter:
        stmt = stmt.where(PaymentTransaction.status == status_filter)
    if payment_method:
        stmt = stmt.where(PaymentTransaction.payment_method == payment_method)
    if search:
        search_term = f"%{search}%"
        stmt = stmt.where(
            or_(
                PaymentTransaction.reference.ilike(search_term),
                PaymentTransaction.sender_phone.ilike(search_term),
            )
        )

    # Total count
    count_stmt = select(func.count()).select_from(stmt.subquery())
    total = db.execute(count_stmt).scalar() or 0

    stmt = (
        stmt.order_by(PaymentTransaction.created_at.desc())
        .offset((page - 1) * limit)
        .limit(limit)
    )
    rows = db.execute(stmt).scalars().all()

    items = [
        PaymentTransactionListItem(
            id=t.id,
            amount=float(t.amount) if t.amount else None,
            currency=t.currency,
            payment_method=t.payment_method,
            sender_phone=t.sender_phone,
            reference=t.reference,
            status=t.status,
            matched_order_id=t.matched_order_id,
            verified_by=t.verified_by,
            created_at=t.created_at,
        )
        for t in rows
    ]

    total_pages = (total + limit - 1) // limit if total > 0 else 0
    return PaginatedResponse(
        items=items, total=total, page=page, page_size=limit, total_pages=total_pages
    )


# ---------------------------------------------------------------------------
# GET /payments/transactions/{id}
# ---------------------------------------------------------------------------


@router.get("/transactions/{transaction_id}", response_model=PaymentTransactionResponse)
def get_transaction(
    transaction_id: int,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """Get a single payment transaction by ID."""
    tx = _get_payment_or_404(db, transaction_id, current_seller.id)
    return tx


# ---------------------------------------------------------------------------
# POST /payments/transactions/{id}/match
# ---------------------------------------------------------------------------


@router.post(
    "/transactions/{transaction_id}/match",
    response_model=PaymentTransactionResponse,
)
def match_transaction(
    transaction_id: int,
    body: PaymentMatchRequest,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Manually match a payment transaction to an order.
    Both must belong to the same seller.
    """
    tx = _get_payment_or_404(db, transaction_id, current_seller.id)
    shop_ids = _get_seller_shop_ids(db, current_seller.id)
    order = _get_order_or_404(db, body.order_id, shop_ids)

    tx.order_id = order.id
    tx.matched_order_id = order.id
    tx.status = PaymentStatus.VERIFIED
    tx.verified_by = "manual"
    tx.verified_at = datetime.now(timezone.utc)

    # Update order payment status
    order.payment_status = "paid"

    db.commit()
    db.refresh(tx)
    return tx


# ---------------------------------------------------------------------------
# POST /payments/transactions/{id}/unmatch
# ---------------------------------------------------------------------------


@router.post(
    "/transactions/{transaction_id}/unmatch",
    response_model=PaymentTransactionResponse,
)
def unmatch_transaction(
    transaction_id: int,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """Unmatch a previously matched transaction from its order."""
    tx = _get_payment_or_404(db, transaction_id, current_seller.id)

    if tx.status != PaymentStatus.VERIFIED:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Transaction is not currently matched to an order.",
        )

    # Restore order payment status if still "paid"
    if tx.matched_order_id:
        stmt = select(Order).where(Order.id == tx.matched_order_id)
        order = db.execute(stmt).scalar_one_or_none()
        if order and order.payment_status == "paid":
            order.payment_status = "pending"

    tx.order_id = None
    tx.matched_order_id = None
    tx.status = PaymentStatus.UNMATCHED
    tx.verified_by = None
    tx.verified_at = None

    db.commit()
    db.refresh(tx)
    return tx


# ---------------------------------------------------------------------------
# GET /payments/reconciliation
# ---------------------------------------------------------------------------


@router.get("/reconciliation", response_model=ReconciliationSummary)
def get_reconciliation(
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Returns a summary of all payment transactions for the current seller:
    total, matched, unmatched, pending counts and amounts.
    """
    shop_ids = _get_seller_shop_ids(db, current_seller.id)
    if not shop_ids:
        return ReconciliationSummary()

    base = select(PaymentTransaction).where(
        PaymentTransaction.seller_id == current_seller.id
    )

    # Total
    total_stmt = select(
        func.count(PaymentTransaction.id),
        func.coalesce(func.sum(PaymentTransaction.amount), 0),
    ).select_from(base.subquery())
    total_row = db.execute(total_stmt).one()
    total_count = total_row[0] or 0
    total_amount = float(total_row[1] or 0)

    # Matched (verified)
    matched_stmt = base.where(PaymentTransaction.status == PaymentStatus.VERIFIED)
    matched_count_stmt = select(
        func.count(), func.coalesce(func.sum(PaymentTransaction.amount), 0)
    ).select_from(matched_stmt.subquery())
    matched_row = db.execute(matched_count_stmt).one()
    matched_count = matched_row[0] or 0
    matched_amount = float(matched_row[1] or 0)

    # Unmatched
    unmatch_stmt = base.where(PaymentTransaction.status == PaymentStatus.UNMATCHED)
    unmatch_count_stmt = select(
        func.count(), func.coalesce(func.sum(PaymentTransaction.amount), 0)
    ).select_from(unmatch_stmt.subquery())
    unmatch_row = db.execute(unmatch_count_stmt).one()
    unmatch_count = unmatch_row[0] or 0
    unmatch_amount = float(unmatch_row[1] or 0)

    # Pending
    pending_stmt = base.where(PaymentTransaction.status == PaymentStatus.PENDING)
    pending_count_stmt = select(
        func.count(), func.coalesce(func.sum(PaymentTransaction.amount), 0)
    ).select_from(pending_stmt.subquery())
    pending_row = db.execute(pending_count_stmt).one()
    pending_count = pending_row[0] or 0
    pending_amount = float(pending_row[1] or 0)

    return ReconciliationSummary(
        total_transactions=total_count,
        total_amount=total_amount,
        matched=matched_count,
        matched_amount=matched_amount,
        unmatched=unmatch_count,
        unmatched_amount=unmatch_amount,
        pending=pending_count,
        pending_amount=pending_amount,
    )


# ---------------------------------------------------------------------------
# GET /payments/suggestions
# ---------------------------------------------------------------------------


@router.get("/suggestions", response_model=list[MatchSuggestion])
def get_match_suggestions(
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Generate auto-match suggestions by comparing unmatched/pending payment
    transactions against pending orders for the same seller.

    Matching criteria:
      - Same amount (exact match)
      - Same sender_phone OR transaction created within 24h of order
      - Returns confidence score (0-100) with match reasons
    """
    shop_ids = _get_seller_shop_ids(db, current_seller.id)
    if not shop_ids:
        return []

    # Get unmatched/pending transactions
    tx_stmt = select(PaymentTransaction).where(
        PaymentTransaction.seller_id == current_seller.id,
        PaymentTransaction.status.in_(
            [PaymentStatus.PENDING, PaymentStatus.UNMATCHED]
        ),
        PaymentTransaction.amount.isnot(None),
    )
    transactions = db.execute(tx_stmt).scalars().all()

    if not transactions:
        return []

    # Get pending orders for the seller's shops
    order_stmt = select(Order).where(
        Order.shop_id.in_(shop_ids),
        Order.payment_status.in_(["pending", "unpaid"]),
    )
    pending_orders = db.execute(order_stmt).scalars().all()

    if not pending_orders:
        return []

    suggestions: list[MatchSuggestion] = []

    for tx in transactions:
        tx_amount = float(tx.amount) if tx.amount else 0
        tx_created = tx.created_at

        for order in pending_orders:
            order_amount = float(order.total_amount)
            confidence = 0
            match_reasons = []

            # Criterion 1: Amount match
            if tx_amount == order_amount:
                confidence += 60
                match_reasons.append("Exact amount match")

            # Criterion 2: Sender phone matches customer phone
            if (
                tx.sender_phone
                and order.customer_phone
                and tx.sender_phone == order.customer_phone
            ):
                confidence += 25
                match_reasons.append("Sender phone matches customer phone")

            # Criterion 3: Time proximity (within 24 hours)
            if tx_created and order.created_at:
                time_diff = abs((tx_created - order.created_at).total_seconds())
                if time_diff <= 86400:  # 24 hours
                    confidence += 15
                    match_reasons.append("Transaction within 24 hours of order")

            # Only suggest if confidence is meaningful
            if confidence >= 60:
                suggestions.append(
                    MatchSuggestion(
                        transaction_id=tx.id,
                        transaction_amount=tx_amount,
                        transaction_reference=tx.reference,
                        transaction_method=tx.payment_method,
                        transaction_created_at=tx.created_at,
                        order_id=order.id,
                        order_number=order.order_number,
                        order_amount=order_amount,
                        customer_name=order.customer_name,
                        customer_phone=order.customer_phone,
                        confidence=min(confidence, 100),
                        match_reasons=match_reasons,
                    )
                )

    # Sort by confidence descending
    suggestions.sort(key=lambda s: s.confidence, reverse=True)
    return suggestions
