"""
Subscription API endpoints for ShopiBD.

Provides endpoints for managing seller subscriptions:
- Get current subscription with plan details
- List available plans
- Select/upgrade plan (before payment)
- Update subscription (auto_renew, plan changes)
- Cancel subscription
"""

from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.v1.dependencies import get_current_seller
from app.core.config import settings
from app.core.database import get_db
from app.models.seller import Seller
from app.models.subscription import Subscription, SubscriptionPlan, SubscriptionStatus
from app.schemas.subscription import (
    PLANS,
    PlanInfo,
    SubscriptionCreate,
    SubscriptionResponse,
    SubscriptionUpdate,
    SubscriptionWithPlanResponse,
)
from app.services.plan_limits import get_current_order_count, get_current_product_count
from app.services.subscription_payments import (
    activate_subscription,
    create_subscription_payment as build_subscription_payment,
)

router = APIRouter(prefix="/subscription", tags=["subscription"])


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def _get_or_create_subscription(db: Session, seller: Seller) -> Subscription:
    """Get existing subscription or create a free tier one for the seller."""
    subscription = db.execute(
        select(Subscription).where(Subscription.seller_id == seller.id)
    ).scalar_one_or_none()

    if subscription is None:
        subscription = Subscription(
            seller_id=seller.id,
            plan=SubscriptionPlan.FREE,
            status=SubscriptionStatus.TRIALING,
            current_period_start=datetime.now(timezone.utc),
            auto_renew=False,
        )
        db.add(subscription)
        db.flush()

    return subscription


def _build_plan_info(subscription: Subscription) -> PlanInfo:
    """Build PlanInfo from subscription plan."""
    plan_key = subscription.plan.value if subscription.plan else "free"
    return PLANS.get(plan_key, PLANS["free"])


def _usage_fields(db: Session, seller: Seller, subscription: Subscription) -> dict:
    """Compute the seller's current product/order usage for the response."""
    return {
        "current_products": get_current_product_count(db, seller),
        "current_orders": get_current_order_count(db, seller, subscription),
    }


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("/plans", response_model=list[PlanInfo])
def list_plans():
    """
    List all available subscription plans.

    Public endpoint - no authentication required.
    """
    return list(PLANS.values())


@router.get("", response_model=SubscriptionWithPlanResponse)
def get_subscription(
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Get the current seller's subscription with plan details.

    Returns the subscription status, current period, and full plan info.
    """
    subscription = _get_or_create_subscription(db, current_seller)
    plan_info = _build_plan_info(subscription)

    return SubscriptionWithPlanResponse(
        id=subscription.id,
        seller_id=subscription.seller_id,
        plan=subscription.plan.value if subscription.plan else "free",
        status=subscription.status.value if subscription.status else "trialing",
        current_period_start=subscription.current_period_start,
        current_period_end=subscription.current_period_end,
        auto_renew=subscription.auto_renew,
        payment_gateway=subscription.payment_gateway,
        payment_gateway_subscription_id=subscription.payment_gateway_subscription_id,
        trial_end=subscription.trial_end,
        canceled_at=subscription.canceled_at,
        created_at=subscription.created_at,
        updated_at=subscription.updated_at,
        plan_info=plan_info,
        **_usage_fields(db, current_seller, subscription),
    )


@router.post("", response_model=SubscriptionWithPlanResponse, status_code=status.HTTP_201_CREATED)
def create_subscription(
    payload: SubscriptionCreate,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Select or upgrade a subscription plan (before payment).

    This endpoint:
    - Creates a new subscription if none exists
    - Updates the plan if upgrading/downgrading
    - Sets status to TRIALING (awaiting payment)
    - Does NOT process payment - that's handled by payment webhooks

    Use this when a seller selects a plan on the pricing page.
    """
    # Validate plan
    plan_key = payload.plan
    if plan_key not in PLANS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid plan '{plan_key}'. Valid plans: {', '.join(PLANS.keys())}",
        )

    # Cannot select free plan via this endpoint (use cancel instead)
    if plan_key == "free":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot select Free plan via this endpoint. Use DELETE to cancel paid plan.",
        )

    subscription = _get_or_create_subscription(db, current_seller)

    # Update subscription
    subscription.plan = SubscriptionPlan(plan_key)
    subscription.status = SubscriptionStatus.TRIALING
    subscription.payment_gateway = payload.payment_gateway
    subscription.auto_renew = payload.auto_renew
    subscription.current_period_start = datetime.now(timezone.utc)
    subscription.current_period_end = None  # Will be set after payment confirmation

    # Update seller's plan fields for quick access / plan limit enforcement
    plan_info = PLANS[plan_key]
    current_seller.plan = plan_key
    current_seller.max_products = plan_info.max_products
    current_seller.max_orders = plan_info.max_orders

    db.commit()
    db.refresh(subscription)

    plan_info = _build_plan_info(subscription)

    return SubscriptionWithPlanResponse(
        id=subscription.id,
        seller_id=subscription.seller_id,
        plan=subscription.plan.value if subscription.plan else "free",
        status=subscription.status.value if subscription.status else "trialing",
        current_period_start=subscription.current_period_start,
        current_period_end=subscription.current_period_end,
        auto_renew=subscription.auto_renew,
        payment_gateway=subscription.payment_gateway,
        payment_gateway_subscription_id=subscription.payment_gateway_subscription_id,
        trial_end=subscription.trial_end,
        canceled_at=subscription.canceled_at,
        created_at=subscription.created_at,
        updated_at=subscription.updated_at,
        plan_info=plan_info,
        **_usage_fields(db, current_seller, subscription),
    )


@router.post("/payment", response_model=dict)
async def create_subscription_payment(
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Create a payment intent for the current subscription.

    The subscription must be in TRIALING status (created via POST /subscription).
    Returns a payment URL to redirect the user to complete payment.
    """
    subscription = _get_or_create_subscription(db, current_seller)

    if subscription.status != SubscriptionStatus.TRIALING:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Subscription is not in trialing status: {subscription.status.value}",
        )

    if subscription.plan == SubscriptionPlan.FREE:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot create payment for free plan",
        )

    # Create the payment using the subscription payment service
    result = await build_subscription_payment(
        db=db,
        seller=current_seller,
        subscription=subscription,
        return_url=f"{settings.FRONTEND_URL}/dashboard/subscription/success?plan={subscription.plan.value}",
    )

    return result


@router.put("", response_model=SubscriptionWithPlanResponse)
def update_subscription(
    payload: SubscriptionUpdate,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Update subscription settings.

    Allowed updates:
    - auto_renew: Enable/disable auto-renewal
    - plan: Upgrade/downgrade plan (sets status to TRIALING for payment)

    Plan changes require payment confirmation via webhook.
    """
    subscription = _get_or_create_subscription(db, current_seller)

    # Update auto_renew if provided
    if payload.auto_renew is not None:
        subscription.auto_renew = payload.auto_renew

    # Handle plan change
    if payload.plan is not None:
        plan_key = payload.plan
        if plan_key not in PLANS:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid plan '{plan_key}'. Valid plans: {', '.join(PLANS.keys())}",
            )

        # If changing to free, cancel the subscription
        if plan_key == "free":
            subscription.plan = SubscriptionPlan.FREE
            subscription.status = SubscriptionStatus.CANCELED
            subscription.canceled_at = datetime.now(timezone.utc)
            subscription.auto_renew = False
        else:
            # Plan upgrade/downgrade - set to TRIALING for payment
            subscription.plan = SubscriptionPlan(plan_key)
            subscription.status = SubscriptionStatus.TRIALING
            subscription.current_period_start = datetime.now(timezone.utc)
            subscription.current_period_end = None

        # Update seller's plan fields for limit enforcement
        plan_info = PLANS[plan_key]
        current_seller.plan = plan_key
        current_seller.max_products = plan_info.max_products
        current_seller.max_orders = plan_info.max_orders

    db.commit()
    db.refresh(subscription)

    plan_info = _build_plan_info(subscription)

    return SubscriptionWithPlanResponse(
        id=subscription.id,
        seller_id=subscription.seller_id,
        plan=subscription.plan.value if subscription.plan else "free",
        status=subscription.status.value if subscription.status else "trialing",
        current_period_start=subscription.current_period_start,
        current_period_end=subscription.current_period_end,
        auto_renew=subscription.auto_renew,
        payment_gateway=subscription.payment_gateway,
        payment_gateway_subscription_id=subscription.payment_gateway_subscription_id,
        trial_end=subscription.trial_end,
        canceled_at=subscription.canceled_at,
        created_at=subscription.created_at,
        updated_at=subscription.updated_at,
        plan_info=plan_info,
        **_usage_fields(db, current_seller, subscription),
    )


@router.delete("", status_code=status.HTTP_204_NO_CONTENT)
def cancel_subscription(
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Cancel the current subscription.

    - Sets status to CANCELED
    - Sets canceled_at timestamp
    - Disables auto_renew
    - Keeps subscription record for history
    - Reverts seller to Free plan limits
    - Emits ``subscription.downgraded`` when moving from a paid plan to free
    """
    subscription = _get_or_create_subscription(db, current_seller)

    if subscription.status in (SubscriptionStatus.CANCELED, SubscriptionStatus.EXPIRED):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Subscription is already canceled or expired",
        )

    old_plan = subscription.plan.value if subscription.plan else "free"
    subscription.status = SubscriptionStatus.CANCELED
    subscription.canceled_at = datetime.now(timezone.utc)
    subscription.auto_renew = False
    subscription.plan = SubscriptionPlan.FREE

    # Revert seller to Free plan limits
    free_plan = PLANS["free"]
    current_seller.plan = "free"
    current_seller.max_products = free_plan.max_products
    current_seller.max_orders = free_plan.max_orders

    # Phase 6: record the downgrade so the event + grace window are applied.
    from app.services.subscription_tasks import record_downgrade

    record_downgrade(db, current_seller, old_plan, "free", reason="canceled")

    db.commit()