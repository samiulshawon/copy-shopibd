"""
Coupon management endpoints for ShopiBD.

All routes require seller authentication.
"""
import json
from datetime import datetime, timezone
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.api.v1.dependencies import get_current_seller
from app.core.database import get_db
from app.models.coupon import Coupon
from app.models.coupon_usage import CouponUsage
from app.models.seller import Seller
from app.models.shop import Shop
from app.schemas.coupon import (
    CouponCreate,
    CouponListResponse,
    CouponResponse,
    CouponUpdate,
    CouponValidateRequest,
    CouponValidateResponse,
)

router = APIRouter(prefix="/coupons", tags=["coupons"])


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_seller_shop_ids(db: Session, seller_id: int) -> list[int]:
    stmt = select(Shop.id).where(Shop.seller_id == seller_id)
    return list(db.execute(stmt).scalars().all())


# ---------------------------------------------------------------------------
# POST /coupons — create coupon
# ---------------------------------------------------------------------------

@router.post("/", response_model=CouponResponse, status_code=status.HTTP_201_CREATED)
def create_coupon(
    payload: CouponCreate,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Create a new coupon for the authenticated seller.

    Auto-uppercases the coupon code. Validates uniqueness per seller.
    """
    code = payload.code.strip().upper()

    # Check uniqueness for this seller
    existing = db.execute(
        select(Coupon).where(
            Coupon.seller_id == current_seller.id,
            Coupon.code == code,
        )
    ).scalar_one_or_none()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Coupon code '{code}' already exists for your account",
        )

    # If shop_id provided, verify it belongs to this seller
    if payload.shop_id is not None:
        shop_stmt = select(Shop).where(
            Shop.id == payload.shop_id,
            Shop.seller_id == current_seller.id,
        )
        shop = db.execute(shop_stmt).scalar_one_or_none()
        if not shop:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Shop not found or does not belong to you",
            )

    coupon = Coupon(
        seller_id=current_seller.id,
        shop_id=payload.shop_id,
        code=code,
        discount_type=payload.discount_type,
        discount_value=payload.discount_value,
        min_order_amount=payload.min_order_amount,
        max_discount=payload.max_discount,
        usage_limit=payload.usage_limit,
        per_customer_limit=payload.per_customer_limit,
        applies_to=payload.applies_to,
        product_ids=payload.product_ids,
        category_ids=payload.category_ids,
        is_active=payload.is_active,
        starts_at=payload.starts_at,
        expires_at=payload.expires_at,
    )
    db.add(coupon)
    db.commit()
    db.refresh(coupon)
    return coupon


# ---------------------------------------------------------------------------
# GET /coupons — list coupons
# ---------------------------------------------------------------------------

@router.get("/", response_model=CouponListResponse)
def list_coupons(
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    is_active: Optional[bool] = Query(None),
    search: Optional[str] = Query(None, description="Search by coupon code"),
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Return a paginated list of coupons for the authenticated seller.
    Optionally filter by active/inactive status and search by code.
    """
    stmt = select(Coupon).where(Coupon.seller_id == current_seller.id)

    if is_active is not None:
        stmt = stmt.where(Coupon.is_active == is_active)

    if search:
        stmt = stmt.where(Coupon.code.ilike(f"%{search.strip().upper()}%"))

    # Total count
    count_stmt = select(func.count()).select_from(stmt.subquery())
    total = db.execute(count_stmt).scalar() or 0

    # Pagination
    stmt = stmt.order_by(Coupon.created_at.desc()).offset((page - 1) * limit).limit(limit)
    coupons = db.execute(stmt).scalars().all()

    return CouponListResponse(items=list(coupons), total=total)


# ---------------------------------------------------------------------------
# GET /coupons/{id} — get single coupon
# ---------------------------------------------------------------------------

@router.get("/{coupon_id}", response_model=CouponResponse)
def get_coupon(
    coupon_id: int,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Return a single coupon by ID (must belong to the current seller).
    """
    coupon = db.execute(
        select(Coupon).where(
            Coupon.id == coupon_id,
            Coupon.seller_id == current_seller.id,
        )
    ).scalar_one_or_none()
    if not coupon:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Coupon not found",
        )
    return coupon


# ---------------------------------------------------------------------------
# PUT /coupons/{id} — update coupon
# ---------------------------------------------------------------------------

@router.put("/{coupon_id}", response_model=CouponResponse)
def update_coupon(
    coupon_id: int,
    payload: CouponUpdate,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Update a coupon. Only the fields provided will be updated.
    """
    coupon = db.execute(
        select(Coupon).where(
            Coupon.id == coupon_id,
            Coupon.seller_id == current_seller.id,
        )
    ).scalar_one_or_none()
    if not coupon:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Coupon not found",
        )

    update_data = payload.model_dump(exclude_unset=True)

    # If code is being changed, uppercase it and check uniqueness
    if "code" in update_data:
        new_code = update_data["code"].strip().upper()
        existing = db.execute(
            select(Coupon).where(
                Coupon.seller_id == current_seller.id,
                Coupon.code == new_code,
                Coupon.id != coupon_id,
            )
        ).scalar_one_or_none()
        if existing:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Coupon code '{new_code}' already exists",
            )
        update_data["code"] = new_code

    for field, value in update_data.items():
        setattr(coupon, field, value)

    db.commit()
    db.refresh(coupon)
    return coupon


# ---------------------------------------------------------------------------
# DELETE /coupons/{id} — delete coupon
# ---------------------------------------------------------------------------

@router.delete("/{coupon_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_coupon(
    coupon_id: int,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Delete a coupon (and its usage records).
    """
    coupon = db.execute(
        select(Coupon).where(
            Coupon.id == coupon_id,
            Coupon.seller_id == current_seller.id,
        )
    ).scalar_one_or_none()
    if not coupon:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Coupon not found",
        )

    db.delete(coupon)
    db.commit()
    return None


# ---------------------------------------------------------------------------
# POST /coupons/validate — validate coupon at checkout
# ---------------------------------------------------------------------------

@router.post("/validate", response_model=CouponValidateResponse)
def validate_coupon(
    payload: CouponValidateRequest,
    db: Session = Depends(get_db),
):
    """
    Validate a coupon code at checkout.

    Checks:
    - Coupon exists and is active
    - Coupon is not expired
    - Usage limit not reached
    - Minimum order amount is met
    - Products are applicable (if applies_to is specific)
    - Coupon has started (if starts_at is set)
    """
    code = payload.code.strip().upper()

    # Resolve shop by ID or slug
    shop_id = payload.shop_id
    if not shop_id and payload.shop_slug:
        shop_stmt = select(Shop).where(Shop.slug == payload.shop_slug)
        shop = db.execute(shop_stmt).scalar_one_or_none()
        if shop:
            shop_id = shop.id

    if not shop_id:
        return CouponValidateResponse(
            valid=False,
            discount_amount=Decimal("0.00"),
            message="Shop identification required",
        )

    coupon = db.execute(
        select(Coupon).where(
            Coupon.code == code,
            Coupon.shop_id == shop_id,
        )
    ).scalar_one_or_none()

    if not coupon:
        return CouponValidateResponse(
            valid=False,
            discount_amount=Decimal("0.00"),
            message="Coupon not found",
        )

    if not coupon.is_active:
        return CouponValidateResponse(
            valid=False,
            discount_amount=Decimal("0.00"),
            message="This coupon is no longer active",
        )

    now = datetime.now(timezone.utc)

    # Check start date
    if coupon.starts_at and coupon.starts_at > now:
        return CouponValidateResponse(
            valid=False,
            discount_amount=Decimal("0.00"),
            message="This coupon is not yet valid",
        )

    # Check expiry
    if coupon.expires_at and coupon.expires_at < now:
        return CouponValidateResponse(
            valid=False,
            discount_amount=Decimal("0.00"),
            message="This coupon has expired",
        )

    # Check usage limit
    if coupon.usage_limit is not None and coupon.usage_count >= coupon.usage_limit:
        return CouponValidateResponse(
            valid=False,
            discount_amount=Decimal("0.00"),
            message="This coupon has reached its usage limit",
        )

    # Check minimum order amount
    if coupon.min_order_amount is not None and payload.total_amount < coupon.min_order_amount:
        return CouponValidateResponse(
            valid=False,
            discount_amount=Decimal("0.00"),
            message=f"Minimum order amount of ৳{coupon.min_order_amount} required",
        )

    # Check product applicability
    if coupon.applies_to == "specific_products" and payload.product_ids:
        if coupon.product_ids:
            try:
                allowed_ids = set(json.loads(coupon.product_ids))
                if not allowed_ids.intersection(payload.product_ids):
                    return CouponValidateResponse(
                        valid=False,
                        discount_amount=Decimal("0.00"),
                        message="Coupon does not apply to the selected products",
                    )
            except (json.JSONDecodeError, TypeError):
                pass

    # Calculate discount
    discount_amount = Decimal("0.00")
    if coupon.discount_type == "fixed":
        discount_amount = coupon.discount_value
    elif coupon.discount_type == "percentage":
        discount_amount = (coupon.discount_value / Decimal("100")) * payload.total_amount
        # Apply max_discount cap
        if coupon.max_discount is not None and discount_amount > coupon.max_discount:
            discount_amount = coupon.max_discount

    # Ensure discount does not exceed total
    if discount_amount > payload.total_amount:
        discount_amount = payload.total_amount

    return CouponValidateResponse(
        valid=True,
        discount_amount=discount_amount.quantize(Decimal("0.01")),
        message=f"Coupon applied! You save ৳{discount_amount:.2f}",
        coupon=CouponResponse.model_validate(coupon),
    )
