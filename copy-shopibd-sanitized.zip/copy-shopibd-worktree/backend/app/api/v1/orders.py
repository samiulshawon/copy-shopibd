"""
Seller order management endpoints for ShopiBD.

All routes are protected by the ``get_current_seller`` dependency and
return only orders that belong to the authenticated seller's shops.
"""

from datetime import date, datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel, ConfigDict
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.api.v1.dependencies import get_current_seller
from app.core.database import get_db
from app.models.audit_log import AuditLog
from app.models.order import Order, OrderItem
from app.models.shop import Shop
from app.models.seller import Seller
from app.schemas.common import PaginatedResponse
from app.services.audit import log_action
from app.services.invoice import generate_invoice_pdf
from app.services.notification import send_status_update_notification
from app.services.whatsapp.factory import get_whatsapp_service

router = APIRouter(prefix="/seller-orders", tags=["orders"])


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------

class OrderStatusUpdate(BaseModel):
    status: str = Query(..., description="Order status: pending/confirmed/shipped/delivered/cancelled")


class OrderItemPublic(BaseModel):
    id: int
    product_id: int
    product_name: str
    quantity: int
    unit_price: float
    subtotal: float

    model_config = ConfigDict(from_attributes=True)


class OrderPublic(BaseModel):
    id: int
    order_number: str
    customer_name: str
    customer_phone: str
    customer_address: str
    total_amount: float
    status: str
    payment_status: str
    notes: Optional[str] = None
    shop_id: int
    created_at: datetime
    items: list[OrderItemPublic] = []

    model_config = ConfigDict(from_attributes=True)


class OrderListItem(BaseModel):
    id: int
    order_number: str
    customer_name: str
    customer_phone: str
    total_amount: float
    status: str
    payment_status: str
    created_at: datetime
    item_count: int

    model_config = ConfigDict(from_attributes=True)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

VALID_STATUSES = {"pending", "confirmed", "shipped", "delivered", "cancelled"}


def _get_seller_shop_ids(db: Session, seller_id: int) -> list[int]:
    stmt = select(Shop.id).where(Shop.seller_id == seller_id)
    result = db.execute(stmt).scalars().all()
    return list(result)


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.get("/", response_model=PaginatedResponse[OrderListItem])
def list_orders(
    page: int = Query(1, ge=1, description="Page number"),
    limit: int = Query(20, ge=1, le=100, description="Items per page"),
    status: Optional[str] = Query(None, description="Filter by order status"),
    date_from: Optional[date] = Query(None, description="Filter orders from this date"),
    date_to: Optional[date] = Query(None, description="Filter orders up to this date"),
    search: Optional[str] = Query(None, description="Search by buyer name, phone, or order ID"),
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Return a paginated list of orders for the current seller only.

    Supports filtering by status, date range, and free-text search across
    buyer name, phone, and order number.
    """
    shop_ids = _get_seller_shop_ids(db, current_seller.id)
    if not shop_ids:
        return PaginatedResponse(
            items=[],
            total=0,
            page=page,
            page_size=limit,
            total_pages=0,
        )

    stmt = (
        select(
            Order.id,
            Order.order_number,
            Order.customer_name,
            Order.customer_phone,
            Order.total_amount,
            Order.status,
            Order.payment_status,
            Order.created_at,
            func.count(OrderItem.id).label("item_count"),
        )
        .join(OrderItem, Order.id == OrderItem.order_id, isouter=True)
        .where(Order.shop_id.in_(shop_ids))
        .group_by(Order.id)
    )

    # Status filter
    if status:
        stmt = stmt.where(Order.status == status)

    # Date range filter
    if date_from:
        stmt = stmt.where(Order.created_at >= datetime.combine(date_from, datetime.min.time()))
    if date_to:
        stmt = stmt.where(Order.created_at <= datetime.combine(date_to, datetime.max.time()))

    # Search filter
    if search:
        search_term = f"%{search}%"
        stmt = stmt.where(
            or_(
                Order.customer_name.ilike(search_term),
                Order.customer_phone.ilike(search_term),
                Order.order_number.ilike(search_term),
            )
        )

    # Total count for pagination
    count_stmt = select(func.count()).select_from(stmt.subquery())
    total = db.execute(count_stmt).scalar() or 0

    # Pagination
    stmt = stmt.order_by(Order.created_at.desc()).offset((page - 1) * limit).limit(limit)
    rows = db.execute(stmt).all()

    items = []
    for row in rows:
        items.append(
            OrderListItem(
                id=row.id,
                order_number=row.order_number,
                customer_name=row.customer_name,
                customer_phone=row.customer_phone,
                total_amount=float(row.total_amount),
                status=row.status,
                payment_status=row.payment_status,
                created_at=row.created_at,
                item_count=row.item_count or 0,
            )
        )

    total_pages = (total + limit - 1) // limit if total > 0 else 0
    return PaginatedResponse(
        items=items,
        total=total,
        page=page,
        page_size=limit,
        total_pages=total_pages,
    )


@router.get("")
def list_orders_no_slash():
    """Redirect /seller-orders (no trailing slash) to /seller-orders/."""
    from fastapi.responses import RedirectResponse

    return RedirectResponse(url="/api/v1/seller-orders/", status_code=307)


@router.get("/{order_id}", response_model=OrderPublic)
def get_order(
    order_id: int,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Return full details for a single order, including items, buyer info,
    and payment status. Verifies the order belongs to the current seller.
    """
    shop_ids = _get_seller_shop_ids(db, current_seller.id)
    if not shop_ids:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No shops found for this seller",
        )

    stmt = (
        select(Order)
        .where(Order.id == order_id, Order.shop_id.in_(shop_ids))
    )
    order = db.execute(stmt).scalar_one_or_none()
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found",
        )

    # Load items
    items_stmt = select(OrderItem).where(OrderItem.order_id == order_id)
    items = db.execute(items_stmt).scalars().all()

    return OrderPublic(
        id=order.id,
        order_number=order.order_number,
        customer_name=order.customer_name,
        customer_phone=order.customer_phone,
        customer_address=order.customer_address,
        total_amount=float(order.total_amount),
        status=order.status,
        payment_status=order.payment_status,
        notes=order.notes,
        shop_id=order.shop_id,
        created_at=order.created_at,
        items=[
            OrderItemPublic(
                id=item.id,
                product_id=item.product_id,
                product_name=item.product_name,
                quantity=item.quantity,
                unit_price=float(item.unit_price),
                subtotal=float(item.subtotal),
            )
            for item in items
        ],
    )


# ---------------------------------------------------------------------------
# GET /{order_id}/invoice — download PDF invoice
# ---------------------------------------------------------------------------


@router.get("/{order_id}/invoice", response_class=__import__("fastapi").responses.Response)
async def download_invoice(
    order_id: int,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Generate and download a PDF invoice for the given order.

    The invoice contains shop info, buyer info, line items, totals, and
    payment details. The PDF is generated on-the-fly (not stored).
    """
    from fastapi.responses import Response

    shop_ids = _get_seller_shop_ids(db, current_seller.id)
    if not shop_ids:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No shops found for this seller",
        )

    stmt = select(Order).where(Order.id == order_id, Order.shop_id.in_(shop_ids))
    order = db.execute(stmt).scalar_one_or_none()
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found",
        )

    # Fetch shop for header info
    shop = db.execute(
        select(Shop).where(Shop.id == order.shop_id)
    ).scalar_one_or_none()
    if not shop:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Shop not found",
        )

    # Load items
    items_stmt = select(OrderItem).where(OrderItem.order_id == order_id)
    order.items = db.execute(items_stmt).scalars().all()

    pdf_bytes = generate_invoice_pdf(order, shop)

    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="invoice-{order.order_number}.pdf"',
            "Content-Length": str(len(pdf_bytes)),
        },
    )


# ---------------------------------------------------------------------------
# Abandoned cart schemas
# ---------------------------------------------------------------------------

class AbandonedOrderItem(BaseModel):
    id: int
    order_number: str
    customer_name: str
    customer_phone: str
    total_amount: float
    status: str
    payment_status: str
    created_at: datetime
    hours_since: int

    model_config = ConfigDict(from_attributes=True)


class AbandonedOrderListResponse(BaseModel):
    items: list[AbandonedOrderItem]
    total: int


class RemindResponse(BaseModel):
    sent: bool
    message: str = ""


# ---------------------------------------------------------------------------
# GET /orders/abandoned — list abandoned orders
# ---------------------------------------------------------------------------

@router.get("/abandoned", response_model=AbandonedOrderListResponse)
def list_abandoned_orders(
    hours: int = Query(24, ge=1, description="Hours since order was created"),
    limit: int = Query(50, ge=1, le=200, description="Max results"),
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Return orders with status="pending" that were created more than
    ``hours`` ago. Only includes orders belonging to the current seller's
    shops.
    """
    shop_ids = _get_seller_shop_ids(db, current_seller.id)
    if not shop_ids:
        return AbandonedOrderListResponse(items=[], total=0)

    cutoff = datetime.now(timezone.utc)
    stmt = (
        select(
            Order.id,
            Order.order_number,
            Order.customer_name,
            Order.customer_phone,
            Order.total_amount,
            Order.status,
            Order.payment_status,
            Order.created_at,
        )
        .where(
            Order.shop_id.in_(shop_ids),
            Order.status == "pending",
            Order.created_at < cutoff,  # We filter by age in Python for SQLite compat
        )
        .order_by(Order.created_at.asc())
        .limit(limit)
    )
    rows = db.execute(stmt).all()

    items = []
    for row in rows:
        # Compute hours since creation
        if row.created_at:
            delta = cutoff - row.created_at
            hours_since = int(delta.total_seconds() // 3600)
        else:
            hours_since = 0

        # Only include those older than the requested hours
        if hours_since < hours:
            continue

        items.append(
            AbandonedOrderItem(
                id=row.id,
                order_number=row.order_number,
                customer_name=row.customer_name,
                customer_phone=row.customer_phone,
                total_amount=float(row.total_amount),
                status=row.status,
                payment_status=row.payment_status,
                created_at=row.created_at,
                hours_since=hours_since,
            )
        )

    return AbandonedOrderListResponse(items=items, total=len(items))


# ---------------------------------------------------------------------------
# POST /orders/{order_id}/remind — send WhatsApp reminder
# ---------------------------------------------------------------------------

@router.post("/{order_id}/remind", response_model=RemindResponse)
async def remind_abandoned_order(
    order_id: int,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Send a WhatsApp reminder to the buyer about an unpaid/pending order.
    """
    shop_ids = _get_seller_shop_ids(db, current_seller.id)
    if not shop_ids:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No shops found",
        )

    order = db.execute(
        select(Order).where(
            Order.id == order_id,
            Order.shop_id.in_(shop_ids),
        )
    ).scalar_one_or_none()

    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found",
        )

    if order.status != "pending":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Order is not in pending status",
        )

    # Get the shop for context
    shop = db.execute(
        select(Shop).where(Shop.id == order.shop_id)
    ).scalar_one_or_none()

    # Build reminder message
    to = order.customer_phone
    if to.startswith("+880"):
        to = "0" + to[4:]

    message = (
        f"⏰ অর্ডারটি এখনও অপেক্ষমাণ!\n"
        f"\n"
        f"প্রিয় {order.customer_name},\n"
        f"আপনার অর্ডার {order.order_number} এখনও নিশ্চিত হয়নি।\n"
        f"আপনি কি অর্ডারটি সম্পূর্ণ করতে চান?\n"
        f"\n"
        f"-------- অর্ডার বিবরণ --------\n"
        f"মোট মূল্য: ৳{float(order.total_amount):.2f}\n"
        f"অর্ডারের তারিখ: {order.created_at.strftime('%d %b %Y, %I:%M %p') if order.created_at else 'N/A'}\n"
    )
    if shop:
        message += (
            f"দোকান: {shop.name}\n"
            f"ফোন: {shop.contact_phone or 'N/A'}\n"
        )
    message += (
        f"\n"
        f"অনুগ্রহ করে অর্ডারটি সম্পূর্ণ করতে দ্রুত পেমেন্ট সম্পন্ন করুন।\n"
        f"ধন্যবাদ 🙏"
    )

    try:
        service = get_whatsapp_service()
        await service.send_message(to, message)
        return RemindResponse(sent=True, message="Reminder sent successfully")
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to send reminder: {str(exc)}",
        )


@router.put("/{order_id}/status", response_model=OrderPublic)
async def update_order_status(
    request: Request,
    order_id: int,
    payload: OrderStatusUpdate,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Update the status of an order. Validates that the order belongs to the
    current seller and that the requested status is valid.
    """
    new_status = payload.status.lower()
    if new_status not in VALID_STATUSES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid status '{payload.status}'. Must be one of: {', '.join(sorted(VALID_STATUSES))}",
        )

    shop_ids = _get_seller_shop_ids(db, current_seller.id)
    if not shop_ids:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No shops found for this seller",
        )

    stmt = select(Order).where(Order.id == order_id, Order.shop_id.in_(shop_ids))
    order = db.execute(stmt).scalar_one_or_none()
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found",
        )

    old_status = order.status
    order.status = new_status
    db.commit()
    db.refresh(order)

    # Log the status change in audit log
    log_action(
        db=db,
        action="order.status_update",
        entity_type="order",
        entity_id=str(order.id),
        seller_id=current_seller.id,
        actor_email=current_seller.email,
        old_values={"status": old_status},
        new_values={"status": new_status},
        ip_address=request.client.host if hasattr(request, "client") else None,
    )
    db.commit()

    # Fetch shop for notification
    shop_stmt = select(Shop).where(Shop.id == order.shop_id)
    shop = db.execute(shop_stmt).scalar_one_or_none()
    if shop:
        await send_status_update_notification(order, shop)

    # Load items for response
    items_stmt = select(OrderItem).where(OrderItem.order_id == order_id)
    items = db.execute(items_stmt).scalars().all()

    return OrderPublic(
        id=order.id,
        order_number=order.order_number,
        customer_name=order.customer_name,
        customer_phone=order.customer_phone,
        customer_address=order.customer_address,
        total_amount=float(order.total_amount),
        status=order.status,
        payment_status=order.payment_status,
        notes=order.notes,
        shop_id=order.shop_id,
        created_at=order.created_at,
        items=[
            OrderItemPublic(
                id=item.id,
                product_id=item.product_id,
                product_name=item.product_name,
                quantity=item.quantity,
                unit_price=float(item.unit_price),
                subtotal=float(item.subtotal),
            )
            for item in items
        ],
    )


# ---------------------------------------------------------------------------
# Abandoned cart schemas
# ---------------------------------------------------------------------------

class AbandonedOrderItem(BaseModel):
    id: int
    order_number: str
    customer_name: str
    customer_phone: str
    total_amount: float
    status: str
    payment_status: str
    created_at: datetime
    hours_since: int

    model_config = ConfigDict(from_attributes=True)


class AbandonedOrderListResponse(BaseModel):
    items: list[AbandonedOrderItem]
    total: int


class RemindResponse(BaseModel):
    sent: bool
    message: str = ""


# ---------------------------------------------------------------------------
# GET /orders/abandoned — list abandoned orders
# ---------------------------------------------------------------------------

@router.get("/abandoned", response_model=AbandonedOrderListResponse)
def list_abandoned_orders(
    hours: int = Query(24, ge=1, description="Hours since order was created"),
    limit: int = Query(50, ge=1, le=200, description="Max results"),
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Return orders with status="pending" that were created more than
    ``hours`` ago. Only includes orders belonging to the current seller's
    shops.
    """
    shop_ids = _get_seller_shop_ids(db, current_seller.id)
    if not shop_ids:
        return AbandonedOrderListResponse(items=[], total=0)

    cutoff = datetime.now(timezone.utc)
    stmt = (
        select(
            Order.id,
            Order.order_number,
            Order.customer_name,
            Order.customer_phone,
            Order.total_amount,
            Order.status,
            Order.payment_status,
            Order.created_at,
        )
        .where(
            Order.shop_id.in_(shop_ids),
            Order.status == "pending",
            Order.created_at < cutoff,  # We filter by age in Python for SQLite compat
        )
        .order_by(Order.created_at.asc())
        .limit(limit)
    )
    rows = db.execute(stmt).all()

    items = []
    for row in rows:
        # Compute hours since creation
        if row.created_at:
            delta = cutoff - row.created_at
            hours_since = int(delta.total_seconds() // 3600)
        else:
            hours_since = 0

        # Only include those older than the requested hours
        if hours_since < hours:
            continue

        items.append(
            AbandonedOrderItem(
                id=row.id,
                order_number=row.order_number,
                customer_name=row.customer_name,
                customer_phone=row.customer_phone,
                total_amount=float(row.total_amount),
                status=row.status,
                payment_status=row.payment_status,
                created_at=row.created_at,
                hours_since=hours_since,
            )
        )

    return AbandonedOrderListResponse(items=items, total=len(items))


# ---------------------------------------------------------------------------
# POST /orders/{order_id}/remind — send WhatsApp reminder
# ---------------------------------------------------------------------------

@router.post("/{order_id}/remind", response_model=RemindResponse)
async def remind_abandoned_order(
    order_id: int,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Send a WhatsApp reminder to the buyer about an unpaid/pending order.
    """
    shop_ids = _get_seller_shop_ids(db, current_seller.id)
    if not shop_ids:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No shops found",
        )

    order = db.execute(
        select(Order).where(
            Order.id == order_id,
            Order.shop_id.in_(shop_ids),
        )
    ).scalar_one_or_none()

    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found",
        )

    if order.status != "pending":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Order is not in pending status",
        )

    # Get the shop for context
    shop = db.execute(
        select(Shop).where(Shop.id == order.shop_id)
    ).scalar_one_or_none()

    # Build reminder message
    to = order.customer_phone
    if to.startswith("+880"):
        to = "0" + to[4:]

    message = (
        f"⏰ অর্ডারটি এখনও অপেক্ষমাণ!\n"
        f"\n"
        f"প্রিয় {order.customer_name},\n"
        f"আপনার অর্ডার {order.order_number} এখনও নিশ্চিত হয়নি।\n"
        f"আপনি কি অর্ডারটি সম্পূর্ণ করতে চান?\n"
        f"\n"
        f"-------- অর্ডার বিবরণ --------\n"
        f"মোট মূল্য: ৳{float(order.total_amount):.2f}\n"
        f"অর্ডারের তারিখ: {order.created_at.strftime('%d %b %Y, %I:%M %p') if order.created_at else 'N/A'}\n"
    )
    if shop:
        message += (
            f"দোকান: {shop.name}\n"
            f"ফোন: {shop.contact_phone or 'N/A'}\n"
        )
    message += (
        f"\n"
        f"অনুগ্রহ করে অর্ডারটি সম্পূর্ণ করতে দ্রুত পেমেন্ট সম্পন্ন করুন।\n"
        f"ধন্যবাদ 🙏"
    )

    try:
        service = get_whatsapp_service()
        await service.send_message(to, message)
        return RemindResponse(sent=True, message="Reminder sent successfully")
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to send reminder: {str(exc)}",
        )
