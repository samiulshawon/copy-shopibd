"""
Analytics & reporting endpoints for ShopiBD.

Provides dashboard metrics, sales chart data, top-product rankings,
order-status breakdowns, and conversion-funnel insights scoped to
the authenticated seller.
"""

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.order import Order, OrderItem
from app.models.product import Product
from app.models.seller import Seller
from app.models.shop import Shop
from app.api.v1.dependencies import get_current_seller
from app.schemas.analytics import (
    DashboardStats,
    SalesChartResponse,
    SalesDataPoint,
    StatusBreakdown,
    TopProduct,
    TopProductsResponse,
)

router = APIRouter(prefix="/analytics", tags=["analytics"])


def _get_seller_shop_ids(seller_id: int, db: Session) -> list[int]:
    """Return all shop IDs owned by *seller_id*."""
    stmt = select(Shop.id).where(Shop.seller_id == seller_id)
    return list(db.execute(stmt).scalars().all())


# ---------------------------------------------------------------------------
# 1.3.1.1  GET /analytics/dashboard
# ---------------------------------------------------------------------------


@router.get("/dashboard", response_model=DashboardStats)
async def get_dashboard(
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Return today's key metrics for the seller's dashboard.

    Includes:
    - Today's order count & revenue
    - Total pending orders
    - Total low-stock products (stock <= low_stock_threshold)
    - Total products and orders across all shops
    """
    shop_ids = _get_seller_shop_ids(current_seller.id, db)

    # Short-circuit if seller has no shops
    if not shop_ids:
        return DashboardStats()

    today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)

    # Today's orders
    today_orders_stmt = select(func.count(Order.id)).where(
        Order.shop_id.in_(shop_ids),
        Order.created_at >= today_start,
    )
    today_orders = db.execute(today_orders_stmt).scalar() or 0

    # Today's revenue (paid orders)
    today_revenue_stmt = select(
        func.coalesce(func.sum(Order.total_amount), 0)
    ).where(
        Order.shop_id.in_(shop_ids),
        Order.created_at >= today_start,
        Order.payment_status.in_(["paid", "completed"]),
    )
    today_revenue = float(db.execute(today_revenue_stmt).scalar() or 0)

    # Pending orders (all time)
    pending_stmt = select(func.count(Order.id)).where(
        Order.shop_id.in_(shop_ids),
        Order.status == "pending",
    )
    pending_orders = db.execute(pending_stmt).scalar() or 0

    # Low stock products (stock <= 5)
    low_stock_stmt = select(func.count(Product.id)).where(
        Product.shop_id.in_(shop_ids),
        Product.stock <= 5,
        Product.is_active == True,
    )
    low_stock_count = db.execute(low_stock_stmt).scalar() or 0

    # Total products
    total_products_stmt = select(func.count(Product.id)).where(
        Product.shop_id.in_(shop_ids)
    )
    total_products = db.execute(total_products_stmt).scalar() or 0

    # Total orders
    total_orders_stmt = select(func.count(Order.id)).where(
        Order.shop_id.in_(shop_ids)
    )
    total_orders = db.execute(total_orders_stmt).scalar() or 0

    return DashboardStats(
        today_orders=today_orders,
        today_revenue=today_revenue,
        pending_orders=pending_orders,
        low_stock_count=low_stock_count,
        total_products=total_products,
        total_orders=total_orders,
    )


# ---------------------------------------------------------------------------
# 1.3.1.2  GET /analytics/sales?period=7d|30d|90d
# ---------------------------------------------------------------------------


@router.get("/sales", response_model=SalesChartResponse)
async def get_sales_chart(
    period: str = Query(
        "7d", pattern="^(7d|30d|90d)$", description="Time period (7d, 30d, 90d)"
    ),
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Return daily sales (order count + revenue) for the requested period.

    Period options:
    - ``7d``  → last 7 days
    - ``30d`` → last 30 days
    - ``90d`` → last 90 days
    """
    shop_ids = _get_seller_shop_ids(current_seller.id, db)
    if not shop_ids:
        return SalesChartResponse(period=period, data=[])

    days = int(period.replace("d", ""))
    since = datetime.now(timezone.utc) - timedelta(days=days)

    # Group by date
    date_col = func.date(Order.created_at)
    stmt = (
        select(
            date_col.label("date"),
            func.count(Order.id).label("orders"),
            func.coalesce(func.sum(Order.total_amount), 0).label("revenue"),
        )
        .where(
            Order.shop_id.in_(shop_ids),
            Order.created_at >= since,
        )
        .group_by(date_col)
        .order_by(date_col)
    )
    rows = db.execute(stmt).all()

    data = [
        SalesDataPoint(
            date=str(row.date),
            orders=row.orders,
            revenue=float(row.revenue),
        )
        for row in rows
    ]

    return SalesChartResponse(period=period, data=data)


# ---------------------------------------------------------------------------
# 1.3.1.3  GET /analytics/top-products?limit=10
# ---------------------------------------------------------------------------


@router.get("/top-products", response_model=TopProductsResponse)
async def get_top_products(
    limit: int = Query(
        10, ge=1, le=100, description="Number of top products to return"
    ),
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Return the top-selling products ranked by total quantity sold.

    Results are scoped to the current seller's shops.
    """
    shop_ids = _get_seller_shop_ids(current_seller.id, db)
    if not shop_ids:
        return TopProductsResponse(items=[])

    stmt = (
        select(
            Product.id,
            Product.name,
            func.coalesce(func.sum(OrderItem.quantity), 0).label("total_quantity"),
            func.coalesce(func.sum(OrderItem.subtotal), 0).label("total_revenue"),
            func.count(OrderItem.id.distinct()).label("order_count"),
        )
        .join(OrderItem, OrderItem.product_id == Product.id)
        .join(Order, Order.id == OrderItem.order_id)
        .where(
            Product.shop_id.in_(shop_ids),
            Order.shop_id.in_(shop_ids),
            Order.status != "cancelled",
        )
        .group_by(Product.id, Product.name)
        .order_by(func.coalesce(func.sum(OrderItem.quantity), 0).desc())
        .limit(limit)
    )
    rows = db.execute(stmt).all()

    items = [
        TopProduct(
            product_id=row.id,
            product_name=row.name,
            total_quantity=row.total_quantity,
            total_revenue=float(row.total_revenue),
            order_count=row.order_count,
        )
        for row in rows
    ]

    return TopProductsResponse(items=items)


# ---------------------------------------------------------------------------
# 1.3.1.4  GET /analytics/order-status-breakdown
# ---------------------------------------------------------------------------


@router.get("/order-status-breakdown", response_model=list[StatusBreakdown])
async def get_order_status_breakdown(
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Return order count grouped by status for the authenticated seller.

    Returns an array of ``{status, count}`` objects representing the
    distribution of orders across all statuses (pending, confirmed,
    shipped, delivered, cancelled, etc.).
    """
    shop_ids = _get_seller_shop_ids(current_seller.id, db)
    if not shop_ids:
        return []

    stmt = (
        select(
            Order.status,
            func.count(Order.id).label("count"),
        )
        .where(Order.shop_id.in_(shop_ids))
        .group_by(Order.status)
        .order_by(Order.status)
    )
    rows = db.execute(stmt).all()

    return [StatusBreakdown(status=row.status, count=row.count) for row in rows]


# ---------------------------------------------------------------------------
# 1.3.1.5  GET /analytics/conversion-funnel  (existing)
# ---------------------------------------------------------------------------


@router.get("/conversion-funnel")
async def get_conversion_funnel(
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Return a conversion funnel showing the visitor → order → paid
    drop-off for the current seller's shops.

    .. note::
       This endpoint uses order records as a proxy for conversions.
       When a dedicated analytics / page-view tracking system is
       added, replace the hard-coded ``visits`` estimate with real
       data.

    The funnel stages:
    - ``visits``       — estimated total page views (placeholder)
    - ``orders``       — total orders created
    - ``paid_orders``  — orders with payment_status = paid or completed
    """
    shop_ids = _get_seller_shop_ids(current_seller.id, db)
    if not shop_ids:
        return {
            "visits": 0,
            "orders": 0,
            "paid_orders": 0,
            "conversion_rate": 0.0,
        }

    # Total orders
    orders_stmt = select(func.count(Order.id)).where(
        Order.shop_id.in_(shop_ids)
    )
    total_orders = db.execute(orders_stmt).scalar() or 0

    # Paid orders
    paid_stmt = select(func.count(Order.id)).where(
        Order.shop_id.in_(shop_ids),
        Order.payment_status.in_(["paid", "completed"]),
    )
    paid_orders = db.execute(paid_stmt).scalar() or 0

    # Estimate visits as 10x total orders (placeholder)
    estimated_visits = total_orders * 10

    conversion_rate = (
        round((paid_orders / total_orders) * 100, 2)
        if total_orders > 0
        else 0.0
    )

    return {
        "visits": estimated_visits,
        "orders": total_orders,
        "paid_orders": paid_orders,
        "conversion_rate": conversion_rate,
    }