from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select, func
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.review import Review
from app.models.product import Product
from app.models.seller import Seller
from app.api.v1.dependencies import get_current_admin_seller
from app.schemas.review import (
    ReviewCreate,
    ReviewPublic,
    ReviewResponse,
    ReviewReject,
)
from app.schemas.common import PaginatedResponse

router = APIRouter(tags=["reviews"])


# ──────────────────────────────────────────────
#  Public endpoints
# ──────────────────────────────────────────────


@router.post("/reviews", response_model=ReviewResponse, status_code=status.HTTP_201_CREATED)
def submit_review(
    review_in: ReviewCreate,
    db: Session = Depends(get_db),
):
    """
    Submit a new product review (public, no authentication required).

    Validates rating between 1-5 and prevents duplicate reviews from the
    same phone number for the same product. New reviews require admin
    approval before becoming visible.
    """
    # Validate rating
    if review_in.rating < 1 or review_in.rating > 5:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Rating must be between 1 and 5",
        )

    # Verify product exists
    product = db.query(Product).filter(Product.id == review_in.product_id).first()
    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Product not found",
        )

    # Prevent duplicate reviews from same phone for same product
    existing = (
        db.query(Review)
        .filter(
            Review.product_id == review_in.product_id,
            Review.buyer_phone == review_in.buyer_phone,
        )
        .first()
    )
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="You have already submitted a review for this product",
        )

    review = Review(
        product_id=review_in.product_id,
        buyer_name=review_in.buyer_name,
        buyer_phone=review_in.buyer_phone,
        rating=review_in.rating,
        title=review_in.title,
        body=review_in.body,
        is_approved=False,
    )
    db.add(review)
    db.commit()
    db.refresh(review)
    return review


@router.get(
    "/products/{product_id}/reviews",
    response_model=PaginatedResponse[ReviewPublic],
)
def list_product_reviews(
    product_id: int,
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    """
    List approved reviews for a product (public).

    Returns only approved reviews with buyer name, rating, title, body,
    created_at and reply information.
    """
    # Verify product exists
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Product not found",
        )

    # Count total approved reviews
    count_stmt = (
        select(func.count())
        .select_from(Review)
        .where(Review.product_id == product_id, Review.is_approved == True)
    )
    total = db.execute(count_stmt).scalar() or 0

    # Fetch paginated approved reviews
    stmt = (
        select(Review)
        .where(Review.product_id == product_id, Review.is_approved == True)
        .order_by(Review.created_at.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
    )
    reviews = db.execute(stmt).scalars().all()

    total_pages = (total + page_size - 1) // page_size if total > 0 else 0

    return PaginatedResponse(
        items=reviews,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
    )


# ──────────────────────────────────────────────
#  Admin endpoints
# ──────────────────────────────────────────────


@router.get(
    "/admin/reviews",
    response_model=PaginatedResponse[ReviewResponse],
)
def list_all_reviews(
    status_filter: str | None = Query(
        default=None, description="Filter by status: pending, approved, rejected"
    ),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    admin_seller: Seller = Depends(get_current_admin_seller),
    db: Session = Depends(get_db),
):
    """
    List all reviews (admin only).

    Optional query parameter ``status_filter``:
    - ``pending``  — reviews awaiting approval (is_approved=False)
    - ``approved`` — approved reviews (is_approved=True)
    - ``rejected`` — rejected reviews (is_approved=False with rejection reason)

    If omitted, returns all reviews ordered by creation date descending.
    """
    stmt = select(Review)

    if status_filter == "pending":
        stmt = stmt.where(Review.is_approved == False)
    elif status_filter == "approved":
        stmt = stmt.where(Review.is_approved == True)
    elif status_filter == "rejected":
        stmt = stmt.where(Review.is_approved == False, Review.reply_text.isnot(None))
    # else: no filter, return all

    # Count total
    count_stmt = select(func.count()).select_from(stmt.subquery())
    total = db.execute(count_stmt).scalar() or 0

    stmt = stmt.order_by(Review.created_at.desc())
    stmt = stmt.offset((page - 1) * page_size).limit(page_size)
    reviews = db.execute(stmt).scalars().all()

    total_pages = (total + page_size - 1) // page_size if total > 0 else 0

    return PaginatedResponse(
        items=reviews,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
    )


@router.put("/admin/reviews/{review_id}/approve", response_model=ReviewResponse)
def approve_review(
    review_id: int,
    admin_seller: Seller = Depends(get_current_admin_seller),
    db: Session = Depends(get_db),
):
    """
    Approve a pending review (admin only).

    Sets ``is_approved`` to ``True``, making the review visible on the
    public product page.
    """
    review = db.query(Review).filter(Review.id == review_id).first()
    if not review:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Review not found",
        )

    if review.is_approved:
        return review

    review.is_approved = True
    db.commit()
    db.refresh(review)
    return review


@router.put("/admin/reviews/{review_id}/reject", response_model=ReviewResponse)
def reject_review(
    review_id: int,
    reject_in: ReviewReject,
    admin_seller: Seller = Depends(get_current_admin_seller),
    db: Session = Depends(get_db),
):
    """
    Reject a pending review (admin only).

    Sets ``is_approved`` to ``False`` and records the rejection reason
    in the ``reply_text`` field.
    """
    review = db.query(Review).filter(Review.id == review_id).first()
    if not review:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Review not found",
        )

    review.is_approved = False
    review.reply_text = reject_in.rejection_reason
    db.commit()
    db.refresh(review)
    return review
