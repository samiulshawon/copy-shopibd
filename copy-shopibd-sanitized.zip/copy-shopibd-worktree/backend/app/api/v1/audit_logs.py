"""
Audit log viewer API for ShopiBD.

Provides paginated, filterable listing of audit log entries for administrators.
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.api.v1.dependencies import get_current_admin_seller
from app.core.database import get_db
from app.models.audit_log import AuditLog
from app.models.seller import Seller
from app.schemas.common import PaginatedResponse
from pydantic import BaseModel, ConfigDict


router = APIRouter(prefix="/audit-logs", tags=["audit-logs"])


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------


class AuditLogItem(BaseModel):
    id: int
    seller_id: Optional[int] = None
    actor_email: Optional[str] = None
    action: str
    entity_type: str
    entity_id: Optional[str] = None
    ip_address: Optional[str] = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class AuditLogDetail(AuditLogItem):
    old_values: Optional[dict] = None
    new_values: Optional[dict] = None
    extra_data: Optional[dict] = None


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("/", response_model=PaginatedResponse[AuditLogItem])
def list_audit_logs(
    page: int = Query(1, ge=1, description="Page number"),
    limit: int = Query(50, ge=1, le=200, description="Items per page"),
    action: Optional[str] = Query(None, description="Filter by action name"),
    entity_type: Optional[str] = Query(None, description="Filter by entity type"),
    seller_id: Optional[int] = Query(None, description="Filter by seller ID"),
    date_from: Optional[datetime] = Query(None, description="Start date"),
    date_to: Optional[datetime] = Query(None, description="End date"),
    current_seller: Seller = Depends(get_current_admin_seller),
    db: Session = Depends(get_db),
):
    """
    Return a paginated list of audit log entries.

    Requires admin-level seller privileges.
    """
    stmt = select(AuditLog)

    if action:
        stmt = stmt.where(AuditLog.action == action)
    if entity_type:
        stmt = stmt.where(AuditLog.entity_type == entity_type)
    if seller_id:
        stmt = stmt.where(AuditLog.seller_id == seller_id)
    if date_from:
        stmt = stmt.where(AuditLog.created_at >= date_from)
    if date_to:
        stmt = stmt.where(AuditLog.created_at <= date_to)

    # Total count
    count_stmt = select(func.count()).select_from(stmt.subquery())
    total = db.execute(count_stmt).scalar() or 0

    # Pagination
    stmt = stmt.order_by(AuditLog.created_at.desc()).offset((page - 1) * limit).limit(limit)
    rows = db.execute(stmt).scalars().all()

    items = [
        AuditLogItem(
            id=entry.id,
            seller_id=entry.seller_id,
            actor_email=entry.actor_email,
            action=entry.action,
            entity_type=entry.entity_type,
            entity_id=entry.entity_id,
            ip_address=entry.ip_address,
            created_at=entry.created_at,
        )
        for entry in rows
    ]

    total_pages = (total + limit - 1) // limit if total > 0 else 0
    return PaginatedResponse(
        items=items,
        total=total,
        page=page,
        page_size=limit,
        total_pages=total_pages,
    )


@router.get("/{log_id}", response_model=AuditLogDetail)
def get_audit_log(
    log_id: int,
    current_seller: Seller = Depends(get_current_admin_seller),
    db: Session = Depends(get_db),
):
    """Return full details of a single audit log entry."""
    stmt = select(AuditLog).where(AuditLog.id == log_id)
    entry = db.execute(stmt).scalar_one_or_none()
    if not entry:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Audit log entry not found",
        )
    return entry
