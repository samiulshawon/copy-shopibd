"""
Seller profile and dashboard endpoints for ShopiBD.

All routes are protected by the ``get_current_seller`` dependency.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.order import Order
from app.models.product import Product
from app.models.seller import Seller
from app.models.shop import Shop
from app.api.v1.dependencies import get_current_seller
from app.schemas.seller import Seller as SellerSchema, SellerUpdate, SellerSettingsUpdate, SellerSettingsUpdate

router = APIRouter(prefix="/sellers", tags=["sellers"])


@router.get("/me", response_model=SellerSchema)
async def get_my_profile(
    current_seller: Seller = Depends(get_current_seller),
) -> Seller:
    """
    Return the profile of the currently authenticated seller.
    """
    return current_seller


@router.put("/me", response_model=SellerSchema)
async def update_my_profile(
    payload: SellerUpdate,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> Seller:
    """
    Update the authenticated seller's profile.

    Only the fields provided in the request body will be changed.
    """
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(current_seller, field, value)

    db.commit()
    db.refresh(current_seller)
    return current_seller


@router.get("/me/dashboard")
async def get_dashboard_stats(
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Return high-level dashboard statistics for the current seller.

    Includes total products, total orders, total revenue (sum of all
    completed order amounts), and counts for pending / processing orders.
    """
    # Total shops
    shops_stmt = select(func.count(Shop.id)).where(
        Shop.seller_id == current_seller.id
    )
    total_shops = db.execute(shops_stmt).scalar() or 0

    # Total products (across all shops)
    products_stmt = (
        select(func.count(Product.id))
        .join(Shop, Product.shop_id == Shop.id)
        .where(Shop.seller_id == current_seller.id)
    )
    total_products = db.execute(products_stmt).scalar() or 0

    # Total orders (across all shops)
    orders_stmt = (
        select(func.count(Order.id))
        .join(Shop, Order.shop_id == Shop.id)
        .where(Shop.seller_id == current_seller.id)
    )
    total_orders = db.execute(orders_stmt).scalar() or 0

    # Pending orders
    pending_stmt = (
        select(func.count(Order.id))
        .join(Shop, Order.shop_id == Shop.id)
        .where(Shop.seller_id == current_seller.id, Order.status == "pending")
    )
    pending_orders = db.execute(pending_stmt).scalar() or 0

    # Total revenue (sum of total_amount for paid/completed orders)
    revenue_stmt = (
        select(func.coalesce(func.sum(Order.total_amount), 0))
        .join(Shop, Order.shop_id == Shop.id)
        .where(
            Shop.seller_id == current_seller.id,
            Order.payment_status.in_(["paid", "completed"]),
        )
    )
    total_revenue = float(db.execute(revenue_stmt).scalar() or 0)

    return {
        "total_shops": total_shops,
        "total_products": total_products,
        "total_orders": total_orders,
        "pending_orders": pending_orders,
        "total_revenue": total_revenue,
    }


@router.get("/me/usage")
async def get_my_usage(
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Return the current seller's resource usage vs plan limits.

    Returns product_count, order_count, and the plan limits
    (max_products, max_orders, plan name).
    """
    # Total products (across all shops)
    products_stmt = (
        select(func.count(Product.id))
        .join(Shop, Product.shop_id == Shop.id)
        .where(Shop.seller_id == current_seller.id)
    )
    product_count = db.execute(products_stmt).scalar() or 0

    # Total orders (across all shops)
    orders_stmt = (
        select(func.count(Order.id))
        .join(Shop, Order.shop_id == Shop.id)
        .where(Shop.seller_id == current_seller.id)
    )
    order_count = db.execute(orders_stmt).scalar() or 0

    return {
        "product_count": product_count,
        "order_count": order_count,
        "plan": current_seller.plan,
        "max_products": current_seller.max_products,
        "max_orders": current_seller.max_orders,
    }


@router.put("/me/settings")
async def update_my_settings(
    payload: SellerSettingsUpdate,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Update the authenticated seller's shop payment methods and delivery settings.

    Updates the seller's first shop with the provided bkash_number,
    nagad_number, rocket_number, and delivery_settings.
    """
    # Find the seller's first shop
    shop_stmt = select(Shop).where(Shop.seller_id == current_seller.id)
    shop = db.execute(shop_stmt).scalar_one_or_none()
    if shop is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No shop found for this seller. Create a shop first.",
        )

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(shop, field, value)

    db.commit()
    db.refresh(shop)
    return {
        "message": "Settings updated successfully",
        "shop": {
            "bkash_number": shop.bkash_number,
            "nagad_number": shop.nagad_number,
            "rocket_number": shop.rocket_number,
            "delivery_settings": shop.delivery_settings,
        },
    }
