"""Customer management & CRM endpoints for ShopiBD.

All routes are seller-scoped (authenticated via ``get_current_seller``).
"""

from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.api.v1.dependencies import get_current_seller
from app.core.database import get_db
from app.models.customer import Customer
from app.models.order import Order
from app.models.seller import Seller
from app.models.shop import Shop
from app.schemas.common import PaginatedResponse
from app.schemas.customer import (
    BroadcastRequest,
    BroadcastResponse,
    CustomerListResponse,
    CustomerResponse,
    CustomerUpdate,
)
from app.services.whatsapp.factory import get_whatsapp_service

router = APIRouter(prefix="/customers", tags=["customers"])


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_seller_shop_ids(db: Session, seller_id: int) -> list[int]:
    stmt = select(Shop.id).where(Shop.seller_id == seller_id)
    return list(db.execute(stmt).scalars().all())


def _recalculate_customer_segment(customer: Customer) -> str:
    """Auto-segment a customer based on their order history.

    Rules:
      - **vip**: total_spent > 50 000 BDT OR total_orders > 10
      - **repeat**: total_orders > 1
      - **inactive**: last_order > 30 days ago (but ≤ 90)
      - **dormant**: last_order > 90 days ago
      - **new**: total_orders = 1
    """
    if customer.total_spent > 50000 or customer.total_orders > 10:
        return "vip"
    if customer.total_orders > 1:
        # Check for inactivity
        if customer.last_order_date:
            days_since_last = (datetime.now(timezone.utc) - customer.last_order_date.replace(tzinfo=None)).days
            if days_since_last > 90:
                return "dormant"
            if days_since_last > 30:
                return "inactive"
        return "repeat"
    if customer.total_orders == 1:
        if customer.last_order_date:
            days_since_last = (datetime.now(timezone.utc) - customer.last_order_date.replace(tzinfo=None)).days
            if days_since_last > 90:
                return "dormant"
            if days_since_last > 30:
                return "inactive"
        return "new"
    return "new"


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("/", response_model=CustomerListResponse)
def list_customers(
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(20, ge=1, le=100, description="Items per page"),
    search: Optional[str] = Query(None, description="Search by name or phone"),
    segment: Optional[str] = Query(None, description="Filter by segment"),
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """Return a paginated list of customers for the current seller.

    Supports free-text search (name / phone) and segment filtering.
    """
    stmt = select(Customer).where(Customer.seller_id == current_seller.id)

    # Search filter
    if search:
        stmt = stmt.where(
            or_(
                Customer.name.ilike(f"%{search}%"),
                Customer.phone.ilike(f"%{search}%"),
            )
        )

    # Segment filter
    if segment:
        stmt = stmt.where(Customer.segment == segment)

    # Total count
    count_stmt = select(func.count()).select_from(stmt.subquery())
    total = db.execute(count_stmt).scalar() or 0

    # Pagination
    total_pages = max(1, (total + page_size - 1) // page_size)
    stmt = stmt.order_by(Customer.updated_at.desc())
    stmt = stmt.offset((page - 1) * page_size).limit(page_size)
    customers = db.execute(stmt).scalars().all()

    items = [
        {
            "id": c.id,
            "name": c.name,
            "phone": c.phone,
            "total_orders": c.total_orders,
            "total_spent": float(c.total_spent) if c.total_spent else 0,
            "segment": c.segment,
            "last_order_date": c.last_order_date.isoformat() if c.last_order_date else None,
        }
        for c in customers
    ]

    return CustomerListResponse(
        items=items,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
    )


@router.get("/{customer_id}", response_model=CustomerResponse)
def get_customer(
    customer_id: int,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """Return full customer profile."""
    stmt = select(Customer).where(
        Customer.id == customer_id,
        Customer.seller_id == current_seller.id,
    )
    customer = db.execute(stmt).scalar_one_or_none()
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")

    return {
        "id": customer.id,
        "name": customer.name,
        "phone": customer.phone,
        "email": customer.email,
        "total_orders": customer.total_orders,
        "total_spent": float(customer.total_spent) if customer.total_spent else 0,
        "last_order_date": customer.last_order_date,
        "tags": customer.tags,
        "notes": customer.notes,
        "segment": customer.segment,
        "created_at": customer.created_at,
    }


@router.put("/{customer_id}/notes", response_model=CustomerResponse)
def update_customer_notes(
    customer_id: int,
    body: CustomerUpdate,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """Update customer notes and / or tags."""
    stmt = select(Customer).where(
        Customer.id == customer_id,
        Customer.seller_id == current_seller.id,
    )
    customer = db.execute(stmt).scalar_one_or_none()
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")

    if body.notes is not None:
        customer.notes = body.notes
    if body.tags is not None:
        customer.tags = body.tags
    if body.segment is not None:
        customer.segment = body.segment

    db.commit()
    db.refresh(customer)

    return {
        "id": customer.id,
        "name": customer.name,
        "phone": customer.phone,
        "email": customer.email,
        "total_orders": customer.total_orders,
        "total_spent": float(customer.total_spent) if customer.total_spent else 0,
        "last_order_date": customer.last_order_date,
        "tags": customer.tags,
        "notes": customer.notes,
        "segment": customer.segment,
        "created_at": customer.created_at,
    }


@router.put("/{customer_id}/segment", response_model=CustomerResponse)
def set_customer_segment(
    customer_id: int,
    body: CustomerUpdate,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """Manually set a customer's segment.

    Allowed values: new, repeat, vip, inactive, dormant.
    """
    if body.segment not in ("new", "repeat", "vip", "inactive", "dormant"):
        raise HTTPException(
            status_code=400,
            detail=f"Invalid segment '{body.segment}'. Allowed: new, repeat, vip, inactive, dormant.",
        )

    stmt = select(Customer).where(
        Customer.id == customer_id,
        Customer.seller_id == current_seller.id,
    )
    customer = db.execute(stmt).scalar_one_or_none()
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")

    customer.segment = body.segment
    db.commit()
    db.refresh(customer)

    return {
        "id": customer.id,
        "name": customer.name,
        "phone": customer.phone,
        "email": customer.email,
        "total_orders": customer.total_orders,
        "total_spent": float(customer.total_spent) if customer.total_spent else 0,
        "last_order_date": customer.last_order_date,
        "tags": customer.tags,
        "notes": customer.notes,
        "segment": customer.segment,
        "created_at": customer.created_at,
    }


@router.get("/{customer_id}/orders", response_model=PaginatedResponse)
def get_customer_orders(
    customer_id: int,
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(20, ge=1, le=100, description="Items per page"),
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """Return orders placed by a specific customer."""
    # Verify customer belongs to this seller
    cust_stmt = select(Customer).where(
        Customer.id == customer_id,
        Customer.seller_id == current_seller.id,
    )
    customer = db.execute(cust_stmt).scalar_one_or_none()
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")

    shop_ids = _get_seller_shop_ids(db, current_seller.id)
    if not shop_ids:
        return PaginatedResponse(items=[], total=0, page=page, page_size=page_size, total_pages=0)

    # Find orders matching the customer's phone in any of the seller's shops
    stmt = (
        select(Order)
        .where(
            Order.customer_phone == customer.phone,
            Order.shop_id.in_(shop_ids),
        )
        .order_by(Order.created_at.desc())
    )

    count_stmt = select(func.count()).select_from(stmt.subquery())
    total = db.execute(count_stmt).scalar() or 0

    total_pages = max(1, (total + page_size - 1) // page_size)
    stmt = stmt.offset((page - 1) * page_size).limit(page_size)
    orders = db.execute(stmt).scalars().all()

    items = [
        {
            "id": o.id,
            "order_number": o.order_number,
            "customer_name": o.customer_name,
            "customer_phone": o.customer_phone,
            "total_amount": float(o.total_amount),
            "status": o.status,
            "payment_status": o.payment_status,
            "created_at": o.created_at,
        }
        for o in orders
    ]

    return PaginatedResponse(
        items=items,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
    )


@router.post("/recalculate", response_model=dict)
def recalculate_segments(
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """Recalculate customer segments for all customers of the current seller."""
    stmt = select(Customer).where(Customer.seller_id == current_seller.id)
    customers = db.execute(stmt).scalars().all()

    updated_count = 0
    for customer in customers:
        new_segment = _recalculate_customer_segment(customer)
        if customer.segment != new_segment:
            customer.segment = new_segment
            updated_count += 1

    db.commit()

    return {
        "message": f"Segments recalculated for {len(customers)} customers",
        "total_customers": len(customers),
        "updated": updated_count,
    }


@router.post("/broadcast", response_model=BroadcastResponse)
async def broadcast_to_segment(
    body: BroadcastRequest,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """Send a WhatsApp message to all customers in a given segment.

    Uses the configured WhatsApp provider.
    """
    stmt = select(Customer).where(
        Customer.seller_id == current_seller.id,
        Customer.segment == body.segment,
    )
    customers = db.execute(stmt).scalars().all()

    if not customers:
        raise HTTPException(
            status_code=404,
            detail=f"No customers found in segment '{body.segment}'",
        )

    whatsapp = get_whatsapp_service()
    sent_count = 0

    for customer in customers:
        try:
            success = await whatsapp.send_message(customer.phone, body.message)
            if success:
                sent_count += 1
        except Exception:
            # Log and continue - don't fail the whole broadcast
            pass

    return BroadcastResponse(
        message=f"Broadcast sent to {len(customers)} customers in segment '{body.segment}'",
        total_customers=len(customers),
        messages_sent=sent_count,
    )


@router.post("/backfill", response_model=dict)
def backfill_customers_from_orders(
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """Create Customer records from existing Order data for the current seller.

    This is a one-time migration helper that scans all orders and builds
    customer profiles with aggregated totals and auto-segmentation.
    """
    shop_ids = _get_seller_shop_ids(db, current_seller.id)
    if not shop_ids:
        return {"message": "No shops found", "created": 0, "updated": 0}

    # Get unique customer phones from orders
    order_stmt = (
        select(
            Order.customer_phone,
            Order.customer_name,
            func.count(Order.id).label("order_count"),
            func.sum(Order.total_amount).label("total_spent"),
            func.max(Order.created_at).label("last_order_date"),
        )
        .where(Order.shop_id.in_(shop_ids))
        .group_by(Order.customer_phone, Order.customer_name)
    )
    order_groups = db.execute(order_stmt).all()

    created = 0
    updated = 0

    for row in order_groups:
        # Check if customer already exists for this seller
        stmt = select(Customer).where(
            Customer.seller_id == current_seller.id,
            Customer.phone == row.customer_phone,
        )
        existing = db.execute(stmt).scalar_one_or_none()

        total_orders = row.order_count or 0
        total_spent = float(row.total_spent) if row.total_spent else 0

        if existing:
            existing.name = row.customer_name
            existing.total_orders = total_orders
            existing.total_spent = Decimal(str(total_spent))
            existing.last_order_date = row.last_order_date
            existing.segment = _recalculate_customer_segment(existing)
            updated += 1
        else:
            new_customer = Customer(
                seller_id=current_seller.id,
                name=row.customer_name,
                phone=row.customer_phone,
                total_orders=total_orders,
                total_spent=Decimal(str(total_spent)),
                last_order_date=row.last_order_date,
                segment="new",  # will be recalculated below
            )
            new_customer.segment = _recalculate_customer_segment(new_customer)
            db.add(new_customer)
            created += 1

    db.commit()

    return {
        "message": f"Backfill complete: {created} created, {updated} updated",
        "created": created,
        "updated": updated,
    }
