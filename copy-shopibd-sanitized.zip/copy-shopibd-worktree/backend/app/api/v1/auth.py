import time
from collections import defaultdict
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from app.core import security
from app.core.database import get_db
from app.models.seller import Seller
from app.schemas.seller import (
    SellerCreate,
    Seller as SellerSchema,
    SellerLogin,
    Token,
    TokenRefresh,
)
from app.services.redis_client import get_redis, sliding_window_add

router = APIRouter()

# ---------------------------------------------------------------------------
# Login rate limiter (Redis-backed, per-IP, falls back to in-memory)
# ---------------------------------------------------------------------------
# Keyed by client IP. Uses a Redis sliding window when available so the
# counter survives restarts and is shared across replicas; otherwise falls
# back to an in-process dict (local dev / CI without Redis).
MAX_LOGIN_ATTEMPTS = 5
LOGIN_WINDOW_SECONDS = 60

REFRESH_TOKEN_EXPIRE_DAYS = 7

_login_attempts: dict[str, list[float]] = defaultdict(list)


def _check_login_rate_limit(client_ip: str) -> None:
    """Raise 429 if the client IP has exceeded the max failed attempts."""
    now = time.time()

    # Redis path: report live count from the shared sliding window.
    allowed, _count = sliding_window_add(
        f"login_attempts:{client_ip}", LOGIN_WINDOW_SECONDS, MAX_LOGIN_ATTEMPTS - 1
    )
    if not allowed:
        # Redis denied; compute retry-after from the oldest entry.
        cutoff = now - LOGIN_WINDOW_SECONDS
        oldest = None
        r = get_redis()
        if r is not None:
            entries = r.zrange(f"login_attempts:{client_ip}", 0, 0, withscores=True)
            if entries:
                oldest = float(entries[0][1])
        retry_after = int((oldest or now) + LOGIN_WINDOW_SECONDS - now) + 1
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Too many login attempts. Try again in {retry_after} seconds.",
            headers={"Retry-After": str(retry_after)},
        )

    # In-memory fallback (Redis unavailable).
    cutoff = now - LOGIN_WINDOW_SECONDS
    timestamps = _login_attempts[client_ip]
    active = [t for t in timestamps if t > cutoff]
    _login_attempts[client_ip] = active

    if len(active) >= MAX_LOGIN_ATTEMPTS:
        retry_after = int(active[0] + LOGIN_WINDOW_SECONDS - now) + 1
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Too many login attempts. Try again in {retry_after} seconds.",
            headers={"Retry-After": str(retry_after)},
        )


def _record_failed_attempt(client_ip: str) -> None:
    """Record a failed login attempt timestamp (Redis path adds to window)."""
    # The Redis sliding window is appended on the next _check_login_rate_limit
    # call; here we also keep the in-memory fallback in sync.
    _login_attempts[client_ip].append(time.time())


def _clear_attempts(client_ip: str) -> None:
    """Clear recorded attempts after a successful login."""
    _login_attempts.pop(client_ip, None)
    r = get_redis()
    if r is not None:
        try:
            r.delete(f"login_attempts:{client_ip}")
        except Exception:  # noqa: BLE001
            pass


def _get_client_ip(request: Request) -> str:
    """Extract client IP from the request, handling proxies."""
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.post("/register", response_model=SellerSchema)
def register(seller_in: SellerCreate, db: Session = Depends(get_db)):
    existing = (
        db.query(Seller)
        .filter((Seller.email == seller_in.email) | (Seller.phone == seller_in.phone))
        .first()
    )
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="A seller with this email or phone already exists.",
        )
    seller = Seller(
        name=seller_in.name,
        email=seller_in.email,
        phone=seller_in.phone,
        password_hash=security.get_password_hash(seller_in.password),
    )
    db.add(seller)
    db.commit()
    db.refresh(seller)
    return seller


@router.post("/login", response_model=Token)
def login(login_in: SellerLogin, request: Request, db: Session = Depends(get_db)):
    client_ip = _get_client_ip(request)
    _check_login_rate_limit(client_ip)

    seller = db.query(Seller).filter(Seller.email == login_in.email).first()
    if not seller or not security.verify_password(login_in.password, seller.password_hash):
        _record_failed_attempt(client_ip)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials.",
        )

    _clear_attempts(client_ip)

    access_token = security.create_access_token(subject=str(seller.id))
    refresh_token = security.create_refresh_token(subject=str(seller.id))

    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
    }


@router.post("/refresh", response_model=Token)
def refresh_token(payload: TokenRefresh, db: Session = Depends(get_db)):
    # Decode full payload to get jti for revocation
    refresh_payload = security.get_token_payload(payload.refresh_token)
    if not refresh_payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired refresh token.",
        )

    # Validate token type
    if refresh_payload.get("type") != security.TOKEN_TYPE_REFRESH:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token type for refresh.",
        )

    # Extract subject
    seller_id = refresh_payload.get("sub")
    if not seller_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token payload.",
        )

    seller = db.query(Seller).filter(Seller.id == int(seller_id)).first()
    if not seller or not seller.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Seller not found or inactive.",
        )

    # Revoke the old refresh token's jti
    old_jti = refresh_payload.get("jti")
    if old_jti:
        security.revoke_jti(old_jti)

    new_access = security.create_access_token(subject=str(seller.id))
    new_refresh = security.create_refresh_token(subject=str(seller.id))
    return {
        "access_token": new_access,
        "refresh_token": new_refresh,
        "token_type": "bearer",
    }


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(payload: TokenRefresh):
    """Revoke the provided refresh token (by its jti)."""
    refresh_payload = security.get_token_payload(payload.refresh_token)
    if refresh_payload and refresh_payload.get("type") == security.TOKEN_TYPE_REFRESH:
        jti = refresh_payload.get("jti")
        if jti:
            security.revoke_jti(jti)
    # Even if token is invalid/expired, we return 204 (idempotent)
    return None
