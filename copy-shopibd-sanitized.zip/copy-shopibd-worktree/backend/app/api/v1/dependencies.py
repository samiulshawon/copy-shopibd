"""
Authentication dependencies for ShopiBD API v1.

Provides dependency injection for retrieving the current authenticated seller
from JWT bearer tokens, as well as admin-level authorization checks.
"""

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.context import set_current_seller_id
from app.core.database import get_db
from app.core.security import decode_token, is_jti_revoked, get_token_payload
from app.models.seller import Seller

security_scheme = HTTPBearer()


def get_current_seller(
    credentials: HTTPAuthorizationCredentials = Depends(security_scheme),
    db: Session = Depends(get_db),
) -> Seller:
    """
    Decode the JWT from the Authorization header and return the
    corresponding Seller object.

    Raises 401 if the token is invalid or the seller does not exist / is inactive.
    """
    token = credentials.credentials
    payload = decode_token(token)
    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired authentication token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    try:
        seller_id = int(payload)
    except (ValueError, TypeError):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token payload",
        )

    stmt = select(Seller).where(Seller.id == seller_id)
    seller = db.execute(stmt).scalar_one_or_none()
    if seller is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Seller not found",
        )
    if not seller.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is deactivated",
        )

    return seller


def get_current_admin_seller(
    seller: Seller = Depends(get_current_seller),
) -> Seller:
    """
    Require the current seller to be a staff administrator.

    Phase 8: gates on the explicit ``is_staff`` flag, NOT ``is_verified``.
    "Verified seller" only means email/identity verified; staff is a
    separate, elevated role. This prevents a verified-but-non-staff seller
    from reaching admin routes.
    """
    if not seller.is_staff:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Staff privileges required",
        )
    return seller


def get_current_super_admin(
    seller: Seller = Depends(get_current_seller),
) -> Seller:
    """
    Require the current seller to be the platform super admin (product owner).

    This is the highest-privilege role: can create/manage client sellers and
    override their subscriptions.  Gated on the ``is_super_admin`` flag.
    """
    if not seller.is_super_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Super admin privileges required",
        )
    return seller
