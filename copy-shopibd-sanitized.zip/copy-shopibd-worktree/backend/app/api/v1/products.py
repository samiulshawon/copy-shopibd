"""
Product API endpoints.
"""
from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from fastapi.responses import StreamingResponse
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from typing import Optional, List

from app.core.database import get_db
from app.models.product import Product as ProductModel, ProductImage
from app.models.shop import Shop
from app.models.seller import Seller
from app.models.import_history import ProductsImport
from app.schemas.product import (
    ProductCreate,
    ProductUpdate,
    Product,
    ProductImageSchema,
)
from app.schemas.bulk_product import (
    BulkProductItem,
    BulkCreateRequest,
    BulkCreateResult,
    BulkStockItem,
    BulkStockUpdateRequest,
    BulkStockUpdateResult,
    BulkPriceUpdateRequest,
    BulkPriceUpdateResult,
    ImportResult,
)
from app.api.v1.dependencies import get_current_seller
from app.services.plan_limits import check_product_limit, check_bulk_product_limit
from app.services.storage import get_storage_service, StorageError

MAX_IMAGES_PER_PRODUCT = 10

import csv
import io
import json

router = APIRouter(prefix="/products")

MAX_CSV_SIZE_BYTES = 5 * 1024 * 1024  # 5 MB
CSV_COLUMNS = ["name", "description", "price", "stock", "sku", "category"]

# ---------------------------------------------------------------------------
# CSV helpers
# ---------------------------------------------------------------------------


def _read_csv_rows(content: str) -> List[dict]:
    """Parse CSV text into a list of row dicts.

    Raises ValueError if required columns are missing or rows are malformed.
    """
    reader = csv.DictReader(io.StringIO(content))
    if not reader.fieldnames:
        raise ValueError("CSV file is empty or has no header row.")

    required = {"name", "price"}
    missing = required - set(reader.fieldnames)
    if missing:
        raise ValueError(f"Missing required CSV columns: {', '.join(sorted(missing))}")

    rows: List[dict] = []
    for idx, row in enumerate(reader, start=2):  # row 1 is header
        name = (row.get("name") or "").strip()
        price_raw = (row.get("price") or "").strip()
        if not name:
            raise ValueError(f"Row {idx}: 'name' is required.")
        try:
            price = float(price_raw) if price_raw else 0.0
        except ValueError:
            raise ValueError(f"Row {idx}: 'price' must be a number.")
        try:
            stock = int(float(row.get("stock") or 0))
        except ValueError:
            stock = 0
        rows.append(
            {
                "name": name,
                "description": (row.get("description") or "").strip() or None,
                "price": price,
                "stock": stock,
                "sku": (row.get("sku") or "").strip() or None,
                "category_id": None,
            }
        )
    return rows


def parse_products_csv(content: str) -> List[dict]:
    """Public wrapper around _read_csv_rows used by the import endpoint."""
    return _read_csv_rows(content)


# ---------------------------------------------------------------------------
# Listing & CRUD
# ---------------------------------------------------------------------------


@router.get("/")
def get_products(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    search: Optional[str] = None,
    category_id: Optional[int] = None,
    shop_id: Optional[int] = None,
    is_active: Optional[bool] = None,
    sort_by: str = Query("created_at", pattern="^(created_at|price|name|stock)$"),
    order: str = Query("desc", pattern="^(asc|desc)$"),
    db: Session = Depends(get_db),
    current_seller: Seller = Depends(get_current_seller),
):
    """List the seller's products with pagination and filters."""
    query = (
        select(ProductModel)
        .join(Shop, ProductModel.shop_id == Shop.id)
        .filter(Shop.seller_id == current_seller.id)
    )

    if shop_id is not None:
        shop = db.query(Shop).filter(Shop.id == shop_id, Shop.seller_id == current_seller.id).first()
        if not shop:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Shop not found")
        query = query.filter(ProductModel.shop_id == shop_id)

    if search:
        query = query.filter(ProductModel.name.ilike(f"%{search}%"))
    if category_id is not None:
        query = query.filter(ProductModel.category_id == category_id)
    if is_active is not None:
        query = query.filter(ProductModel.is_active == is_active)

    count_query = select(func.count()).select_from(query.subquery())
    total = db.execute(count_query).scalar() or 0

    sort_column = getattr(ProductModel, sort_by)
    query = query.order_by(sort_column.asc() if order == "asc" else sort_column.desc())

    offset = (page - 1) * page_size
    products = db.execute(query.offset(offset).limit(page_size)).scalars().all()

    return {
        "items": products,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size if page_size else 0,
    }


@router.post("/", response_model=Product, status_code=status.HTTP_201_CREATED)
def create_product(
    product: ProductCreate,
    shop_id: int = Query(...),
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """Create a single product for one of the seller's shops."""
    shop = db.query(Shop).filter(Shop.id == shop_id, Shop.seller_id == current_seller.id).first()
    if not shop:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Shop not found")

    check_product_limit(db, current_seller)

    db_product = ProductModel(
        name=product.name,
        description=product.description,
        price=product.price,
        stock=product.stock,
        sku=product.sku,
        is_active=product.is_active if product.is_active is not None else True,
        shop_id=shop_id,
    )
    db.add(db_product)
    db.commit()
    db.refresh(db_product)
    return db_product


@router.get("/{product_id}", response_model=Product)
def get_product(
    product_id: int,
    db: Session = Depends(get_db),
    current_seller: Seller = Depends(get_current_seller),
):
    """Get a single product owned by the seller."""
    product = (
        db.query(ProductModel)
        .join(Shop, ProductModel.shop_id == Shop.id)
        .filter(ProductModel.id == product_id, Shop.seller_id == current_seller.id)
        .first()
    )
    if not product:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product not found")
    return product


@router.put("/{product_id}", response_model=Product)
def update_product(
    product_id: int,
    product: ProductUpdate,
    db: Session = Depends(get_db),
    current_seller: Seller = Depends(get_current_seller),
):
    """Update a product owned by the seller."""
    db_product = (
        db.query(ProductModel)
        .join(Shop, ProductModel.shop_id == Shop.id)
        .filter(ProductModel.id == product_id, Shop.seller_id == current_seller.id)
        .first()
    )
    if not db_product:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product not found")

    update_data = product.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(db_product, field, value)

    db.commit()
    db.refresh(db_product)
    return db_product


@router.delete("/{product_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_product(
    product_id: int,
    db: Session = Depends(get_db),
    current_seller: Seller = Depends(get_current_seller),
):
    """Delete a product owned by the seller."""
    db_product = (
        db.query(ProductModel)
        .join(Shop, ProductModel.shop_id == Shop.id)
        .filter(ProductModel.id == product_id, Shop.seller_id == current_seller.id)
        .first()
    )
    if not db_product:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product not found")

    db.delete(db_product)
    db.commit()
    return None


# ---------------------------------------------------------------------------
# Bulk operations
# ---------------------------------------------------------------------------


@router.post("/bulk", response_model=BulkCreateResult)
def bulk_create_products(
    payload: BulkCreateRequest,
    shop_id: int = Query(...),
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """Create multiple products in one request, enforcing the plan limit."""
    shop = db.query(Shop).filter(Shop.id == shop_id, Shop.seller_id == current_seller.id).first()
    if not shop:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Shop not found")

    products = payload.products
    if not products:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="No products provided")

    check_bulk_product_limit(db, current_seller, len(products))

    created = 0
    failed: List[dict] = []
    for idx, item in enumerate(products):
        try:
            db_product = ProductModel(
                name=item.name,
                description=item.description,
                price=item.price,
                stock=item.stock,
                sku=item.sku,
                is_active=item.is_active if item.is_active is not None else True,
                shop_id=shop_id,
            )
            db.add(db_product)
            db.flush()
            created += 1
        except Exception as exc:
            failed.append({"index": idx, "error": str(exc)})

    db.commit()
    return BulkCreateResult(created=created, failed=failed)


@router.put("/bulk/stock", response_model=BulkStockUpdateResult)
def bulk_update_stock(
    payload: BulkStockUpdateRequest,
    db: Session = Depends(get_db),
    current_seller: Seller = Depends(get_current_seller),
):
    """Update stock for multiple products owned by the seller."""
    updated = 0
    for item in payload.products:
        product = (
            db.query(ProductModel)
            .join(Shop, ProductModel.shop_id == Shop.id)
            .filter(ProductModel.id == item.id, Shop.seller_id == current_seller.id)
            .first()
        )
        if not product:
            continue
        product.stock = item.stock
        updated += 1
    db.commit()
    return BulkStockUpdateResult(updated=updated)


@router.put("/bulk/price", response_model=BulkPriceUpdateResult)
def bulk_update_price(
    payload: BulkPriceUpdateRequest,
    db: Session = Depends(get_db),
    current_seller: Seller = Depends(get_current_seller),
):
    """Update prices for multiple products owned by the seller."""
    # Determine target product IDs
    if payload.product_ids:
        product_ids = payload.product_ids
    else:
        product_ids = [
            p.id
            for p in db.query(ProductModel)
            .join(Shop, ProductModel.shop_id == Shop.id)
            .filter(Shop.seller_id == current_seller.id)
            .all()
        ]

    products = (
        db.query(ProductModel)
        .join(Shop, ProductModel.shop_id == Shop.id)
        .filter(ProductModel.id.in_(product_ids), Shop.seller_id == current_seller.id)
        .all()
    )

    updated = 0
    for product in products:
        if payload.type == "fixed":
            product.price = float(product.price) + payload.value
        elif payload.type == "percentage":
            product.price = float(product.price) * (1 + payload.value / 100)
        updated += 1
    db.commit()
    return BulkPriceUpdateResult(updated=updated)


@router.post("/bulk/delete", status_code=status.HTTP_200_OK)
def bulk_delete_products(
    product_ids: List[int],
    db: Session = Depends(get_db),
    current_seller: Seller = Depends(get_current_seller),
):
    """Delete multiple products owned by the seller."""
    deleted = 0
    for pid in product_ids:
        product = (
            db.query(ProductModel)
            .join(Shop, ProductModel.shop_id == Shop.id)
            .filter(ProductModel.id == pid, Shop.seller_id == current_seller.id)
            .first()
        )
        if product:
            db.delete(product)
            deleted += 1
    db.commit()
    return {"deleted": deleted}


# ---------------------------------------------------------------------------
# Export / Import
# ---------------------------------------------------------------------------


@router.get("/export")
def export_products_csv(
    shop_id: int = Query(...),
    db: Session = Depends(get_db),
    current_seller: Seller = Depends(get_current_seller),
):
    """Export the seller's products (for the given shop) as a CSV stream."""
    shop = db.query(Shop).filter(Shop.id == shop_id, Shop.seller_id == current_seller.id).first()
    if not shop:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Shop not found")

    products = db.query(ProductModel).filter(ProductModel.shop_id == shop_id).all()

    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=CSV_COLUMNS)
    writer.writeheader()
    for p in products:
        writer.writerow(
            {
                "name": p.name,
                "description": p.description or "",
                "price": p.price,
                "stock": p.stock,
                "sku": p.sku or "",
                "category": "",
            }
        )

    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=products.csv"},
    )


def _get_owned_product(product_id: int, seller: Seller, db: Session) -> ProductModel:
    """Return a product owned by the seller, or raise 404."""
    product = (
        db.query(ProductModel)
        .join(Shop, ProductModel.shop_id == Shop.id)
        .filter(ProductModel.id == product_id, Shop.seller_id == seller.id)
        .first()
    )
    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Product not found"
        )
    return product


@router.post("/{product_id}/images", response_model=ProductImageSchema, status_code=status.HTTP_201_CREATED)
async def upload_product_image(
    product_id: int,
    file: UploadFile = File(...),
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """Upload an image to a product's gallery (max 10 images)."""
    product = _get_owned_product(product_id, current_seller, db)

    existing = db.query(ProductImage).filter(ProductImage.product_id == product_id).count()
    if existing >= MAX_IMAGES_PER_PRODUCT:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Maximum of {MAX_IMAGES_PER_PRODUCT} images per product reached.",
        )

    try:
        storage = get_storage_service()
        image_url = await storage.save(file, f"products/{product.shop_id}")
    except StorageError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))

    is_primary = existing == 0  # first image becomes primary
    image = ProductImage(
        product_id=product_id,
        image_url=image_url,
        sort_order=existing,
        is_primary=is_primary,
    )
    db.add(image)
    db.commit()
    db.refresh(image)
    return image


@router.delete("/{product_id}/images/{image_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_product_image(
    product_id: int,
    image_id: int,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """Delete a product image (removes the file from storage too)."""
    product = _get_owned_product(product_id, current_seller, db)
    image = (
        db.query(ProductImage)
        .filter(ProductImage.id == image_id, ProductImage.product_id == product_id)
        .first()
    )
    if not image:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Image not found"
        )

    try:
        storage = get_storage_service()
        await storage.delete(image.image_url)
    except StorageError:
        pass  # best-effort cleanup

    was_primary = image.is_primary
    db.delete(image)
    db.commit()

    # If we removed the primary, promote the first remaining image.
    if was_primary:
        remaining = (
            db.query(ProductImage)
            .filter(ProductImage.product_id == product_id)
            .order_by(ProductImage.sort_order)
            .first()
        )
        if remaining:
            remaining.is_primary = True
            db.commit()


@router.put("/{product_id}/images/{image_id}/primary", response_model=ProductImageSchema)
async def set_primary_image(
    product_id: int,
    image_id: int,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """Mark an image as the product's primary image."""
    _get_owned_product(product_id, current_seller, db)
    image = (
        db.query(ProductImage)
        .filter(ProductImage.id == image_id, ProductImage.product_id == product_id)
        .first()
    )
    if not image:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Image not found"
        )

    # Unset any existing primary, then set this one.
    db.query(ProductImage).filter(
        ProductImage.product_id == product_id, ProductImage.is_primary == True  # noqa: E712
    ).update({ProductImage.is_primary: False})
    image.is_primary = True
    db.commit()
    db.refresh(image)
    return image


@router.post("/import", response_model=ImportResult)
async def import_products_csv(
    file: UploadFile = File(...),
    shop_id: int = Query(...),
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """Import products from a CSV file."""
    shop = db.query(Shop).filter(Shop.id == shop_id, Shop.seller_id == current_seller.id).first()
    if not shop:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Shop not found")

    if file.size is not None and file.size > MAX_CSV_SIZE_BYTES:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"File too large. Maximum size is {MAX_CSV_SIZE_BYTES // (1024 * 1024)} MB.",
        )

    content = await file.read()
    try:
        file_str = content.decode("utf-8-sig")
    except UnicodeDecodeError:
        file_str = content.decode("utf-8")

    try:
        rows = parse_products_csv(file_str)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))

    total = len(rows)

    # Enforce plan product limit BEFORE creating anything (returns 402 if exceeded)
    check_bulk_product_limit(db, current_seller, total)

    created = 0
    failed: list[dict] = []

    for row_index, row in enumerate(rows):
        try:
            product = ProductModel(
                name=row.get("name", f"Imported Product {row_index + 1}"),
                description=row.get("description"),
                price=row.get("price", 0.0),
                stock=row.get("stock", 0),
                sku=row.get("sku"),
                shop_id=shop_id,
            )
            db.add(product)
            db.flush()
            created += 1
        except Exception as exc:
            failed.append({"row": row_index + 2, "error": str(exc)})

    db.commit()

    import_record = ProductsImport(
        seller_id=current_seller.id,
        shop_id=shop_id,
        filename=file.filename or "unknown.csv",
        total_rows=total,
        created_count=created,
        failed_count=len(failed),
        errors=json.dumps(failed) if failed else None,
    )
    db.add(import_record)
    db.commit()

    return ImportResult(total=total, created=created, failed=failed)
