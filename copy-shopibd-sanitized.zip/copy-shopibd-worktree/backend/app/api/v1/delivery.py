"""
Delivery / shipment management endpoints for ShopiBD.

All routes are protected by the ``get_current_seller`` dependency and
scope data to the authenticated seller's shops.
"""

import json
import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.api.v1.dependencies import get_current_seller
from app.core.database import get_db
from app.models.delivery import CourierName, Delivery, ShipmentStatus
from app.models.order import Order
from app.models.seller import Seller
from app.models.shop import Shop
from app.schemas.delivery import (
    CourierEnum,
    DeliveryCreate,
    DeliveryListItem,
    DeliveryListResponse,
    DeliveryResponse,
    DeliveryStatusUpdate,
    ShipmentStatusEnum,
)
from app.services.courier import get_courier_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/delivery", tags=["delivery"])


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_seller_shop_ids(db: Session, seller_id: int) -> list[int]:
    stmt = select(Shop.id).where(Shop.seller_id == seller_id)
    result = db.execute(stmt).scalars().all()
    return list(result)


def _get_order_or_404(
    db: Session, order_id: int, shop_ids: list[int]
) -> Order:
    stmt = select(Order).where(
        Order.id == order_id, Order.shop_id.in_(shop_ids)
    )
    order = db.execute(stmt).scalar_one_or_none()
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found or does not belong to you",
        )
    return order


def _get_delivery_or_404(
    db: Session, delivery_id: int, seller_id: int
) -> Delivery:
    stmt = select(Delivery).where(
        Delivery.id == delivery_id, Delivery.seller_id == seller_id
    )
    delivery = db.execute(stmt).scalar_one_or_none()
    if not delivery:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Delivery shipment not found",
        )
    return delivery


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post("/shipments", response_model=DeliveryResponse, status_code=201)
def create_shipment(
    payload: DeliveryCreate,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Create a delivery shipment for an order using the chosen courier.

    If the order already has a delivery record, a 409 Conflict is returned.
    """
    shop_ids = _get_seller_shop_ids(db, current_seller.id)
    order = _get_order_or_404(db, payload.order_id, shop_ids)

    # Check existing delivery
    existing = db.execute(
        select(Delivery).where(Delivery.order_id == order.id)
    ).scalar_one_or_none()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A shipment already exists for this order",
        )

    # Call the courier service
    courier_service = get_courier_service(payload.courier_name.value)
    try:
        result = courier_service.create_shipment(
            order,
            pickup_address=payload.pickup_address,
            weight_kg=payload.weight_kg,
            cod_amount=payload.cod_amount,
        )
    except Exception as exc:
        logger.error("Courier API error: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Courier service error: {exc}",
        )

    tracking_number = result.get("tracking_number")
    estimated_date = result.get("estimated_delivery_date")
    shipping_cost = result.get("shipping_cost")

    delivery = Delivery(
        order_id=order.id,
        seller_id=current_seller.id,
        courier_name=CourierName(payload.courier_name.value),
        tracking_number=tracking_number,
        shipment_status=ShipmentStatus.PENDING,
        pickup_address=payload.pickup_address,
        delivery_address=order.customer_address,
        weight_kg=payload.weight_kg,
        cod_amount=payload.cod_amount,
        shipping_cost=shipping_cost,
        estimated_delivery_date=estimated_date,
    )
    db.add(delivery)
    db.commit()
    db.refresh(delivery)

    logger.info(
        "Shipment created: delivery=%d courier=%s tracking=%s",
        delivery.id,
        delivery.courier_name,
        tracking_number,
    )
    return delivery


@router.get("/shipments", response_model=DeliveryListResponse)
def list_shipments(
    page: int = Query(1, ge=1, description="Page number"),
    limit: int = Query(20, ge=1, le=100, description="Items per page"),
    courier: Optional[CourierEnum] = Query(
        None, description="Filter by courier provider"
    ),
    status: Optional[ShipmentStatusEnum] = Query(
        None, description="Filter by shipment status"
    ),
    order_id: Optional[int] = Query(None, description="Filter by order ID"),
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """Return a paginated list of shipments for the current seller."""
    stmt = select(Delivery).where(Delivery.seller_id == current_seller.id)

    if courier:
        stmt = stmt.where(Delivery.courier_name == CourierName(courier.value))
    if status:
        stmt = stmt.where(
            Delivery.shipment_status == ShipmentStatus(status.value)
        )
    if order_id:
        stmt = stmt.where(Delivery.order_id == order_id)

    # Total count
    count_stmt = select(func.count()).select_from(stmt.subquery())
    total = db.execute(count_stmt).scalar() or 0

    stmt = (
        stmt.order_by(Delivery.created_at.desc())
        .offset((page - 1) * limit)
        .limit(limit)
    )
    rows = db.execute(stmt).scalars().all()

    items = [
        DeliveryListItem(
            id=d.id,
            order_id=d.order_id,
            courier_name=d.courier_name,
            tracking_number=d.tracking_number,
            shipment_status=d.shipment_status,
            cod_amount=float(d.cod_amount) if d.cod_amount else None,
            shipping_cost=float(d.shipping_cost) if d.shipping_cost else None,
            estimated_delivery_date=d.estimated_delivery_date,
            created_at=d.created_at,
        )
        for d in rows
    ]

    total_pages = (total + limit - 1) // limit if total > 0 else 0
    return DeliveryListResponse(
        items=items,
        total=total,
        page=page,
        page_size=limit,
        total_pages=total_pages,
    )


@router.get("/shipments/{delivery_id}", response_model=DeliveryResponse)
def get_shipment(
    delivery_id: int,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """Return full details of a single delivery shipment."""
    delivery = _get_delivery_or_404(db, delivery_id, current_seller.id)

    # Optionally sync tracking status from courier API
    if delivery.tracking_number and delivery.courier_name != CourierName.MANUAL:
        try:
            courier_service = get_courier_service(delivery.courier_name.value)
            status_data = courier_service.get_tracking_status(
                delivery.tracking_number
            )
            # Update status if changed
            new_status = status_data.get("status")
            if new_status and new_status != delivery.shipment_status.value:
                delivery.shipment_status = ShipmentStatus(new_status)
                if new_status == "delivered":
                    from datetime import datetime, timezone
                    delivery.delivered_at = datetime.now(timezone.utc)
                db.commit()
                db.refresh(delivery)
        except Exception as exc:
            logger.warning(
                "Failed to sync tracking status for delivery %d: %s",
                delivery_id,
                exc,
            )

    return delivery


@router.put(
    "/shipments/{delivery_id}/status", response_model=DeliveryResponse
)
def update_shipment_status(
    delivery_id: int,
    payload: DeliveryStatusUpdate,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Update the status (and optionally tracking number / notes) of a shipment.
    """
    delivery = _get_delivery_or_404(db, delivery_id, current_seller.id)

    delivery.shipment_status = ShipmentStatus(payload.status.value)

    if payload.tracking_number is not None:
        delivery.tracking_number = payload.tracking_number
    if payload.notes is not None:
        delivery.notes = payload.notes

    # If marking delivered, record the timestamp
    if payload.status == ShipmentStatusEnum.DELIVERED:
        from datetime import datetime, timezone
        delivery.delivered_at = datetime.now(timezone.utc)

    db.commit()
    db.refresh(delivery)
    return delivery


@router.post(
    "/shipments/{delivery_id}/cancel", response_model=DeliveryResponse
)
def cancel_shipment(
    delivery_id: int,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
):
    """
    Cancel a shipment.  For non-manual couriers this also calls the
    courier's cancellation endpoint.
    """
    delivery = _get_delivery_or_404(db, delivery_id, current_seller.id)

    if delivery.shipment_status in (
        ShipmentStatus.DELIVERED,
        ShipmentStatus.RETURNED,
        ShipmentStatus.FAILED,
    ):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Cannot cancel shipment with status '{delivery.shipment_status.value}'",
        )

    # Call courier cancellation for non-manual services
    if (
        delivery.tracking_number
        and delivery.courier_name != CourierName.MANUAL
    ):
        try:
            courier_service = get_courier_service(
                delivery.courier_name.value
            )
            courier_service.cancel_shipment(delivery.tracking_number)
        except Exception as exc:
            logger.error("Courier cancellation error: %s", exc)
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=f"Courier cancellation failed: {exc}",
            )

    delivery.shipment_status = ShipmentStatus.FAILED
    db.commit()
    db.refresh(delivery)
    return delivery


@router.get("/couriers")
def list_couriers():
    """
    Return the list of available courier providers.
    """
    providers = [
        {"name": "Steadfast", "value": "steadfast"},
        {"name": "eCourier", "value": "ecourier"},
        {"name": "Pathao", "value": "pathao"},
        {"name": "Redx", "value": "redx"},
        {"name": "Manual", "value": "manual"},
    ]
    return {"couriers": providers}


# ---------------------------------------------------------------------------
# Inbound webhook (Phase 10.2, R10.2) — Steadfast shipment status updates
# ---------------------------------------------------------------------------


@router.post("/webhook/steadfast")
async def steadfast_webhook(
    request: Request,
    db: Session = Depends(get_db),
):
    """
    Receive a Steadfast shipment-status webhook.

    Verifies the HMAC-SHA256 signature (header ``X-Steadfast-Signature``)
    before applying any status change, so spoofed updates are rejected.
    The signed payload is the raw request body. When no webhook secret is
    configured, signature verification is skipped (dev/local only).
    """
    from datetime import datetime, timezone

    from app.services.courier.steadfast import SteadfastCourierService

    raw_body = await request.body()
    signature = request.headers.get("X-Steadfast-Signature", "")
    if not SteadfastCourierService.verify_webhook_signature(raw_body, signature):
        logger.warning("Rejected Steadfast webhook with invalid signature")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid webhook signature",
        )

    try:
        payload = json.loads(raw_body or b"{}")
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid JSON body",
        )

    # Steadfast sends either invoice (order_number) or consignment/tracking id.
    tracking = (
        payload.get("tracking_code")
        or payload.get("consignment_id")
        or payload.get("invoice")
        or ""
    )
    steadfast_status = (payload.get("status") or "").lower()
    if not tracking or not steadfast_status:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Missing tracking/invoice or status in webhook payload",
        )

    delivery = db.execute(
        select(Delivery).where(Delivery.tracking_number == tracking)
    ).scalar_one_or_none()
    if delivery is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No shipment found for the given tracking number",
        )

    normalised = SteadfastCourierService._normalise_status(steadfast_status)
    delivery.shipment_status = ShipmentStatus(normalised)
    if normalised == "delivered":
        delivery.delivered_at = datetime.now(timezone.utc)
    delivery.notes = payload.get("status_note") or delivery.notes
    db.commit()
    db.refresh(delivery)

    logger.info(
        "Webhook updated delivery %d -> %s", delivery.id, normalised
    )
    return {"status": "ok", "delivery_id": delivery.id, "shipment_status": normalised}
