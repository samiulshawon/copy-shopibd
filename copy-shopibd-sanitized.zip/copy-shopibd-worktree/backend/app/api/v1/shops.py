"""
Shop management endpoints for ShopiBD.

Handles both authenticated seller shop management and public shop
page retrieval by slug.
"""

import json
import logging
import re
from datetime import datetime, timezone
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import get_db

logger = logging.getLogger(__name__)
from app.models.seller import Seller
from app.models.shop import Shop
from app.models.product import Product
from app.models.category import Category
from app.models.order import Order, OrderItem
from app.models.coupon import Coupon
from app.models.coupon_usage import CouponUsage
from app.api.v1.dependencies import get_current_seller
from app.schemas.shop import ShopCreate, ShopResponse, ShopUpdate, ShopPublic
from app.schemas.order import (
    OrderCreatePublic,
    OrderPublic,
    OrderConfirmation,
    OrderItemPublic,
)
from app.services.notification import (
    send_new_order_alert_to_seller,
    send_order_confirmation_to_buyer,
)
from app.services.plan_limits import check_order_limit

router = APIRouter(prefix="/shops", tags=["shops"])


# ---------------------------------------------------------------------------
# Phase 9 — Subdomain availability
# ---------------------------------------------------------------------------

_SUBDOMAIN_RE = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,38}[a-z0-9])?$")
_RESERVED_SUBDOMAINS = {
    "www", "api", "admin", "app", "mail", "shopibd", "dashboard",
    "store", "shop", "new", "login", "register", "auth", "static",
    "cdn", "assets", "help", "support", "docs",
}


def _normalize_subdomain(value: str) -> str:
    normalized = value.lower().strip()
    normalized = re.sub(r"[^a-z0-9-]", "", normalized)
    normalized = re.sub(r"-+", "-", normalized).strip("-")
    return normalized


def _is_subdomain_taken(db: Session, subdomain: str) -> bool:
    existing = db.execute(
        select(Shop).where(Shop.subdomain == subdomain)
    ).scalar_one_or_none()
    return existing is not None


def _suggest_subdomains(base: str, db: Session, count: int = 3) -> list[str]:
    """Return up to ``count`` available suggestions for a taken *base*.

    Mirrors the spec scenario: ``client-a`` taken -> suggest
    ``client-a-bd``, ``client-a1``. Each suggestion must pass the same
    collision check as ``reserve_subdomain``.
    """
    candidates: list[str] = []
    suffixes = ["bd", "shop", "store"]
    for i in range(1, 8):
        if len(candidates) >= count:
            break
        # suffix-based: client-a-bd
        for suffix in suffixes:
            if len(candidates) >= count:
                break
            cand = f"{base}-{suffix}"
            if cand not in candidates and _SUBDOMAIN_RE.match(cand) and not _is_subdomain_taken(db, cand):
                candidates.append(cand)
        # numeric: client-a1, client-a2
        cand = f"{base}{i}"
        if cand not in candidates and _SUBDOMAIN_RE.match(cand) and not _is_subdomain_taken(db, cand):
            candidates.append(cand)
    return candidates


@router.get("/subdomain-available")
async def check_subdomain_availability(
    subdomain: str = Query(..., min_length=2, max_length=40),
    db: Session = Depends(get_db),
):
    """Return whether a subdomain is available, plus suggestions if taken.

    Phase 9 — used by the signup/new-client page for live availability UX.
    """
    candidate = _normalize_subdomain(subdomain)
    if not candidate or len(candidate) < 2:
        return {"available": False, "subdomain": candidate, "suggestions": [], "reason": "invalid"}
    if not _SUBDOMAIN_RE.match(candidate):
        return {"available": False, "subdomain": candidate, "suggestions": [], "reason": "invalid"}
    if candidate in _RESERVED_SUBDOMAINS:
        return {"available": False, "subdomain": candidate, "suggestions": [], "reason": "reserved"}
    if _is_subdomain_taken(db, candidate):
        return {
            "available": False,
            "subdomain": candidate,
            "suggestions": _suggest_subdomains(candidate, db),
            "reason": "taken",
        }
    return {"available": True, "subdomain": candidate, "suggestions": [], "reason": "available"}


def _get_seller_shop(
    seller_id: int,
    db: Session,
) -> Shop:
    """Return the first shop owned by *seller_id*, or raise 404."""
    stmt = select(Shop).where(
        Shop.seller_id == seller_id,
    )
    shop = db.execute(stmt).scalar_one_or_none()
    if shop is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No shop found for this seller",
        )
    return shop


def _generate_slug(name: str) -> str:
    """Generate a URL-friendly slug from a name."""
    slug = name.lower().strip()
    slug = re.sub(r"[^a-z0-9\s-]", "", slug)
    slug = re.sub(r"[\s_]+", "-", slug)
    slug = re.sub(r"-+", "-", slug)
    slug = slug.strip("-")
    return slug


@router.post("", response_model=ShopResponse, status_code=status.HTTP_201_CREATED)
async def create_shop(
    payload: ShopCreate,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> Shop:
    """
    Create a new shop for the authenticated seller.

    If *slug* is not provided it will be auto-generated from *name*.
    Slug uniqueness is enforced across all shops.
    """
    # Auto-generate slug if not provided
    slug = payload.slug
    if slug is None or slug.strip() == "":
        slug = _generate_slug(payload.name)

    # Ensure slug is not empty after generation
    if not slug:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Could not generate a valid slug from the shop name",
        )

    # Check slug uniqueness
    slug_stmt = select(Shop).where(Shop.slug == slug)
    existing = db.execute(slug_stmt).scalar_one_or_none()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Shop slug '{slug}' is already taken",
        )

    shop = Shop(
        name=payload.name,
        slug=slug,
        description=payload.description,
        contact_phone=payload.contact_phone or "",
        bkash_number=payload.bkash_number,
        nagad_number=payload.nagad_number,
        seller_id=current_seller.id,
    )
    db.add(shop)
    db.commit()
    db.refresh(shop)
    return shop


@router.get("/me", response_model=ShopResponse)
async def get_my_shop(
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> Shop:
    """
    Return the shop owned by the currently authenticated seller.
    """
    return _get_seller_shop(current_seller.id, db)


@router.put("/me", response_model=ShopResponse)
async def update_my_shop(
    payload: ShopUpdate,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> Shop:
    """
    Update the current seller's shop details.

    If *slug* is provided it will be checked for uniqueness across all
    shops (excluding the current shop).
    """
    shop = _get_seller_shop(current_seller.id, db)

    # Slug uniqueness check
    if payload.slug is not None and payload.slug != shop.slug:
        slug_stmt = select(Shop).where(
            Shop.slug == payload.slug, Shop.id != shop.id
        )
        existing = db.execute(slug_stmt).scalar_one_or_none()
        if existing:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Shop slug '{payload.slug}' is already taken",
            )

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(shop, field, value)

    db.commit()
    db.refresh(shop)
    return shop


@router.get("/{slug}/products/{product_id}")
async def get_product_by_slug(
    slug: str,
    product_id: int,
    db: Session = Depends(get_db),
):
    """
    Public endpoint — return a single active product by shop slug and product ID.

    Returns 404 if the shop is inactive, the product does not belong to the
    shop, or the product is inactive.
    """
    shop_stmt = select(Shop).where(Shop.slug == slug, Shop.is_active == True)
    shop = db.execute(shop_stmt).scalar_one_or_none()
    if shop is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Shop not found or is inactive",
        )

    product_stmt = (
        select(Product)
        .where(
            Product.id == product_id,
            Product.shop_id == shop.id,
            Product.is_active == True,
        )
    )
    product = db.execute(product_stmt).scalar_one_or_none()
    if product is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Product not found",
        )

    return {
        "id": product.id,
        "name": product.name,
        "description": product.description,
        "price": float(product.price),
        "stock": product.stock,
        "sku": product.sku,
        "is_active": product.is_active,
    }


@router.get("/{slug}", response_model=ShopPublic)
async def get_shop_by_slug(
    slug: str,
    db: Session = Depends(get_db),
):
    """
    Public endpoint — return a shop (and its active products) by URL slug.

    This is intended for the storefront to display a seller's public
    shop page.
    """
    stmt = select(Shop).where(Shop.slug == slug, Shop.is_active == True)
    shop = db.execute(stmt).scalar_one_or_none()
    if shop is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Shop not found or is inactive",
        )

    # Fetch active products for this shop
    products_stmt = (
        select(Product)
        .where(Product.shop_id == shop.id, Product.is_active == True)
        .order_by(Product.name)
    )
    products = db.execute(products_stmt).scalars().all()

    # Fetch active categories for this shop
    categories_stmt = (
        select(Category)
        .where(Category.shop_id == shop.id, Category.is_active == True)
        .order_by(Category.sort_order)
    )
    categories = db.execute(categories_stmt).scalars().all()

    return ShopPublic(
        id=shop.id,
        name=shop.name,
        slug=shop.slug,
        description=shop.description,
        logo_url=shop.logo_url,
        is_active=shop.is_active,
        products=[
            {
                "id": p.id,
                "name": p.name,
                "description": p.description,
                "price": float(p.price),
                "stock": p.stock,
                "sku": p.sku,
                "primary_image_url": next(
                    (i.image_url for i in p.images if i.is_primary),
                    (p.images[0].image_url if p.images else None),
                ),
            }
            for p in products
        ],
        banner_url=shop.banner_url,
        contact_phone=shop.contact_phone,
        bkash_number=shop.bkash_number,
        nagad_number=shop.nagad_number,
        categories=[
            {
                "id": c.id,
                "name_bn": c.name_bn,
                "name_en": c.name_en,
                "description": c.description,
                "sort_order": c.sort_order,
                "is_active": c.is_active,
            }
            for c in categories
        ],
    )


# ---------------------------------------------------------------------------
# Public storefront order endpoints
# ---------------------------------------------------------------------------

_BD_PHONE_RE = re.compile(r"^(?:\+880|01)[1-9]\d{8}$")


def _validate_bd_phone(phone: str) -> str:
    normalized = phone.strip()
    if not _BD_PHONE_RE.match(normalized):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid Bangladeshi phone number. Use +880XXXXXXXXXX or 01XXXXXXXXX",
        )
    return normalized


def _generate_order_number(db: Session) -> str:
    """Generate unique order number SB-YYYY-XXXXXX."""
    now = datetime.now(timezone.utc)
    prefix = f"SB-{now.year}"
    # Find the latest order with this prefix
    stmt = (
        select(Order.order_number)
        .where(Order.order_number.startswith(prefix))
        .order_by(Order.order_number.desc())
        .limit(1)
    )
    last = db.execute(stmt).scalar_one_or_none()
    if last:
        try:
            seq = int(last.split("-")[-1]) + 1
        except ValueError:
            seq = 1
    else:
        seq = 1
    return f"{prefix}-{seq:06d}"


@router.post("/{slug}/orders", response_model=OrderConfirmation, status_code=status.HTTP_201_CREATED)
async def create_public_order(
    slug: str,
    payload: OrderCreatePublic,
    db: Session = Depends(get_db),
):
    """
    Public endpoint — create a new order for a shop by slug.

    Validates shop, product, stock, and phone number.
    Does NOT deduct stock (manual verification later).
    Supports payment_method: manual (default), bkash, nagad, cod.
    For bkash/nagad, creates a payment intent and returns payment_url.
    """
    # 1. Shop must exist and be active
    shop_stmt = select(Shop).where(Shop.slug == slug, Shop.is_active == True)
    shop = db.execute(shop_stmt).scalar_one_or_none()
    if shop is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Shop not found or is inactive",
        )

    # Enforce seller's plan order limit
    check_order_limit(db, shop.seller)

    # 2. Product must exist, be active, and belong to this shop
    product_stmt = (
        select(Product)
        .where(
            Product.id == payload.product_id,
            Product.shop_id == shop.id,
            Product.is_active == True,
        )
    )
    product = db.execute(product_stmt).scalar_one_or_none()
    if product is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Product not found",
        )

    # 3. Stock check
    if product.stock < payload.quantity:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Insufficient stock. Available: {product.stock}",
        )

    # 4. Validate phone
    buyer_phone = _validate_bd_phone(payload.buyer_phone)

    # 5. Build address string
    address_dict = payload.buyer_address.model_dump()
    customer_address = json.dumps(address_dict, ensure_ascii=False)

    # 6. Calculate total
    total_amount = float(product.price) * payload.quantity

    # 7. Handle coupon (optional)
    coupon_code = None
    discount_amount = 0.0
    if payload.coupon_code:
        coupon_code = payload.coupon_code.strip().upper()
        coupon = db.execute(
            select(Coupon).where(
                Coupon.code == coupon_code,
                Coupon.shop_id == shop.id,
                Coupon.is_active == True,
            )
        ).scalar_one_or_none()

        if not coupon:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid or inactive coupon code",
            )

        # Validate coupon
        now = datetime.now(timezone.utc)

        # Expiry check
        if coupon.expires_at and coupon.expires_at < now:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Coupon has expired",
            )

        # Usage limit check
        if coupon.usage_limit is not None and coupon.usage_count >= coupon.usage_limit:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Coupon usage limit reached",
            )

        # Min order check
        if coupon.min_order_amount is not None and total_amount < float(coupon.min_order_amount):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Minimum order amount of ৳{coupon.min_order_amount} required",
            )

        # Calculate discount
        if coupon.discount_type == "fixed":
            discount_amount = float(coupon.discount_value)
        elif coupon.discount_type == "percentage":
            discount_amount = (float(coupon.discount_value) / 100) * total_amount
            if coupon.max_discount is not None and discount_amount > float(coupon.max_discount):
                discount_amount = float(coupon.max_discount)

        if discount_amount > total_amount:
            discount_amount = total_amount

        total_amount -= discount_amount
        total_amount = round(total_amount, 2)

    # 8. Generate unique order number
    order_number = _generate_order_number(db)

    # 8a. Determine payment method
    payment_method = (payload.payment_method or "manual").lower()
    if payment_method not in ("manual", "bkash", "nagad", "cod"):
        payment_method = "manual"

    # 9. Create order
    order = Order(
        order_number=order_number,
        customer_name=payload.buyer_name.strip(),
        customer_phone=buyer_phone,
        customer_address=customer_address,
        total_amount=total_amount,
        payment_method=payment_method,
        notes=payload.notes,
        shop_id=shop.id,
        status="pending",
        payment_status="pending" if payment_method in ("manual", "cod") else "pending",
    )
    db.add(order)
    db.flush()

    # 10. Create order item
    order_item = OrderItem(
        order_id=order.id,
        product_id=product.id,
        product_name=product.name,
        quantity=payload.quantity,
        unit_price=float(product.price),
        subtotal=float(product.price) * payload.quantity,
    )
    db.add(order_item)
    db.flush()

    # 11. Record coupon usage if applicable
    if coupon_code and coupon:
        coupon.usage_count = (coupon.usage_count or 0) + 1
        coupon_usage = CouponUsage(
            coupon_id=coupon.id,
            order_id=order.id,
            customer_phone=buyer_phone,
            discount_amount=discount_amount,
        )
        db.add(coupon_usage)

    db.commit()
    db.refresh(order)
    db.refresh(order_item)

    # 12. Send WhatsApp notifications (fire-and-forget)
    await send_order_confirmation_to_buyer(order, shop)
    await send_new_order_alert_to_seller(order, shop)

    # 13. If bkash/nagad, create payment intent
    payment_url = None
    payment_id = None

    if payment_method == "bkash" and settings.PAYMENT_PROVIDER == "bkash":
        try:
            from app.services.payment.bkash import BKashPaymentProvider
            provider = BKashPaymentProvider()
            callback_url = f"{settings.API_BASE_URL}/api/v1/payment-webhook/bkash"
            result = await provider.create_payment(
                order_id=order.order_number,
                amount=int(total_amount),
                callback_url=callback_url,
            )
            payment_url = result.get("payment_url")
            payment_id = result.get("paymentID")
        except Exception as exc:
            logger.exception("Failed to create bKash payment: %s", exc)
            payment_url = None

    elif payment_method == "nagad" and settings.PAYMENT_PROVIDER == "nagad":
        try:
            from app.services.payment.nagad import NagadPaymentProvider
            provider = NagadPaymentProvider()
            callback_url = f"{settings.API_BASE_URL}/api/v1/payment-webhook/nagad"
            result = await provider.create_payment(
                order_id=order.order_number,
                amount=int(total_amount),
                callback_url=callback_url,
            )
            payment_url = result.get("payment_url")
            payment_id = result.get("payment_ref_id")
        except Exception as exc:
            logger.exception("Failed to create Nagad payment: %s", exc)
            payment_url = None

    # 14. Build response
    items = [
        OrderItemPublic(
            id=order_item.id,
            product_id=order_item.product_id,
            product_name=order_item.product_name,
            quantity=order_item.quantity,
            unit_price=float(order_item.unit_price),
            subtotal=float(order_item.subtotal),
        )
    ]

    return OrderConfirmation(
        id=order.id,
        order_number=order.order_number,
        customer_name=order.customer_name,
        customer_phone=order.customer_phone,
        customer_address=order.customer_address,
        total_amount=float(order.total_amount),
        status=order.status,
        payment_status=order.payment_status,
        payment_method=payment_method,
        notes=order.notes,
        shop_id=order.shop_id,
        created_at=order.created_at,
        items=items,
        shop_name=shop.name,
        shop_contact_phone=shop.contact_phone,
        bkash_number=shop.bkash_number,
        nagad_number=shop.nagad_number,
        coupon_code=coupon_code,
        discount_amount=discount_amount if discount_amount > 0 else None,
        payment_url=payment_url,
        paymentID=payment_id,
    )


@router.get("/{slug}/orders/track", response_model=OrderPublic)
async def track_order(
    slug: str,
    phone: str = Query(..., description="Buyer phone number"),
    order_id: str = Query(..., description="Order number (e.g. SB-2026-000001)"),
    db: Session = Depends(get_db),
):
    """
    Public endpoint — track an order by phone number and order ID.

    No auth required.
    """
    # Validate shop exists
    shop_stmt = select(Shop).where(Shop.slug == slug, Shop.is_active == True)
    shop = db.execute(shop_stmt).scalar_one_or_none()
    if shop is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Shop not found or is inactive",
        )

    # Normalize phone
    normalized_phone = phone.strip()
    if not _BD_PHONE_RE.match(normalized_phone):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid Bangladeshi phone number",
        )

    # Find order
    order_stmt = (
        select(Order)
        .where(
            Order.order_number == order_id.strip(),
            Order.customer_phone == normalized_phone,
            Order.shop_id == shop.id,
        )
        .order_by(Order.created_at.desc())
        .limit(1)
    )
    order = db.execute(order_stmt).scalar_one_or_none()
    if order is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found",
        )

    # Load items
    items_stmt = select(OrderItem).where(OrderItem.order_id == order.id)
    items = db.execute(items_stmt).scalars().all()

    return OrderPublic(
        id=order.id,
        order_number=order.order_number,
        customer_name=order.customer_name,
        customer_phone=order.customer_phone,
        customer_address=order.customer_address,
        total_amount=float(order.total_amount),
        status=order.status,
        payment_status=order.payment_status,
        notes=order.notes,
        shop_id=order.shop_id,
        created_at=order.created_at,
        items=[
            OrderItemPublic(
                id=item.id,
                product_id=item.product_id,
                product_name=item.product_name,
                quantity=item.quantity,
                unit_price=float(item.unit_price),
                subtotal=float(item.subtotal),
            )
            for item in items
        ],
    )
