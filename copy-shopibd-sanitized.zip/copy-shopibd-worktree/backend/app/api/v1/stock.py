"""
Stock movement API endpoints for ShopiBD.

Provides endpoints to list, create, and retrieve stock movements,
scoped to the authenticated seller's products.
"""

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.api.v1.dependencies import get_current_seller
from app.core.database import get_db
from app.models.product import Product
from app.models.seller import Seller
from app.models.shop import Shop
from app.models.stock import MovementType, StockMovement
from app.schemas.stock import (
    StockMovementCreate,
    StockMovementListResponse,
    StockMovementResponse,
)
from app.services.notification import send_low_stock_alert

router = APIRouter(prefix="/stock", tags=["stock"])


def _get_seller_product_ids(
    seller_id: int,
    db: Session,
) -> set[int]:
    """Return the set of product IDs owned by *seller_id*."""
    stmt = select(Product.id).where(Product.shop_id.in_(
        select(Shop.id).where(Shop.seller_id == seller_id)
    ))
    result = db.execute(stmt).scalars().all()
    return set(result)


@router.get("/movements", response_model=StockMovementListResponse)
def list_stock_movements(
    product_id: Optional[int] = Query(None, description="Filter by product ID"),
    movement_type: Optional[str] = Query(None, description="Filter by movement type (sale, adjustment, return, purchase)"),
    page: int = Query(1, ge=1, description="Page number"),
    limit: int = Query(20, ge=1, le=100, description="Items per page"),
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> StockMovementListResponse:
    """
    List stock movements for the authenticated seller's products.

    Supports optional filtering by *product_id* and *movement_type*,
    and is paginated via *page* and *limit*.
    """
    # Base query: movements belonging to this seller
    base_query = select(StockMovement).where(
        StockMovement.seller_id == current_seller.id
    )

    # Optional filters
    if product_id is not None:
        base_query = base_query.where(StockMovement.product_id == product_id)
    if movement_type is not None:
        try:
            mv_type = MovementType(movement_type.lower())
            base_query = base_query.where(StockMovement.movement_type == mv_type)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid movement_type '{movement_type}'. "
                       f"Allowed: {[e.value for e in MovementType]}",
            )

    # Count total matching records
    count_stmt = select(func.count()).select_from(base_query.subquery())
    total = db.execute(count_stmt).scalar_one()

    # Paginated fetch
    offset = (page - 1) * limit
    query = base_query.order_by(StockMovement.created_at.desc()).offset(offset).limit(limit)
    movements = db.execute(query).scalars().all()

    return StockMovementListResponse(
        items=[StockMovementResponse.model_validate(m) for m in movements],
        total=total,
    )


LOW_STOCK_THRESHOLD = 5


@router.post("/movements", response_model=StockMovementResponse, status_code=status.HTTP_201_CREATED)
async def create_stock_movement(
    payload: StockMovementCreate,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> StockMovementResponse:
    """
    Record a manual stock adjustment.

    Only *adjustment* type movements can be created through this endpoint.
    Sale, return, and purchase movements are handled by their respective
    subsystems (orders, purchases, etc.).
    """
    # Verify the product exists and belongs to this seller
    product_stmt = (
        select(Product)
        .where(Product.id == payload.product_id)
        .where(Product.shop_id.in_(
            select(Shop.id).where(Shop.seller_id == current_seller.id)
        ))
    )
    product = db.execute(product_stmt).scalar_one_or_none()
    if product is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Product not found or does not belong to you",
        )

    # Calculate previous and new quantities
    previous_quantity = product.stock
    new_quantity = previous_quantity + payload.quantity_change
    if new_quantity < 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Insufficient stock. Current stock is {previous_quantity}, "
                   f"cannot reduce by {abs(payload.quantity_change)}.",
        )

    # Create the movement record
    movement = StockMovement(
        seller_id=current_seller.id,
        product_id=payload.product_id,
        movement_type=MovementType(payload.movement_type),
        quantity_change=payload.quantity_change,
        previous_quantity=previous_quantity,
        new_quantity=new_quantity,
        note=payload.note,
        reference_type=payload.reference_type,
        reference_id=payload.reference_id,
    )
    db.add(movement)

    # Update product stock
    product.stock = new_quantity

    db.commit()
    db.refresh(movement)

    # Send low stock alert if stock drops below threshold
    if product.stock <= LOW_STOCK_THRESHOLD:
        await send_low_stock_alert(current_seller, product)

    return StockMovementResponse.model_validate(movement)


@router.get("/movements/{movement_id}", response_model=StockMovementResponse)
def get_stock_movement(
    movement_id: int,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> StockMovementResponse:
    """
    Retrieve a single stock movement by its ID.

    The movement must belong to the authenticated seller.
    """
    stmt = select(StockMovement).where(
        StockMovement.id == movement_id,
        StockMovement.seller_id == current_seller.id,
    )
    movement = db.execute(stmt).scalar_one_or_none()
    if movement is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Stock movement not found",
        )
    return StockMovementResponse.model_validate(movement)


@router.get("/products/{product_id}/movements", response_model=StockMovementListResponse)
def get_product_movements(
    product_id: int,
    page: int = Query(1, ge=1, description="Page number"),
    limit: int = Query(20, ge=1, le=100, description="Items per page"),
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> StockMovementListResponse:
    """
    List all stock movements for a specific product.

    The product must belong to the authenticated seller.
    """
    # Verify the product belongs to this seller
    product_stmt = (
        select(Product)
        .where(Product.id == product_id)
        .where(Product.shop_id.in_(
            select(Shop.id).where(Shop.seller_id == current_seller.id)
        ))
    )
    product = db.execute(product_stmt).scalar_one_or_none()
    if product is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Product not found or does not belong to you",
        )

    # Count total
    count_stmt = select(func.count()).where(
        StockMovement.product_id == product_id,
        StockMovement.seller_id == current_seller.id,
    )
    total = db.execute(count_stmt).scalar_one()

    # Paginated fetch
    offset = (page - 1) * limit
    query = (
        select(StockMovement)
        .where(
            StockMovement.product_id == product_id,
            StockMovement.seller_id == current_seller.id,
        )
        .order_by(StockMovement.created_at.desc())
        .offset(offset)
        .limit(limit)
    )
    movements = db.execute(query).scalars().all()

    return StockMovementListResponse(
        items=[StockMovementResponse.model_validate(m) for m in movements],
        total=total,
    )