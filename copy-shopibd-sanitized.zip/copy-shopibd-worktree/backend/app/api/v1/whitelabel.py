"""
White-label / custom domain API endpoints for ShopiBD.

Allows sellers to configure custom domains, subdomains, branding settings,
and verify DNS records.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.seller import Seller
from app.models.shop import Shop
from app.api.v1.dependencies import get_current_seller
from app.services.plan_capabilities import (
    can_use_custom_domain,
    can_use_subdomain,
)
from app.schemas.whitelabel import (
    BrandingSettings,
    DomainRequest,
    DomainVerifyResponse,
    SubdomainRequest,
    WhiteLabelStatus,
)
from app.services.domain_verifier import (
    get_required_dns_records,
    provision_ssl,
    provision_ssl_cert,
    verify_cname,
    verify_txt_record,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/whitelabel", tags=["whitelabel"])


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_seller_shop(seller_id: int, db: Session) -> Shop:
    """Return the seller's first shop or raise 404."""
    stmt = select(Shop).where(Shop.seller_id == seller_id)
    shop = db.execute(stmt).scalar_one_or_none()
    if shop is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No shop found for this seller",
        )
    return shop


def _build_domain_verify_response(
    shop: Shop,
    domain: str,
    verified: bool,
    message: str = "",
) -> DomainVerifyResponse:
    """Build a ``DomainVerifyResponse`` with the appropriate DNS records."""
    records = get_required_dns_records(domain, subdomain=shop.subdomain)
    return DomainVerifyResponse(
        verified=verified,
        dns_records=records,
        message=message,
    )


# ---------------------------------------------------------------------------
# GET /whitelabel/status
# ---------------------------------------------------------------------------


@router.get("/status", response_model=WhiteLabelStatus)
async def get_whitelabel_status(
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> WhiteLabelStatus:
    """Return the current white-label status for the seller's shop."""
    shop = _get_seller_shop(current_seller.id, db)

    branding = None
    if shop.branding_settings:
        branding = BrandingSettings(**shop.branding_settings)

    return WhiteLabelStatus(
        custom_domain=shop.custom_domain,
        subdomain=shop.subdomain,
        domain_verified=shop.domain_verified,
        domain_verified_at=shop.domain_verified_at,
        ssl_provisioned=shop.ssl_provisioned,
        branding=branding,
        hide_branding=shop.hide_branding,
    )


# ---------------------------------------------------------------------------
# POST /whitelabel/domain  – request/set custom domain
# ---------------------------------------------------------------------------


@router.post("/domain", response_model=WhiteLabelStatus)
async def set_custom_domain(
    payload: DomainRequest,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> WhiteLabelStatus:
    """Set (or update) the custom domain for the seller's shop.

    Validates that the domain is not already in use by another shop.
    After setting the domain, the seller must verify ownership via DNS.
    """
    shop = _get_seller_shop(current_seller.id, db)

    # Plan enforcement: custom domains require an Enterprise plan.
    if not can_use_custom_domain(current_seller.plan):
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail="Custom domain requires an Enterprise plan",
        )

    domain = payload.domain.lower().strip()

    # Check if domain is already taken (excluding current shop)
    existing_stmt = select(Shop).where(
        Shop.custom_domain == domain,
        Shop.id != shop.id,
    )
    existing = db.execute(existing_stmt).scalar_one_or_none()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Domain '{domain}' is already in use by another shop",
        )

    shop.custom_domain = domain
    shop.domain_verified = False
    shop.domain_verified_at = None
    shop.ssl_provisioned = False
    # Phase 7: reset SSL state when the custom domain changes so the old
    # cert/expiry don't leak onto the new domain.
    shop.ssl_status = "none"
    shop.ssl_expires_at = None
    db.commit()
    db.refresh(shop)

    logger.info("Custom domain set for shop %s: %s", shop.id, domain)

    branding = None
    if shop.branding_settings:
        branding = BrandingSettings(**shop.branding_settings)

    return WhiteLabelStatus(
        custom_domain=shop.custom_domain,
        subdomain=shop.subdomain,
        domain_verified=shop.domain_verified,
        domain_verified_at=shop.domain_verified_at,
        ssl_provisioned=shop.ssl_provisioned,
        branding=branding,
        hide_branding=shop.hide_branding,
    )


# ---------------------------------------------------------------------------
# GET /whitelabel/domain/verify  – check current verification status
# ---------------------------------------------------------------------------


@router.get("/domain/verify", response_model=DomainVerifyResponse)
async def check_domain_verification(
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> DomainVerifyResponse:
    """Return the current verification status and required DNS records."""
    shop = _get_seller_shop(current_seller.id, db)
    if not shop.custom_domain:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No custom domain has been set yet",
        )

    return _build_domain_verify_response(
        shop=shop,
        domain=shop.custom_domain,
        verified=shop.domain_verified,
        message="DNS records required for verification"
        if not shop.domain_verified
        else "Domain is verified",
    )


# ---------------------------------------------------------------------------
# POST /whitelabel/domain/verify  – trigger domain verification
# ---------------------------------------------------------------------------


@router.post("/domain/verify", response_model=DomainVerifyResponse)
async def trigger_domain_verification(
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> DomainVerifyResponse:
    """Check DNS records now and update verification status."""
    shop = _get_seller_shop(current_seller.id, db)
    if not shop.custom_domain:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No custom domain has been set yet",
        )

    domain = shop.custom_domain

    # Check CNAME record
    cname_ok = verify_cname(domain, "shopibd.com")

    # Check verification TXT record
    expected_txt = f"shopibd-domain-verify={domain}"
    txt_ok = verify_txt_record(domain, expected_txt)

    verified = cname_ok and txt_ok

    if verified:
        shop.domain_verified = True
        shop.domain_verified_at = datetime.now(timezone.utc)
        # Phase 7: provision an SSL cert via the ACME backend and record the
        # resulting status + expiry on the shop row. Falls back to the stub
        # backend when certbot is unavailable so the flow never breaks the
        # verification response.
        shop.ssl_status = "provisioning"
        db.commit()
        result = provision_ssl_cert(domain)
        if result.success:
            shop.ssl_provisioned = True
            shop.ssl_status = "provisioned"
            shop.ssl_expires_at = result.expires_at
        else:
            shop.ssl_provisioned = False
            shop.ssl_status = "failed"
            logger.warning(
                "SSL provisioning failed for %s (shop %s): %s",
                domain,
                shop.id,
                result.error,
            )
        db.commit()
        db.refresh(shop)
        message = "Domain verified successfully!"
        logger.info("Domain %s verified for shop %s", domain, shop.id)
    else:
        message = "DNS records not yet configured correctly"
        logger.info(
            "Domain verification failed for %s (shop %s): CNAME=%s TXT=%s",
            domain,
            shop.id,
            cname_ok,
            txt_ok,
        )

    return _build_domain_verify_response(shop, domain, verified, message)


# ---------------------------------------------------------------------------
# POST /whitelabel/subdomain  – set custom subdomain
# ---------------------------------------------------------------------------


@router.post("/subdomain", response_model=WhiteLabelStatus)
async def set_subdomain(
    payload: SubdomainRequest,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> WhiteLabelStatus:
    """Set a custom subdomain for the seller's shop (e.g. 'rina')."""
    shop = _get_seller_shop(current_seller.id, db)

    # Plan enforcement: subdomains require a plan that permits them.
    if not can_use_subdomain(current_seller.plan):
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail="Your current plan does not permit a subdomain",
        )

    subdomain = payload.subdomain.lower().strip()

    # Check uniqueness
    existing_stmt = select(Shop).where(
        Shop.subdomain == subdomain,
        Shop.id != shop.id,
    )
    existing = db.execute(existing_stmt).scalar_one_or_none()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Subdomain '{subdomain}' is already taken",
        )

    shop.subdomain = subdomain
    db.commit()
    db.refresh(shop)

    logger.info("Subdomain set for shop %s: %s", shop.id, subdomain)

    branding = None
    if shop.branding_settings:
        branding = BrandingSettings(**shop.branding_settings)

    return WhiteLabelStatus(
        custom_domain=shop.custom_domain,
        subdomain=shop.subdomain,
        domain_verified=shop.domain_verified,
        domain_verified_at=shop.domain_verified_at,
        ssl_provisioned=shop.ssl_provisioned,
        branding=branding,
        hide_branding=shop.hide_branding,
    )


# ---------------------------------------------------------------------------
# PUT /whitelabel/branding  – update branding settings
# ---------------------------------------------------------------------------


@router.put("/branding", response_model=WhiteLabelStatus)
async def update_branding(
    payload: BrandingSettings,
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> WhiteLabelStatus:
    """Update the branding settings for the seller's shop."""
    shop = _get_seller_shop(current_seller.id, db)
    shop.branding_settings = payload.model_dump()
    db.commit()
    db.refresh(shop)

    logger.info("Branding updated for shop %s", shop.id)

    branding = BrandingSettings(**shop.branding_settings)
    return WhiteLabelStatus(
        custom_domain=shop.custom_domain,
        subdomain=shop.subdomain,
        domain_verified=shop.domain_verified,
        domain_verified_at=shop.domain_verified_at,
        ssl_provisioned=shop.ssl_provisioned,
        branding=branding,
        hide_branding=shop.hide_branding,
    )


# ---------------------------------------------------------------------------
# PUT /whitelabel/branding/toggle  – toggle hide_branding
# ---------------------------------------------------------------------------


@router.put("/branding/toggle", response_model=WhiteLabelStatus)
async def toggle_hide_branding(
    current_seller: Seller = Depends(get_current_seller),
    db: Session = Depends(get_db),
) -> WhiteLabelStatus:
    """Toggle the 'hide_branding' flag on/off."""
    shop = _get_seller_shop(current_seller.id, db)
    shop.hide_branding = not shop.hide_branding
    db.commit()
    db.refresh(shop)

    logger.info(
        "Hide-branding toggled to %s for shop %s",
        shop.hide_branding,
        shop.id,
    )

    branding = None
    if shop.branding_settings:
        branding = BrandingSettings(**shop.branding_settings)

    return WhiteLabelStatus(
        custom_domain=shop.custom_domain,
        subdomain=shop.subdomain,
        domain_verified=shop.domain_verified,
        domain_verified_at=shop.domain_verified_at,
        ssl_provisioned=shop.ssl_provisioned,
        branding=branding,
        hide_branding=shop.hide_branding,
    )
