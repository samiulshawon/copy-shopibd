from fastapi import APIRouter

from app.api.v1 import auth, sellers, shops, orders, products, categories, staff, analytics, admin, stock, reviews, payments, payment_webhook, delivery, whitelabel, customers, coupons, audit_logs, subscription

router = APIRouter(prefix="/api/v1")
router.include_router(auth.router, prefix="/auth")
router.include_router(sellers.router)
router.include_router(shops.router)
router.include_router(orders.router)
router.include_router(subscription.router)
router.include_router(products.router)
router.include_router(categories.router)
router.include_router(staff.router)
router.include_router(analytics.router)
router.include_router(admin.router)
router.include_router(stock.router)
router.include_router(reviews.router)
router.include_router(payments.router)
router.include_router(payment_webhook.router)
router.include_router(delivery.router)
router.include_router(whitelabel.router)
router.include_router(customers.router)
router.include_router(coupons.router)
router.include_router(audit_logs.router)
