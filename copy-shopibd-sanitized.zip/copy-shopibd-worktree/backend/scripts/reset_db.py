"""
Teardown and reseed script for ShopiBD development database.

Drops all tables, recreates them, and runs the seed script to populate
with fresh test data.  Safe to run repeatedly — no manual cleanup needed.

Usage:
    cd backend
    python -m scripts.reset_db
"""

import sys
from pathlib import Path

backend_root = str(Path(__file__).resolve().parent.parent)
if backend_root not in sys.path:
    sys.path.insert(0, backend_root)

from app.core.database import engine, Base
from app.models import *  # noqa: F401,F403 — register all tables on Base.metadata
from scripts.seed import seed_database


def reset_database() -> None:
    """Drop all tables, recreate them, and reseed."""
    print("[RESET] Dropping all tables …")
    Base.metadata.drop_all(bind=engine)
    print("[RESET] All tables dropped.")

    print("[RESET] Recreating all tables …")
    Base.metadata.create_all(bind=engine)
    print("[RESET] All tables created.")

    print("[RESET] Running seed …")
    seed_database()
    print("[RESET] Done.")


if __name__ == "__main__":
    reset_database()
