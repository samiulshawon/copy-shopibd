"""
Comprehensive seed script for ShopiBD development database.

Populates:
  - 1 seller with complete profile (owner: Sawan)
  - 1 shop for the seller
  - 3 categories (Clothing/পোশাক, Electronics/ইলেকট্রনিক্স, Home/গৃহস্থালি)
  - 6 products across categories (bilingual names, BDT prices, stock)
  - 1 staff member (manager)
  - 3 orders (pending, confirmed, delivered) with order items
  - Stock movement records linked to orders

Usage:
    cd backend
    python -m scripts.seed
"""

import sys
from pathlib import Path

# Ensure the backend root is on sys.path so that "app" can be imported
backend_root = str(Path(__file__).resolve().parent.parent)
if backend_root not in sys.path:
    sys.path.insert(0, backend_root)

from decimal import Decimal
from datetime import datetime, timezone, timedelta

from sqlalchemy.orm import Session

from app.core.database import SessionLocal
from app.core.security import get_password_hash
from app.models import (
    Seller,
    Shop,
    Category,
    Product,
    Order,
    OrderItem,
    StaffMember,
    StockMovement,
    ProductVariant,
)
from app.models.stock import MovementType
from app.models.subscription import (
    Subscription,
    SubscriptionPlan,
    SubscriptionStatus,
)


# ── Seed constants ───────────────────────────────────────────────────────
# These values must match the E2E test credentials in frontend/tests/e2e/.
SELLER_NAME = "Sawan's Shop"
SELLER_EMAIL = "sawan@shopibd.com"
SELLER_PASSWORD = "12345678"
SHOP_NAME = "Sawan's Shop"
SHOP_SLUG = "sawan-shop"
STAFF_NAME = "Sawan Manager"
STAFF_EMAIL = "staff@sawan.shop"
STAFF_PASSWORD = "12345678"


def seed_database() -> None:
    db: Session = SessionLocal()

    try:
        # -- Seller ----------------------------------------------------------
        seller = Seller(
            name=SELLER_NAME,
            email=SELLER_EMAIL,
            phone="01812345678",
            password_hash=get_password_hash(SELLER_PASSWORD),
            is_active=True,
            is_verified=True,
            is_super_admin=True,
            # Phase 8: the seeded platform owner is a staff admin.
            is_staff=True,
        )
        db.add(seller)
        db.flush()
        print(f"[OK] Seller created: {seller.name} (id={seller.id})")

        # -- Subscription (active Business plan for the seeded seller) ------
        subscription = Subscription(
            seller_id=seller.id,
            plan=SubscriptionPlan.BUSINESS,
            status=SubscriptionStatus.ACTIVE,
            current_period_start=datetime.now(timezone.utc),
            current_period_end=datetime.now(timezone.utc) + timedelta(days=30),
            auto_renew=True,
        )
        db.add(subscription)
        db.flush()
        print(f"[OK] Subscription created: plan={subscription.plan.value}, status={subscription.status.value}")

        # -- Shop ------------------------------------------------------------
        shop = Shop(
            name=SHOP_NAME,
            slug=SHOP_SLUG,
            description="Best electronics, fashion & home products",
            seller_id=seller.id,
            is_active=True,
        )
        db.add(shop)
        db.flush()
        print(f"[OK] Shop created: {shop.name} (id={shop.id})")

        # -- Categories (bilingual) ------------------------------------------
        categories_data = [
            {"name_bn": "পোশাক", "name_en": "Clothing", "desc": "Clothing & fashion items"},
            {"name_bn": "ইলেকট্রনিক্স", "name_en": "Electronics", "desc": "Electronic products & gadgets"},
            {"name_bn": "গৃহস্থালি", "name_en": "Home & Living", "desc": "Home goods & furniture"},
        ]
        categories = []
        for cd in categories_data:
            cat = Category(
                seller_id=seller.id,
                shop_id=shop.id,
                name_bn=cd["name_bn"],
                name_en=cd["name_en"],
                description=cd["desc"],
                sort_order=len(categories),
                is_active=True,
            )
            db.add(cat)
            db.flush()
            categories.append(cat)
            # Print only English to avoid cp1252 encoding issues
            print(f"[OK] Category created: {cat.name_en} (id={cat.id})")

        # -- Products (bilingual names, BDT prices, stock) -------------------
        products_data = [
            {
                "name_en": "Branded T-Shirt",
                "name_bn": "ব্র্যান্ডেড টি-শার্ট",
                "name": "Branded T-Shirt | ব্র্যান্ডেড টি-শার্ট",
                "desc": "Comfortable cotton t-shirt, regular fit",
                "price": Decimal("599.00"),
                "stock": 100,
                "category": categories[0],
            },
            {
                "name_en": "Denim Jeans Pant",
                "name_bn": "ডেনিম জিন্স প্যান্ট",
                "name": "Denim Jeans Pant | ডেনিম জিন্স প্যান্ট",
                "desc": "Trendy denim jeans, multiple sizes available",
                "price": Decimal("1299.00"),
                "stock": 50,
                "category": categories[0],
            },
            {
                "name_en": "Smartphone",
                "name_bn": "স্মার্টফোন",
                "name": "Smartphone | স্মার্টফোন",
                "desc": "6.5 inch display, 128GB storage",
                "price": Decimal("18999.00"),
                "stock": 25,
                "category": categories[1],
            },
            {
                "name_en": "Wireless Earbuds",
                "name_bn": "ওয়্যারলেস ইয়ারবাড",
                "name": "Wireless Earbuds | ওয়্যারলেস ইয়ারবাড",
                "desc": "Bluetooth 5.3, active noise cancellation",
                "price": Decimal("2499.00"),
                "stock": 75,
                "category": categories[1],
            },
            {
                "name_en": "Decorative Lamp",
                "name_bn": "ডেকোরেটিভ ল্যাম্প",
                "name": "Decorative Lamp | ডেকোরেটিভ ল্যাম্প",
                "desc": "LED table lamp, adjustable brightness",
                "price": Decimal("899.00"),
                "stock": 40,
                "category": categories[2],
            },
            {
                "name_en": "Cushion Set (4 pcs)",
                "name_bn": "কুশন সেট",
                "name": "Cushion Set (4 pcs) | কুশন সেট",
                "desc": "Soft velvet cushions, available in multiple colours",
                "price": Decimal("1599.00"),
                "stock": 30,
                "category": categories[2],
            },
        ]

        products = []
        for pd in products_data:
            prod = Product(
                name=pd["name"],
                description=pd["desc"],
                price=pd["price"],
                stock=pd["stock"],
                shop_id=shop.id,
                category_id=pd["category"].id,
                is_active=True,
            )
            db.add(prod)
            db.flush()
            products.append(prod)
            print(f"[OK] Product created: {pd['name_en']} (id={prod.id}, BDT {prod.price})")

        # -- Staff Member (manager) ------------------------------------------
        staff = StaffMember(
            name=STAFF_NAME,
            email=STAFF_EMAIL,
            phone="01912345678",
            password_hash=get_password_hash(STAFF_PASSWORD),
            role="manager",
            is_active=True,
            seller_id=seller.id,
        )
        db.add(staff)
        db.flush()
        print(f"[OK] Staff created: {staff.name} (id={staff.id}, role={staff.role})")

        # -- Orders ----------------------------------------------------------
        now = datetime.now(timezone.utc)

        # Order 1: pending
        order1 = Order(
            order_number="ORD-2026-0001",
            customer_name="Shamim Hasan",
            customer_phone="01611111111",
            customer_address="12/3, Gulshan, Dhaka",
            total_amount=Decimal("599.00"),
            status="pending",
            payment_status="pending",
            notes="Order is pending",
            shop_id=shop.id,
            created_at=now,
        )
        db.add(order1)
        db.flush()

        oi1 = OrderItem(
            order_id=order1.id,
            product_id=products[0].id,
            product_name=products[0].name,
            quantity=1,
            unit_price=products[0].price,
            subtotal=products[0].price,
        )
        db.add(oi1)
        db.flush()
        print(f"[OK] Order created: {order1.order_number} (status={order1.status})")

        # Order 2: confirmed
        order2 = Order(
            order_number="ORD-2026-0002",
            customer_name="Nusrat Jahan",
            customer_phone="01722222222",
            customer_address="45/B, Uttar Badda, Dhaka",
            total_amount=Decimal("21498.00"),
            status="confirmed",
            payment_status="paid",
            notes="Payment confirmed",
            shop_id=shop.id,
            created_at=now,
        )
        db.add(order2)
        db.flush()

        oi2a = OrderItem(
            order_id=order2.id,
            product_id=products[2].id,
            product_name=products[2].name,
            quantity=1,
            unit_price=products[2].price,
            subtotal=products[2].price,
        )
        oi2b = OrderItem(
            order_id=order2.id,
            product_id=products[3].id,
            product_name=products[3].name,
            quantity=1,
            unit_price=products[3].price,
            subtotal=products[3].price,
        )
        db.add_all([oi2a, oi2b])
        db.flush()
        print(f"[OK] Order created: {order2.order_number} (status={order2.status})")

        # Order 3: delivered
        order3 = Order(
            order_number="ORD-2026-0003",
            customer_name="Farhan Ahmed",
            customer_phone="01533333333",
            customer_address="78, Mirpur, Dhaka",
            total_amount=Decimal("2498.00"),
            status="delivered",
            payment_status="paid",
            notes="Delivery completed",
            shop_id=shop.id,
            created_at=now,
        )
        db.add(order3)
        db.flush()

        oi3a = OrderItem(
            order_id=order3.id,
            product_id=products[4].id,
            product_name=products[4].name,
            quantity=1,
            unit_price=products[4].price,
            subtotal=products[4].price,
        )
        oi3b = OrderItem(
            order_id=order3.id,
            product_id=products[5].id,
            product_name=products[5].name,
            quantity=1,
            unit_price=products[5].price,
            subtotal=products[5].price,
        )
        db.add_all([oi3a, oi3b])
        db.flush()
        print(f"[OK] Order created: {order3.order_number} (status={order3.status})")

        # -- Stock Movements -------------------------------------------------
        sm1 = StockMovement(
            seller_id=seller.id,
            product_id=products[0].id,
            variant_id=None,
            movement_type=MovementType.SALE,
            quantity_change=-1,
            previous_quantity=products[0].stock,
            new_quantity=products[0].stock - 1,
            reference_id=order1.id,
            reference_type="order",
            unit_cost=None,
            note=f"Sale via order {order1.order_number}",
            created_by=staff.id,
        )
        products[0].stock -= 1

        sm2a = StockMovement(
            seller_id=seller.id,
            product_id=products[2].id,
            variant_id=None,
            movement_type=MovementType.SALE,
            quantity_change=-1,
            previous_quantity=products[2].stock,
            new_quantity=products[2].stock - 1,
            reference_id=order2.id,
            reference_type="order",
            unit_cost=None,
            note=f"Sale via order {order2.order_number}",
            created_by=staff.id,
        )
        products[2].stock -= 1

        sm2b = StockMovement(
            seller_id=seller.id,
            product_id=products[3].id,
            variant_id=None,
            movement_type=MovementType.SALE,
            quantity_change=-1,
            previous_quantity=products[3].stock,
            new_quantity=products[3].stock - 1,
            reference_id=order2.id,
            reference_type="order",
            unit_cost=None,
            note=f"Sale via order {order2.order_number}",
            created_by=staff.id,
        )
        products[3].stock -= 1

        sm3a = StockMovement(
            seller_id=seller.id,
            product_id=products[4].id,
            variant_id=None,
            movement_type=MovementType.SALE,
            quantity_change=-1,
            previous_quantity=products[4].stock,
            new_quantity=products[4].stock - 1,
            reference_id=order3.id,
            reference_type="order",
            unit_cost=None,
            note=f"Sale via order {order3.order_number}",
            created_by=staff.id,
        )
        products[4].stock -= 1

        sm3b = StockMovement(
            seller_id=seller.id,
            product_id=products[5].id,
            variant_id=None,
            movement_type=MovementType.SALE,
            quantity_change=-1,
            previous_quantity=products[5].stock,
            new_quantity=products[5].stock - 1,
            reference_id=order3.id,
            reference_type="order",
            unit_cost=None,
            note=f"Sale via order {order3.order_number}",
            created_by=staff.id,
        )
        products[5].stock -= 1

        db.add_all([sm1, sm2a, sm2b, sm3a, sm3b])
        db.flush()
        print(f"[OK] Stock movements created (5 records)")

        # -- Commit everything -----------------------------------------------
        db.commit()
        print("\n[SUCCESS] Database seeded successfully with comprehensive test data!")
        print(f"   Seller:        {seller.name}")
        print(f"   Subscription:  {subscription.plan.value} ({subscription.status.value})")
        print(f"   Shop:          {shop.name}")
        print(f"   Categories:    {len(categories)}")
        print(f"   Products:      {len(products)}")
        print(f"   Staff:         {staff.name} ({staff.role})")
        print(f"   Orders:        3 (pending, confirmed, delivered)")
        print(f"   Stock Moves:   5")

    except Exception as exc:
        db.rollback()
        print(f"\n[ERROR] Seeding failed: {exc}")
        raise
    finally:
        db.close()


if __name__ == "__main__":
    seed_database()
