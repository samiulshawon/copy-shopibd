#!/bin/sh
# ShopiBD container entrypoint (backend).
#
# 1. Apply pending migrations.
# 2. Optionally seed demo data when SEED_DEMO=1 AND the database is empty
#    (idempotent across redeploys - never duplicates rows).
# 3. Start uvicorn on $PORT (Render/PaaS) or 8080 (local default).

set -e

alembic upgrade head

if [ "$SEED_DEMO" = "1" ]; then
  if python scripts/seed_if_empty.py; then
    echo "[entrypoint] empty database - seeding demo data"
    python -m scripts.seed || echo "[entrypoint] seed failed - continuing without demo data"
  else
    echo "[entrypoint] database already populated - skipping seed"
  fi
fi

exec uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-8080}"
