"""
Phase 8 backfill — mark existing super-admins as staff.

Run once after the ``is_staff`` column is added::

    python -m scripts.backfill_roles

Idempotent: sets ``is_staff = True`` for every seller with
``is_super_admin = True`` (and leaves non-super-admins untouched). The
migration ``p8_role_is_staff`` also performs this backfill inline; this
script exists for environments that apply schema changes out-of-band or
need a re-run after manual data changes.
"""
from __future__ import annotations

import sys

from sqlalchemy import select, update

from app.core.database import SessionLocal
from app.models.seller import Seller


def backfill_roles() -> int:
    """Promote every ``is_super_admin`` seller to ``is_staff``.

    Returns the number of rows updated.
    """
    db = SessionLocal()
    try:
        result = db.execute(
            update(Seller)
            .where(Seller.is_super_admin.is_(True))
            .values(is_staff=True)
        )
        db.commit()
        return int(result.rowcount or 0)
    finally:
        db.close()


def main() -> int:
    updated = backfill_roles()
    print(f"[backfill_roles] Promoted {updated} super-admin seller(s) to is_staff=True.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
