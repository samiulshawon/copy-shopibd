#!/usr/bin/env python3
"""
Generate TypeScript type definitions from the FastAPI OpenAPI schema.

This script:
1. Starts the FastAPI app in the background (or uses an already-running server)
2. Fetches /api/v1/openapi.json
3. Converts the schema to TypeScript interfaces using `openapi-typescript`
   or a built-in generator.

Usage:
    python scripts/generate-types.py

Requirements (install before running):
    pip install httpx openapi-typescript  # or use npx
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import httpx

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
API_BASE_URL = "http://localhost:8000"
OPENAPI_URL = f"{API_BASE_URL}/api/v1/openapi.json"
OUTPUT_DIR = Path(__file__).resolve().parent.parent.parent / "frontend" / "src" / "types" / "generated"
OUTPUT_FILE = OUTPUT_DIR / "api.ts"


def fetch_openapi_schema() -> dict:
    """Fetch the OpenAPI schema from the running FastAPI server."""
    try:
        response = httpx.get(OPENAPI_URL, timeout=10)
        response.raise_for_status()
        return response.json()
    except httpx.RequestError as exc:
        print(f"Error fetching OpenAPI schema: {exc}", file=sys.stderr)
        print("Make sure the FastAPI server is running.", file=sys.stderr)
        sys.exit(1)


def save_schema_json(schema: dict, path: Path) -> None:
    """Save the raw schema as JSON for openapi-typescript."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(schema, f, indent=2)
    print(f"Schema saved to {path}")


def generate_typescript_types(schema_path: Path, output_path: Path) -> None:
    """
    Use openapi-typescript (via npx) to generate TypeScript types.
    Falls back to a simple Python-based generator if npx is unavailable.
    """
    try:
        # Try using openapi-typescript CLI
        result = subprocess.run(
            [
                "npx",
                "--yes",
                "openapi-typescript",
                str(schema_path),
                "--output",
                str(output_path),
            ],
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode == 0:
            print(f"TypeScript types generated at {output_path}")
            return
        else:
            print(f"openapi-typescript failed: {result.stderr}", file=sys.stderr)
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        print(f"npx/openapi-typescript not available: {e}", file=sys.stderr)

    # Fallback: generate minimal types from schema
    print("Falling back to built-in TypeScript type generator...")
    generate_types_fallback(schema_path, output_path)


def generate_types_fallback(schema_path: Path, output_path: Path) -> None:
    """Simple fallback generator that produces basic TypeScript types from the schema."""
    with open(schema_path, "r", encoding="utf-8") as f:
        schema = json.load(f)

    output_path.parent.mkdir(parents=True, exist_ok=True)

    lines: list[str] = [
        "// ---------------------------------------------------------------------------",
        "// Auto-generated TypeScript types from OpenAPI schema",
        "// Regenerate with: python scripts/generate-types.py",
        "// ---------------------------------------------------------------------------",
        "",
    ]

    for name, schema_obj in schema.get("components", {}).get("schemas", {}).items():
        ts_name = to_pascal_case(name)
        lines.append(f"export interface {ts_name} {{")

        for prop_name, prop_info in schema_obj.get("properties", {}).items():
            ts_type = openapi_to_typescript(prop_info)
            required = prop_name in schema_obj.get("required", [])
            optional_marker = "" if required else "?"
            lines.append(f"  {prop_name}{optional_marker}: {ts_type};")

        lines.append("}")
        lines.append("")

    output_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"Fallback TypeScript types generated at {output_path}")


def to_pascal_case(s: str) -> str:
    """Convert snake_case or kebab-case to PascalCase."""
    return "".join(word.capitalize() for word in s.replace("-", "_").split("_"))


def openapi_to_typescript(prop: dict) -> str:
    """Map an OpenAPI property schema to a TypeScript type string."""
    if "$ref" in prop:
        ref_name = prop["$ref"].split("/")[-1]
        return to_pascal_case(ref_name)

    type_ = prop.get("type", "any")
    if type_ == "string":
        if prop.get("format") == "date-time":
            return "string"
        if prop.get("enum"):
            return " | ".join(f'"{e}"' for e in prop["enum"])
        return "string"
    elif type_ == "integer":
        return "number"
    elif type_ == "number":
        return "number"
    elif type_ == "boolean":
        return "boolean"
    elif type_ == "array":
        items = prop.get("items", {})
        return f"{openapi_to_typescript(items)}[]"
    elif type_ == "object":
        return "Record<string, unknown>"
    return "unknown"


def main() -> None:
    print("Fetching OpenAPI schema...")
    schema = fetch_openapi_schema()

    schema_path = OUTPUT_DIR / "schema.json"
    save_schema_json(schema, schema_path)

    print("Generating TypeScript types...")
    generate_typescript_types(schema_path, OUTPUT_FILE)

    print("Done!")


if __name__ == "__main__":
    main()
