"""Exit 0 when the database has no sellers (safe to seed), else exit 1.

Used by the container entrypoint to make SEED_DEMO=1 idempotent across
redeploys: demo data is only inserted into an empty database.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.core.database import SessionLocal
from app.models.seller import Seller


def main() -> int:
    db = SessionLocal()
    try:
        count = db.query(Seller).count()
    finally:
        db.close()
    print(f"sellers in database: {count}")
    return 0 if count == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
