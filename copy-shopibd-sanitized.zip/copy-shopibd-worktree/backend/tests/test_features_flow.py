"""
Tests for the flows built across Features 1-6:
  - Product image upload (Feature 6)
  - Subscription lifecycle + manual payment webhook (Feature 4)
  - Admin activity feed + settings (Features 1 & 2)
  - Plan-limit order enforcement (Feature 3)

Self-contained (no shared conftest). Uses an in-memory SQLite DB and the
TestClient, mirroring tests/test_plan_limits.py. The storage service is
monkeypatched to an in-memory fake so image tests never touch disk. Admin
endpoints override get_current_super_admin to bypass the Basic-auth middleware.

Run from backend/:  python -m pytest tests/test_features_flow.py -q
"""

from __future__ import annotations

from datetime import datetime, timezone

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.core.database import Base, get_db
from app.core.security import create_access_token, get_password_hash
from app.models.seller import Seller
from app.models.shop import Shop
from app.models.product import Product, ProductImage
from app.models.subscription import Subscription, SubscriptionPlan, SubscriptionStatus
from app.models.audit_log import AuditLog
from app.schemas.subscription import PLANS
from app.main import app
from app.api.v1 import dependencies as deps


# In-memory SQLite — isolated per test session
ENGINE = create_engine(
    "sqlite://",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=ENGINE)


@pytest.fixture()
def db_session():
    Base.metadata.create_all(bind=ENGINE)
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()
        Base.metadata.drop_all(bind=ENGINE)


@pytest.fixture()
def client(db_session):
    def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


@pytest.fixture(autouse=True)
def low_free_limits():
    """Lower Free plan limits so the 402 paths are reachable without seeding."""
    original = {
        "max_products": PLANS["free"].max_products,
        "max_orders": PLANS["free"].max_orders,
    }
    PLANS["free"].max_products = 1
    PLANS["free"].max_orders = 0
    yield
    PLANS["free"].max_products = original["max_products"]
    PLANS["free"].max_orders = original["max_orders"]


def _make_seller(db, email="seller@example.com", super_admin=False, password="password123"):
    seller = Seller(
        email=email,
        name="Test Seller",
        phone="01711111111",
        password_hash=get_password_hash(password),
        is_verified=True,
        is_super_admin=super_admin,
        plan="free",
        max_products=50,
        max_orders=200,
    )
    db.add(seller)
    db.flush()
    shop = Shop(name="Test Shop", slug="test-shop", seller_id=seller.id, is_active=True)
    db.add(shop)
    db.flush()
    sub = Subscription(
        seller_id=seller.id,
        plan=SubscriptionPlan.FREE,
        status=SubscriptionStatus.ACTIVE,
        current_period_start=datetime.now(timezone.utc),
        current_period_end=datetime.now(timezone.utc),
    )
    db.add(sub)
    db.commit()
    return seller, shop


def _auth(seller_id):
    token = create_access_token(subject=str(seller_id))
    return {"Authorization": f"Bearer {token}"}


# ---------------------------------------------------------------------------
# Feature 6 — Product image upload
# ---------------------------------------------------------------------------

class _FakeStorage:
    """In-memory stand-in for LocalStorageService; never touches disk."""

    async def save(self, file, folder: str) -> str:
        return f"/media/{folder}/fake.png"

    async def delete(self, url: str) -> None:
        return None


@pytest.fixture()
def fake_storage(monkeypatch):
    import app.services.storage as storage_mod

    monkeypatch.setattr(storage_mod, "get_storage_service", lambda: _FakeStorage())


def _create_product(client, auth, shop_id):
    resp = client.post(
        "/api/v1/products",
        json={"name": "Test Product", "price": 10, "stock": 5},
        params={"shop_id": shop_id},
        headers=auth,
    )
    assert resp.status_code == 201, resp.text
    return resp.json()["id"]


def test_upload_first_image_becomes_primary(client, fake_storage, db_session):
    seller, shop = _make_seller(db_session)
    auth = _auth(seller.id)
    pid = _create_product(client, auth, shop.id)

    resp = client.post(
        f"/api/v1/products/{pid}/images",
        files={"file": ("a.png", b"imgdata", "image/png")},
        headers=auth,
    )
    assert resp.status_code == 201, resp.text
    body = resp.json()
    assert body["image_url"].startswith("/media/")
    assert body["is_primary"] is True


def test_second_image_not_primary(client, fake_storage, db_session):
    seller, shop = _make_seller(db_session)
    auth = _auth(seller.id)
    pid = _create_product(client, auth, shop.id)

    client.post(
        f"/api/v1/products/{pid}/images",
        files={"file": ("a.png", b"imgdata", "image/png")},
        headers=auth,
    )
    resp2 = client.post(
        f"/api/v1/products/{pid}/images",
        files={"file": ("b.png", b"imgdata", "image/png")},
        headers=auth,
    )
    assert resp2.status_code == 201
    assert resp2.json()["is_primary"] is False


def test_set_primary_flips(client, fake_storage, db_session):
    seller, shop = _make_seller(db_session)
    auth = _auth(seller.id)
    pid = _create_product(client, auth, shop.id)

    r1 = client.post(f"/api/v1/products/{pid}/images", files={"file": ("a.png", b"x", "image/png")}, headers=auth).json()
    r2 = client.post(f"/api/v1/products/{pid}/images", files={"file": ("b.png", b"x", "image/png")}, headers=auth).json()

    resp = client.put(f"/api/v1/products/{pid}/images/{r2['id']}/primary", headers=auth)
    assert resp.status_code == 200
    assert resp.json()["is_primary"] is True

    # Re-fetch product to confirm exactly one primary
    prod = client.get(f"/api/v1/products/{pid}", headers=auth).json()
    primaries = [i for i in prod["images"] if i["is_primary"]]
    assert len(primaries) == 1 and primaries[0]["id"] == r2["id"]


def test_delete_primary_promotes_next(client, fake_storage, db_session):
    seller, shop = _make_seller(db_session)
    auth = _auth(seller.id)
    pid = _create_product(client, auth, shop.id)

    r1 = client.post(f"/api/v1/products/{pid}/images", files={"file": ("a.png", b"x", "image/png")}, headers=auth).json()
    r2 = client.post(f"/api/v1/products/{pid}/images", files={"file": ("b.png", b"x", "image/png")}, headers=auth).json()

    resp = client.delete(f"/api/v1/products/{pid}/images/{r1['id']}", headers=auth)
    assert resp.status_code == 204

    prod = client.get(f"/api/v1/products/{pid}", headers=auth).json()
    primaries = [i for i in prod["images"] if i["is_primary"]]
    assert len(primaries) == 1 and primaries[0]["id"] == r2["id"]


def test_max_ten_images(client, fake_storage, db_session):
    seller, shop = _make_seller(db_session)
    auth = _auth(seller.id)
    pid = _create_product(client, auth, shop.id)

    for _ in range(10):
        r = client.post(f"/api/v1/products/{pid}/images", files={"file": ("a.png", b"x", "image/png")}, headers=auth)
        assert r.status_code == 201
    eleventh = client.post(f"/api/v1/products/{pid}/images", files={"file": ("a.png", b"x", "image/png")}, headers=auth)
    assert eleventh.status_code == 400
    assert "10 images" in eleventh.text


def test_non_image_rejected(client, fake_storage, db_session):
    seller, shop = _make_seller(db_session)
    auth = _auth(seller.id)
    pid = _create_product(client, auth, shop.id)

    # The real LocalStorageService validates extension/size in save(); a .txt
    # file must raise StorageError (which the endpoint maps to HTTP 400).
    import asyncio

    from app.services.storage import LocalStorageService, StorageError

    class Txt:
        filename = "note.txt"

    with pytest.raises(StorageError):
        asyncio.run(LocalStorageService().save(Txt(), "x"))  # type: ignore


# ---------------------------------------------------------------------------
# Feature 4 — Subscription lifecycle + manual webhook
# ---------------------------------------------------------------------------

def test_subscription_select_then_manual_payment_activates(client, db_session):
    seller, shop = _make_seller(db_session)
    auth = _auth(seller.id)

    # Select a paid plan -> TRIALING
    sel = client.post("/api/v1/subscription", json={"plan": "starter"}, headers=auth)
    assert sel.status_code == 201, sel.text
    assert sel.json()["status"] == "trialing"

    # Create payment intent (manual) -> returns manual payment_url
    pay = client.post("/api/v1/subscription/payment", headers=auth)
    assert pay.status_code == 200, pay.text
    assert "manual=true" in pay.json()["payment_url"]

    # Manual webhook -> ACTIVE, plan synced
    wh = client.post(
        "/api/v1/payment-webhook/subscription",
        json={"payment_gateway": "manual", "payment_id": "manual-123", "status": "success", "seller_id": seller.id},
    )
    assert wh.status_code == 200, wh.text

    db_session.refresh(seller)
    assert seller.plan == "starter"
    assert seller.max_products == PLANS["starter"].max_products


def test_cancel_subscription_reverts_to_free(client, db_session):
    seller, shop = _make_seller(db_session)
    auth = _auth(seller.id)

    client.post("/api/v1/subscription", json={"plan": "business"}, headers=auth)
    cancel = client.delete("/api/v1/subscription", headers=auth)
    assert cancel.status_code == 204, cancel.text

    db_session.refresh(seller)
    assert seller.plan == "free"


# ---------------------------------------------------------------------------
# Features 1 & 2 — Admin activity + settings
# ---------------------------------------------------------------------------

@pytest.fixture()
def super_admin_client(client, db_session):
    seller, _ = _make_seller(db_session, email="admin@shopibd.com", super_admin=True)

    def override_super_admin():
        return seller

    app.dependency_overrides[deps.get_current_super_admin] = override_super_admin
    # Provide a Bearer token so the middleware's JWT layer (if any) is satisfied
    client.headers.update(_auth(seller.id))
    yield client, seller
    app.dependency_overrides.pop(deps.get_current_super_admin, None)
    client.headers.clear()


def test_admin_activity_returns_feed(client, super_admin_client, db_session):
    c, admin = super_admin_client
    db_session.add(AuditLog(action="product.create", entity_type="product", entity_id=1, actor_email="x@y.com"))
    db_session.commit()

    resp = c.get("/api/v1/admin/activity")
    assert resp.status_code == 200, resp.text
    data = resp.json()
    assert isinstance(data, list) and len(data) >= 1
    assert "action" in data[0] and "actor_email" in data[0]


def test_admin_settings_get_and_profile(client, super_admin_client, db_session):
    c, admin = super_admin_client

    get = c.get("/api/v1/admin/settings")
    assert get.status_code == 200
    assert get.json()["email"] == admin.email

    upd = c.put("/api/v1/admin/settings/profile", json={"name": "New Name", "phone": "01999999999"})
    assert upd.status_code == 200
    assert upd.json()["name"] == "New Name"


def test_admin_password_change(client, super_admin_client, db_session):
    c, admin = super_admin_client

    ok = c.put("/api/v1/admin/settings/password", json={"current_password": "password123", "new_password": "newpassword123"})
    assert ok.status_code == 200, ok.text

    bad_old = c.put("/api/v1/admin/settings/password", json={"current_password": "wrong", "new_password": "newpassword123"})
    assert bad_old.status_code == 400

    too_short = c.put("/api/v1/admin/settings/password", json={"current_password": "newpassword123", "new_password": "short"})
    assert too_short.status_code == 400


# ---------------------------------------------------------------------------
# Feature 3 — Plan-limit order enforcement (public order endpoint)
# ---------------------------------------------------------------------------

def test_order_limit_returns_402(client, db_session):
    seller, shop = _make_seller(db_session)
    auth = _auth(seller.id)
    pid = _create_product(client, auth, shop.id)
    # ensure product has stock
    prod = db_session.get(Product, pid)
    prod.stock = 10
    db_session.commit()

    payload = {
        "buyer_name": "Buyer",
        "buyer_phone": "01711111111",
        "buyer_address": {"division": "Dhaka", "district": "Dhaka", "area": "Gulshan", "details": "House 1"},
        "product_id": pid,
        "quantity": 1,
        "payment_method": "manual",
    }
    resp = client.post(f"/api/v1/shops/{shop.slug}/orders", json=payload)
    # max_orders=0 under low_free_limits -> 402
    assert resp.status_code == 402, resp.text
    assert "plan_limit_exceeded" in resp.text
