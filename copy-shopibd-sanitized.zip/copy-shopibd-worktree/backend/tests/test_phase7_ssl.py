"""
Tests for Phase 7 — Custom Domain SSL Provisioning (Task 7.3).

Covers the three spec'd behaviours:

* 7.3.1  Verified domain -> cert provisioned (stub backend in tests) -> Shop
         gets ssl_status="provisioned" and ssl_expires_at set; exercising
         the real whitelabel verify endpoint end-to-end.
* 7.3.2  Cert < 30 days -> renewal job runs and refreshes ssl_expires_at;
         the /health ssl summary reflects provisioning health.

Self-contained. Uses the StubBackend (SSL_BACKEND=stub) so no real
ACME issuer is contacted. DNS verification is mocked by monkeypatching the
verifier lookups.
"""
from __future__ import annotations

import types
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.api.v1 import dependencies as deps
from app.core.config import settings as app_settings
from app.core.database import Base, get_db
from app.core.security import create_access_token, get_password_hash
from app.main import app
from app.models.seller import Seller
from app.models.shop import Shop
from app.models.subscription import Subscription, SubscriptionPlan, SubscriptionStatus
from app.services import domain_verifier as dv
from app.services import ssl_renewal
from app.services.domain_verifier import ProvisionResult, needs_renewal


ENGINE = create_engine(
    "sqlite://",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=ENGINE)


@pytest.fixture()
def db_session():
    Base.metadata.create_all(bind=ENGINE)
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()
        Base.metadata.drop_all(bind=ENGINE)


@pytest.fixture()
def client(db_session):
    def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


def _enterprise_seller(db_session, email="ssl@example.com", domain="clientb.com"):
    seller = Seller(
        email=email,
        name="SSL Seller",
        phone="01700000001",
        password_hash=get_password_hash("password123"),
        is_active=True,
        is_verified=True,
        plan="enterprise",
    )
    db_session.add(seller)
    db_session.flush()
    db_session.add(
        Subscription(
            seller_id=seller.id,
            plan=SubscriptionPlan.ENTERPRISE,
            status=SubscriptionStatus.ACTIVE,
        )
    )
    db_session.add(
        Shop(
            name="SSL Shop",
            slug="sslshop",
            subdomain="sslshop",
            custom_domain=domain,
            seller_id=seller.id,
            is_active=True,
        )
    )
    db_session.commit()
    db_session.refresh(seller)
    return seller


def _auth(seller: Seller) -> dict:
    token = create_access_token(subject=str(seller.id))
    return {"Authorization": f"Bearer {token}"}


# ---------------------------------------------------------------------------
# Provisioning backend unit tests (no HTTP)
# ---------------------------------------------------------------------------


def test_stub_backend_issues_cert_with_expiry():
    backend = dv._StubBackend()
    result = backend.provision("clientb.com", staging=True)
    assert isinstance(result, ProvisionResult)
    assert result.success is True
    assert result.expires_at is not None
    assert result.expires_at > datetime.utcnow()


def test_needs_renewal_threshold():
    soon = datetime.utcnow() + timedelta(days=10)
    far = datetime.utcnow() + timedelta(days=90)
    assert needs_renewal(soon, threshold_days=30) is True
    assert needs_renewal(far, threshold_days=30) is False
    assert needs_renewal(None) is True


def test_provision_ssl_cert_uses_stub_when_debug(monkeypatch):
    monkeypatch.setattr(app_settings, "SSL_BACKEND", "stub")
    result = dv.provision_ssl_cert("clientx.com")
    assert result.success is True
    assert result.expires_at is not None


# ---------------------------------------------------------------------------
# 7.3.1 — Verified domain provisions cert (end-to-end via API)
# ---------------------------------------------------------------------------


def test_verify_domain_provisions_ssl(client, db_session, monkeypatch):
    seller = _enterprise_seller(db_session)
    # Make DNS checks pass so verification succeeds.
    # Patch where used: whitelabel imports these names directly from
    # domain_verifier, so patching the dv module attributes has no effect.
    monkeypatch.setattr(
        "app.api.v1.whitelabel.verify_cname", lambda domain, target: True
    )
    monkeypatch.setattr(
        "app.api.v1.whitelabel.verify_txt_record", lambda domain, expected: True
    )
    # Ensure the stub backend is used regardless of env.
    monkeypatch.setattr(app_settings, "SSL_BACKEND", "stub")

    resp = client.post(
        "/api/v1/whitelabel/domain/verify",
        headers=_auth(seller),
    )
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["verified"] is True

    shop = db_session.query(Shop).filter_by(seller_id=seller.id).first()
    assert shop.domain_verified is True
    assert shop.ssl_status == "provisioned"
    assert shop.ssl_provisioned is True
    assert shop.ssl_expires_at is not None
    assert shop.ssl_expires_at > datetime.utcnow()


def test_set_domain_resets_ssl_state(client, db_session, monkeypatch):
    seller = _enterprise_seller(db_session)
    shop = db_session.query(Shop).filter_by(seller_id=seller.id).first()
    shop.ssl_status = "provisioned"
    shop.ssl_provisioned = True
    shop.ssl_expires_at = datetime.utcnow() + timedelta(days=90)
    db_session.commit()

    resp = client.post(
        "/api/v1/whitelabel/domain",
        headers=_auth(seller),
        json={"domain": "newdomain.com"},
    )
    assert resp.status_code == 200, resp.text
    db_session.refresh(shop)
    assert shop.custom_domain == "newdomain.com"
    assert shop.ssl_status == "none"
    assert shop.ssl_expires_at is None
    assert shop.ssl_provisioned is False


# ---------------------------------------------------------------------------
# 7.3.2 — Renewal job + /health SSL status
# ---------------------------------------------------------------------------


def test_renewal_job_renews_near_expiry(db_session, monkeypatch):
    monkeypatch.setattr(app_settings, "SSL_BACKEND", "stub")
    seller = _enterprise_seller(db_session)
    shop = db_session.query(Shop).filter_by(seller_id=seller.id).first()
    # Cert expires in 5 days -> within the 30-day renewal window.
    shop.ssl_status = "provisioned"
    shop.ssl_expires_at = datetime.utcnow() + timedelta(days=5)
    db_session.commit()

    # Renewal goes through ssl_renewal's direct import of renew_ssl_cert;
    # stub the cert issuance itself (backend selection is covered by the
    # dv stub tests above).
    monkeypatch.setattr(
        ssl_renewal,
        "renew_ssl_cert",
        lambda domain, **kw: dv.ProvisionResult(
            success=True, expires_at=datetime.utcnow() + timedelta(days=90)
        ),
    )
    summary = ssl_renewal.run_ssl_renewal(db_session)
    assert summary["checked"] == 1
    assert summary["renewed"] == 1

    db_session.refresh(shop)
    assert shop.ssl_status == "provisioned"
    # New cert expiry is ~90 days out again.
    assert shop.ssl_expires_at > datetime.utcnow() + timedelta(days=60)


def test_renewal_job_skips_far_expiry(db_session, monkeypatch):
    monkeypatch.setattr(app_settings, "SSL_BACKEND", "stub")
    seller = _enterprise_seller(db_session)
    shop = db_session.query(Shop).filter_by(seller_id=seller.id).first()
    shop.ssl_status = "provisioned"
    shop.ssl_expires_at = datetime.utcnow() + timedelta(days=90)
    db_session.commit()

    summary = ssl_renewal.run_ssl_renewal(db_session)
    assert summary["checked"] == 1
    assert summary["renewed"] == 0
    assert summary["skipped"] == 1


def test_health_includes_ssl_summary(client, db_session, monkeypatch):
    monkeypatch.setattr(app_settings, "SSL_BACKEND", "stub")
    seller = _enterprise_seller(db_session)
    shop = db_session.query(Shop).filter_by(seller_id=seller.id).first()
    shop.ssl_status = "provisioned"
    shop.ssl_expires_at = datetime.utcnow() + timedelta(days=90)
    db_session.commit()

    resp = client.get("/health")
    assert resp.status_code == 200
    ssl = resp.json()["ssl"]
    assert ssl["total_custom_domains"] == 1
    assert ssl["provisioned"] == 1
    assert ssl["failed"] == 0
