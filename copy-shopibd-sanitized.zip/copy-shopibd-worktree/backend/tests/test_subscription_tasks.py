"""
Tests for subscription lifecycle background tasks.

Covers expiry detection, auto-renew extension, past-due checks,
and plan limit field synchronisation.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.core.database import Base
from app.models.seller import Seller
from app.models.subscription import Subscription, SubscriptionPlan, SubscriptionStatus
from app.schemas.subscription import PLANS
from app.services.subscription_tasks import (
    check_and_expire_subscriptions,
    check_past_due_subscriptions,
    run_all_subscription_tasks,
    sync_seller_plan_fields,
)

ENGINE = create_engine(
    "sqlite://",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=ENGINE)


@pytest.fixture()
def db_session():
    Base.metadata.create_all(bind=ENGINE)
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()
        Base.metadata.drop_all(bind=ENGINE)


def _create_seller(db, id=1, plan="free") -> Seller:
    seller = Seller(
        id=id,
        email=f"seller{id}@test.com",
        name=f"Seller {id}",
        password_hash="dummy",
        phone=f"017{id:08d}",
        is_active=True,
        plan=plan,
        max_products=PLANS[plan].max_products,
        max_orders=PLANS[plan].max_orders,
    )
    db.add(seller)
    db.flush()
    return seller


def _create_subscription(
    db,
    seller_id=1,
    plan=SubscriptionPlan.STARTER,
    status=SubscriptionStatus.ACTIVE,
    auto_renew=False,
    days_ago=0,
) -> Subscription:
    now = datetime.now(timezone.utc)
    sub = Subscription(
        seller_id=seller_id,
        plan=plan,
        status=status,
        auto_renew=auto_renew,
        current_period_start=now - timedelta(days=30),
        current_period_end=now - timedelta(days=days_ago),
    )
    db.add(sub)
    db.flush()
    return sub


class TestCheckAndExpire:
    def test_expires_overdue_subscription(self, db_session):
        """Active subscription past current_period_end should be marked EXPIRED."""
        seller = _create_seller(db_session, id=1)
        sub = _create_subscription(
            db_session,
            seller_id=seller.id,
            auto_renew=False,
            days_ago=1,
        )
        result = check_and_expire_subscriptions(db_session)
        db_session.refresh(sub)
        assert sub.status == SubscriptionStatus.EXPIRED
        assert sub.plan == SubscriptionPlan.FREE
        assert result["expired"] == 1

    def test_auto_renews_subscription(self, db_session):
        """Active subscription with auto_renew should extend period."""
        seller = _create_seller(db_session, id=2)
        sub = _create_subscription(
            db_session,
            seller_id=seller.id,
            plan=SubscriptionPlan.BUSINESS,
            auto_renew=True,
            days_ago=1,
        )
        db_session.refresh(sub)
        old_end = sub.current_period_end
        # Strip timezone for comparison since SQLite may not preserve it
        old_end_naive = old_end.replace(tzinfo=None) if old_end else None
        result = check_and_expire_subscriptions(db_session)
        db_session.refresh(sub)
        new_end_naive = sub.current_period_end.replace(tzinfo=None) if sub.current_period_end else None
        assert new_end_naive is not None and old_end_naive is not None
        assert new_end_naive > old_end_naive
        assert sub.status == SubscriptionStatus.ACTIVE
        assert result["renewed"] == 1

    def test_does_not_expire_future_subscription(self, db_session):
        """Active subscription within its period should be left alone."""
        seller = _create_seller(db_session, id=3)
        now = datetime.now(timezone.utc)
        sub = Subscription(
            seller_id=seller.id,
            plan=SubscriptionPlan.STARTER,
            status=SubscriptionStatus.ACTIVE,
            current_period_start=now - timedelta(days=15),
            current_period_end=now + timedelta(days=15),
        )
        db_session.add(sub)
        db_session.flush()
        result = check_and_expire_subscriptions(db_session)
        db_session.refresh(sub)
        assert sub.status == SubscriptionStatus.ACTIVE
        assert result["expired"] == 0


class TestCheckPastDue:
    def test_reports_past_due_count(self, db_session):
        """Past-due subscriptions should be counted."""
        seller = _create_seller(db_session, id=10)
        sub = Subscription(
            seller_id=seller.id,
            plan=SubscriptionPlan.STARTER,
            status=SubscriptionStatus.PAST_DUE,
            current_period_start=datetime.now(timezone.utc) - timedelta(days=30),
            current_period_end=datetime.now(timezone.utc) + timedelta(days=1),
        )
        db_session.add(sub)
        db_session.flush()
        result = check_past_due_subscriptions(db_session)
        assert result["past_due_count"] == 1

    def test_returns_zero_when_none_past_due(self, db_session):
        """No past-due subscriptions should return zero."""
        result = check_past_due_subscriptions(db_session)
        assert result["past_due_count"] == 0


class TestSyncSellerPlanFields:
    def test_syncs_seller_limits_to_free_plan(self, db_session):
        """Seller with free plan but inflated limits should be synced back."""
        seller = _create_seller(db_session, id=20, plan="free")
        seller.max_products = 999
        seller.max_orders = 999
        db_session.flush()
        result = sync_seller_plan_fields(db_session)
        db_session.refresh(seller)
        assert seller.max_products == PLANS["free"].max_products
        assert seller.max_orders == PLANS["free"].max_orders
        assert result["synced"] == 1

    def test_does_not_sync_when_aligned(self, db_session):
        """Seller already on correct limits should not be modified."""
        seller = _create_seller(db_session, id=30, plan="free")
        original_products = seller.max_products
        original_orders = seller.max_orders
        result = sync_seller_plan_fields(db_session)
        assert result["synced"] == 0


class TestRunAll:
    def test_orchestrates_all_tasks(self, db_session):
        """run_all_subscription_tasks should return results for all three tasks."""
        _create_seller(db_session, id=40)
        _create_subscription(
            db_session,
            seller_id=40,
            auto_renew=False,
            days_ago=5,
        )
        result = run_all_subscription_tasks(db=db_session)
        assert "expire_check" in result
        assert "past_due_check" in result
        assert "sync" in result
        assert result["expire_check"]["expired"] >= 1
