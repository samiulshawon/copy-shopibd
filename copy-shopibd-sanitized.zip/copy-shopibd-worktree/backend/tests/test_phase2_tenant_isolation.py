"""
Tests for Phase 2: tenant isolation via the request-scoped context var,
super-admin impersonation tokens carrying ``impersonated_by``, and audit
logging for super-admin actions.

Self-contained (no shared conftest). Mirrors the fixture shape of
``tests/test_admin_create_client_url.py``: in-memory SQLite via
``StaticPool``, ``app.dependency_overrides[get_db]`` swapped per test,
super-admin seller materialised directly in the DB and the
``get_current_super_admin`` dependency overridden. Tokens are produced by
``security.create_access_token(subject=str(seller.id))`` and carried via
``Authorization: Bearer``.

The SQLite path bypasses the Postgres RLS plumbing, so the
``set_current_seller_id`` / contextvar behaviour is a no-op — the tests
verify the contract on the *edges* (200 / 401, claim decoding, audit-log
row presence) rather than asserting on cross-request state.
"""
from __future__ import annotations

from datetime import datetime, timezone

import pytest
from fastapi.testclient import TestClient
from jose import jwt
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.api.v1 import dependencies as deps
from app.core.config import settings
from app.core.context import (
    get_current_seller_id,
    get_current_seller_id_or_default,
    set_current_seller_id,
)
from app.core.database import Base, get_db
from app.core.security import create_access_token, get_password_hash
from app.main import app
from app.models.audit_log import AuditLog
from app.models.seller import Seller
from app.models.shop import Shop
from app.models.subscription import Subscription, SubscriptionPlan, SubscriptionStatus


ENGINE = create_engine(
    "sqlite://",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=ENGINE)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def db_session():
    Base.metadata.create_all(bind=ENGINE)
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()
        Base.metadata.drop_all(bind=ENGINE)
        # Clear any contextvar residue from the request handlers above.
        set_current_seller_id(None)


@pytest.fixture()
def client(db_session):
    def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


def _seed_subscription(db, seller_id: int) -> Subscription:
    sub = Subscription(
        seller_id=seller_id,
        plan=SubscriptionPlan.FREE,
        status=SubscriptionStatus.ACTIVE,
        current_period_start=datetime.now(timezone.utc),
        auto_renew=False,
    )
    db.add(sub)
    return sub


def _seed_shop(db, seller_id: int, slug: str) -> Shop:
    shop = Shop(
        name=f"Shop {slug}",
        slug=slug,
        seller_id=seller_id,
        is_active=True,
    )
    db.add(shop)
    return shop


def _make_super_admin(db) -> Seller:
    admin = Seller(
        email="admin@shopibd.com",
        name="Super Admin",
        phone="01700000000",
        password_hash=get_password_hash("password123"),
        is_active=True,
        is_verified=True,
        is_super_admin=True,
        plan="free",
        max_products=50,
        max_orders=200,
    )
    db.add(admin)
    db.flush()
    _seed_subscription(db, admin.id)
    db.commit()
    db.refresh(admin)
    return admin


def _make_seller(
    db,
    email: str,
    phone: str,
    *,
    name: str = "Regular Seller",
    is_active: bool = True,
    super_admin: bool = False,
) -> Seller:
    seller = Seller(
        email=email,
        name=name,
        phone=phone,
        password_hash=get_password_hash("password123"),
        is_active=is_active,
        is_verified=True,
        is_super_admin=super_admin,
        plan="free",
        max_products=50,
        max_orders=200,
    )
    db.add(seller)
    db.flush()
    _seed_subscription(db, seller.id)
    _seed_shop(db, seller.id, email.replace("@", "-at-").replace(".", "-"))
    db.commit()
    db.refresh(seller)
    return seller


@pytest.fixture()
def super_admin_client(client, db_session):
    """Yield a TestClient whose ``get_current_super_admin`` returns the seeded
    super-admin and whose Authorization header carries a freshly minted JWT."""
    admin = _make_super_admin(db_session)

    def override_super_admin():
        return admin

    app.dependency_overrides[deps.get_current_super_admin] = override_super_admin
    client.headers.update(
        {"Authorization": f"Bearer {create_access_token(subject=str(admin.id))}"}
    )
    yield client, admin
    app.dependency_overrides.pop(deps.get_current_super_admin, None)
    client.headers.clear()


def _login(client, email: str, password: str = "password123") -> str:
    """Log in via the actual /auth/login endpoint and return the access_token."""
    resp = client.post(
        "/api/v1/auth/login", json={"email": email, "password": password}
    )
    assert resp.status_code == 200, resp.text
    body = resp.json()
    return body["access_token"]


# ---------------------------------------------------------------------------
# Test 1 — Context var cleared on unauthenticated, honoured on authed requests
# ---------------------------------------------------------------------------


def test_context_var_cleared_when_no_token(client, db_session):
    """A bare request to a protected endpoint must come back 401; afterwards
    the contextvar must read as None (its default) — the unauthenticated
    path is not allowed to leak the previous request's seller id."""
    set_current_seller_id(None)  # ensure clean slate

    resp = client.get("/api/v1/sellers/me")
    assert resp.status_code == 401, resp.text
    assert get_current_seller_id_or_default(None) is None
    # And the strict accessor agrees (no LookupError / stale value).
    assert get_current_seller_id() is None


def test_context_var_after_real_jwt_login(client, db_session):
    """A real login through ``/api/v1/auth/login`` yields a JWT that
    successfully authenticates ``GET /api/v1/sellers/me`` (200). After the
    request the contextvar falls back to None (SQLite / no-op path)."""
    seller = _make_seller(db_session, "regular1@example.com", "01711112233")
    token = _login(client, "regular1@example.com")

    set_current_seller_id(None)  # clear before the instrumented request
    resp = client.get(
        "/api/v1/sellers/me", headers={"Authorization": f"Bearer {token}"}
    )
    assert resp.status_code == 200, resp.text
    body = resp.json()
    assert body["id"] == seller.id
    # After the request the strict context accessor agrees we're back to None
    # (the production Postgres path would set the id during the handler; for
    # SQLite the value remains the default).
    assert get_current_seller_id_or_default(None) is None


# ---------------------------------------------------------------------------
# Test 2 — Impersonation token carries ``impersonated_by``
# ---------------------------------------------------------------------------


def test_impersonation_token_carries_impersonated_by(
    client, db_session, super_admin_client
):
    """The endpoint MUST return a short-lived JWT whose ``sub`` is the
    target seller's id and whose ``impersonated_by`` claim equals the
    acting super-admin's id; ``type`` must remain ``access``."""
    c, admin = super_admin_client
    target = _make_seller(
        db_session,
        "target@example.com",
        "01711112244",
        name="Target Seller",
    )

    resp = c.post(
        f"/api/v1/admin/sellers/{target.id}/impersonate",
        json={"reason": "phase-2 test"},
    )
    assert resp.status_code == 200, resp.text
    body = resp.json()

    assert "access_token" in body
    assert "expires_in_seconds" in body
    assert body["impersonated_by"] == admin.id
    assert body["seller_id"] == target.id

    payload = jwt.decode(
        body["access_token"],
        settings.SECRET_KEY,
        algorithms=[settings.ALGORITHM],
    )
    assert payload["sub"] == str(target.id)
    assert payload["impersonated_by"] == admin.id
    assert payload["type"] == "access"


# ---------------------------------------------------------------------------
# Test 3 — Impersonation forbidden for self / inactive sellers
# ---------------------------------------------------------------------------


def test_impersonate_self_returns_400(client, db_session, super_admin_client):
    """The super-admin must not be able to impersonate themselves."""
    c, admin = super_admin_client
    resp = c.post(
        f"/api/v1/admin/sellers/{admin.id}/impersonate",
        json={"reason": "self-test"},
    )
    assert resp.status_code == 400, resp.text


def test_impersonate_inactive_returns_400(client, db_session, super_admin_client):
    """The super-admin must not be able to impersonate an inactive client."""
    c, _admin = super_admin_client
    target = _make_seller(
        db_session,
        "inactive@example.com",
        "01711112255",
        name="Inactive Seller",
        is_active=False,
    )
    resp = c.post(
        f"/api/v1/admin/sellers/{target.id}/impersonate",
        json={"reason": "inactive-test"},
    )
    assert resp.status_code == 400, resp.text


# ---------------------------------------------------------------------------
# Test 4 — Audit log rows for super-admin actions
# ---------------------------------------------------------------------------


def test_audit_log_for_client_create(client, db_session, super_admin_client):
    """``POST /admin/sellers`` must write an ``AuditLog`` with
    ``action="client.create"``, ``entity_type="seller"`` and an
    ``actor_email`` that is the super-admin's email."""
    c, admin = super_admin_client

    payload = {
        "name": "New Client",
        "email": "newclient@example.com",
        "phone": "01711112266",
        "password": "password123",
        "shop_name": "New Client Shop",
    }
    resp = c.post("/api/v1/admin/sellers", json=payload)
    assert resp.status_code == 201, resp.text
    new_seller = (
        db_session.query(Seller).filter(Seller.email == payload["email"]).one()
    )

    log = (
        db_session.query(AuditLog)
        .filter(AuditLog.entity_id == str(new_seller.id))
        .one()
    )
    assert log.action == "client.create"
    assert log.entity_type == "seller"
    assert log.actor_email == admin.email
    assert log.seller_id == new_seller.id


def test_audit_log_for_client_activate_and_deactivate(
    client, db_session, super_admin_client
):
    """``POST /admin/sellers/{id}/activate`` and ``.../deactivate`` must each
    write their own audit row opposite each other."""
    c, admin = super_admin_client
    target = _make_seller(
        db_session, "toggletarget@example.com", "01711112277"
    )

    # Start deactivated (it's active=True by default; flip it once).
    deact = c.post(f"/api/v1/admin/sellers/{target.id}/deactivate")
    assert deact.status_code == 200, deact.text
    deact_log = (
        db_session.query(AuditLog)
        .filter(
            AuditLog.action == "client.deactivate",
            AuditLog.entity_id == str(target.id),
        )
        .one()
    )
    assert deact_log.entity_type == "seller"
    assert deact_log.actor_email == admin.email
    assert deact_log.seller_id == target.id

    act = c.post(f"/api/v1/admin/sellers/{target.id}/activate")
    assert act.status_code == 200, act.text
    act_log = (
        db_session.query(AuditLog)
        .filter(
            AuditLog.action == "client.activate",
            AuditLog.entity_id == str(target.id),
        )
        .one()
    )
    assert act_log.entity_type == "seller"
    assert act_log.actor_email == admin.email
    assert act_log.seller_id == target.id


def test_audit_log_for_subscription_override(
    client, db_session, super_admin_client
):
    """``PUT /admin/sellers/{id}/subscription`` must record the old and
    new plan values on the audit row."""
    c, admin = super_admin_client
    target = _make_seller(
        db_session, "subtarget@example.com", "01711112288"
    )

    resp = c.put(
        f"/api/v1/admin/sellers/{target.id}/subscription",
        json={"plan": "starter", "auto_renew": True},
    )
    assert resp.status_code == 200, resp.text

    log = (
        db_session.query(AuditLog)
        .filter(
            AuditLog.action == "client.subscription_override",
            AuditLog.entity_id == str(target.id),
        )
        .one()
    )
    assert log.entity_type == "seller"
    assert log.actor_email == admin.email
    assert log.seller_id == target.id
    assert log.old_values is not None and "plan" in log.old_values
    assert log.new_values is not None
    assert log.new_values.get("plan") == "starter"


def test_audit_log_for_impersonate(client, db_session, super_admin_client):
    """``POST /admin/sellers/{id}/impersonate`` must record the
    ``reason`` passed in the request body on the audit row's
    ``extra_data`` field."""
    c, admin = super_admin_client
    target = _make_seller(
        db_session, "imptarget@example.com", "01711112299"
    )

    reason = "phase-2: testing impersonation audit"
    resp = c.post(
        f"/api/v1/admin/sellers/{target.id}/impersonate",
        json={"reason": reason},
    )
    assert resp.status_code == 200, resp.text

    log = (
        db_session.query(AuditLog)
        .filter(
            AuditLog.action == "client.impersonate",
            AuditLog.entity_id == str(target.id),
        )
        .one()
    )
    assert log.entity_type == "seller"
    assert log.actor_email == admin.email
    assert log.seller_id == target.id
    assert log.extra_data is not None
    assert log.extra_data.get("reason") == reason
    assert "expires_in_seconds" in log.extra_data


# ---------------------------------------------------------------------------
# Test 5 — Context cleared when auth fails (invalid token)
# ---------------------------------------------------------------------------


def test_context_cleared_after_invalid_token(client, db_session):
    """A protected endpoint called with a syntactically invalid Bearer
    token must return 401 and must NOT mutate the contextvar to any
    stale value from a prior request."""
    _make_seller(db_session, "regular2@example.com", "01711112300")
    set_current_seller_id(None)  # start from a known clean default

    resp = client.get(
        "/api/v1/sellers/me",
        headers={"Authorization": "Bearer this-is-not-a-valid-jwt"},
    )
    assert resp.status_code == 401, resp.text
    assert get_current_seller_id_or_default(None) is None
    assert get_current_seller_id() is None
