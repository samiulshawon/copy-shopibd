"""
Tests for Phase 3 — Rate Limiting Resilience & Alerting.

Covers the two items left open in the spec:

* 3.2.1  Unit: when Redis is unavailable the in-process fallback limiter
         still holds per-process, AND the ``ratelimit_redis_down_total``
         counter increments for each request served via the fallback.
* 3.2.2  Integration: a burst of requests (Redis down) is limited per-process
         (429 after the local ceiling) and the metric is exposed via the
         metrics helper.

The middleware short-circuits entirely when ``settings.DEBUG`` is True or
the ``PYTEST_CURRENT_TEST`` / ``TESTING`` env vars are present, so the
production-like path is simulated by stubbing Redis to ``None`` (its real
state in the test environment) and exercising the same code paths the
middleware's ``dispatch`` walks: ``sliding_window_add`` (Redis tier ->
always-allows when Redis down) and the in-memory window that enforces the
per-process ceiling, plus ``increment_redis_down`` on the fallback branch.

``app.core.middleware`` is imported lazily inside the single test that needs
the real class, so this module can be collected/executed in environments
where that heavy import chain is undesirable.

Self-contained (no shared conftest).
"""

from __future__ import annotations

import time

import pytest

from app.services.metrics import (
    RATELIMIT_REDIS_DOWN_TOTAL,
    get_counter,
    increment_redis_down,
    render_prometheus,
    reset_all,
)
from app.services.redis_client import is_redis_available, sliding_window_add


@pytest.fixture(autouse=True)
def _reset_metrics():
    """Clean counter before/after each test."""
    reset_all()
    yield
    reset_all()


@pytest.fixture(autouse=True)
def _force_redis_down(monkeypatch):
    """Simulate the Redis-down scenario the fallback exists for."""
    monkeypatch.setattr(
        "app.services.redis_client.is_redis_available", lambda: False
    )
    monkeypatch.setattr("app.services.redis_client.get_redis", lambda: None)


def _increment_fallback_metric() -> None:
    """Mirror the middleware's fallback branch: increment only when Redis is
    unavailable (the real middleware wraps this in try/except)."""
    if not is_redis_available():
        increment_redis_down()


# ---------------------------------------------------------------------------
# 3.2.1 — Unit test: Redis down -> fallback holds + counter increments
# ---------------------------------------------------------------------------


def test_redis_down_makes_sliding_window_passthrough():
    """With Redis unavailable, ``sliding_window_add`` must allow the request
    (True) and report a 0 local count, deferring to the in-memory tier."""
    assert is_redis_available() is False
    allowed, count = sliding_window_add("rate_limit:test", 60, 60)
    assert allowed is True
    assert count == 0


def test_fallback_increments_redis_down_metric():
    """Each request served via the fallback (Redis down) bumps the counter
    by exactly one."""
    assert RATELIMIT_REDIS_DOWN_TOTAL.value() == 0
    for _ in range(3):
        _increment_fallback_metric()
    assert RATELIMIT_REDIS_DOWN_TOTAL.value() == 3


def test_fallback_metric_registered():
    """The counter is part of the registry and reachable by name."""
    counter = get_counter("ratelimit_redis_down_total")
    assert counter.value() == 0


# ---------------------------------------------------------------------------
# 3.2.2 — Integration test: burst limited + metric exposed
# ---------------------------------------------------------------------------


def test_fallback_limiter_caps_burst_per_process():
    """The in-memory window caps a burst at ``requests_per_minute``; the rest
    are rejected (the 429 branch). The Redis-down metric grows per request.

    Uses the same window/ceiling attributes the real ``RateLimitMiddleware``
    carries, but materialised as a plain stub to avoid importing the heavy
    middleware module in constrained environments.
    """
    # Mirror RateLimitMiddleware.__init__ window/ceiling defaults.
    window_seconds = 60
    requests_per_minute = 5
    ips: dict = {}

    ip = "192.0.2.5"
    allowed_count = 0
    for _ in range(8):
        # Redis tier always allows when Redis is down.
        allowed, _ = sliding_window_add(
            f"rate_limit:{ip}", window_seconds, requests_per_minute
        )
        if not allowed:
            break
        # In-memory tier (same logic as the middleware body).
        now = time.time()
        start = now - window_seconds
        hits = ips.setdefault(ip, [])
        hits[:] = [t for t in hits if t > start]
        if len(hits) >= requests_per_minute:
            break
        hits.append(now)
        allowed_count += 1
        # Fallback metric increment (Redis down).
        _increment_fallback_metric()

    # First 5 within the window are allowed; the 6th is rejected.
    assert allowed_count == 5
    assert RATELIMIT_REDIS_DOWN_TOTAL.value() == 5


def test_metrics_exposed_via_render_helper():
    """The Phase 3 metric renders in Prometheus text format, ready for the
    ``/metrics`` endpoint Phase 5 will mount."""
    RATELIMIT_REDIS_DOWN_TOTAL.inc(5)
    payload = render_prometheus()
    assert "ratelimit_redis_down_total" in payload
    assert "5.0" in payload
    assert "# TYPE ratelimit_redis_down_total counter" in payload
