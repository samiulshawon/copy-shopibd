"""Shared fixtures for OpenAPI contract tests."""

from collections.abc import Generator

import pytest
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture()
def client() -> Generator[TestClient, None, None]:
    """Provide a synchronous client for app/schema contract checks."""
    with TestClient(app) as test_client:
        yield test_client
