"""Contract checks generated from the FastAPI OpenAPI schema."""

from __future__ import annotations

import pytest

# Schemathesis is a CI dev-dependency; skip the module (instead of erroring
# at collection) when it is not installed in a local/offline environment.
schemathesis = pytest.importorskip("schemathesis")

from app.main import app  # noqa: E402

schema = schemathesis.from_asgi("/api/v1/openapi.json", app)


@pytest.mark.contract
@schema.parametrize()
def test_openapi_schema_contract(case):
    """Generated requests must return responses that match the schema."""
    case.call_and_validate()


@pytest.mark.contract
def test_openapi_schema_served(client):
    """The configured OpenAPI route serves a valid schema for this app."""
    response = client.get("/api/v1/openapi.json")
    assert response.status_code == 200

    document = response.json()
    assert "openapi" in document
    assert document["info"]["title"] == "ShopiBD"
    assert "paths" in document


@pytest.mark.contract
def test_openapi_endpoints_match_routes(client):
    """Every documented API route is present in the generated schema."""
    document = client.get("/api/v1/openapi.json").json()
    spec_paths = set(document["paths"])

    app_routes = {
        route.path
        for route in app.routes
        if hasattr(route, "path") and route.path.startswith("/api/")
    }

    missing_paths = app_routes - spec_paths
    assert not missing_paths, f"Routes missing from OpenAPI: {sorted(missing_paths)}"
