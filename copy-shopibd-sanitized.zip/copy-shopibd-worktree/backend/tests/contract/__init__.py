"""
Contract / schema tests for ShopiBD backend API.
"""
