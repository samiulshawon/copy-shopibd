"""
Tests for Phase 9 — Subdomain Availability UX (Task 9.3).

Covers the spec'd behaviours:

* 9.3.1  ``GET /api/v1/shops/subdomain-available`` returns the right shape
         for available, taken (with suggestions), reserved, and invalid
         inputs. The suggestion generator matches the spec scenario:
         ``client-a`` taken -> suggestions like ``client-a-bd`` and
         ``client-a1``.
* 9.3.2  The availability contract the signup page relies on: a taken base
         yields suggestions that are themselves available (no collision),
         so clicking one would pass. (Frontend is React; this verifies the
         backend contract the page calls.)

Self-contained, in-memory SQLite + dependency override.
"""
from __future__ import annotations

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.core.database import Base, get_db
from app.main import app
from app.models.seller import Seller
from app.models.shop import Shop


ENGINE = create_engine(
    "sqlite://",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=ENGINE)


@pytest.fixture()
def client(db_session):
    def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


@pytest.fixture()
def db_session():
    Base.metadata.create_all(bind=ENGINE)
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()
        Base.metadata.drop_all(bind=ENGINE)


def _add_shop(db_session, subdomain: str):
    seller = Seller(
        email=f"{subdomain}@example.com",
        name=subdomain,
        phone=f"017000000{hash(subdomain) % 10}",
        password_hash="x",
        is_active=True,
        is_verified=True,
        plan="free",
    )
    db_session.add(seller)
    db_session.flush()
    db_session.add(
        Shop(name=subdomain, slug=subdomain, subdomain=subdomain, seller_id=seller.id, is_active=True)
    )
    db_session.commit()


# ---------------------------------------------------------------------------
# 9.3.1 — Availability endpoint shape
# ---------------------------------------------------------------------------


def test_available_subdomain(client, db_session):
    resp = client.get("/api/v1/shops/subdomain-available?subdomain=brandnewshop")
    assert resp.status_code == 200
    body = resp.json()
    assert body["available"] is True
    assert body["subdomain"] == "brandnewshop"
    assert body["suggestions"] == []
    assert body["reason"] == "available"


def test_taken_subdomain_returns_suggestions(client, db_session):
    _add_shop(db_session, "client-a")
    resp = client.get("/api/v1/shops/subdomain-available?subdomain=client-a")
    assert resp.status_code == 200
    body = resp.json()
    assert body["available"] is False
    assert body["reason"] == "taken"
    assert len(body["suggestions"]) > 0
    # Spec scenario: suggest client-a-bd and/or client-a1.
    suggestions = body["suggestions"]
    assert any(s == "client-a-bd" or s == "client-a1" for s in suggestions)


def test_reserved_subdomain_rejected(client, db_session):
    resp = client.get("/api/v1/shops/subdomain-available?subdomain=admin")
    assert resp.status_code == 200
    body = resp.json()
    assert body["available"] is False
    assert body["reason"] == "reserved"


def test_invalid_subdomain_rejected(client, db_session):
    # Uppercase + invalid characters -> normalized away to invalid/empty.
    resp = client.get("/api/v1/shops/subdomain-available?subdomain=AB!!")
    assert resp.status_code == 200
    body = resp.json()
    assert body["available"] is False
    assert body["reason"] in ("invalid", "reserved")


def test_normalization_lowercases_and_strips(client, db_session):
    _add_shop(db_session, "coolshop")
    # Case and surrounding whitespace are normalized before the lookup.
    resp = client.get("/api/v1/shops/subdomain-available?subdomain=COOLSHOP")
    assert resp.status_code == 200
    body = resp.json()
    # The input normalizes to "coolshop", which is taken.
    assert body["available"] is False
    assert body["subdomain"] == "coolshop"

    resp = client.get("/api/v1/shops/subdomain-available?subdomain=%20coolshop%20")
    assert resp.status_code == 200
    assert resp.json()["available"] is False

    # Hyphens are legal in subdomains, so "cool-shop" is a DIFFERENT
    # candidate from "coolshop" and stays available.
    resp = client.get("/api/v1/shops/subdomain-available?subdomain=Cool-Shop")
    assert resp.status_code == 200
    body = resp.json()
    assert body["available"] is True
    assert body["subdomain"] == "cool-shop"


# ---------------------------------------------------------------------------
# 9.3.2 — Suggestions are themselves available (frontend contract)
# ---------------------------------------------------------------------------


def test_suggestions_are_available(client, db_session):
    """Every suggestion returned for a taken subdomain must be free to take.

    The new-client page lets the user click a suggestion to fill the field,
    so each suggestion must not collide with an existing shop.
    """
    _add_shop(db_session, "client-a")
    resp = client.get("/api/v1/shops/subdomain-available?subdomain=client-a")
    suggestions = resp.json()["suggestions"]
    assert len(suggestions) > 0
    for suggestion in suggestions:
        check = client.get(
            f"/api/v1/shops/subdomain-available?subdomain={suggestion}"
        ).json()
        assert check["available"] is True, f"suggestion {suggestion} is not free: {check}"
