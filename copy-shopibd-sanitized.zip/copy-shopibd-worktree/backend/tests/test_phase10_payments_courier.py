"""
Tests for Phase 10 — Payments, Courier & Abandoned Cart (Task 10.4).

Covers the spec'd behaviours:

* 10.4.1  Steadfast webhook: valid HMAC signature updates delivery status;
         invalid/missing signature is rejected (403); unknown tracking -> 404;
         malformed body -> 400.
* 10.4.2  Abandoned-cart job: pending orders older than N hours (with a
         phone) are nudged (recovery_sent_at stamped, WhatsApp sent via the
         mock provider) and not re-nudged; newer orders are skipped; marking
         recovered sets recovered_at.
* 10.4.3  Provider sandbox scaffolding: the integration skip guards in
         ``tests.integration.scaffold_providers`` skip cleanly when no creds
         are present (the default CI state) and report sandbox mode.

Self-contained, in-memory SQLite + dependency override for the webhook; the
abandoned-cart job uses its own session over the same engine.
"""
from __future__ import annotations

import hashlib
import hmac
import json
from datetime import datetime, timedelta, timezone

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.core.config import settings
from app.core.database import Base, get_db
from app.main import app
from app.models.order import Order
from app.models.seller import Seller
from app.models.shop import Shop
from app.models.delivery import Delivery, ShipmentStatus, CourierName
from app.services.courier.steadfast import SteadfastCourierService
from app.services import abandoned_cart


ENGINE = create_engine(
    "sqlite://",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=ENGINE)


@pytest.fixture()
def db_session():
    Base.metadata.create_all(bind=ENGINE)
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()
        Base.metadata.drop_all(bind=ENGINE)


@pytest.fixture()
def client(db_session):
    def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


# ---------------------------------------------------------------------------
# 10.4.1 — Steadfast webhook signature verification
# ---------------------------------------------------------------------------


def _make_delivery(db_session, tracking: str) -> Delivery:
    seller = Seller(
        email="courier@shopibd.com",
        name="Courier Seller",
        phone="01700000001",
        password_hash="x",
        is_active=True,
        is_verified=True,
        plan="business",
    )
    db_session.add(seller)
    db_session.flush()
    shop = Shop(name="cs", slug="cs", subdomain="cs", seller_id=seller.id, is_active=True)
    db_session.add(shop)
    db_session.flush()
    delivery = Delivery(
        seller_id=seller.id,
        order_id=1,
        courier_name=CourierName.STEADFAST,
        tracking_number=tracking,
        pickup_address="Dhaka",
        delivery_address="Dhaka",
        shipment_status=ShipmentStatus.PENDING,
    )
    db_session.add(delivery)
    db_session.commit()
    db_session.refresh(delivery)
    return delivery


def _signed_body(secret: str, payload: dict) -> tuple[bytes, str]:
    body = json.dumps(payload).encode("utf-8")
    sig = hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
    return body, sig


def test_webhook_with_valid_signature_updates_status(client, db_session, monkeypatch):
    monkeypatch.setattr(settings, "STEADFAST_WEBHOOK_SECRET", "test-secret")
    delivery = _make_delivery(db_session, "SF123")

    body, sig = _signed_body(
        "test-secret",
        {"tracking_code": "SF123", "status": "Delivered"},
    )
    resp = client.post(
        "/api/v1/delivery/webhook/steadfast",
        content=body,
        headers={"X-Steadfast-Signature": sig},
    )
    assert resp.status_code == 200, resp.text
    db_session.refresh(delivery)
    assert delivery.shipment_status == ShipmentStatus.DELIVERED
    assert delivery.delivered_at is not None


def test_webhook_with_invalid_signature_rejected(client, db_session, monkeypatch):
    monkeypatch.setattr(settings, "STEADFAST_WEBHOOK_SECRET", "test-secret")
    _make_delivery(db_session, "SF456")
    body, _ = _signed_body("test-secret", {"tracking_code": "SF456", "status": "Delivered"})
    resp = client.post(
        "/api/v1/delivery/webhook/steadfast",
        content=body,
        headers={"X-Steadfast-Signature": "deadbeef"},
    )
    assert resp.status_code == 403


def test_webhook_unknown_tracking_returns_404(client, db_session, monkeypatch):
    monkeypatch.setattr(settings, "STEADFAST_WEBHOOK_SECRET", "test-secret")
    body, sig = _signed_body("test-secret", {"tracking_code": "NOPE", "status": "Delivered"})
    resp = client.post(
        "/api/v1/delivery/webhook/steadfast",
        content=body,
        headers={"X-Steadfast-Signature": sig},
    )
    assert resp.status_code == 404


def test_webhook_requires_status_field(client, db_session, monkeypatch):
    monkeypatch.setattr(settings, "STEADFAST_WEBHOOK_SECRET", "test-secret")
    _make_delivery(db_session, "SF789")
    body, sig = _signed_body("test-secret", {"tracking_code": "SF789"})
    resp = client.post(
        "/api/v1/delivery/webhook/steadfast",
        content=body,
        headers={"X-Steadfast-Signature": sig},
    )
    assert resp.status_code == 400


# ---------------------------------------------------------------------------
# 10.4.2 — Abandoned-cart recovery job
# ---------------------------------------------------------------------------


def _make_pending_order(db_session, *, phone="01722222222", hours_ago=3, recovery_sent_at=None):
    seller = Seller(
        email=f"ab{counter()['n']}@shopibd.com",
        name="Ab Seller",
        phone="0170000000" + str(counter()["n"]),
        password_hash="x",
        is_active=True,
        is_verified=True,
        plan="free",
    )
    db_session.add(seller)
    db_session.flush()
    shop = Shop(name="ab", slug=f"ab{counter()['n']}", subdomain=f"ab{counter()['n']}", seller_id=seller.id, is_active=True)
    db_session.add(shop)
    db_session.flush()
    order = Order(
        order_number=f"ORD-{counter()['n']}-{hours_ago}",
        customer_name="Buyer",
        customer_phone=phone,
        customer_address="Dhaka",
        total_amount=500.00,
        status="pending",
        payment_status="pending",
        shop_id=shop.id,
        created_at=datetime.now(timezone.utc) - timedelta(hours=hours_ago),
        recovery_sent_at=recovery_sent_at,
    )
    db_session.add(order)
    db_session.commit()
    db_session.refresh(order)
    return order


_counter = {"n": 0}


def counter():
    _counter["n"] += 1
    return {"n": _counter["n"]}


def test_abandoned_cart_job_nudges_old_pending_orders(db_session, monkeypatch):
    monkeypatch.setattr(settings, "WHATSAPP_PROVIDER", "mock")
    o1 = _make_pending_order(db_session, hours_ago=3)
    o2 = _make_pending_order(db_session, hours_ago=5)
    # Fresh order should be skipped.
    _make_pending_order(db_session, hours_ago=0)

    summary = abandoned_cart.run_abandoned_cart_reminders(db_session, hours=1)
    assert summary["candidates"] == 2
    assert summary["nudged"] == 2
    assert summary["skipped"] == 1

    db_session.refresh(o1)
    db_session.refresh(o2)
    assert o1.recovery_sent_at is not None
    assert o2.recovery_sent_at is not None


def test_abandoned_cart_job_does_not_repeat_nudge(db_session, monkeypatch):
    monkeypatch.setattr(settings, "WHATSAPP_PROVIDER", "mock")
    o = _make_pending_order(db_session, hours_ago=3, recovery_sent_at=datetime.now(timezone.utc))

    summary = abandoned_cart.run_abandoned_cart_reminders(db_session, hours=1)
    assert summary["candidates"] == 0
    assert summary["nudged"] == 0


def test_abandoned_cart_mark_recovered(db_session):
    o = _make_pending_order(db_session, hours_ago=3, recovery_sent_at=datetime.now(timezone.utc))
    abandoned_cart.mark_recovered(db_session, o)
    db_session.refresh(o)
    assert o.recovered_at is not None


# ---------------------------------------------------------------------------
# 10.4.3 — Provider sandbox scaffolding (integration guards)
# ---------------------------------------------------------------------------


def test_sandbox_guards_skip_without_creds():
    """With no provider creds configured, the integration guards skip.

    This mirrors the CI default where *_SANDBOX creds are absent, so the
    10.4.3 integration tests are skipped rather than failing.
    """
    from tests.integration.scaffold_providers import (
        bkash_credentials_present,
        nagad_credentials_present,
        sslcommerz_credentials_present,
        sandbox_mode_for,
    )

    # In the default test env no real creds are set -> all False.
    assert bkash_credentials_present() is False
    assert nagad_credentials_present() is False
    assert sslcommerz_credentials_present() is False
    # Sandbox is on by default (non-prod), so integration tests hit stubs.
    assert sandbox_mode_for("bkash") is True


def test_sandbox_mode_off_in_production(monkeypatch):
    from tests.integration.scaffold_providers import sandbox_mode_for

    monkeypatch.setattr(settings, "APP_ENV", "production")
    monkeypatch.setattr(settings, "BKASH_SANDBOX", False)
    assert sandbox_mode_for("bkash") is False
    # Reset so other tests see dev defaults.
    monkeypatch.setattr(settings, "APP_ENV", "development")
    monkeypatch.setattr(settings, "BKASH_SANDBOX", True)
