"""
Tests for the storage service abstraction (local + S3/MinIO).

Covers file validation, save/delete lifecycle, and backend selection.
"""

from __future__ import annotations

import io
import os
import tempfile
from unittest.mock import patch

import pytest
from fastapi import UploadFile

from app.services.storage import (
    LocalStorageService,
    S3StorageService,
    StorageError,
    get_storage_service,
)


def _fake_upload(filename: str, content: bytes = b"fake-image-data") -> UploadFile:
    """Create a minimal UploadFile for testing."""
    return UploadFile(file=io.BytesIO(content), filename=filename, size=len(content))


class TestLocalStorage:
    """LocalStorageService integration tests against real disk."""

    @pytest.mark.asyncio
    async def test_save_returns_public_url(self):
        """Saved file should return a /media/... URL."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("app.services.storage.settings.MEDIA_ROOT", tmpdir):
                svc = LocalStorageService()
                fake = _fake_upload("test.jpg")
                url = await svc.save(fake, "products")
                assert url.startswith("/media/products/")
                assert url.endswith(".jpg")

    @pytest.mark.asyncio
    async def test_save_persists_file(self):
        """File content should be written to disk."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("app.services.storage.settings.MEDIA_ROOT", tmpdir):
                svc = LocalStorageService()
                fake = _fake_upload("photo.png", b"png-content")
                url = await svc.save(fake, "avatars")
                rel = url[len("/media/"):]
                full_path = os.path.join(tmpdir, rel)
                assert os.path.exists(full_path)
                with open(full_path, "rb") as f:
                    assert f.read() == b"png-content"

    @pytest.mark.asyncio
    async def test_delete_removes_file(self):
        """Deleted file should no longer exist on disk."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("app.services.storage.settings.MEDIA_ROOT", tmpdir):
                svc = LocalStorageService()
                fake = _fake_upload("delete-me.jpeg", b"to-delete")
                url = await svc.save(fake, "tmp")
                await svc.delete(url)
                rel = url[len("/media/"):]
                assert not os.path.exists(os.path.join(tmpdir, rel))

    @pytest.mark.asyncio
    async def test_rejects_invalid_extension(self):
        """Non-image file extensions should be rejected."""
        svc = LocalStorageService()
        fake = _fake_upload("document.pdf")
        with pytest.raises(StorageError, match="Unsupported image type"):
            await svc.save(fake, "any")

    @pytest.mark.asyncio
    async def test_rejects_oversized_file(self):
        """Files larger than 5 MB should be rejected."""
        svc = LocalStorageService()
        fake = _fake_upload("large.webp", b"x" * (6 * 1024 * 1024))  # 6 MB
        with pytest.raises(StorageError, match="5 MB limit"):
            await svc.save(fake, "any")

    @pytest.mark.asyncio
    async def test_delete_missing_file_does_not_raise(self):
        """Deleting a non-existent file should be a no-op."""
        svc = LocalStorageService()
        await svc.delete("/media/nonexistent/foo.jpg")


class TestS3Storage:
    """S3StorageService constructor and validation tests.

    Actual upload/download is tested against the mocked/stubbed MinIO
    environment in integration tests. Here we validate config rejection
    and factory routing only.
    """

    def test_init_raises_without_bucket(self):
        """S3StorageService should raise if AWS_S3_BUCKET is empty."""
        with patch("app.services.storage.settings.AWS_S3_BUCKET", ""):
            with pytest.raises(StorageError, match="AWS_S3_BUCKET is not configured"):
                S3StorageService()

    def test_init_succeeds_with_bucket(self):
        """S3StorageService should initialise when bucket is set."""
        bucket = "test-bucket"
        with (
            patch("app.services.storage.settings.AWS_S3_BUCKET", bucket),
            patch("app.services.storage.settings.AWS_S3_ENDPOINT_URL", "http://localhost:9000"),
            patch("app.services.storage.settings.AWS_S3_REGION", "us-east-1"),
            patch("app.services.storage.settings.AWS_ACCESS_KEY_ID", "minioadmin"),
            patch("app.services.storage.settings.AWS_SECRET_ACCESS_KEY", "minioadmin"),
        ):
            svc = S3StorageService()
            assert svc.bucket == bucket

    def test_url_to_key_strips_prefix(self):
        """_url_to_key should extract the object key from a public URL."""
        with (
            patch("app.services.storage.settings.AWS_S3_BUCKET", "bucket"),
            patch("app.services.storage.settings.AWS_S3_ENDPOINT_URL", "http://minio:9000"),
            patch("app.services.storage.settings.AWS_ACCESS_KEY_ID", "key"),
            patch("app.services.storage.settings.AWS_SECRET_ACCESS_KEY", "secret"),
        ):
            svc = S3StorageService()
            key = svc._url_to_key("http://minio:9000/bucket/products/uuid.jpg")
            assert key == "products/uuid.jpg"

    def test_get_content_type_maps_extensions(self):
        """_get_content_type should return correct MIME types."""
        assert S3StorageService._get_content_type(".jpg") == "image/jpeg"
        assert S3StorageService._get_content_type(".png") == "image/png"
        assert S3StorageService._get_content_type(".webp") == "image/webp"
        assert S3StorageService._get_content_type(".gif") == "image/gif"
        assert S3StorageService._get_content_type(".unknown") == "application/octet-stream"


class TestGetStorageService:
    """Factory function routing tests."""

    def test_defaults_to_local(self):
        """get_storage_service should return LocalStorageService by default."""
        with patch("app.services.storage.settings.STORAGE_BACKEND", "local"):
            svc = get_storage_service()
            assert isinstance(svc, LocalStorageService)

    def test_s3_routing(self):
        """get_storage_service should return S3StorageService when configured."""
        with (
            patch("app.services.storage.settings.STORAGE_BACKEND", "s3"),
            patch("app.services.storage.settings.AWS_S3_BUCKET", "bucket"),
            patch("app.services.storage.settings.AWS_S3_ENDPOINT_URL", "http://minio:9000"),
            patch("app.services.storage.settings.AWS_ACCESS_KEY_ID", "key"),
            patch("app.services.storage.settings.AWS_SECRET_ACCESS_KEY", "secret"),
        ):
            svc = get_storage_service()
            assert isinstance(svc, S3StorageService)

    def test_invalid_backend_falls_to_local(self):
        """Unknown STORAGE_BACKEND should fall back to local."""
        with patch("app.services.storage.settings.STORAGE_BACKEND", "invalid"):
            svc = get_storage_service()
            assert isinstance(svc, LocalStorageService)
