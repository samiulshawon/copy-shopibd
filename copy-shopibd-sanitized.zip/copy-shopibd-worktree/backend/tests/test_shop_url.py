"""
Tests for the preview-URL resolver (Spec 2, Task 2).

Exercises ``shop_preview_url`` in both local (path-based) and live
(host-based) modes using a lightweight stand-in for the Shop ORM model so no
database is required.
"""

from __future__ import annotations

import types

from app.core.config import settings
from app.services.shop_url import shop_preview_url


def _make_shop(subdomain="acme", slug="acme", custom_domain=None):
    return types.SimpleNamespace(
        subdomain=subdomain,
        slug=slug,
        custom_domain=custom_domain,
    )


def test_local_mode_returns_path_based_url(monkeypatch):
    monkeypatch.setattr(settings, "LOCAL_DOMAIN_MODE", True)
    monkeypatch.setattr(settings, "DOMAIN", "localhost")
    shop = _make_shop(subdomain="acme", slug="acme")
    assert shop_preview_url(shop) == "/shop/acme"


def test_local_mode_uses_base_url_prefix(monkeypatch):
    monkeypatch.setattr(settings, "LOCAL_DOMAIN_MODE", True)
    monkeypatch.setattr(settings, "DOMAIN", "localhost")
    shop = _make_shop(subdomain="acme", slug="acme")
    assert shop_preview_url(shop, base_url="http://localhost:8000") == (
        "http://localhost:8000/shop/acme"
    )


def test_live_mode_returns_subdomain_host_url(monkeypatch):
    monkeypatch.setattr(settings, "LOCAL_DOMAIN_MODE", False)
    monkeypatch.setattr(settings, "DOMAIN", "shopibd.com")
    shop = _make_shop(subdomain="acme", slug="acme")
    assert shop_preview_url(shop) == "https://acme.shopibd.com"


def test_live_mode_returns_custom_domain_url(monkeypatch):
    monkeypatch.setattr(settings, "LOCAL_DOMAIN_MODE", False)
    monkeypatch.setattr(settings, "DOMAIN", "shopibd.com")
    shop = _make_shop(subdomain="acme", slug="acme", custom_domain="shop.acme.com")
    assert shop_preview_url(shop) == "https://shop.acme.com"
