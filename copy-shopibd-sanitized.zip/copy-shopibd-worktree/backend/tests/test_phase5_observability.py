"""Tests for Phase 5 — Observability: request IDs, metrics, scheduler run visibility."""
from __future__ import annotations

import importlib
import types

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.core.database import Base, get_db
from app.core.request_context import get_request_id, set_request_id
from app.main import app
from app.models.shop import Shop
from app.models.seller import Seller
from app.models.subscription import Subscription, SubscriptionPlan, SubscriptionStatus
from app.models.scheduler_run import SchedulerRun
from app.services.metrics import (
    RATELIMIT_REDIS_DOWN_TOTAL,
    render_prometheus,
    reset_all,
)
from app.services import subscription_tasks


ENGINE = create_engine(
    "sqlite://",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=ENGINE)


@pytest.fixture()
def db_session():
    Base.metadata.create_all(bind=ENGINE)
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()
        Base.metadata.drop_all(bind=ENGINE)


@pytest.fixture()
def client(db_session):
    def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


@pytest.fixture(autouse=True)
def _reset_metrics():
    reset_all()
    set_request_id(None)
    yield
    reset_all()
    set_request_id(None)


@pytest.fixture(autouse=True)
def _isolate_scheduler_db(monkeypatch):
    """Force the scheduler task to use the test session."""
    monkeypatch.setattr(
        subscription_tasks, "SessionLocal", TestingSessionLocal
    )
    yield


def _make_active_shop(db_session, subdomain: str, custom_domain: str | None = None):
    seller = Seller(
        email=f"{subdomain}@example.com",
        name=subdomain,
        phone="01700000000",
        password_hash="x",
        is_active=True,
        is_verified=True,
        plan="business",
    )
    db_session.add(seller)
    db_session.flush()
    db_session.add(
        Subscription(
            seller_id=seller.id,
            plan=SubscriptionPlan.BUSINESS,
            status=SubscriptionStatus.ACTIVE,
        )
    )
    db_session.add(
        Shop(
            name=subdomain,
            slug=subdomain,
            subdomain=subdomain,
            custom_domain=custom_domain,
            seller_id=seller.id,
            is_active=True,
        )
    )
    db_session.commit()


# ---------------------------------------------------------------------------
# R5.1 — Request-ID
# ---------------------------------------------------------------------------


def test_response_includes_request_id(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    assert "X-Request-ID" in resp.headers
    assert len(resp.headers["X-Request-ID"]) >= 8


def test_request_id_present_in_log_output(client, caplog):
    import logging

    with caplog.at_level(logging.INFO):
        client.get("/health")
    assert any("request_id" in record.message for record in caplog.records) or any(
        getattr(record, "request_id", None) for record in caplog.records
    )


def test_request_id_cleared_after_request():
    import asyncio

    from app.core.log import add_request_id_middleware

    async def call_next(request):
        from starlette.responses import JSONResponse

        return JSONResponse({})

    scope = {
        "type": "http",
        "method": "GET",
        "path": "/health",
        "headers": [],
        "client": ("127.0.0.1", 1234),
        "query_string": b"",
    }
    from starlette.requests import Request

    request = Request(scope)
    asyncio.get_event_loop().run_until_complete(
        add_request_id_middleware(request, call_next)
    )
    assert get_request_id() is None


# ---------------------------------------------------------------------------
# R5.2 — Metrics
# ---------------------------------------------------------------------------


def test_metrics_endpoint_exposes_counters(client, db_session):
    _make_active_shop(db_session, "metricsa", custom_domain="a.example.com")
    resp = client.get("/metrics")
    assert resp.status_code == 200
    body = resp.text
    assert "ratelimit_redis_down_total" in body
    assert "shopibd_subdomains_total" in body
    assert "shopibd_custom_domains_total" in body
    assert "shopibd_active_subscriptions_total" in body
    assert "shopibd_db_pool_checked_out" in body


def test_metrics_render_helper_includes_counters():
    RATELIMIT_REDIS_DOWN_TOTAL.inc(3)
    payload = render_prometheus()
    assert "ratelimit_redis_down_total 3.0" in payload


# ---------------------------------------------------------------------------
# R5.2b — /metrics token guard (go-live hardening)
# ---------------------------------------------------------------------------


def test_metrics_endpoint_requires_token_when_configured(client, monkeypatch):
    from app.core.config import settings as app_settings

    monkeypatch.setattr(app_settings, "METRICS_TOKEN", "scraper-secret")
    # No header / wrong header -> 401.
    assert client.get("/metrics").status_code == 401
    wrong = client.get(
        "/metrics", headers={"Authorization": "Bearer wrong-secret"}
    )
    assert wrong.status_code == 401
    # Correct bearer token -> 200.
    ok = client.get(
        "/metrics", headers={"Authorization": "Bearer scraper-secret"}
    )
    assert ok.status_code == 200


def test_metrics_endpoint_open_without_token(client, monkeypatch):
    from app.core.config import settings as app_settings

    monkeypatch.setattr(app_settings, "METRICS_TOKEN", "")
    resp = client.get("/metrics")
    assert resp.status_code == 200
    assert "shopibd_subdomains_total" in resp.text


# ---------------------------------------------------------------------------
# R5.3 — Scheduler visibility
# ---------------------------------------------------------------------------


def test_scheduler_run_persisted(db_session):
    subscription_tasks.run_all_subscription_tasks(db_session)
    run = db_session.query(SchedulerRun).order_by(SchedulerRun.id.desc()).first()
    assert run is not None
    assert run.status == "ok"
    assert run.result is not None
    assert run.finished_at is not None


def test_health_reports_latest_scheduler_run(client, db_session):
    subscription_tasks.run_all_subscription_tasks(db_session)
    resp = client.get("/health")
    assert resp.status_code == 200
    scheduler = resp.json()["scheduler"]
    assert scheduler["status"] == "ok"
    assert scheduler["last_run"] is not None


# ---------------------------------------------------------------------------
# R5.4 — Middleware shared session
# ---------------------------------------------------------------------------


def test_request_session_middleware_sets_state(db_session):
    """Each request should get a single scoped session on request.state."""
    from app.core.request_session import RequestSessionMiddleware
    import asyncio

    captured = {}

    async def call_next(request):
        from starlette.responses import JSONResponse

        captured["db"] = request.state.db
        return JSONResponse({})

    scope = {
        "type": "http",
        "method": "GET",
        "path": "/health",
        "headers": [],
        "client": ("127.0.0.1", 1234),
        "query_string": b"",
    }
    from starlette.requests import Request

    mw = RequestSessionMiddleware(app=None)
    request = Request(scope)
    asyncio.get_event_loop().run_until_complete(mw.dispatch(request, call_next))
    assert captured["db"] is not None


if __name__ == "__main__":
    import sys

    sys.exit(pytest.main([__file__, "-v"]))
