"""
Tests for the plan pricing catalog (B5).

Self-contained unit test asserting the canonical plan tiers defined in
``app.schemas.subscription.PLANS`` match the agreed pricing and that the Free
tier limits align with the Seller model defaults. This locks B5 as a
regression guard so pricing cannot silently drift.

Run from backend/:  python -m pytest tests/test_plans.py -q
"""

from __future__ import annotations

from decimal import Decimal

from app.models.seller import Seller
from app.schemas.subscription import PLANS


EXPECTED_PRICING = {
    "free": Decimal("0"),
    "starter": Decimal("499"),
    "business": Decimal("999"),
    "enterprise": Decimal("2999"),
}


def test_four_tiers_defined():
    assert set(PLANS.keys()) == {"free", "starter", "business", "enterprise"}


def test_prices_match_bangladeshi_tiers():
    for plan_id, price in EXPECTED_PRICING.items():
        assert PLANS[plan_id].price_bdt == price, (
            f"{plan_id} price expected ৳{price}, got ৳{PLANS[plan_id].price_bdt}"
        )


def test_free_limits_match_seller_defaults():
    free = PLANS["free"]
    assert free.max_products == Seller.max_products.default.arg
    assert free.max_orders == Seller.max_orders.default.arg


def test_enterprise_is_unlimited():
    enterprise = PLANS["enterprise"]
    assert enterprise.max_products >= 99999
    assert enterprise.max_orders >= 99999


def test_paid_plans_are_priced_and_limited():
    for plan_id in ("starter", "business", "enterprise"):
        plan = PLANS[plan_id]
        assert plan.price_bdt > 0
        assert plan.max_products > 0
        assert plan.max_orders > 0
        assert plan.features, f"{plan_id} should expose a feature list"
