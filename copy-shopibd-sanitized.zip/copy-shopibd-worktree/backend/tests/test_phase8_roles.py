"""
Tests for Phase 8 — Role Model Cleanup (Task 8.3).

Two spec'd behaviours:

* 8.3.1  A verified seller who is NOT staff gets 403 on an admin route
         (``get_current_admin_seller`` now gates on ``is_staff``, not
         ``is_verified``). A staff seller is allowed through.
* 8.3.2  ``scripts/backfill_roles`` promotes existing super-admins to staff;
         the seed path produces a staff super-admin so super-admin login works.

Self-contained, mirroring the in-memory SQLite + dependency-override style.
"""
from __future__ import annotations

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.api.v1 import dependencies as deps
from app.core.database import Base, get_db
from app.core.security import create_access_token, get_password_hash
from app.main import app
from app.models.seller import Seller
from app.models.shop import Shop
from app.models.subscription import Subscription, SubscriptionPlan, SubscriptionStatus
from scripts import backfill_roles


ENGINE = create_engine(
    "sqlite://",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=ENGINE)


@pytest.fixture()
def db_session():
    Base.metadata.create_all(bind=ENGINE)
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()
        Base.metadata.drop_all(bind=ENGINE)


@pytest.fixture()
def client(db_session):
    def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


def _make_seller(db_session, *, email, verified=True, staff=False, super_admin=False):
    seller = Seller(
        email=email,
        name=email.split("@")[0],
        phone="0170000000" + str(db_session.query(Seller).count() + 1),
        password_hash=get_password_hash("password123"),
        is_active=True,
        is_verified=verified,
        is_staff=staff,
        is_super_admin=super_admin,
    )
    db_session.add(seller)
    db_session.commit()
    db_session.refresh(seller)
    return seller


def _auth(seller: Seller) -> dict:
    token = create_access_token(subject=str(seller.id))
    return {"Authorization": f"Bearer {token}"}


# ---------------------------------------------------------------------------
# 8.3.1 — Admin gate on is_staff
# ---------------------------------------------------------------------------


def test_verified_non_staff_seller_gets_403(client, db_session):
    seller = _make_seller(db_session, email="verified@shopibd.com", verified=True, staff=False)
    resp = client.get("/api/v1/admin/sellers", headers=_auth(seller))
    assert resp.status_code == 403


def test_staff_seller_allowed_through_admin_gate(client, db_session):
    seller = _make_seller(
        db_session, email="staff@shopibd.com", verified=True, staff=True
    )
    resp = client.get("/api/v1/admin/sellers", headers=_auth(seller))
    assert resp.status_code == 200


def test_unverified_non_staff_seller_gets_403(client, db_session):
    seller = _make_seller(
        db_session, email="unverified@shopibd.com", verified=False, staff=False
    )
    resp = client.get("/api/v1/admin/sellers", headers=_auth(seller))
    assert resp.status_code == 403


def test_inactive_seller_blocked_before_admin_gate(client, db_session):
    seller = _make_seller(
        db_session, email="inactive@shopibd.com", verified=True, staff=True
    )
    seller.is_active = False
    db_session.commit()
    resp = client.get("/api/v1/admin/sellers", headers=_auth(seller))
    assert resp.status_code == 403


# ---------------------------------------------------------------------------
# 8.3.2 — Backfill script + seed semantics
# ---------------------------------------------------------------------------


def test_backfill_promotes_super_admins_to_staff(db_session, monkeypatch):
    monkeypatch.setattr(backfill_roles, "SessionLocal", TestingSessionLocal)
    # Two super-admins, one verified non-staff seller.
    sa1 = _make_seller(
        db_session, email="sa1@shopibd.com", verified=True, staff=False, super_admin=True
    )
    sa2 = _make_seller(
        db_session, email="sa2@shopibd.com", verified=True, staff=False, super_admin=True
    )
    client = _make_seller(
        db_session, email="plain@shopibd.com", verified=True, staff=False, super_admin=False
    )
    assert sa1.is_staff is False and sa2.is_staff is False

    updated = backfill_roles.backfill_roles()
    db_session.refresh(sa1)
    db_session.refresh(sa2)
    db_session.refresh(client)

    assert updated == 2
    assert sa1.is_staff is True
    assert sa2.is_staff is True
    # Non-super-admin seller is untouched.
    assert client.is_staff is False


def test_backfill_is_idempotent(db_session, monkeypatch):
    monkeypatch.setattr(backfill_roles, "SessionLocal", TestingSessionLocal)
    sa = _make_seller(
        db_session, email="sa@shopibd.com", verified=True, staff=False, super_admin=True
    )
    first = backfill_roles.backfill_roles()
    db_session.refresh(sa)
    assert sa.is_staff is True
    # Second run updates 0 rows (already staff).
    second = backfill_roles.backfill_roles()
    assert second == 0
    assert first == 1


def test_seed_super_admin_is_staff(db_session, monkeypatch):
    """The seed constant path yields a staff super-admin so admin login works."""
    from scripts import seed as seed_module

    # Seed writes through its own SessionLocal; bind it to the test engine.
    monkeypatch.setattr(seed_module, "SessionLocal", TestingSessionLocal)
    seed_module.seed_database()
    seller = db_session.query(Seller).filter_by(
        email=seed_module.SELLER_EMAIL
    ).scalar_one_or_none()
    assert seller is not None
    assert seller.is_super_admin is True
    assert seller.is_staff is True
