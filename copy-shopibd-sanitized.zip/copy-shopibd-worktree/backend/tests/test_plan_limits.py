"""
Tests for plan-limit enforcement (B2).

Self-contained (no shared conftest). Uses an in-memory SQLite DB and integer
seller IDs matching the real Seller model. Verifies that product/order creation
and CSV import return 402 Payment Required when a seller exceeds their plan
limit.

The enforcement reads the seller's *plan* limits from ``PLANS`` (not the
seller's ``max_products``/``max_orders`` columns, which are kept in sync with
the plan). To exercise the limit without seeding hundreds of rows, these tests
temporarily lower the Free plan's limits.

Run from backend/:  python -m pytest tests/test_plan_limits.py -q
"""

from __future__ import annotations

import io
from datetime import datetime, timezone

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool

from app.core.database import Base, get_db
from app.core.security import create_access_token, get_password_hash
from app.models.seller import Seller
from app.models.shop import Shop
from app.models.product import Product
from app.models.subscription import Subscription, SubscriptionPlan, SubscriptionStatus
from app.schemas.subscription import PLANS
from app.main import app


# In-memory SQLite — isolated per test session
ENGINE = create_engine(
    "sqlite://",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=ENGINE)


@pytest.fixture()
def db_session():
    Base.metadata.create_all(bind=ENGINE)
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()
        Base.metadata.drop_all(bind=ENGINE)


@pytest.fixture()
def client(db_session: Session):
    def _override():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_db] = _override
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


@pytest.fixture(autouse=True)
def low_free_limits():
    """Temporarily lower the Free plan limits so the 402 path is reachable."""
    plan = PLANS["free"]
    original_products = plan.max_products
    original_orders = plan.max_orders
    plan.max_products = 1
    plan.max_orders = 0
    yield
    plan.max_products = original_products
    plan.max_orders = original_orders


def _make_seller(db: Session, email: str) -> tuple[Seller, Shop]:
    seller = Seller(
        name="Test Seller",
        email=email,
        phone=f"+88017{abs(hash(email)) % 100000000:08d}",
        password_hash=get_password_hash("password123"),
        is_active=True,
        is_verified=True,
        plan="free",
        max_products=1,
        max_orders=0,
    )
    db.add(seller)
    db.flush()
    shop = Shop(name="Test Shop", slug="test-shop", seller_id=seller.id, is_active=True)
    db.add(shop)
    db.flush()
    subscription = Subscription(
        seller_id=seller.id,
        plan=SubscriptionPlan.FREE,
        status=SubscriptionStatus.ACTIVE,
        current_period_start=datetime.now(timezone.utc),
    )
    db.add(subscription)
    db.commit()
    return seller, shop


def _auth(seller_id: int) -> dict:
    token = create_access_token(subject=str(seller_id))
    return {"Authorization": f"Bearer {token}"}


class TestPlanLimitEnforcement:
    def test_product_limit_returns_402(self, client, db_session):
        seller, shop = _make_seller(db_session, "limit-prod@test.com")
        headers = _auth(seller.id)

        # First product allowed (within limit of 1)
        r1 = client.post(
            "/api/v1/products/",
            headers=headers,
            params={"shop_id": shop.id},
            json={"name": "P1", "price": 10, "stock": 1},
        )
        assert r1.status_code == 201, r1.text

        # Second product exceeds max_products=1 -> 402
        r2 = client.post(
            "/api/v1/products/",
            headers=headers,
            params={"shop_id": shop.id},
            json={"name": "P2", "price": 10, "stock": 1},
        )
        assert r2.status_code == 402, r2.text
        assert r2.json()["detail"]["error"] == "plan_limit_exceeded"

    def test_order_limit_returns_402(self, client, db_session):
        seller, shop = _make_seller(db_session, "limit-order@test.com")
        headers = _auth(seller.id)

        payload = {
            "buyer_name": "Buyer",
            "buyer_phone": "+8801700000000",
            "buyer_address": {
                "division": "Dhaka",
                "district": "Dhaka",
                "area": "Gulshan",
                "details": "123 Test Road",
            },
            # product_id 0 won't exist, but order-limit check runs first (402)
            "product_id": 0,
            "quantity": 1,
        }
        r = client.post(f"/api/v1/shops/{shop.slug}/orders", headers=headers, json=payload)
        assert r.status_code == 402, r.text
        assert r.json()["detail"]["error"] == "plan_limit_exceeded"

    def test_csv_import_limit_returns_402(self, client, db_session):
        seller, shop = _make_seller(db_session, "limit-csv@test.com")
        headers = _auth(seller.id)

        # One product already exists (within the limit of 1), so importing
        # two more rows exceeds max_products=1 -> 402.
        client.post(
            "/api/v1/products/",
            headers=headers,
            params={"shop_id": shop.id},
            json={"name": "Existing", "price": 1, "stock": 1},
        )

        csv_content = "name,price,stock\nA,1,1\nB,2,2\n"
        r = client.post(
            "/api/v1/products/import",
            headers=headers,
            params={"shop_id": shop.id},
            files={"file": ("p.csv", io.BytesIO(csv_content.encode()), "text/csv")},
        )
        assert r.status_code == 402, r.text
        assert r.json()["detail"]["error"] == "plan_limit_exceeded"
