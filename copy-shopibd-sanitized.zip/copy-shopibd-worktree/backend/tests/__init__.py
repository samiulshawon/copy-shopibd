"""
Test suite for ShopiBD backend.
"""
