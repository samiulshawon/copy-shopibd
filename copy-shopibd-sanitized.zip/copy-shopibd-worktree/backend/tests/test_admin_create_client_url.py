"""
Tests for Spec 1 Task 2 — plan-gated URL assignment on client (seller) creation.

When the super-admin creates a client via POST /api/v1/admin/sellers, the
endpoint must also auto-create a Shop with:
  - a unique slug,
  - an auto-provisioned (or requested) subdomain — all plans are entitled,
  - a custom domain ONLY when the plan allows it (Enterprise), else 402.

Self-contained (no shared conftest). Uses an in-memory SQLite DB and the
TestClient, mirroring tests/test_features_flow.py.
"""

from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

import pytest
from app.core.database import Base, get_db
from app.core.security import create_access_token, get_password_hash
from app.main import app
from app.api.v1 import dependencies as deps
from app.models.seller import Seller
from app.models.shop import Shop
from app.models.subscription import Subscription, SubscriptionPlan, SubscriptionStatus
from app.services.plan_capabilities import reserve_subdomain
from fastapi.testclient import TestClient


ENGINE = create_engine(
    "sqlite://",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=ENGINE)


@pytest.fixture()
def db_session():
    Base.metadata.create_all(bind=ENGINE)
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()
        Base.metadata.drop_all(bind=ENGINE)


@pytest.fixture()
def client(db_session):
    def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


def _make_super_admin(db_session):
    admin = Seller(
        email="admin@shopibd.com",
        name="Super Admin",
        phone="01700000000",
        password_hash=get_password_hash("password123"),
        is_verified=True,
        is_super_admin=True,
        plan="free",
        max_products=50,
        max_orders=200,
    )
    db_session.add(admin)
    db_session.commit()
    return admin


@pytest.fixture()
def super_admin_client(client, db_session):
    admin = _make_super_admin(db_session)

    def override_super_admin():
        return admin

    app.dependency_overrides[deps.get_current_super_admin] = override_super_admin
    client.headers.update({"Authorization": f"Bearer {create_access_token(subject=str(admin.id))}"})
    yield client
    app.dependency_overrides.pop(deps.get_current_super_admin, None)
    client.headers.clear()


def test_create_client_auto_subdomain(super_admin_client, db_session):
    from app.services.plan_capabilities import can_use_subdomain

    payload = {
        "name": "Client A",
        "email": "clienta@example.com",
        "phone": "01711112222",
        "password": "password123",
        "shop_name": "Client A Store",
    }
    resp = super_admin_client.post("/api/v1/admin/sellers", json=payload)
    assert resp.status_code == 201, resp.text

    seller = db_session.query(Seller).filter(Seller.email == payload["email"]).one()
    shop = db_session.query(Shop).filter(Shop.seller_id == seller.id).one()

    assert shop.subdomain is not None
    assert shop.subdomain == "client-a-store"
    assert shop.slug == "client-a-store"
    assert shop.is_active is True

    # Plan-gated: every plan is entitled to a subdomain; free must be True.
    assert can_use_subdomain(seller.plan) is True


def test_create_client_custom_domain_requires_enterprise(super_admin_client, db_session):
    payload = {
        "name": "Client B",
        "email": "clientb@example.com",
        "phone": "01711113333",
        "password": "password123",
        "custom_domain": "clientb.com",
    }
    resp = super_admin_client.post("/api/v1/admin/sellers", json=payload)
    assert resp.status_code == 402, resp.text
    assert "Enterprise" in resp.text


def test_reserve_subdomain_collision(db_session):
    db_session.add(Shop(name="S1", slug="s1", seller_id=1, subdomain="client-a", is_active=True))
    db_session.add(Shop(name="S2", slug="s2", seller_id=2, subdomain="client-a-1", is_active=True))
    db_session.commit()

    result = reserve_subdomain(db_session, "client a")
    assert result == "client-a-2"

    # Actualize the reservation and verify the next collision jumps to -3.
    db_session.add(Shop(name="S3", slug="s3", seller_id=3, subdomain=result, is_active=True))
    db_session.commit()
    assert reserve_subdomain(db_session, "client a") == "client-a-3"
