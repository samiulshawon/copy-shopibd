"""
Tests for plan capability helpers (Spec 1, Task 1).

Verifies that URL entitlements are derived correctly from the in-memory plan
catalog: subdomains are granted to every tier while custom domains are gated to
the enterprise tier only. No DB needed — PLANS is in-memory.
"""

from __future__ import annotations

from app.schemas.subscription import PLANS
from app.services.plan_capabilities import (
    can_use_custom_domain,
    can_use_subdomain,
)

FREE_TIERS = ("free", "starter", "business")


def test_free_tiers_use_subdomain_but_not_custom_domain():
    for plan in FREE_TIERS:
        assert can_use_subdomain(plan) is True
        assert can_use_custom_domain(plan) is False


def test_enterprise_uses_both_subdomain_and_custom_domain():
    assert can_use_subdomain("enterprise") is True
    assert can_use_custom_domain("enterprise") is True


def test_plan_info_allow_subdomain_true_for_all():
    for plan in PLANS.values():
        assert plan.allow_subdomain is True


def test_plan_info_allow_custom_domain_only_for_enterprise():
    for plan_id, plan in PLANS.items():
        expected = plan_id == "enterprise"
        assert plan.allow_custom_domain is expected
