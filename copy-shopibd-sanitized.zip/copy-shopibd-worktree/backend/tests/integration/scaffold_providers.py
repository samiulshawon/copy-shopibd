"""
Phase 10.1 — Payment provider sandbox test scaffolding (integration tests).

This module is the shared harness for the *integration* tests in Task 10.4.
It centralises the sandbox-mode decision and credential checks so the
integration tests can be written once and skipped automatically when the
required provider credentials are absent (CI default).

Real money is never moved: every provider operates in sandbox mode unless
``APP_ENV=production`` AND the provider sandbox flag is explicitly False.

Usage in 10.4 tests::

    from tests.integration.scaffold_providers import bkash_sandbox

    bkash_sandbox  # pytest fixture-like skip guard; raises Skip if no creds
"""
from __future__ import annotations

import pytest

from app.core.config import settings


def _has_creds(*fields: str) -> bool:
    return all(getattr(settings, f, "") for f in fields)


def _sandbox_active(flag: str) -> bool:
    # Sandbox is on unless we're in production AND the flag is explicitly off.
    in_prod = getattr(settings, "APP_ENV", "development") == "production"
    return not (in_prod and not getattr(settings, flag, True))


# --- bKash -----------------------------------------------------------------


def bkash_credentials_present() -> bool:
    return _has_creds(
        "BKASH_APP_KEY", "BKASH_APP_SECRET", "BKASH_USERNAME", "BKASH_PASSWORD"
    )


bkash_sandbox = pytest.mark.skipif(
    not bkash_credentials_present(),
    reason="bKash sandbox credentials not configured (set BKASH_* env)",
)

# --- Nagad -----------------------------------------------------------------


def nagad_credentials_present() -> bool:
    return _has_creds(
        "NAGAD_MERCHANT_ID", "NAGAD_MERCHANT_NUMBER", "NAGAD_PUB_KEY", "NAGAD_PRIVATE_KEY"
    )


nagad_sandbox = pytest.mark.skipif(
    not nagad_credentials_present(),
    reason="Nagad sandbox credentials not configured (set NAGAD_* env)",
)

# --- SSLCommerz ------------------------------------------------------------


def sslcommerz_credentials_present() -> bool:
    return _has_creds("SSLCOMMERZ_STORE_ID", "SSLCOMMERZ_STORE_PASSWORD")


sslcommerz_sandbox = pytest.mark.skipif(
    not sslcommerz_credentials_present(),
    reason="SSLCommerz sandbox credentials not configured (set SSLCOMMERZ_* env)",
)


def sandbox_mode_for(provider: str) -> bool:
    """Return whether *provider* ('bkash'|'nagad'|'sslcommerz') is in sandbox."""
    flag = {
        "bkash": "BKASH_SANDBOX",
        "nagad": "NAGAD_SANDBOX",
        "sslcommerz": "SSLCOMMERZ_SANDBOX",
    }[provider]
    return _sandbox_active(flag)
