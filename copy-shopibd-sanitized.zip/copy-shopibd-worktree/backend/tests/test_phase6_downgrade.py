"""
Tests for Phase 6 — Subscription Downgrade: events, grace period, recovery.

Three spec'd behaviours (tasks 6.4.1-6.4.3):

* 6.4.1  Enterprise->Business downgrade emits ``subscription.downgraded``
         and writes a ``custom_domain_grace_until`` timestamp on the shop.
* 6.4.2  While within grace, the customer's custom domain still routes
         (middleware honours the grace window); the admin sees the warning
         fields on the seller record.
* 6.4.3  Upgrading back within grace restores full capability (no data
         loss, domain stays active).

Self-contained, mirroring the in-memory SQLite + dependency-override style
of the other phase tests. Event emission is asserted via the
``event_outbox`` row written by ``publish`` (durable outbox).
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.api.v1 import dependencies as deps
from app.core.database import Base, get_db
from app.core.security import create_access_token, get_password_hash
from app.main import app
from app.models.seller import Seller
from app.models.shop import Shop
from app.models.subscription import Subscription, SubscriptionPlan, SubscriptionStatus
from app.services.events import EventOutbox
from app.services.subscription_tasks import (
    DOWNGRADE_GRACE_DAYS,
    PLAN_RANK,
    record_downgrade,
)

ENGINE = create_engine(
    "sqlite://",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=ENGINE)


@pytest.fixture()
def db_session():
    Base.metadata.create_all(bind=ENGINE)
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()
        Base.metadata.drop_all(bind=ENGINE)


@pytest.fixture()
def client(db_session):
    def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


def _super_admin(db_session):
    admin = Seller(
        email="admin6@example.com",
        name="Admin",
        phone="01700000002",
        password_hash=get_password_hash("password123"),
        is_active=True,
        is_verified=True,
        is_super_admin=True,
        is_staff=True,  # Phase 8: admin routes gate on is_staff
        plan="free",
    )
    db_session.add(admin)
    db_session.commit()
    db_session.refresh(admin)
    return admin


def _make_enterprise_seller(db_session, *, custom_domain="clientb.com"):
    seller = Seller(
        email="enterprise@example.com",
        name="Enterprise Co",
        phone="01700000001",
        password_hash=get_password_hash("password123"),
        is_active=True,
        is_verified=True,
        plan="enterprise",
    )
    db_session.add(seller)
    db_session.flush()
    db_session.add(
        Subscription(
            seller_id=seller.id,
            plan=SubscriptionPlan.ENTERPRISE,
            status=SubscriptionStatus.ACTIVE,
        )
    )
    db_session.add(
        Shop(
            name="Enterprise",
            slug="enterprise",
            subdomain="enterprise",
            custom_domain=custom_domain,
            seller_id=seller.id,
            is_active=True,
        )
    )
    db_session.commit()
    db_session.refresh(seller)
    return seller


def _auth_headers(admin: Seller) -> dict:
    token = create_access_token(subject=str(admin.id))
    return {"Authorization": f"Bearer {token}"}


# ---------------------------------------------------------------------------
# 6.4.1 — Downgrade emits event + grace timestamp
# ---------------------------------------------------------------------------


def test_enterprise_to_business_emits_event_and_grace(db_session):
    seller = _make_enterprise_seller(db_session)

    record_downgrade(db_session, seller, "enterprise", "business", reason="test")

    # Event published to the durable outbox.
    event = db_session.query(EventOutbox).filter_by(
        event_type="subscription.downgraded"
    ).first()
    assert event is not None
    payload = __import__("json").loads(event.payload)
    assert payload["old_plan"] == "enterprise"
    assert payload["new_plan"] == "business"
    assert payload["lost_custom_domain"] is True
    assert payload["grace_until"] is not None

    # Shop grace timestamp stamped ~7 days out.
    shop = db_session.query(Shop).filter_by(seller_id=seller.id).first()
    assert shop.custom_domain_grace_until is not None
    delta = shop.custom_domain_grace_until - datetime.now(timezone.utc).replace(tzinfo=None)
    assert timedelta(days=6) <= delta <= timedelta(days=8)


def test_upgrade_or_same_plan_does_not_emit_event(db_session):
    seller = _make_enterprise_seller(db_session)
    record_downgrade(db_session, seller, "enterprise", "enterprise", reason="noop")
    assert db_session.query(EventOutbox).count() == 0


def test_plan_rank_detects_downgrade():
    assert PLAN_RANK["business"] < PLAN_RANK["enterprise"]
    assert PLAN_RANK["free"] < PLAN_RANK["business"]


# ---------------------------------------------------------------------------
# 6.4.2 — Within grace, custom domain still routes; admin sees warning
# ---------------------------------------------------------------------------


def test_admin_sees_grace_warning_fields(client, db_session):
    admin = _super_admin(db_session)
    seller = _make_enterprise_seller(db_session)
    record_downgrade(db_session, seller, "enterprise", "business", reason="test")

    resp = client.get(f"/api/v1/admin/sellers/{seller.id}", headers=_auth_headers(admin))
    assert resp.status_code == 200
    body = resp.json()
    assert body["shop_custom_domain"] == "clientb.com"
    assert body["custom_domain_grace_until"] is not None


def test_grace_window_blocks_routing_after_expiry(db_session):
    """Once the grace window passes, the custom domain is no longer in grace."""
    seller = _make_enterprise_seller(db_session)
    shop = db_session.query(Shop).filter_by(seller_id=seller.id).first()
    shop.custom_domain_grace_until = datetime.now(timezone.utc).replace(
        tzinfo=None
    ) - timedelta(days=1)
    db_session.commit()

    grace_until = shop.custom_domain_grace_until
    in_grace = grace_until is not None and datetime.utcnow() < grace_until
    assert in_grace is False


def test_grace_window_allows_routing_within_period(db_session):
    seller = _make_enterprise_seller(db_session)
    shop = db_session.query(Shop).filter_by(seller_id=seller.id).first()
    shop.custom_domain_grace_until = datetime.now(timezone.utc).replace(
        tzinfo=None
    ) + timedelta(days=3)
    db_session.commit()

    grace_until = shop.custom_domain_grace_until
    in_grace = grace_until is not None and datetime.utcnow() < grace_until
    assert in_grace is True


# ---------------------------------------------------------------------------
# 6.4.3 — Upgrade back within grace restores fully
# ---------------------------------------------------------------------------


def test_upgrade_within_grace_restores_capability(db_session):
    seller = _make_enterprise_seller(db_session)
    # Downgrade first (stamps grace).
    record_downgrade(db_session, seller, "enterprise", "business", reason="test")
    shop = db_session.query(Shop).filter_by(seller_id=seller.id).first()
    assert shop.custom_domain_grace_until is not None

    # Upgrade back to enterprise within grace — no data loss, domain stays.
    seller.plan = "enterprise"
    subscription = db_session.query(Subscription).filter_by(
        seller_id=seller.id
    ).first()
    subscription.plan = SubscriptionPlan.ENTERPRISE
    db_session.commit()

    assert shop.custom_domain == "clientb.com"
    assert shop.is_active is True
    assert shop.custom_domain_grace_until is not None
