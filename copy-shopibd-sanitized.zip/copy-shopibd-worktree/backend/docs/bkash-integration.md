# bKash Merchant API Integration

## Overview

bKash provides a **Tokenized Checkout** API for merchants to accept payments via bKash mobile wallet. The API follows a 3-step flow:

1. **Grant Token** – Obtain an access token using app credentials.
2. **Create Payment** – Create a payment intent with amount, invoice number, and callback URL.
3. **Execute Payment** – Confirm/execute the payment after the buyer approves it on the bKash app.

---

## API Endpoints (Tokenized Checkout v1.2.0-beta)

| Environment | Base URL |
|---|---|
| **Sandbox** | `https://tokenized.sandbox.bka.sh/v1.2.0-beta` |
| **Production** | `https://tokenized.pay.bka.sh/v1.2.0-beta` |

### Authentication

**Grant Token** – `POST /tokenized/checkout/token/grant`

Request:
```json
{
  "app_key": "<APP_KEY>",
  "app_secret": "<APP_SECRET>"
}
```

Response:
```json
{
  "id_token": "<JWT_TOKEN>",
  "token_type": "Bearer",
  "expires_in": 3600
}
```

**Refresh Token** – `POST /tokenized/checkout/token/refresh`

Request:
```json
{
  "app_key": "<APP_KEY>",
  "app_secret": "<APP_SECRET>",
  "refresh_token": "<REFRESH_TOKEN>"
}
```

### Payment Creation

**Create Payment** – `POST /tokenized/checkout/create`

Headers:
- `Authorization: Bearer <id_token>`
- `X-APP-Key: <APP_KEY>`

Request:
```json
{
  "mode": "0011",
  "payerReference": "01",
  "callbackURL": "https://your-domain.com/api/v1/payment-webhook/bkash",
  "amount": "100.00",
  "currency": "BDT",
  "intent": "sale",
  "merchantInvoiceNumber": "SB-2026-000001"
}
```

Response:
```json
{
  "statusCode": "0000",
  "statusMessage": "Successful",
  "paymentID": "TR0011H3Dp123456",
  "bkashURL": "https://sandbox.bka.sh/checkout?paymentID=TR0011H3Dp123456",
  "callbackURL": "https://your-domain.com/api/v1/payment-webhook/bkash",
  "successCallbackURL": "",
  "failureCallbackURL": "",
  "cancelCallbackURL": "",
  "amount": "100.00",
  "currency": "BDT",
  "intent": "sale",
  "merchantInvoiceNumber": "SB-2026-000001"
}
```

### Execute Payment

**Execute Payment** – `POST /tokenized/checkout/execute`

Headers:
- `Authorization: Bearer <id_token>`
- `X-APP-Key: <APP_KEY>`

Request:
```json
{
  "paymentID": "TR0011H3Dp123456"
}
```

Response (Success):
```json
{
  "statusCode": "0000",
  "statusMessage": "Successful",
  "paymentID": "TR0011H3Dp123456",
  "trxID": "ABC123DEF",
  "transactionStatus": "Completed",
  "amount": "100.00",
  "currency": "BDT",
  "merchantInvoiceNumber": "SB-2026-000001",
  "customerMsisdn": "01712345678"
}
```

### Query Payment

**Query Payment** – `POST /tokenized/checkout/status`

Headers:
- `Authorization: Bearer <id_token>`
- `X-APP-Key: <APP_KEY>`

Request:
```json
{
  "paymentID": "TR0011H3Dp123456"
}
```

---

## Sandbox Credentials

| Credential | Value (Sandbox) |
|---|---|
| App Key | `4f6o0cjiki2rfm34kfdadl1eqq` |
| App Secret | `2is7hdktrekvrbljjh44ll3d9l1dtjo4p1j0a0k0d0h0c0a0b0c0d0e0f0g0h0i0j0k0l0m0n0o0p` |
| Username | `01711111111` |
| Password | `n.a.` (not used in tokenized flow) |

> **Note**: The sandbox credentials above are the official bKash test credentials.  
> All amounts in sandbox are automatically approved (any payment succeeds).

### Test Wallet (OTP)
- **Number**: `01711111111` (or the username used)
- **OTP**: `123456` (always works in sandbox)

---

## Webhook / Callback URL Format

bKash calls back to the `callbackURL` provided during payment creation with the following query parameters:

```
GET {callbackURL}?paymentID=TR0011H3Dp123456&status=success
```

Or in some flows, bKash sends a POST with JSON body containing `paymentID` and `status`.

### Expected Callback Parameters

| Parameter | Type | Description |
|---|---|---|
| `paymentID` | string | bKash payment ID |
| `status` | string | `success`, `failure`, or `cancel` |
| `trxID` | string | (optional) Transaction ID on success |

The webhook handler must:
1. Receive the callback
2. Call **Execute Payment** to confirm
3. Update the order as paid
4. Return HTTP 200 to bKash

---

## Required Fields for Payment Creation

| Field | Type | Required | Description |
|---|---|---|---|
| `mode` | string | Yes | `0011` for tokenized checkout |
| `payerReference` | string | Yes | Reference for payer (`01` or phone) |
| `callbackURL` | string | Yes | HTTPS URL for post-payment callback |
| `amount` | string | Yes | Amount in BDT (2 decimal places) |
| `currency` | string | Yes | `BDT` |
| `intent` | string | Yes | `sale` |
| `merchantInvoiceNumber` | string | Yes | Unique invoice/order number |
| `merchantAssociationInfo` | string | No | Optional merchant info |

---

## Approval Process Requirements

To use bKash Merchant API in production, merchants must submit:

1. **Trade License** (Trademark/Shop registration certificate)
2. **TIN Certificate** (Taxpayer Identification Number)
3. **Bank Account Details** (Bank name, branch, account number)
4. **NID** (National ID of business owner)
5. **Profile Photo** (Owner's passport-size photo)
6. **Business Address Proof** (Utility bill or rent agreement)
7. **Email & Phone** (Active contact details)

### Process
1. Register at https://merchant.bka.sh
2. Submit documents for verification
3. Receive app key and secret after approval
4. Go live after sandbox testing

---

## Error Codes

| Status Code | Meaning |
|---|---|
| `0000` | Success |
| `2001` | Invalid app key/secret |
| `2002` | Token expired |
| `2003` | Invalid payment ID |
| `2004` | Insufficient balance (simulated in sandbox) |
| `2005` | Payment already completed |
| `2006` | Invalid amount |
| `4001` | Authentication failed |
| `4002` | Invalid request |
| `5000` | System error |

---

## Reference

- [bKash Tokenized Checkout API Documentation (Sandbox)](https://developer.bka.sh/apis/tokenized-checkout)
- [bKash Merchant Portal](https://merchant.bka.sh)
- [Sandbox Login](https://merchant.sandbox.bka.sh)
