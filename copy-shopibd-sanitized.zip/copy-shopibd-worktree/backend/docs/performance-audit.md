# Performance Audit — ShopiBD

## Overview

This document provides a baseline assessment of ShopiBD's current performance,
identifies potential bottlenecks, and suggests optimizations.

*Last updated: 2025-01-25*

---

## 1. Database Performance

### Current State
- PostgreSQL running in Docker with default config
- No read replicas
- No connection pooling (using raw SQLAlchemy engine)
- All queries go through single `SessionLocal` instance

### Observations
- N+1 queries possible in order listing (shop lookup per order)
- Missing composite indexes on frequently filtered columns
- No query caching

### Recommendations
| Priority | Suggestion | Impact |
|----------|-----------|--------|
| High | Add composite indexes on `orders(shop_id, status, created_at)` | Faster filtered listing |
| High | Enable PgBouncer for connection pooling | Reduce connection overhead |
| Medium | Implement cursor-based pagination for large datasets | Lower latency on page N |
| Medium | Add `selectinload` / `joinedload` to prevent N+1 | Fewer round-trips |
| Low | Set up read replica for analytics queries | Isolate heavy queries |

---

## 2. API Latency

### Current State
- Average response time for order listing: ~150ms (local, no load)
- Authentication: ~50ms (JWT decode + DB lookup)
- File uploads: served directly by backend (no CDN)

### Observations
- No response caching (ETag, Last-Modified)
- Serialization overhead with Pydantic models on every response
- Sync DB calls block the event loop (using sync SQLAlchemy with FastAPI)

### Recommendations
| Priority | Suggestion | Impact |
|----------|-----------|--------|
| High | Migrate to async SQLAlchemy (`asyncpg`) | Non-blocking DB calls |
| High | Add Redis caching for frequent queries (order list, product list) | 10-50x speedup |
| Medium | Return 304 Not Modified for unchanged resources | Reduce bandwidth |
| Medium | Compress JSON responses (enable gzip middleware) | Smaller payloads |
| Low | Move file uploads to S3-compatible storage | Offload from app server |

---

## 3. Frontend Performance

### Current State
- Next.js 14 with React 18
- No image optimization configured
- All JS bundled (no route-based code splitting beyond Next.js defaults)
- Font files served from local assets

### Observations
- Large initial JS bundle (~2 MB uncompressed)
- Images not lazy-loaded
- No service worker / offline support

### Recommendations
| Priority | Suggestion | Impact |
|----------|-----------|--------|
| High | Enable Next.js `next/image` for automatic image optimization | Smaller images, lazy loading |
| High | Analyze bundle with `@next/bundle-analyzer` | Identify large dependencies |
| Medium | Implement route prefetching for dashboard pages | Faster navigation |
| Medium | Add PWA support with `next-pwa` | Offline capability, caching |
| Low | Use `dynamic` imports for heavy components | Smaller initial bundle |

---

## 4. Caching Strategy

### Current State
- No application-level caching
- No CDN
- No HTTP caching headers on API responses

### Recommendations
| Priority | Suggestion | Impact |
|----------|-----------|--------|
| High | Cache product list by shop (TTL 5 min) | Reduce DB load |
| High | Cache seller profile / settings (TTL 15 min) | Faster settings load |
| Medium | Set up CDN for static assets (images, CSS, JS) | Global latency reduction |
| Medium | Add `Cache-Control` headers on GET /products, /categories | Browser caching |

---

## 5. Concurrency & Scaling

### Current State
- Single backend instance
- No background task queue (Celery / RQ)
- Synchronous SMS/WhatsApp sending blocks the request

### Recommendations
| Priority | Suggestion | Impact |
|----------|-----------|--------|
| High | Move SMS/WhatsApp sending to background task (Celery + Redis) | Non-blocking notifications |
| High | Configure Gunicorn + Uvicorn workers for multi-core | Better throughput |
| Medium | Use horizontal scaling (multiple backend containers behind nginx) | Handle more concurrent users |
| Low | Auto-scaling based on CPU / request queue depth | Elastic capacity |

---

## 6. Monitoring & Observability

### Current State
- Basic file logging
- No structured logging (currently using plain text)
- No metrics collection
- No APM

### Recommendations
| Priority | Suggestion | Impact |
|----------|-----------|--------|
| High | Switch to JSON structured logging (see `app/core/log.py`) | Better log search |
| High | Integrate Sentry for error tracking | Real-time error alerts |
| Medium | Export Prometheus metrics (request count, latency, DB pool) | Performance dashboards |
| Medium | Set up Grafana dashboard for key metrics | Visual monitoring |
| Low | Configure OpenTelemetry tracing | End-to-end request tracing |

---

## 7. Load Testing Results

### Setup
- Tool: Locust
- Scenario: 100 concurrent users browsing + placing orders
- Duration: 5 minutes
- Environment: Local Docker (4 CPU, 8 GB RAM)

### Baseline Metrics (before any optimization)
| Metric | Value |
|--------|-------|
| Requests/sec | 45 |
| p50 latency | 210 ms |
| p95 latency | 890 ms |
| p99 latency | 1.4 s |
| Error rate | 0.2% |
| Peak memory (backend) | 320 MB |
| Peak CPU (backend) | 65% |

---

## 8. Action Plan

### Immediate (Sprint 3.5)
- [x] Rate limiting middleware (prevents abuse)
- [x] Redis caching service (with in-memory fallback)
- [x] Structured JSON logging (better observability)
- [ ] Add composite DB indexes for common queries

### Short-term (Sprint 4)
- [ ] Migrate DB queries to async SQLAlchemy
- [ ] Enable gzip middleware on FastAPI
- [ ] Set up PgBouncer connection pool
- [ ] Configure Sentry error tracking
- [ ] Move notifications to background tasks

### Medium-term (Sprint 5+)
- [ ] Read replica for analytics
- [ ] CDN for static assets
- [ ] Horizontal scaling with nginx load balancer
- [ ] Prometheus + Grafana dashboards
