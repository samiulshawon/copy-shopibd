# Payment Gateway Sandbox Testing Guide

## Prerequisites

1. **Python 3.11+** with dependencies installed:
   ```bash
   cd shopibd/backend
   pip install -r requirements.txt
   pip install httpx  # For bkash/nagad API calls
   ```

2. **Environment Configuration** – Copy `.env.local.example` to `.env.local` and fill in credentials.

---

## 1. Configuration

### `.env.local` settings

```ini
# --- Payment Provider ---
# Options: manual (default), bkash, nagad
PAYMENT_PROVIDER=manual

# --- bKash Sandbox Credentials ---
BKASH_APP_KEY=4f6o0cjiki2rfm34kfdadl1eqq
BKASH_APP_SECRET=2is7hdktrekvrbljjh44ll3d9l1dtjo4p1j0a0k0d0h0c0a0b0c0d0e0f0g0h0i0j0k0l0m0n0o0p
BKASH_USERNAME=01711111111
BKASH_PASSWORD=
BKASH_BASE_URL=https://tokenized.sandbox.bka.sh/v1.2.0-beta

# --- Nagad Sandbox Credentials ---
NAGAD_MERCHANT_ID=your_merchant_id
NAGAD_PRIVATE_KEY=your_private_key_here
NAGAD_PUB_KEY=nagad_public_key_here
NAGAD_BASE_URL=https://sandbox.mynagad.com:10001

# --- API Base URL (for webhook callbacks) ---
API_BASE_URL=http://localhost:8000
```

> **bKash Sandbox**: The credentials above are the **official bKash test credentials**.
> All amounts are auto-approved in sandbox mode.

> **Nagad Sandbox**: Contact Nagad merchant support to obtain sandbox credentials.

---

## 2. Testing bKash Flow

### Step-by-step

1. **Set provider to bKash** in `.env.local`:
   ```ini
   PAYMENT_PROVIDER=bkash
   ```

2. **Start the backend**:
   ```bash
   cd shopibd/backend
   uvicorn app.main:app --reload --port 8000
   ```

3. **Test token grant** (verify credentials):
   ```bash
   curl -s -X POST http://localhost:8000/api/v1/payment-webhook/bkash/test-token
   ```
   Or use the Python test script:
   ```python
   from app.services.payment.bkash import BKashPaymentProvider
   import asyncio
   
   async def test():
       provider = BKashPaymentProvider()
       token = await provider._get_token()
       print(f"Token: {token[:50]}...")
   
   asyncio.run(test())
   ```

4. **Create a test payment**:
   ```python
   from app.services.payment.bkash import BKashPaymentProvider
   import asyncio
   
   async def test():
       provider = BKashPaymentProvider()
       result = await provider.create_payment(
           order_id="SB-2026-TEST-001",
           amount=100,  # ৳100
           callback_url="http://localhost:8000/api/v1/payment-webhook/bkash"
       )
       print(f"Payment URL: {result['payment_url']}")
       print(f"Payment ID: {result['paymentID']}")
   
   asyncio.run(test())
   ```

5. **Simulate callback** (in sandbox, payments auto-succeed):
   Open the `payment_url` in a browser. bKash sandbox will auto-approve and redirect to the callback URL.

6. **Verify webhook was received**:
   Check server logs for:
   ```
   bKash webhook received: {'paymentID': '...', 'status': 'success'}
   bKash payment ... processed successfully. trxID=...
   ```

### Automated Test Script

```python
"""
test_bkash_sandbox.py - Run this with the backend running and PAYMENT_PROVIDER=bkash.
"""
import asyncio
import json
import httpx

BASE = "http://localhost:8000/api/v1"

async def test_full_flow():
    # 1. Create a payment
    async with httpx.AsyncClient() as client:
        resp = await client.post(
            f"{BASE}/payment-webhook/bkash/test-create",
            json={
                "order_id": "TEST-SB-001",
                "amount": 500,
                "callback_url": f"{BASE}/payment-webhook/bkash"
            }
        )
        print("Create response:", resp.json())
        data = resp.json()
        payment_id = data.get("paymentID")
    
    if payment_id:
        # 2. Execute payment
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{BASE}/payment-webhook/bkash/test-execute",
                json={"paymentID": payment_id}
            )
            print("Execute response:", resp.json())

asyncio.run(test_full_flow())
```

---

## 3. Testing Nagad Flow

### Step-by-step

1. **Set provider to Nagad** in `.env.local`:
   ```ini
   PAYMENT_PROVIDER=nagad
   ```

2. **Start the backend** as above.

3. **Test payment creation**:
   ```python
   from app.services.payment.nagad import NagadPaymentProvider
   import asyncio
   
   async def test():
       provider = NagadPaymentProvider()
       result = await provider.create_payment(
           order_id="SB-2026-TEST-001",
           amount=100,
           callback_url="http://localhost:8000/api/v1/payment-webhook/nagad"
       )
       print(f"Payment URL: {result['payment_url']}")
   
   asyncio.run(test())
   ```

---

## 4. End-to-End Checkout Test

### Using the Web UI

1. Set `PAYMENT_PROVIDER=bkash` in `.env.local`
2. Start both backend and frontend:
   ```bash
   # Terminal 1
   cd shopibd/backend && uvicorn app.main:app --reload --port 8000
   
   # Terminal 2
   cd shopibd/frontend && npm run dev
   ```
3. Open a shop page (e.g., `http://localhost:3000/myshop`)
4. Select a product, fill in buyer details
5. Choose **bKash** or **Nagad** as payment method
6. Click **Place Order**
7. You should be redirected to the bKash/Nagad sandbox checkout page
8. After "payment", you'll be redirected back to the site

### Using curl

```bash
# Create order with bKash payment
curl -s -X POST http://localhost:8000/api/v1/shops/{slug}/orders \
  -H "Content-Type: application/json" \
  -d '{
    "buyer_name": "Test User",
    "buyer_phone": "+8801711111111",
    "buyer_address": {
      "division": "Dhaka",
      "district": "Dhaka",
      "area": "Mirpur",
      "details": "House 12, Road 5"
    },
    "product_id": 1,
    "quantity": 1,
    "payment_method": "bkash"
  }'
```

Expected response:
```json
{
  "order_number": "SB-2026-000001",
  "total_amount": 100.0,
  "payment_method": "bkash",
  "payment_url": "https://sandbox.bka.sh/checkout?paymentID=...",
  "paymentID": "TR0011H3Dp..."
}
```

---

## 5. Testing Webhook Handling

### bKash Webhook Test

```bash
# Simulate bKash callback
curl -s -X POST http://localhost:8000/api/v1/payment-webhook/bkash \
  -H "Content-Type: application/json" \
  -d '{
    "paymentID": "TR0011TEST123",
    "status": "success"
  }'
```

### Nagad Webhook Test

```bash
curl -s -X POST http://localhost:8000/api/v1/payment-webhook/nagad \
  -H "Content-Type: application/json" \
  -d '{
    "payment_ref_id": "NAGAD123TEST",
    "status": "success"
  }'
```

---

## 6. Troubleshooting

| Problem | Likely Cause | Solution |
|---|---|---|
| `bKash token grant failed` | Invalid APP_KEY/APP_SECRET | Use sandbox credentials from docs |
| `bKash create payment failed` | Token expired or wrong base URL | Check BKASH_BASE_URL ends with `v1.2.0-beta` |
| `Nagad create payment failed` | Invalid merchant ID or keys | Verify NAGAD_MERCHANT_ID, NAGAD_PRIVATE_KEY |
| `Order not found for invoice` | Webhook received before order commit | Check DB for order existence |
| `payment_url is None` | Provider not configured correctly | Set PAYMENT_PROVIDER=bkash or nagad in .env.local |
| Webhook returns 404 | Webhook router not registered | Check api/v1/__init__.py includes payment_webhook |

---

## 7. Payment Status Reference

| Status | Description |
|---|---|
| `pending` | Order created, awaiting payment |
| `paid` | Payment received and verified |
| `failed` | Payment failed or cancelled |
| `refunded` | Payment refunded |

Transaction statuses in `PaymentTransaction`:
| Status | Description |
|---|---|
| `pending` | Awaiting verification |
| `verified` | Payment matched and verified |
| `mismatched` | Amount mismatch with order |
| `unmatched` | No matching order found |
