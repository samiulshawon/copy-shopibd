# 🧪 ShopiBD — Complete Testing Guide

Welcome! This guide will walk you through testing **every part** of the ShopiBD application — from the buyer's storefront to the seller dashboard to the admin panel.

Everything is designed to run on your computer (localhost), so no internet connection is needed after setup.

---

## 📋 Table of Contents

1. [Prerequisites — What You Need First](#1-prerequisites--what-you-need-first)
2. [Starting Everything](#2-starting-everything)
3. [Testing the Buyer Experience (Storefront)](#3-testing-the-buyer-experience-storefront)
4. [Testing the Seller Dashboard](#4-testing-the-seller-dashboard)
5. [Testing Sprint 3 Features](#5-testing-sprint-3-features)
6. [Testing the Admin Panel](#6-testing-the-admin-panel)
7. [Troubleshooting — Common Problems & Fixes](#7-troubleshooting--common-problems--fixes)

---

## 1. Prerequisites — What You Need First

### ✅ 1.1 Docker Desktop

Docker runs the database (PostgreSQL) and Redis (caching) inside containers.

- [ ] **Step 1:** Download Docker Desktop from [docker.com](https://www.docker.com/products/docker-desktop/)
- [ ] **Step 2:** Install it (just click Next → Next → Finish)
- [ ] **Step 3:** After installation, open Docker Desktop from the Start Menu
- [ ] **Step 4:** Wait until you see a green "Running" status at the bottom-left corner

> **💡 Tip:** Docker takes 1–2 minutes to start. Wait for the green light before proceeding.

---

## 2. Starting Everything

### ⚡ Quick Start (One Command)

- [ ] **Step 1:** Press the **Windows key** on your keyboard
- [ ] **Step 2:** Type **PowerShell**
- [ ] **Step 3:** Right-click on **Windows PowerShell** and select **Run as Administrator**
- [ ] **Step 4:** Copy and paste this command into the PowerShell window, then press **Enter**:

```powershell
cd e:\SaaS test\shopibd
```

- [ ] **Step 5:** Now copy and paste this command and press **Enter**:

```powershell
.\start-dev.ps1
```

> ⚠️ If you get a security warning about running scripts, type this first and press Enter:
> ```powershell
> Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
> ```
> Then try `.\start-dev.ps1` again.

### What happens next (wait for all steps to complete):

| Step | Message You Should See | Time |
|------|----------------------|------|
| ✅ 1/5 | `Docker is running.` | Instant |
| ✅ 2/5 | `Starting PostgreSQL...` then `PostgreSQL ready` | ~10 seconds |
| ✅ 3/5 | `Cache cleared.` | Instant |
| ✅ 4/5 | `Backend starting on http://localhost:8080` | ~5 seconds |
| ✅ 5/5 | `Frontend starting on http://localhost:3001` | ~5 seconds |

When you see this screen below, everything is working:

```
========================================
  Ready!
  Frontend: http://localhost:3001
  Backend:  http://localhost:8080
  API Docs: http://localhost:8080/docs
========================================
```

### 🛑 To Stop Everything Later

When you're done testing, run:

```powershell
.\stop-dev.ps1
```

### 🟢 Alternative: Using the Batch file (simpler)

If PowerShell gives you trouble, double-click **`start-dev.bat`** in the `e:\SaaS test\shopibd` folder.

---

## 3. Testing the Buyer Experience (Storefront)

This is what a customer sees when they visit an online shop. We have a demo shop called **"Sawan's Shop"**.

### 3.1 Visit the Shop

- [ ] **Action:** Open your web browser (Chrome, Edge, or Firefox)
- [ ] **Action:** Type this address in the URL bar and press **Enter**:

```
http://localhost:3001/sawan-shop
```

- [ ] **Expected Result:** You should see:

| What to Look For | ✅ Check |
|-----------------|----------|
| Shop name: **"Sawan's Shop"** at the top | ☐ |
| Shop description: **"Best electronics, fashion & home products"** | ☐ |
| **6 products** displayed in a grid with images, names, and prices | ☐ |
| Prices shown in **BDT (৳)** currency format | ☐ |
| Products like: **Branded T-Shirt (৳599), Smartphone (৳18,999), Wireless Earbuds (৳2,499)** | ☐ |

### 3.2 View a Product Detail Page

- [ ] **Action:** Click on any product (for example **"Branded T-Shirt"**)
- [ ] **Expected Result:** A new page opens showing:

| What to Look For | ✅ Check |
|-----------------|----------|
| Product name (larger text) | ☐ |
| Product description | ☐ |
| Price in BDT (৳) | ☐ |
| An **"Order Now"** button | ☐ |
| You can go back by clicking the browser back button | ☐ |

### 3.3 Place an Order

- [ ] **Action:** While viewing a product, click the **"Order Now"** button
- [ ] **Expected Result:** An order form appears with these fields:

```
┌─────────────────────────────────┐
│  📋 Place Your Order           │
│                                 │
│  Your Name: [______________]   │
│  Phone:     [______________]   │
│  Division:  [______________]   │  ← dropdown
│  District:  [______________]   │  ← dropdown
│  Area:      [______________]   │  ← dropdown
│  Address:   [______________]   │
│  Quantity:  [___1___] [+] [-]  │
│  Payment:   ○ bKash  ○ Nagad   │
│             ○ Bank Transfer    │
│             ○ Cash on Delivery │
│                                 │
│  [Submit Order]                 │
└─────────────────────────────────┘
```

- [ ] **Action:** Fill in the form with these exact values:

| Field | Type This |
|-------|-----------|
| **Your Name** | `Test Buyer` |
| **Phone** | `01712345678` |
| **Division** | Click and select **Dhaka** |
| **District** | Click and select **Dhaka** |
| **Area** | Click and select **Mirpur** |
| **Address** | `Road 5, House 10` |
| **Quantity** | Leave as `1` |
| **Payment Method** | Click **"Cash on Delivery"** |

- [ ] **Action:** Click the **"Submit Order"** button
- [ ] **Expected Result:** You should see a success message:

```
✅ Order Placed Successfully!

Your order number: ORD-2026-XXXX
Total: ৳599

We'll contact you at 01712345678 for confirmation.
```

> 🎉 **Congratulations!** You just completed a customer purchase!

### 3.4 Track an Order

- [ ] **Action:** Visit this URL:

```
http://localhost:3001/sawan-shop/orders/track
```

- [ ] **Expected Result:** A tracking form appears:

```
┌──────────────────────────────────┐
│  🔍 Track Your Order           │
│                                  │
│  Phone Number: [______________] │
│  Order ID:     [______________] │
│                                  │
│  [Track Order]                   │
└──────────────────────────────────┘
```

- [ ] **Action:** Enter the phone number you used above
- [ ] **Action:** Enter the order number you received (e.g., `ORD-2026-XXXX`)
- [ ] **Action:** Click **"Track Order"**
- [ ] **Expected Result:** You should see:

| What to Look For | ✅ Check |
|-----------------|----------|
| Order number displayed | ☐ |
| Customer name: **Test Buyer** | ☐ |
| Order status (e.g., "Pending") | ☐ |
| Product name and quantity | ☐ |
| Total amount | ☐ |
| A **progress bar** showing the status steps (Pending → Confirmed → Shipped → Delivered) | ☐ |

---

## 4. Testing the Seller Dashboard

This is where shop owners manage their business.

### 4.1 Log In to the Seller Dashboard

- [ ] **Action:** Visit this URL:

```
http://localhost:3001/auth/login
```

- [ ] **Expected Result:** A login page appears:

```
┌─────────────────────┐
│  Login to ShopiBD   │
│                     │
│  Email:             │
│  [________________] │
│                     │
│  Password:          │
│  [________________] │
│                     │
│  [Login]            │
└─────────────────────┘
```

- [ ] **Action:** Type these credentials:

| Field | Type This |
|-------|-----------|
| **Email** | `sawan@shopibd.com` |
| **Password** | `12345678` |

- [ ] **Action:** Click the **"Login"** button
- [ ] **Expected Result:** After a moment, you should be redirected to:

```
http://localhost:3001/dashboard/orders
```

| What to Look For | ✅ Check |
|-----------------|----------|
| A sidebar menu on the left with: **Orders, Analytics, Products, Customers, Coupons, Settings, etc.** | ☐ |
| A table showing **3 orders** in the list | ☐ |
| Orders from customers: **Shamim Hasan**, **Nusrat Jahan**, **Farhan Ahmed** | ☐ |
| Different statuses: **Pending**, **Confirmed**, **Delivered** | ☐ |

### 4.2 View & Update an Order

- [ ] **Action:** Click on any order in the table (click the order number or the row)
- [ ] **Expected Result:** You see the order detail page:

| What to Look For | ✅ Check |
|-----------------|----------|
| Order number at the top | ☐ |
| Customer name, phone, address | ☐ |
| Products ordered (with quantity and price) | ☐ |
| Total amount | ☐ |
| Current status displayed | ☐ |
| A **dropdown or buttons to change status** | ☐ |

- [ ] **Action:** Change the order status (e.g., from **"Pending"** to **"Confirmed"**)
- [ ] **Action:** Click **Save** or **Update**
- [ ] **Expected Result:** A success message appears: **"Order status updated"**
- [ ] **Action:** Go back to the orders list (click **"Orders"** in the sidebar)
- [ ] **Expected Result:** The status has changed in the table

### 4.3 Test Analytics Dashboard

- [ ] **Action:** Click **"Analytics"** in the left sidebar

Or visit directly:

```
http://localhost:3001/dashboard/analytics
```

- [ ] **Expected Result:** You should see:

| What to Look For | ✅ Check |
|-----------------|----------|
| **Stats cards** showing: Total Sales, Orders, Revenue, etc. | ☐ |
| A **sales chart** (line/bar graph showing orders over time) | ☐ |
| **Top Products** list | ☐ |
| **Order Status Pie Chart** (showing pending/confirmed/delivered breakdown) | ☐ |
| All numbers in **BDT (৳)** format | ☐ |

### 4.4 Test Products Page

- [ ] **Action:** Click **"Products"** in the sidebar

Or visit:

```
http://localhost:3001/dashboard/products
```

- [ ] **Expected Result:** You should see:

| What to Look For | ✅ Check |
|-----------------|----------|
| List of **6 products** | ☐ |
| Product names, prices, stock quantities | ☐ |
| Option to **Add Product**, **Edit**, or **Delete** | ☐ |
| Buttons like **"Bulk Add"** or **"Import CSV"** | ☐ |

### 4.5 Test Customers Page

- [ ] **Action:** Visit:

```
http://localhost:3001/dashboard/customers
```

- [ ] **Expected Result:** A page showing customer list (may be empty since this is a new shop — that's okay)

### 4.6 Test Coupons Page

- [ ] **Action:** Visit:

```
http://localhost:3001/dashboard/coupons
```

- [ ] **Expected Result:** Coupon management page (you can create discount coupons)

### 4.7 Test Abandoned Cart Page

- [ ] **Action:** Visit:

```
http://localhost:3001/dashboard/abandoned
```

- [ ] **Expected Result:** Shows abandoned carts (customers who started ordering but didn't finish)

### 4.8 Test Branding Page

- [ ] **Action:** Visit:

```
http://localhost:3001/dashboard/branding
```

- [ ] **Expected Result:** Shop branding settings (logo, colors, theme)

### 4.9 Test Staff Management

- [ ] **Action:** Visit:

```
http://localhost:3001/dashboard/staff
```

- [ ] **Expected Result:** Staff list showing **Sawan Manager**, with options to invite new staff

### 4.10 Test Notifications

- [ ] **Action:** Visit:

```
http://localhost:3001/dashboard/notifications
```

- [ ] **Expected Result:** Notification settings page

### 4.11 Test Payments

- [ ] **Action:** Visit:

```
http://localhost:3001/dashboard/payments
```

- [ ] **Expected Result:** Payment method configuration (bKash, Nagad, etc.)

### 4.12 Test Settings

- [ ] **Action:** Visit:

```
http://localhost:3001/dashboard/settings
```

- [ ] **Expected Result:** Shop profile settings page where you can edit:
  - Shop name
  - Contact info
  - Delivery settings
  - Language preferences

---

## 5. Testing Sprint 3 Features

These are the newest features added in Sprint 3. Test each one carefully.

### 5.1 Test Coupon/Discount on Storefront

- [ ] **Action:** Go to any product page:

```
http://localhost:3001/sawan-shop/products/1
```

(or click any product from the shop)

- [ ] **Action:** Click **"Order Now"**
- [ ] **Expected Result:** In the order form, look for a **"Have a coupon?"** link or input field
- [ ] **Action:** Click it to expand the coupon input

### 5.2 Test Order Tracking Page

- [ ] **Action:** Visit:

```
http://localhost:3001/sawan-shop/orders/track
```

- [ ] **Expected Result:** A clean tracking page with phone + order ID inputs
- [ ] **Action:** Enter `01712345678` and an order number you received
- [ ] **Action:** Click **"Track Order"**
- [ ] **Expected Result:** Order status with progress steps shown

### 5.3 Test Bengali Language Support

- [ ] **Action:** Check if there's a language switcher (English/Bengali) on any page
- [ ] **Expected Result:** Product names may show Bengali text like `ব্র্যান্ডেড টি-শার্ট` alongside English

### 5.4 Test bKash / Nagad Payment Options

- [ ] **Action:** During the order form step, look for payment method options
- [ ] **Expected Result:** You should see:
  - ☐ **bKash** option (pink icon)
  - ☐ **Nagad** option (orange icon)
  - ☐ **Cash on Delivery**
  - ☐ **Manual / Bank Transfer**

---

## 6. Testing the Admin Panel

The admin panel is a special dashboard for ShopiBD administrators to manage all sellers, shops, products, and orders across the entire platform.

### 6.1 Log In to Admin Panel

- [ ] **Action:** Visit this URL (note: the port is **8080**, not 3001):

```
http://localhost:8080/admin
```

- [ ] **Expected Result:** A login popup appears (a small window asking for username and password):

```
Authentication Required
Username: [________________]
Password: [________________]
```

- [ ] **Action:** Type these credentials:

| Field | Type This |
|-------|-----------|
| **Username** | `admin` |
| **Password** | `admin123` |

- [ ] **Action:** Click **"Sign In"** or **"OK"** (or press Enter)

### 6.2 Explore the Admin Dashboard

- [ ] **Expected Result:** You should see the **SQLAdmin** interface with a sidebar menu showing:

| What to Look For | ✅ Check |
|-----------------|----------|
| **Sellers** — list of all sellers on the platform | ☐ |
| **Shops** — list of all shops | ☐ |
| **Products** — list of all products | ☐ |
| **Orders** — list of all orders | ☐ |
| **Staff** — list of all staff members | ☐ |

### 6.3 Browse Sellers

- [ ] **Action:** Click **"Sellers"** in the admin sidebar
- [ ] **Expected Result:** You should see:

| What to Look For | ✅ Check |
|-----------------|----------|
| **Sawan's Shop** in the list | ☐ |
| Email: **sawan@shopibd.com** | ☐ |
| Phone: **01812345678** | ☐ |
| Status: **Active** | ☐ |
| You can click on a seller row to view/edit details | ☐ |

### 6.4 Browse Orders

- [ ] **Action:** Click **"Orders"** in the admin sidebar
- [ ] **Expected Result:** You should see **3 orders**:

| Order Number | Customer | Amount | Status |
|-------------|----------|--------|--------|
| ORD-2026-0001 | Shamim Hasan | ৳599.00 | Pending |
| ORD-2026-0002 | Nusrat Jahan | ৳21,498.00 | Confirmed |
| ORD-2026-0003 | Farhan Ahmed | ৳2,498.00 | Delivered |

- [ ] **Action:** Click on any order to see its full details
- [ ] **Expected Result:** You can see order items, change status, and edit fields

### 6.5 Browse Products

- [ ] **Action:** Click **"Products"** in the admin sidebar
- [ ] **Expected Result:** All **6 products** are listed with prices and stock levels

### 6.6 Browse Staff

- [ ] **Action:** Click **"Staff"** in the admin sidebar
- [ ] **Expected Result:** **Sawan Manager** is listed with role **manager**

---

## 7. Troubleshooting — Common Problems & Fixes

### ❌ Problem: Page Shows "Internal Server Error" (500)

**When:** Visiting any page on `http://localhost:3001`

**Fix:**
1. Go back to your PowerShell window
2. Press **Ctrl + C** to stop the running process
3. Wait 5 seconds
4. Run the start script again:
```powershell
.\start-dev.ps1
```

### ❌ Problem: "This site can't be reached" or Connection Refused

**When:** Trying to visit `http://localhost:3001` or `http://localhost:8080`

**Fix:**
1. Check if Docker is running (Docker Desktop should show green)
2. If Docker is not running, open Docker Desktop and wait for it to start
3. Run the start script again:
```powershell
.\start-dev.ps1
```

### ❌ Problem: Login Fails / "Incorrect email or password"

**When:** Trying to log in to the seller dashboard

**Fix:**
1. Make sure you're typing the credentials exactly:
   - Email: `sawan@shopibd.com`
   - Password: `12345678`
2. If it still fails, the database might not be seeded. Run:
```powershell
cd e:\SaaS test\shopibd\backend
.\venv\Scripts\python.exe -m scripts.seed
```

### ❌ Problem: "Docker is not running" Error

**When:** Running `.\start-dev.ps1`

**Fix:**
1. Open **Docker Desktop** from the Start Menu
2. Wait for it to fully start (green indicator at bottom-left)
3. Run the start script again

### ❌ Problem: Blank Page or Loading Spinner Never Stops

**When:** Visiting any page

**Fix:**
1. Clear your browser cache (press **Ctrl + Shift + Delete** → choose "Cached images and files" → click Delete)
2. Or try a different browser (Chrome, Edge, or Firefox)
3. Restart the frontend:
   - In PowerShell, run `.\stop-dev.ps1` then `.\start-dev.ps1`

### ❌ Problem: Admin Panel Won't Load

**When:** Visiting `http://localhost:8080/admin`

**Fix:**
1. Make sure the backend is running (visit `http://localhost:8080/health` — should show `{"status":"healthy"}`)
2. If backend is not responding, check the PowerShell window for errors
3. Restart everything

### ❌ Problem: Can't Find the Shop (404)

**When:** Visiting `http://localhost:3001/sawan-shop`

**Fix:**
1. The database might not be seeded. Run this in PowerShell:
```powershell
cd e:\SaaS test\shopibd\backend
.\venv\Scripts\python.exe -m scripts.seed
```
2. Then refresh the page

### ❌ Problem: Python/Virtual Environment Not Found

**When:** Running start-dev.ps1 shows: "WARNING: Virtual env not found"

**Fix:**
```powershell
cd e:\SaaS test\shopibd\backend
python -m venv venv
.\venv\Scripts\pip install -e ".[dev]"
```

### ❌ Problem: Port Already in Use

**When:** Starting the backend or frontend fails with "port already in use"

**Fix:**
1. Run the stop script first:
```powershell
.\stop-dev.ps1
```
2. Wait 5 seconds
3. Try starting again:
```powershell
.\start-dev.ps1
```

---

## 🎯 Summary Checklist — Did You Test Everything?

| Section | Tests | Status |
|---------|-------|--------|
| **Prerequisites** | Docker Desktop installed and running | ☐ |
| **Start** | `.\start-dev.ps1` completed without errors | ☐ |
| **Buyer Storefront** | Shop page loads with 6 products | ☐ |
| **Product Detail** | Clicking a product shows detail page | ☐ |
| **Place Order** | Order form submits successfully | ☐ |
| **Track Order** | Order tracking shows status | ☐ |
| **Seller Login** | Login with sawan@shopibd.com works | ☐ |
| **Orders Dashboard** | 3 orders visible | ☐ |
| **Order Update** | Can change order status | ☐ |
| **Analytics** | Charts and stats load | ☐ |
| **Products** | Product list works | ☐ |
| **Customers** | Customer page loads | ☐ |
| **Coupons** | Coupon page loads | ☐ |
| **Abandoned Cart** | Abandoned cart page loads | ☐ |
| **Branding** | Branding settings load | ☐ |
| **Staff** | Staff list shows Sawan Manager | ☐ |
| **Notifications** | Notification settings load | ☐ |
| **Payments** | Payment settings load | ☐ |
| **Settings** | Shop settings load | ☐ |
| **Sprint 3 Features** | Coupon, tracking, bKash/Nagad options visible | ☐ |
| **Admin Panel** | Admin login works | ☐ |
| **Admin - Sellers** | Sawan's Shop visible | ☐ |
| **Admin - Orders** | All 3 orders visible | ☐ |
| **Admin - Products** | All 6 products visible | ☐ |
| **Admin - Staff** | Sawan Manager visible | ☐ |

---

## 📞 Need Help?

If something doesn't work and it's not in the troubleshooting section:

1. **Check the PowerShell window** — look for any red error messages
2. **Restart everything** — run `.\stop-dev.ps1` then `.\start-dev.ps1`
3. **Check the backend logs** — open `backend\backend.log` or `backend\backend-error.log`
4. **Check the API is alive** — visit `http://localhost:8080/health` (should show `{"status":"healthy"}`)

---

*Happy Testing! 🚀*
