import { chromium } from "playwright";
import fs from "node:fs";

const OUT = "screenshots";
fs.mkdirSync(OUT, { recursive: true });

const targets = [
  { name: "01_home_desktop", url: "http://localhost:3001/", vp: { width: 1440, height: 900 } },
  { name: "02_home_mobile", url: "http://localhost:3001/", vp: { width: 390, height: 844 } },
  { name: "03_login_desktop", url: "http://localhost:3001/auth/login", vp: { width: 1440, height: 900 } },
  { name: "04_login_mobile", url: "http://localhost:3001/auth/login", vp: { width: 390, height: 844 } },
  { name: "05_pricing_desktop", url: "http://localhost:3001/pricing", vp: { width: 1440, height: 900 } },
  { name: "06_pricing_mobile", url: "http://localhost:3001/pricing", vp: { width: 390, height: 844 } },
  { name: "07_storefront_desktop", url: "http://localhost:3001/sawan-shop", vp: { width: 1440, height: 900 } },
  { name: "08_storefront_mobile", url: "http://localhost:3001/sawan-shop", vp: { width: 390, height: 844 } },
];

const browser = await chromium.launch({
  executablePath: process.env.LOCALAPPDATA + "\\ms-playwright\\chromium_headless_shell-1223\\chrome-headless-shell-win64\\chrome-headless-shell.exe",
  args: [
    "--no-sandbox",
    "--disable-setuid-sandbox",
    "--disable-dev-shm-usage",
    "--disable-gpu",
    "--font-render-hinting=none",
  ],
});

for (const t of targets) {
  const ctx = await browser.newContext({
    viewport: t.vp,
    deviceScaleFactor: 1,
    colorScheme: "dark",
    ignoreHTTPSErrors: true,
  });
  const page = await ctx.newPage();
  try {
    await page.goto(t.url, { waitUntil: "domcontentloaded", timeout: 45000 });
    await page.waitForLoadState("networkidle", { timeout: 20000 }).catch(() => {});
    await page.waitForTimeout(800);
    await page.screenshot({
      path: `${OUT}/${t.name}.png`,
      fullPage: false,
      animations: "disabled",
    });
    console.log(`OK  ${t.name}  ${t.vp.width}x${t.vp.height}`);
  } catch (e) {
    console.log(`ERR ${t.name}: ${e.message}`);
  } finally {
    await ctx.close();
  }
}

await browser.close();
console.log("done");