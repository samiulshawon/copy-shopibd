import { test, expect } from "@playwright/test";

const TEST_EMAIL = "sawan@shopibd.com";
const TEST_PASSWORD = "12345678";
const API_URL = "http://localhost:8000/api/v1";
const FRONTEND_URL = "http://localhost:3001";

async function loginViaApi(page: any) {
  const response = await page.request.post(`${API_URL}/auth/login`, {
    data: { email: TEST_EMAIL, password: TEST_PASSWORD },
  });
  expect(response.ok()).toBeTruthy();
  const data = await response.json();
  return data.access_token;
}

async function setAuthSession(page: any, token: string) {
  // Set cookie for server-side getServerSession
  await page.context().addCookies([
    { name: "shopibd_access_token", value: token, url: FRONTEND_URL, sameSite: "Lax" },
  ]);
  // Set localStorage for client-side auth
  await page.goto("/auth/login", { waitUntil: "domcontentloaded", timeout: 60000 });
  await page.evaluate((t: string) => {
    localStorage.setItem("shopibd_access_token", t);
  }, token);
}

test.describe("Authentication Flow", () => {
  test("unauthenticated user is redirected to login from protected page", async ({
    page,
  }) => {
    await page.goto("/dashboard/orders", { waitUntil: "domcontentloaded", timeout: 60000 });
    await page.waitForURL(/\/auth\/login/, { timeout: 30000 });
    expect(page.url()).toContain("/auth/login");
  });

  test("user can log in with valid credentials", async ({ page }) => {
    const token = await loginViaApi(page);
    await setAuthSession(page, token);

    await page.goto("/dashboard/orders", { waitUntil: "domcontentloaded", timeout: 60000 });

    await expect(
      page.getByLabel("Dashboard content").getByRole("heading", { name: "Orders", level: 1 }),
    ).toBeVisible({ timeout: 30000 });
  });

  test("invalid credentials show error message", async ({ page }) => {
    // Use the API directly to verify the error response
    const response = await page.request.post(`${API_URL}/auth/login`, {
      data: { email: TEST_EMAIL, password: "wrongpassword" },
    });
    expect(response.status()).toBe(401);
    const data = await response.json();
    expect(data.detail).toMatch(/Incorrect email or password|Invalid credentials/i);
  });

  test("user can log out", async ({ page }) => {
    const token = await loginViaApi(page);
    await setAuthSession(page, token);

    await page.goto("/dashboard/orders", { waitUntil: "domcontentloaded", timeout: 60000 });
    await expect(
      page.getByLabel("Dashboard content").getByRole("heading", { name: "Orders", level: 1 }),
    ).toBeVisible({ timeout: 30000 });

    // Clear auth and verify redirect to login
    await page.evaluate(() => {
      localStorage.removeItem("shopibd_access_token");
      document.cookie = "shopibd_access_token=; path=/; max-age=0; SameSite=Lax";
    });
    await page.goto("/dashboard/orders", { waitUntil: "domcontentloaded", timeout: 60000 });
    await page.waitForURL(/\/auth\/login/, { timeout: 30000 });
    expect(page.url()).toContain("/auth/login");
  });
});
