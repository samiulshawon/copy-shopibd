import { execSync } from 'child_process'
import path from 'path'

export default async function globalSetup() {
  console.log('[global-setup] Resetting database …')
  const scriptPath = path.resolve(__dirname, '../../../backend/scripts/reset_db.py')
  execSync(`python -m scripts.reset_db`, {
    cwd: path.dirname(scriptPath),
    stdio: 'inherit',
  })
  console.log('[global-setup] Database reset complete.')
}
