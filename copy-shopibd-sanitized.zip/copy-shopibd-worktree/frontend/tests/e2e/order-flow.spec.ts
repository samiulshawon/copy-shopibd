import { test, expect } from "@playwright/test";

const SHOP_SLUG = "sawan-shop";
const TEST_EMAIL = "sawan@shopibd.com";
const TEST_PASSWORD = "12345678";

test.describe("Storefront & Order Flow", () => {
  test("storefront page loads and displays products", async ({ page }) => {
    await page.goto(`/${SHOP_SLUG}`, { waitUntil: "domcontentloaded", timeout: 60000 });

    // Shop name should be visible
    await expect(
      page.locator("text=Sawan's Shop").first(),
    ).toBeVisible({ timeout: 30000 });

    // Product grid heading should be visible
    await expect(page.locator("text=Products").first()).toBeVisible({ timeout: 20000 });

    // At least one in-stock product card link should exist
    await expect(
      page.getByRole("link", { name: /^View / }).first(),
    ).toBeVisible({ timeout: 20000 });
  });

  test("user can place an order through the storefront", async ({ page }) => {
    // Step 1: Go to the storefront
    await page.goto(`/${SHOP_SLUG}`, { waitUntil: "domcontentloaded", timeout: 60000 });
    await page.waitForSelector('a[aria-label^="View "]', {
      timeout: 30000,
    });

    // Step 2: Click the first in-stock product card
    // This navigates to the product detail page.
    await page.locator('a[aria-label^="View "]').first().click();
    await page.waitForURL(/\/products\//, { timeout: 30000 });

    // Step 3: Click "Order Now" on the product detail page
    // The link points to /{slug}/order?product_id={id}. Both the desktop
    // CTA and the mobile sticky buy bar share this label, so use the first.
    await page.locator('a:has-text("Order Now")').first().click();
    await page.waitForURL(/\/order/, { timeout: 30000 });

    // Step 4: Fill in the order form
    await page
      .locator('input[placeholder="আপনার নাম লিখুন"]')
      .fill("E2E Test Buyer");
    await page
      .locator('input[placeholder="+8801XXXXXXXXX"]')
      .fill("01711111111");
    // Division (first ঢাকা input)
    await page.locator('input[placeholder="ঢাকা"]').first().fill("Dhaka");
    // District (second ঢাকা input)
    await page.locator('input[placeholder="ঢাকা"]').nth(1).fill("Dhaka");
    await page.locator('input[placeholder="মিরপুর"]').fill("Mirpur");
    await page
      .locator('input[placeholder*="রোড"]')
      .fill("123 Test Road, Block A");

    // Select "Cash on Delivery" as payment method
    await page.locator("text=Cash on Delivery").click();

    // Step 5: Submit the order
    await page.click('button:has-text("Place Order")');

    // Step 6: Verify order confirmation appears inline
    // The order form shows success inline with "Order Confirmed" text
    await expect(page.locator("text=Order Confirmed")).toBeVisible({
      timeout: 30000,
    });
    await expect(page.locator("text=Order ID")).toBeVisible({ timeout: 20000 });
    await expect(page.locator("text=Total Amount")).toBeVisible({ timeout: 20000 });
  });

  test("seller can see existing orders in dashboard", async ({ page }) => {
    // Log in via API (form submission via Playwright triggers native GET)
    const response = await page.request.post("http://localhost:8000/api/v1/auth/login", {
      data: { email: TEST_EMAIL, password: TEST_PASSWORD },
    });
    expect(response.ok()).toBeTruthy();
    const token = (await response.json()).access_token;

    // Set cookie + localStorage for auth
    await page.context().addCookies([
      { name: "shopibd_access_token", value: token, url: "http://localhost:3001", sameSite: "Lax" },
    ]);
    await page.goto("/auth/login", { waitUntil: "domcontentloaded", timeout: 60000 });
    await page.evaluate((t) => localStorage.setItem("shopibd_access_token", t), token);

    await page.goto("/dashboard/orders", { waitUntil: "domcontentloaded", timeout: 60000 });

    // Orders should be loaded and visible (at least one customer name present)
    await expect(page.locator("table").first()).toBeVisible({ timeout: 30000 });
    // The orders table should contain at least one row
    await expect(page.locator("tbody tr").first()).toBeVisible({ timeout: 30000 });
  });
});
