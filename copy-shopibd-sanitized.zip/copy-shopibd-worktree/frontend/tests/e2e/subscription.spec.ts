import { test, expect } from "@playwright/test";

const TEST_EMAIL = "sawan@shopibd.com";
const TEST_PASSWORD = "12345678";
const API_URL = "http://localhost:8000/api/v1";
const FRONTEND_URL = "http://localhost:3001";

async function loginViaApi(page: any) {
  const response = await page.request.post(`${API_URL}/auth/login`, {
    data: { email: TEST_EMAIL, password: TEST_PASSWORD },
  });
  expect(response.ok()).toBeTruthy();
  const data = await response.json();
  return data.access_token;
}

async function setAuthSession(page: any, token: string) {
  // Set cookie + localStorage via init script so the very first navigation
  // already carries the session. Avoids an extra /auth/login hop that tends to
  // trip the sandbox's browser file-access guard (ERR_ABORTED on navigation).
  await page.context().addCookies([
    { name: "shopibd_access_token", value: token, url: FRONTEND_URL, sameSite: "Lax" },
  ]);
  await page.addInitScript((t: string) => {
    localStorage.setItem("shopibd_access_token", t);
  }, token);
}

/**
 * Select the first *paid* plan that is NOT the current one, so the test is
 * robust to whatever plan the seeded seller currently has. The Free plan
 * cannot be selected via the subscription endpoint, so it is skipped.
 */
async function selectFirstUpgradeablePlan(page: any) {
  const paidPlans = ["Enterprise", "Business", "Starter"];
  for (const name of paidPlans) {
    // The redesigned plan comparison is a card grid (PlanCard), not tabs.
    // Locate the card by its heading and click its action button. The CTA
    // copy varies: "Upgrade to {name}" (upgrade), "Switch to {name}" /
    // "Choose {name}" (downgrade or fresh).
    const card = page
      .locator(":is(article, section, div)")
      .filter({ has: page.getByRole("heading", { name }) })
      .first();
    if (!(await card.count())) continue;
    const action = card
      .locator(
        "button:has-text('Upgrade'), button:has-text('Switch to'), button:has-text('Choose')",
      )
      .first();
    if (!(await action.count())) continue;
    await action.click();
    return;
  }
  throw new Error("No upgradeable (paid) plan card found");
}

test.describe("Subscription & Usage Flow", () => {
  test.setTimeout(90000);
  test("subscription page renders plan badge, usage bars, and pricing", async ({ page }) => {
    const token = await loginViaApi(page);
    await setAuthSession(page, token);

    await page.goto("/dashboard/subscription", { waitUntil: "domcontentloaded", timeout: 60000 });

    // Current plan header should be visible
    await expect(
      page.getByRole("heading", { name: "Subscription workspace", level: 1 }),
    ).toBeVisible({ timeout: 30000 });

    // PlanBadge ("X Plan") should render in the current-plan card
    await expect(page.locator("text=/\\w+ Plan/").first()).toBeVisible({ timeout: 30000 });

    // Usage bars ("Products used" / "Orders this period") should render
    await expect(page.locator("text=Products used").first()).toBeVisible({ timeout: 30000 });
    await expect(page.locator("text=Orders this period").first()).toBeVisible({ timeout: 30000 });

    // Plan pricing for all four tiers should be visible (৳ formatted)
    await expect(page.locator("text=৳0").first()).toBeVisible({ timeout: 30000 });
    await expect(page.locator("text=৳499").first()).toBeVisible({ timeout: 30000 });
    await expect(page.locator("text=৳999").first()).toBeVisible({ timeout: 30000 });
    await expect(page.locator("text=৳2999").first()).toBeVisible({ timeout: 30000 });

    // A non-current plan should be selectable, revealing its confirm button
    await selectFirstUpgradeablePlan(page);
    await expect(
      page
        .locator(
          "button:has-text('Continue to payment'), button:has-text('Switch to'), button:has-text('Continue with')",
        )
        .first(),
    ).toBeVisible({ timeout: 30000 });
  });

  test("selecting a plan triggers subscription + payment API calls", async ({ page }) => {
    const token = await loginViaApi(page);
    await setAuthSession(page, token);

    // Stub the payment endpoint so we don't hit a real gateway; return a fake URL.
    await page.route(`${API_URL}/subscription/payment`, async (route) => {
      await route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify({ payment_url: "https://example.com/fake-payment", payment_id: "pay_test", payment_method: "manual", amount: 499 }),
      });
    });

    await page.goto("/dashboard/subscription", { waitUntil: "domcontentloaded", timeout: 60000 });
    await expect(
      page.getByRole("heading", { name: "Subscription workspace", level: 1 }),
    ).toBeVisible({ timeout: 30000 });

    // Wait for the plan cards to actually render (not the loading skeleton).
    await expect(
      page.getByRole("heading", { name: "Enterprise" }),
    ).toBeVisible({ timeout: 30000 });

    // Select a non-current plan (robust to the seeded seller's current plan)
    await selectFirstUpgradeablePlan(page);

    // The selected plan reveals a "Continue to payment" / "Switch to" / "Continue with"
    // confirm button + gateway selector.
    const confirmButton = page
      .locator(
        "button:has-text('Continue to payment'), button:has-text('Switch to'), button:has-text('Continue with')",
      )
      .first();
    await expect(confirmButton).toBeVisible({ timeout: 30000 });

    // Choose the Manual gateway to avoid external payment redirects.
    const gatewaySelect = page.locator("select").first();
    await expect(gatewaySelect).toBeVisible({ timeout: 30000 });
    await gatewaySelect.selectOption({ label: "Manual / Bank Transfer" });

    // Wait for both API calls deterministically using waitForRequest (registered
    // BEFORE the click). Both must fire for the plan change flow to complete.
    const createPromise = page.waitForRequest(
      (req) =>
        req.url().endsWith("/subscription") &&
        req.method() === "POST",
      { timeout: 30000 },
    );
    const paymentPromise = page.waitForRequest(
      (req) =>
        req.url().endsWith("/subscription/payment") &&
        req.method() === "POST",
      { timeout: 30000 },
    );

    await confirmButton.click();

    const createReq = await createPromise;
    const paymentReq = await paymentPromise;

    // Sanity-check the responses were 2xx (the test stub returns 200 for payment).
    const createRes = await createReq.response();
    expect(createRes, "create subscription response").not.toBeNull();
    expect(createRes!.status()).toBeLessThan(400);

    const paymentRes = await paymentReq.response();
    expect(paymentRes, "create payment response").not.toBeNull();
    expect(paymentRes!.status()).toBeLessThan(400);

    // No error toast should be shown.
    await expect(page.locator("text=Failed to change plan").first()).toHaveCount(0, { timeout: 5000 });
  });
});
