"""
Test package for ShopiBD frontend.
"""
