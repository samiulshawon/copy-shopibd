// Local-only override for Phase T3+ verification against the live dev stack.
// Disables the destructive global-setup database reset, and points Chromium
// at the locally installed browser binary because the headless shell revision
// (1228) that Playwright 1.61.1 expects was not downloaded in this
// environment. DO NOT use this config for CI.
import { defineConfig, devices } from '@playwright/test'
import base from './playwright.config'

const CHROME_1234 = `${process.env.LOCALAPPDATA}\\ms-playwright\\chromium-1234\\chrome-win64\\chrome.exe`

const chromiumUse = (extra: Parameters<typeof defineConfig>[0]['use']) => ({
  ...devices['Desktop Chrome'],
  launchOptions: {
    executablePath: CHROME_1234,
    args: [
      '--no-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu',
      '--disable-software-rasterizer',
      '--disable-features=Translate,BackForwardCache',
    ],
  },
  ...extra,
})

export default defineConfig({
  ...base,
  globalSetup: undefined,
  projects: [
    {
      name: 'desktop-chrome',
      use: chromiumUse({ viewport: { width: 1280, height: 800 } }),
    },
    {
      name: 'mobile',
      use: chromiumUse({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true }),
    },
    {
      name: 'tablet',
      use: chromiumUse({ viewport: { width: 820, height: 1180 } }),
    },
    {
      name: 'wide-desktop',
      use: chromiumUse({ viewport: { width: 1536, height: 960 } }),
    },
  ],
})