import React from 'react'
import type { Metadata } from 'next'
import { Be_Vietnam_Pro, Noto_Sans_Bengali } from 'next/font/google'
import { Providers } from './providers'
import './globals.css'

const beVietnamPro = Be_Vietnam_Pro({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-be-vietnam-pro',
  display: 'swap',
})

const noto = Noto_Sans_Bengali({
  subsets: ['bengali'],
  weight: ['400', '500', '700'],
  variable: '--font-noto-bengali',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'ShopiBD - Multi-tenant E-commerce Platform',
  description: 'A multi-tenant e-commerce platform for Bangladesh',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="bn" suppressHydrationWarning>
      <body className={`${beVietnamPro.variable} ${noto.variable} font-sans antialiased`}>
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}
