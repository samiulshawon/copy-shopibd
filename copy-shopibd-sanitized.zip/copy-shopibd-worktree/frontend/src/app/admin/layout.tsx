import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { SuperAdminShell } from "@/components/layout/super-admin-shell";
import { getServerSession } from "@/lib/auth";

export default async function AdminLayout({
  children,
}: {
  children: ReactNode;
}) {
  const session = await getServerSession();

  if (!session) {
    redirect("/auth/login");
  }

  // Only the platform super admin can access this route group
  if (!session.is_super_admin) {
    redirect("/dashboard");
  }

  return <SuperAdminShell>{children}</SuperAdminShell>;
}