"use client";

import { useEffect, useState, useCallback } from "react";
import { adminReviewsApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { StarRating } from "@/components/ui/star-rating";
import { Select } from "@/components/ui/select";
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Loader2, CheckCircle2, XCircle, MessageSquareText } from "lucide-react";
import type { ReviewResponse } from "@/types/review";
import {
  MetricCard,
  MetricStrip,
  PageActions,
  PageDescription,
  PageEyebrow,
  PageFrame,
  PageHeader,
  PageHeaderContent,
  PageTitle,
  SectionDescription,
  SectionHeader,
  SectionTitle,
  SurfaceSection,
} from "@/components/layout/page-structure";

const STATUS_OPTIONS = [
  { value: "", label: "All" },
  { value: "pending", label: "Pending" },
  { value: "approved", label: "Approved" },
  { value: "rejected", label: "Rejected" },
];

export default function AdminReviewsPage() {
  const { toast } = useToast();
  const [reviews, setReviews] = useState<ReviewResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState("");
  const [actionLoading, setActionLoading] = useState<number | null>(null);
  const [rejectDialogOpen, setRejectDialogOpen] = useState(false);
  const [rejectReviewId, setRejectReviewId] = useState<number | null>(null);
  const [rejectReason, setRejectReason] = useState("");

  const fetchReviews = useCallback(async () => {
    setLoading(true);
    try {
      const response = await adminReviewsApi.listAll(
        statusFilter || undefined,
      );
      setReviews(response.data as ReviewResponse[]);
    } catch {
      toast({
        message: "Failed to load reviews",
        variant: "error",
      });
    } finally {
      setLoading(false);
    }
  }, [statusFilter, toast]);

  useEffect(() => {
    fetchReviews();
  }, [fetchReviews]);

  async function handleApprove(id: number) {
    setActionLoading(id);
    try {
      await adminReviewsApi.approve(id);
      toast({ message: "Review approved", variant: "success" });
      fetchReviews();
    } catch {
      toast({ message: "Failed to approve review", variant: "error" });
    } finally {
      setActionLoading(null);
    }
  }

  function openRejectDialog(id: number) {
    setRejectReviewId(id);
    setRejectReason("");
    setRejectDialogOpen(true);
  }

  async function handleReject() {
    if (rejectReviewId === null) return;
    setActionLoading(rejectReviewId);
    setRejectDialogOpen(false);
    try {
      await adminReviewsApi.reject(
        rejectReviewId,
        rejectReason.trim() || "No reason provided",
      );
      toast({ message: "Review rejected", variant: "success" });
      fetchReviews();
    } catch {
      toast({ message: "Failed to reject review", variant: "error" });
    } finally {
      setActionLoading(null);
      setRejectReviewId(null);
    }
  }

  function formatDate(dateStr: string): string {
    try {
      return new Date(dateStr).toLocaleDateString("en-BD", {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return dateStr;
    }
  }

  function statusBadge(status: string) {
    switch (status) {
      case "approved":
        return <Badge variant="success">Approved</Badge>;
      case "rejected":
        return <Badge variant="destructive">Rejected</Badge>;
      default:
        return <Badge variant="warning">Pending</Badge>;
    }
  }

  const pendingCount = reviews.filter((r) => r.is_approved === null).length;
  const approvedCount = reviews.filter((r) => r.is_approved === true).length;
  const rejectedCount = reviews.filter((r) => r.is_approved === false).length;

  return (
    <PageFrame>
      <PageHeader>
        <PageHeaderContent>
          <PageEyebrow>Admin / moderation</PageEyebrow>
          <PageTitle>Review moderation</PageTitle>
          <PageDescription>
            Approve or reject customer reviews before they appear on the
            storefront.
          </PageDescription>
        </PageHeaderContent>
        <PageActions>
          <Select
            options={STATUS_OPTIONS}
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-40 bg-muted"
          />
          <Button
            variant="outline"
            onClick={fetchReviews}
            disabled={loading}
          >
            Refresh
          </Button>
        </PageActions>
      </PageHeader>

      {/* Summary metrics */}
      <MetricStrip>
        <MetricCard>
          <p className="text-sm font-medium text-muted-foreground">Pending</p>
          <p className="mt-2 text-2xl font-semibold tracking-tight text-warning">{pendingCount}</p>
          <p className="mt-1 text-xs text-muted-foreground">Awaiting moderation.</p>
        </MetricCard>
        <MetricCard>
          <p className="text-sm font-medium text-muted-foreground">Approved</p>
          <p className="mt-2 text-2xl font-semibold tracking-tight text-success">{approvedCount}</p>
          <p className="mt-1 text-xs text-muted-foreground">Visible on storefront.</p>
        </MetricCard>
        <MetricCard>
          <p className="text-sm font-medium text-muted-foreground">Rejected</p>
          <p className="mt-2 text-2xl font-semibold tracking-tight text-destructive">{rejectedCount}</p>
          <p className="mt-1 text-xs text-muted-foreground">Hidden from buyers.</p>
        </MetricCard>
      </MetricStrip>

      {/* Reviews table */}
      <SurfaceSection>
        <SectionHeader>
          <div>
            <SectionTitle>All reviews</SectionTitle>
            <SectionDescription>
              {reviews.length} review{reviews.length !== 1 ? "s" : ""} found
            </SectionDescription>
          </div>
        </SectionHeader>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="size-8 animate-spin text-muted-foreground" />
          </div>
        ) : reviews.length === 0 ? (
          <div className="flex flex-col items-center gap-3 border border-dashed border-border py-16 text-center">
            <div className="flex size-14 items-center justify-center border border-border bg-background text-muted-foreground">
              <MessageSquareText className="size-6" />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">No reviews found</p>
              <p className="mt-1 text-xs text-muted-foreground">
                No reviews match the selected filter.
              </p>
            </div>
          </div>
        ) : (
          <div className="mt-4 overflow-x-auto border border-border">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead>Product</TableHead>
                  <TableHead>Buyer</TableHead>
                  <TableHead>Rating</TableHead>
                  <TableHead>Review</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reviews.map((review) => (
                  <TableRow key={review.id} className="hover:bg-muted/50">
                    <TableCell className="max-w-[160px] truncate font-medium">
                      #{review.product_id}
                    </TableCell>
                    <TableCell>
                      <div className="text-sm font-medium">{review.buyer_name}</div>
                      <div className="text-xs text-muted-foreground">
                        {review.buyer_phone}
                      </div>
                    </TableCell>
                    <TableCell>
                      <StarRating value={review.rating} size="sm" />
                    </TableCell>
                    <TableCell className="max-w-xs">
                      <div className="space-y-1">
                        {review.title && (
                          <p className="text-sm font-medium">{review.title}</p>
                        )}
                        <p className="line-clamp-3 text-sm text-muted-foreground">
                          {review.body}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
                      {formatDate(review.created_at)}
                    </TableCell>
                    <TableCell>{statusBadge(review.is_approved ? "approved" : review.is_approved === false ? "rejected" : "pending")}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        {review.is_approved === null && (
                          <>
                            <Button
                              variant="outline"
                              size="sm"
                              className="border-success/40 text-success hover:bg-success/10"
                              disabled={actionLoading === review.id}
                              onClick={() => handleApprove(review.id)}
                            >
                              {actionLoading === review.id ? (
                                <Loader2 className="size-3.5 animate-spin" />
                              ) : (
                                <CheckCircle2 className="size-3.5" />
                              )}
                              Approve
                            </Button>
                            <Dialog
                              open={rejectDialogOpen && rejectReviewId === review.id}
                              onOpenChange={(open) => {
                                if (!open) setRejectDialogOpen(false);
                              }}
                            >
                              <DialogTrigger asChild>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="border-destructive/40 text-destructive hover:bg-destructive/10"
                                  disabled={actionLoading === review.id}
                                  onClick={() => openRejectDialog(review.id)}
                                >
                                  <XCircle className="size-3.5" />
                                  Reject
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Reject Review</DialogTitle>
                                  <DialogDescription>
                                    Provide a reason for rejecting this review.
                                  </DialogDescription>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <textarea
                                    rows={3}
                                    placeholder="Reason for rejection..."
                                    className="flex w-full border border-border bg-muted px-3 py-2 text-sm text-foreground outline-none placeholder:text-muted-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
                                    value={rejectReason}
                                    onChange={(e) => setRejectReason(e.target.value)}
                                  />
                                  <div className="flex justify-end gap-3">
                                    <DialogClose asChild>
                                      <Button variant="outline" size="sm">
                                        Cancel
                                      </Button>
                                    </DialogClose>
                                    <Button
                                      variant="destructive"
                                      size="sm"
                                      onClick={handleReject}
                                    >
                                      Reject Review
                                    </Button>
                                  </div>
                                </div>
                              </DialogContent>
                            </Dialog>
                          </>
                        )}
                        {review.is_approved === true && (
                          <Badge variant="success">Approved</Badge>
                        )}
                        {review.is_approved === false && (
                          <Badge variant="destructive">Rejected</Badge>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </SurfaceSection>
    </PageFrame>
  );
}