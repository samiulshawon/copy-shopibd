"use client";

import { useEffect, useState } from "react";
import { Check, Loader2, Lock, User } from "lucide-react";
import { superAdminApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function SettingsPage() {
  const [profile, setProfile] = useState({ name: "", email: "", phone: "" });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Password form
  const [currentPw, setCurrentPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const [pwLoading, setPwLoading] = useState(false);
  const [pwError, setPwError] = useState("");
  const [pwSuccess, setPwSuccess] = useState("");

  useEffect(() => {
    async function load() {
      try {
        const res = await superAdminApi.getSettings();
        setProfile(res.data);
      } catch {
        setError("Failed to load profile.");
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  async function saveProfile() {
    setSaving(true);
    setError("");
    setSuccess("");
    try {
      await superAdminApi.updateProfile({ name: profile.name, phone: profile.phone });
      setSuccess("Profile updated.");
    } catch (err: any) {
      setError(err?.response?.data?.detail || "Failed to update.");
    } finally {
      setSaving(false);
    }
  }

  async function changePassword() {
    if (newPw !== confirmPw) {
      setPwError("New passwords do not match.");
      return;
    }
    if (newPw.length < 8) {
      setPwError("New password must be at least 8 characters.");
      return;
    }
    setPwLoading(true);
    setPwError("");
    setPwSuccess("");
    try {
      await superAdminApi.changePassword({ current_password: currentPw, new_password: newPw });
      setPwSuccess("Password changed successfully.");
      setCurrentPw("");
      setNewPw("");
      setConfirmPw("");
    } catch (err: any) {
      setPwError(err?.response?.data?.detail || "Failed to change password.");
    } finally {
      setPwLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="mx-auto max-w-lg space-y-6">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-64" />
        <Skeleton className="h-64" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-lg space-y-6">
      <div>
        <h2 className="text-headline-md text-xl font-semibold text-foreground">Settings</h2>
        <p className="mt-1 text-sm text-muted-foreground">Manage your owner account.</p>
      </div>

      {error ? (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      ) : null}
      {success ? (
        <Alert>
          <Check className="size-4" />
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      ) : null}

      {/* Profile */}
      <div className="border border-border bg-background p-6">
        <h3 className="text-headline-md mb-5 text-lg font-semibold">Profile</h3>
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-label-sm text-sm font-medium text-foreground">Email</label>
            <Input
              className="h-10 border-border bg-background"
              value={profile.email}
              disabled
            />
            <p className="text-xs text-muted-foreground">Email cannot be changed.</p>
          </div>
          <div className="space-y-2">
            <label className="text-label-sm text-sm font-medium text-foreground">Name</label>
            <Input
              className="h-10 border-border bg-background"
              value={profile.name}
              onChange={(e) => setProfile((p) => ({ ...p, name: e.target.value }))}
            />
          </div>
          <div className="space-y-2">
            <label className="text-label-sm text-sm font-medium text-foreground">Phone</label>
            <Input
              className="h-10 border-border bg-background"
              value={profile.phone}
              onChange={(e) => setProfile((p) => ({ ...p, phone: e.target.value }))}
            />
          </div>
        </div>
        <div className="mt-4 border-t border-border pt-4">
          <Button onClick={saveProfile} disabled={saving}>
            {saving ? <Loader2 className="mr-2 size-4 animate-spin" /> : null}
            Save changes
          </Button>
        </div>
      </div>

      {/* Password */}
      <div className="border border-border bg-background p-6">
        <h3 className="text-headline-md mb-5 text-lg font-semibold">Change Password</h3>

        {pwError ? (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{pwError}</AlertDescription>
          </Alert>
        ) : null}
        {pwSuccess ? (
          <Alert className="mb-4">
            <Check className="size-4" />
            <AlertDescription>{pwSuccess}</AlertDescription>
          </Alert>
        ) : null}

        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-label-sm text-sm font-medium text-foreground">Current password</label>
            <Input
              type="password"
              className="h-10 border-border bg-background"
              placeholder="Enter current password"
              value={currentPw}
              onChange={(e) => setCurrentPw(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <label className="text-label-sm text-sm font-medium text-foreground">New password</label>
            <Input
              type="password"
              className="h-10 border-border bg-background"
              placeholder="Min 8 characters"
              value={newPw}
              onChange={(e) => setNewPw(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <label className="text-label-sm text-sm font-medium text-foreground">Confirm new password</label>
            <Input
              type="password"
              className="h-10 border-border bg-background"
              placeholder="Re-enter new password"
              value={confirmPw}
              onChange={(e) => setConfirmPw(e.target.value)}
            />
          </div>
        </div>
        <div className="mt-4 border-t border-border pt-4">
          <Button onClick={changePassword} disabled={pwLoading}>
            {pwLoading ? <Loader2 className="mr-2 size-4 animate-spin" /> : null}
            Change password
          </Button>
        </div>
      </div>
    </div>
  );
}