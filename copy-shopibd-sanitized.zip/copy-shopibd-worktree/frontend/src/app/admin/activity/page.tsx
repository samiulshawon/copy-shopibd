"use client";

import { useCallback, useEffect, useState } from "react";
import { ScrollText, Loader2, Search } from "lucide-react";
import { cn } from "@/lib/utils";
import { superAdminApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";

interface ActivityEntry {
  id: number;
  action: string;
  entity_type: string;
  entity_id: number;
  actor_email: string;
  created_at: string;
}

function formatDate(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleDateString("en-BD", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}

function actionBadge(action: string) {
  const colors: Record<string, string> = {
    create: "border-primary/30 text-primary bg-primary/10",
    update: "border-primary/30 text-primary bg-primary/10",
    delete: "border-destructive/30 text-destructive bg-destructive/10",
    status_update: "border-warning/30 text-warning bg-warning/10",
  };
  // match prefix (e.g. "order.create" → "create")
  const prefix = action.split(".").pop() ?? action;
  return colors[prefix] ?? "border-outline-variant text-muted-foreground bg-muted/30";
}

export default function ActivityPage() {
  const [entries, setEntries] = useState<ActivityEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [search, setSearch] = useState("");
  const [actionFilter, setActionFilter] = useState("all");
  const [entityFilter, setEntityFilter] = useState("all");
  const [hasMore, setHasMore] = useState(true);

  const fetchEntries = useCallback(async (limit: number, replace: boolean) => {
    if (replace) setLoading(true);
    else setLoadingMore(true);
    try {
      const res = await superAdminApi.getActivity(limit);
      const data: ActivityEntry[] = res.data;
      setEntries(replace ? data : (prev) => [...prev, ...data]);
      if (data.length < limit) setHasMore(false);
    } catch {
      // ignore
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  }, []);

  useEffect(() => {
    fetchEntries(50, true);
  }, [fetchEntries]);

  async function loadMore() {
    const nextLimit = entries.length + 30;
    await fetchEntries(nextLimit, false);
  }

  // client-side filter
  const filtered = entries.filter((e) => {
    if (actionFilter !== "all" && e.action !== actionFilter) return false;
    if (entityFilter !== "all" && e.entity_type !== entityFilter) return false;
    if (search) {
      const q = search.toLowerCase();
      return e.actor_email.toLowerCase().includes(q) || e.action.toLowerCase().includes(q);
    }
    return true;
  });

  const actions = [...new Set(entries.map((e) => e.action))].sort().map((a) => ({ value: a, label: a }));
  const entities = [...new Set(entries.map((e) => e.entity_type))].sort().map((a) => ({ value: a, label: a }));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-headline-md text-xl font-semibold text-foreground">Activity Log</h2>
        <p className="mt-1 text-sm text-muted-foreground">Platform activity across all clients.</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative max-w-xs flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            className="h-10 border-border bg-background pl-10"
            placeholder="Search actor or action..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Select
          value={actionFilter}
          onChange={(e) => setActionFilter(e.target.value)}
          options={[{ value: "all", label: "All actions" }, ...actions]}
          placeholder="All actions"
        />
        <Select
          value={entityFilter}
          onChange={(e) => setEntityFilter(e.target.value)}
          options={[{ value: "all", label: "All entities" }, ...entities]}
          placeholder="All entities"
        />
      </div>

      {/* Table */}
      <div className="overflow-hidden border border-border bg-background">
        {loading ? (
          <div className="space-y-3 p-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="h-10" />
            ))}
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-left">
                <thead>
                  <tr className="border-b border-border bg-background">
                    <th className="text-label-sm px-4 py-3 text-xs font-semibold uppercase tracking-[0.03em] text-muted-foreground">Action</th>
                    <th className="text-label-sm px-4 py-3 text-xs font-semibold uppercase tracking-[0.03em] text-muted-foreground">Entity</th>
                    <th className="text-label-sm px-4 py-3 text-xs font-semibold uppercase tracking-[0.03em] text-muted-foreground">Entity ID</th>
                    <th className="text-label-sm px-4 py-3 text-xs font-semibold uppercase tracking-[0.03em] text-muted-foreground">Actor</th>
                    <th className="text-label-sm px-4 py-3 text-right text-xs font-semibold uppercase tracking-[0.03em] text-muted-foreground">Time</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-12 text-center text-sm text-muted-foreground">
                        <ScrollText className="mx-auto mb-2 size-6 opacity-40" />
                        No activity found.
                      </td>
                    </tr>
                  ) : (
                    filtered.map((entry) => (
                      <tr key={entry.id} className="border-b border-border transition-colors hover:bg-muted">
                        <td className="px-4 py-3">
                          <Badge variant="outline" className={cn("capitalize text-xs", actionBadge(entry.action))}>
                            {entry.action}
                          </Badge>
                        </td>
                        <td className="text-body-md px-4 py-3 text-sm capitalize">{entry.entity_type}</td>
                        <td className="text-body-md px-4 py-3 text-sm text-muted-foreground">#{entry.entity_id}</td>
                        <td className="text-body-md px-4 py-3 text-sm text-muted-foreground">{entry.actor_email}</td>
                        <td className="text-body-md px-4 py-3 text-right text-sm text-muted-foreground">{formatDate(entry.created_at)}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {hasMore && filtered.length === entries.length ? (
              <div className="flex justify-center border-t border-border p-4">
                <Button variant="outline" onClick={loadMore} disabled={loadingMore}>
                  {loadingMore ? <Loader2 className="mr-2 size-4 animate-spin" /> : null}
                  Load more
                </Button>
              </div>
            ) : null}
          </>
        )}
      </div>
    </div>
  );
}