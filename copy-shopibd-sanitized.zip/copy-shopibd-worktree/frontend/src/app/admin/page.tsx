"use client";

import { useEffect, useState } from "react";
import {
  Banknote,
  Building2,
  Store,
  TrendingUp,
  UserPlus,
  ScrollText,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { superAdminApi } from "@/lib/api";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { MetricCard, MetricStrip } from "@/components/layout/page-structure";

interface PlatformStats {
  total_sellers: number;
  active_sellers: number;
  total_shops: number;
  active_shops: number;
  new_signups_7d: number;
  total_revenue: number;
  plan_distribution: Record<string, number>;
}

interface ActivityEntry {
  id: number;
  action: string;
  entity_type: string;
  entity_id: number;
  actor_email: string;
  created_at: string;
}

function formatDate(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleDateString("en-BD", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}

function planBadge(plan: string) {
  const colors: Record<string, string> = {
    free: "border-outline-variant text-muted-foreground bg-muted/30",
    starter: "border-success/35 text-success-foreground bg-success/15",
    business: "border-primary/30 text-primary bg-primary/10",
    enterprise: "border-warning/30 text-warning bg-warning/10",
  };
  return colors[plan] ?? colors.free;
}

export default function AdminDashboardPage() {
  const { user } = useAuth();
  const [stats, setStats] = useState<PlatformStats | null>(null);
  const [activity, setActivity] = useState<ActivityEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        const [statsRes, activityRes] = await Promise.all([
          superAdminApi.getStats(),
          superAdminApi.getActivity(5),
        ]);
        setStats(statsRes.data);
        setActivity(activityRes.data);
      } catch {
        // Silently fail — skeleton stays
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const name = user?.name || "Owner";

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-72" />
        <div className="grid grid-cols-1 gap-6 md:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-36" />
          ))}
        </div>
        <div className="grid grid-cols-1 gap-6 md:grid-cols-12">
          <Skeleton className="h-64 md:col-span-8" />
          <Skeleton className="h-64 md:col-span-4" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-display-lg mb-2 text-4xl font-bold tracking-[-0.02em] text-foreground">
          Welcome back, {name}
        </h1>
        <p className="text-body-lg text-lg text-muted-foreground">
          Here is what&apos;s happening across your platform.
        </p>
      </div>

      {/* Metric cards */}
      <MetricStrip className="gap-4 sm:gap-6 md:grid-cols-4">
        <MetricCard
          index={0}
          value={stats?.total_sellers ?? 0}
          format="number"
          label={<span className="inline-flex items-center gap-1.5"><Building2 className="size-4 text-primary" />Total Clients</span>}
          helper={<span className="inline-flex items-center gap-1 text-primary"><TrendingUp className="size-3.5" />{`${stats?.active_sellers ?? 0} active`}</span>}
        />
        <MetricCard
          index={1}
          value={stats?.active_shops ?? 0}
          format="number"
          label={<span className="inline-flex items-center gap-1.5"><Store className="size-4 text-primary" />Active Shops</span>}
          helper={<span className="inline-flex items-center gap-1 text-primary"><TrendingUp className="size-3.5" />{`${stats?.total_shops ?? 0} total shops`}</span>}
        />
        <MetricCard
          index={2}
          value={stats?.total_revenue ?? 0}
          label={<span className="inline-flex items-center gap-1.5"><Banknote className="size-4 text-primary" />Total Revenue</span>}
          helper={<span className="inline-flex items-center gap-1 text-primary"><TrendingUp className="size-3.5" />All-time platform revenue</span>}
        />
        <MetricCard
          index={3}
          value={stats?.new_signups_7d ?? 0}
          format="number"
          label={<span className="inline-flex items-center gap-1.5"><UserPlus className="size-4 text-primary" />New Signups (7d)</span>}
          helper={<span className="inline-flex items-center gap-1 text-primary"><TrendingUp className="size-3.5" />Last 7 days</span>}
        />
      </MetricStrip>

      {/* Two-column: activity + plan distribution */}
      <div className="grid grid-cols-1 gap-6 md:grid-cols-12">
        {/* Activity feed */}
        <div className="border border-border bg-background p-6 md:col-span-8">
          <div className="mb-6 flex items-center justify-between">
            <h2 className="text-headline-md text-xl font-semibold">Recent Activity</h2>
          </div>
          {activity.length === 0 ? (
            <p className="text-sm text-muted-foreground">No activity recorded yet.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-left">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-label-sm pb-3 text-xs font-semibold uppercase tracking-[0.03em] text-muted-foreground">Action</th>
                    <th className="text-label-sm pb-3 text-xs font-semibold uppercase tracking-[0.03em] text-muted-foreground">Entity</th>
                    <th className="text-label-sm pb-3 text-xs font-semibold uppercase tracking-[0.03em] text-muted-foreground">Actor</th>
                    <th className="text-label-sm pb-3 text-right text-xs font-semibold uppercase tracking-[0.03em] text-muted-foreground">Time</th>
                  </tr>
                </thead>
                <tbody>
                  {activity.map((entry) => (
                    <tr key={entry.id} className="border-b border-border transition-colors hover:bg-muted">
                      <td className="text-body-md py-3 text-sm">{entry.action}</td>
                      <td className="text-body-md py-3 text-sm">
                        <span className="text-muted-foreground">{entry.entity_type}</span> #{entry.entity_id}
                      </td>
                      <td className="text-body-md py-3 text-sm text-muted-foreground">{entry.actor_email}</td>
                      <td className="text-body-md py-3 text-right text-sm text-muted-foreground">{formatDate(entry.created_at)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Plan distribution */}
        <div className="border border-border bg-background p-6 md:col-span-4">
          <h2 className="text-headline-md mb-6 text-xl font-semibold">Plan Distribution</h2>
          {stats?.plan_distribution && Object.keys(stats.plan_distribution).length > 0 ? (
            <ul className="space-y-4">
              {Object.entries(stats.plan_distribution).map(([plan, count]) => (
                <li key={plan} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Badge variant="outline" className={cn("capitalize text-xs", planBadge(plan))}>
                      {plan}
                    </Badge>
                  </div>
                  <span className="text-headline-md text-xl font-semibold">{count}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-muted-foreground">No data yet.</p>
          )}
        </div>
      </div>
    </div>
  );
}
