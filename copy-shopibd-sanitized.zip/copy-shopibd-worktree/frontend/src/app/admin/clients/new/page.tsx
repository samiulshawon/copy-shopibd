"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, Loader2, Check, X } from "lucide-react";
import { superAdminApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function NewClientPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    plan: "free",
    shop_name: "",
    subdomain: "",
    custom_domain: "",
  });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  // Phase 9: live subdomain availability
  const [availability, setAvailability] = useState<{
    status: "idle" | "checking" | "available" | "taken" | "invalid";
    suggestions: string[];
  }>({ status: "idle", suggestions: [] });

  function handleChange(field: string) {
    return (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
      setForm((prev) => ({ ...prev, [field]: e.target.value }));
  }

  function slugify(value: string): string {
    return value
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");
  }

  const effectiveSubdomain =
    form.subdomain || slugify(form.shop_name || form.name) || "client";

  const previewUrl =
    form.plan === "enterprise" && form.custom_domain
      ? `https://${form.custom_domain}`
      : `https://${effectiveSubdomain}.shopibd.com`;

  // Phase 9: debounced availability check whenever the effective subdomain changes.
  useEffect(() => {
    const candidate = effectiveSubdomain;
    if (!candidate || candidate.length < 2) {
      setAvailability({ status: "idle", suggestions: [] });
      return;
    }
    let cancelled = false;
    setAvailability({ status: "checking", suggestions: [] });
    const handle = setTimeout(async () => {
      try {
        const res = await superAdminApi.checkSubdomainAvailable(candidate);
        if (cancelled) return;
        if (res.available) {
          setAvailability({ status: "available", suggestions: [] });
        } else if (res.reason === "invalid" || res.reason === "reserved") {
          setAvailability({ status: "invalid", suggestions: res.suggestions });
        } else {
          setAvailability({ status: "taken", suggestions: res.suggestions });
        }
      } catch {
        if (!cancelled) setAvailability({ status: "idle", suggestions: [] });
      }
    }, 350);
    return () => {
      cancelled = true;
      clearTimeout(handle);
    };
  }, [effectiveSubdomain]);

  function pickSuggestion(s: string) {
    setForm((prev) => ({ ...prev, subdomain: s }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      const res = await superAdminApi.createSeller({
        name: form.name,
        email: form.email,
        phone: form.phone,
        password: form.password,
        shop_name: form.shop_name,
        subdomain: form.subdomain,
        custom_domain: form.plan === "enterprise" ? form.custom_domain : "",
      });
      router.push(`/admin/clients/${res.data.id}`);
    } catch (err: any) {
      const msg = err?.response?.data?.detail || "Failed to create client.";
      setError(msg);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="mx-auto max-w-lg space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild aria-label="Back to clients">
          <Link href="/admin/clients">
            <ArrowLeft className="size-4" />
          </Link>
        </Button>
        <div>
          <h2 className="text-headline-md text-xl font-semibold text-foreground">New client</h2>
          <p className="mt-1 text-sm text-muted-foreground">Create a new seller account.</p>
        </div>
      </div>

      {error ? (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      ) : null}

      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="space-y-2">
          <label htmlFor="name" className="text-label-sm text-sm font-medium text-foreground">
            Full name
          </label>
          <Input
            id="name"
            className="h-10 border-border bg-background"
            placeholder="Client's full name"
            value={form.name}
            onChange={handleChange("name")}
            required
          />
        </div>
        <div className="space-y-2">
          <label htmlFor="email" className="text-label-sm text-sm font-medium text-foreground">
            Email
          </label>
          <Input
            id="email"
            type="email"
            className="h-10 border-border bg-background"
            placeholder="client@example.com"
            value={form.email}
            onChange={handleChange("email")}
            required
          />
        </div>
        <div className="space-y-2">
          <label htmlFor="phone" className="text-label-sm text-sm font-medium text-foreground">
            Phone
          </label>
          <Input
            id="phone"
            className="h-10 border-border bg-background"
            placeholder="01812345678"
            value={form.phone}
            onChange={handleChange("phone")}
            required
          />
        </div>
        <div className="space-y-2">
          <label htmlFor="password" className="text-label-sm text-sm font-medium text-foreground">
            Password
          </label>
          <Input
            id="password"
            type="password"
            className="h-10 border-border bg-background"
            placeholder="Min 8 characters"
            value={form.password}
            onChange={handleChange("password")}
            required
            minLength={8}
          />
        </div>
        <div className="space-y-2">
          <label htmlFor="plan" className="text-label-sm text-sm font-medium text-foreground">
            Plan
          </label>
          <select
            id="plan"
            className="h-10 w-full border border-border bg-background px-3"
            value={form.plan}
            onChange={handleChange("plan")}
          >
            <option value="free">Free</option>
            <option value="starter">Starter</option>
            <option value="business">Business</option>
            <option value="enterprise">Enterprise</option>
          </select>
        </div>
        <div className="space-y-2">
          <label htmlFor="shop_name" className="text-label-sm text-sm font-medium text-foreground">
            Shop name
          </label>
          <Input
            id="shop_name"
            className="h-10 border-border bg-background"
            placeholder="Client's Shop"
            value={form.shop_name}
            onChange={handleChange("shop_name")}
          />
        </div>
        <div className="space-y-2">
          <label htmlFor="subdomain" className="text-label-sm text-sm font-medium text-foreground">
            Subdomain
          </label>
          <div className="relative">
            <Input
              id="subdomain"
              className="h-10 border-border bg-background pr-10"
              placeholder="client-shop"
              value={form.subdomain}
              onChange={handleChange("subdomain")}
            />
            {availability.status === "checking" ? (
              <Loader2 className="absolute right-3 top-1/2 size-4 -translate-y-1/2 animate-spin text-muted-foreground" />
            ) : availability.status === "available" ? (
              <Check className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-primary" />
            ) : availability.status === "taken" || availability.status === "invalid" ? (
              <X className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-destructive" />
            ) : null}
          </div>
          <p className="text-xs text-muted-foreground">
            Leave blank to auto-generate from shop name. Resolves at {effectiveSubdomain}.shopibd.com
          </p>
          {availability.status === "available" ? (
            <p className="text-xs text-primary">
              &ldquo;{availability.status === "available" ? effectiveSubdomain : ""}&rdquo; is available.
            </p>
          ) : null}
          {availability.status === "taken" && availability.suggestions.length > 0 ? (
            <div className="space-y-1">
              <p className="text-xs text-destructive">
                &ldquo;{effectiveSubdomain}&rdquo; is taken. Suggestions:
              </p>
              <div className="flex flex-wrap gap-2">
                {availability.suggestions.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => pickSuggestion(s)}
                    className="border border-border bg-background px-2 py-1 text-xs text-foreground hover:bg-secondary"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : null}
          {availability.status === "invalid" ? (
            <p className="text-xs text-destructive">
              Invalid or reserved subdomain. Use lowercase letters, numbers, and hyphens.
            </p>
          ) : null}
        </div>
        {form.plan === "enterprise" ? (
          <div className="space-y-2">
            <label htmlFor="custom_domain" className="text-label-sm text-sm font-medium text-foreground">
              Custom domain
            </label>
            <Input
              id="custom_domain"
              className="h-10 border-border bg-background"
              placeholder="clienta.com"
              value={form.custom_domain}
              onChange={handleChange("custom_domain")}
            />
            <p className="text-xs text-muted-foreground">
              Requires Enterprise plan. e.g. clienta.com
            </p>
          </div>
        ) : null}
        <div className="space-y-2">
          <span className="text-label-sm text-sm font-medium text-foreground">Storefront URL</span>
          <div className="border border-border bg-background px-3 py-2 text-sm">
            <span className="break-all text-primary">{previewUrl}</span>
          </div>
        </div>
        <div className="flex gap-3 pt-2">
          <Button type="submit" disabled={submitting} className="flex-1">
            {submitting ? <Loader2 className="mr-2 size-4 animate-spin" /> : null}
            Create client
          </Button>
          <Button variant="outline" asChild>
            <Link href="/admin/clients">Cancel</Link>
          </Button>
        </div>
      </form>
    </div>
  );
}