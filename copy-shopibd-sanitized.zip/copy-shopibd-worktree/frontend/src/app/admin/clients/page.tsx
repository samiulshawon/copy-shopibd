"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Check, MoreHorizontal, Plus, Search, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { superAdminApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Select } from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface SellerItem {
  id: number;
  name: string;
  email: string;
  phone: string;
  plan: string;
  is_active: boolean;
  is_super_admin?: boolean;
}

function planBadge(plan: string) {
  const colors: Record<string, string> = {
    free: "border-outline-variant text-muted-foreground bg-muted/30",
    starter: "border-success/35 text-success-foreground bg-success/15",
    business: "border-primary/30 text-primary bg-primary/10",
    enterprise: "border-warning/30 text-warning bg-warning/10",
  };
  return colors[plan] ?? colors.free;
}

export default function ClientsPage() {
  const [sellers, setSellers] = useState<SellerItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [planFilter, setPlanFilter] = useState("all");

  const fetchSellers = useCallback(async () => {
    try {
      const res = await superAdminApi.getSellers();
      setSellers(res.data);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchSellers();
  }, [fetchSellers]);

  async function toggleActive(seller: SellerItem) {
    try {
      if (seller.is_active) {
        await superAdminApi.deactivateSeller(seller.id);
      } else {
        await superAdminApi.activateSeller(seller.id);
      }
      setSellers((prev) =>
        prev.map((s) => (s.id === seller.id ? { ...s, is_active: !s.is_active } : s)),
      );
    } catch {
      // ignore
    }
  }

  const filtered = sellers.filter((s) => {
    if (s.is_super_admin) return false; // hide super admins from client list
    if (planFilter !== "all" && s.plan !== planFilter) return false;
    if (search) {
      const q = search.toLowerCase();
      return s.name.toLowerCase().includes(q) || s.email.toLowerCase().includes(q);
    }
    return true;
  });

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-14" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-headline-md text-xl font-semibold text-foreground">Clients</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {filtered.length} client{filtered.length !== 1 ? "s" : ""}
          </p>
        </div>
        <Button asChild>
          <Link href="/admin/clients/new">
            <Plus className="mr-2 size-4" />
            Add client
          </Link>
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative max-w-sm flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            className="h-10 border-border bg-background pl-10"
            placeholder="Search by name or email..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Select
          value={planFilter}
          onChange={(e) => setPlanFilter(e.target.value)}
          options={[
            { value: "all", label: "All plans" },
            { value: "free", label: "Free" },
            { value: "starter", label: "Starter" },
            { value: "business", label: "Business" },
            { value: "enterprise", label: "Enterprise" },
          ]}
          placeholder="Select plan"
        />
      </div>

      {/* Table */}
      <div className="overflow-hidden border border-border bg-background">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left">
            <thead>
              <tr className="border-b border-border bg-background">
                <th className="text-label-sm px-4 py-3 text-xs font-semibold uppercase tracking-[0.03em] text-muted-foreground">Name</th>
                <th className="text-label-sm px-4 py-3 text-xs font-semibold uppercase tracking-[0.03em] text-muted-foreground">Email</th>
                <th className="text-label-sm hidden px-4 py-3 text-xs font-semibold uppercase tracking-[0.03em] text-muted-foreground sm:table-cell">Phone</th>
                <th className="text-label-sm px-4 py-3 text-xs font-semibold uppercase tracking-[0.03em] text-muted-foreground">Plan</th>
                <th className="text-label-sm px-4 py-3 text-xs font-semibold uppercase tracking-[0.03em] text-muted-foreground">Status</th>
                <th className="text-label-sm px-4 py-3 text-right text-xs font-semibold uppercase tracking-[0.03em] text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-sm text-muted-foreground">
                    No clients found.{" "}
                    <Link href="/admin/clients/new" className="text-primary hover:underline">
                      Create your first client.
                    </Link>
                  </td>
                </tr>
              ) : (
                filtered.map((seller) => (
                  <tr key={seller.id} className="border-b border-border transition-colors hover:bg-muted">
                    <td className="text-body-md px-4 py-3 text-sm font-medium">{seller.name}</td>
                    <td className="text-body-md px-4 py-3 text-sm text-muted-foreground">{seller.email}</td>
                    <td className="text-body-md hidden px-4 py-3 text-sm text-muted-foreground sm:table-cell">{seller.phone}</td>
                    <td className="px-4 py-3">
                      <Badge variant="outline" className={cn("capitalize text-xs", planBadge(seller.plan))}>
                        {seller.plan}
                      </Badge>
                    </td>
                    <td className="px-4 py-3">
                      <Badge
                        variant="outline"
                        className={cn(
                          "capitalize text-xs",
                          seller.is_active
                            ? "border-primary/30 text-primary bg-primary/10"
                            : "border-outline-variant text-muted-foreground bg-muted/30",
                        )}
                      >
                        {seller.is_active ? "Active" : "Inactive"}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="size-8" aria-label="Client actions">
                            <MoreHorizontal className="size-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem asChild>
                            <Link href={`/admin/clients/${seller.id}`}>Edit</Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => toggleActive(seller)}>
                            {seller.is_active ? (
                              <>
                                <X className="mr-2 size-4" /> Deactivate
                              </>
                            ) : (
                              <>
                                <Check className="mr-2 size-4" /> Activate
                              </>
                            )}
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}