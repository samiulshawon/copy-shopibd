"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import {
  ArrowLeft,
  Check,
  Loader2,
  ShieldOff,
  ShieldCheck,
  Store,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { superAdminApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Select } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface ClientDetail {
  id: number;
  name: string;
  email: string;
  phone: string;
  plan: string;
  is_active: boolean;
  is_verified: boolean;
  max_products: number;
  max_orders: number;
  shop_subdomain?: string | null;
  shop_custom_domain?: string | null;
  custom_domain_grace_until?: string | null;
}

const PLANS: Record<string, { label: string; max_products: number; max_orders: number }> = {
  free: { label: "Free", max_products: 50, max_orders: 200 },
  starter: { label: "Starter", max_products: 200, max_orders: 1000 },
  business: { label: "Business", max_products: 1000, max_orders: 5000 },
  enterprise: { label: "Enterprise", max_products: 5000, max_orders: 25000 },
};

function planBadge(plan: string) {
  const colors: Record<string, string> = {
    free: "border-outline-variant text-muted-foreground bg-muted/30",
    starter: "border-success/35 text-success-foreground bg-success/15",
    business: "border-primary/30 text-primary bg-primary/10",
    enterprise: "border-warning/30 text-warning bg-warning/10",
  };
  return colors[plan] ?? colors.free;
}

export default function ClientDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const id = Number(params.id);

  const [client, setClient] = useState<ClientDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [impersonating, setImpersonating] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Form state
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [selectedPlan, setSelectedPlan] = useState("");

  useEffect(() => {
    async function load() {
      try {
        const res = await superAdminApi.getSellers();
        const found = res.data.find((s: any) => s.id === id);
        if (found) {
          setClient(found);
          setName(found.name);
          setPhone(found.phone);
          setSelectedPlan(found.plan);
        }
      } catch {
        setError("Failed to load client.");
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [id]);

  async function saveProfile() {
    setSaving(true);
    setError("");
    setSuccess("");
    try {
      const res = await superAdminApi.updateSeller(id, { name, phone });
      setClient(res.data);
      setSuccess("Profile updated.");
    } catch (err: any) {
      setError(err?.response?.data?.detail || "Failed to update.");
    } finally {
      setSaving(false);
    }
  }

  async function toggleActive() {
    try {
      if (client?.is_active) {
        const res = await superAdminApi.deactivateSeller(id);
        setClient(res.data);
      } else {
        const res = await superAdminApi.activateSeller(id);
        setClient(res.data);
      }
    } catch {
      setError("Failed to change status.");
    }
  }

  async function upgradePlan() {
    if (selectedPlan === client?.plan) return;
    setSaving(true);
    setError("");
    setSuccess("");
    try {
      const res = await superAdminApi.overrideSubscription(id, { plan: selectedPlan });
      setClient((prev) =>
        prev
          ? {
              ...prev,
              plan: selectedPlan,
              max_products: res.data.max_products,
              max_orders: res.data.max_orders,
            }
          : prev,
      );
      setSuccess(`Plan upgraded to ${PLANS[selectedPlan]?.label ?? selectedPlan}.`);
    } catch (err: any) {
      setError(err?.response?.data?.detail || "Failed to upgrade plan.");
    } finally {
      setSaving(false);
    }
  }

  async function impersonateClient() {
    if (!client) return;
    setImpersonating(true);
    setError("");
    try {
      const res = await superAdminApi.impersonateSeller(id, {
        reason: `Support: ${client.name}`,
      });
      const token: string | undefined = res?.data?.access_token;
      if (!token) {
        setError("Impersonation token missing in response.");
        return;
      }
      // Persist token in sessionStorage so the impersonated session can be
      // restored on reload. Clearing on session end is the user's choice.
      try {
        window.sessionStorage.setItem("impersonation_token", token);
        window.sessionStorage.setItem("impersonated_seller", String(client.id));
      } catch {
        // sessionStorage may be unavailable (SSR / private browsing).
      }
      setSuccess(
        `Impersonation token issued for ${client.email}. The next request to /dashboard will use this token until it expires (15 min).`,
      );
    } catch (err: any) {
      setError(err?.response?.data?.detail || "Failed to issue impersonation token.");
    } finally {
      setImpersonating(false);
    }
  }

  if (loading) {
    return (
      <div className="mx-auto max-w-3xl space-y-6">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-64" />
        <Skeleton className="h-64" />
      </div>
    );
  }

  if (!client) {
    return (
      <div className="mx-auto max-w-lg py-12 text-center">
        <p className="text-muted-foreground">Client not found.</p>
        <Button variant="outline" asChild className="mt-4">
          <Link href="/admin/clients">Back to clients</Link>
        </Button>
      </div>
    );
  }

  const planChanged = selectedPlan !== client.plan;

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      {/* Back */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild aria-label="Back to clients">
          <Link href="/admin/clients">
            <ArrowLeft className="size-4" />
          </Link>
        </Button>
        <div>
          <h2 className="text-headline-md text-xl font-semibold text-foreground">{client.name}</h2>
          <p className="mt-1 text-sm text-muted-foreground">{client.email}</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <Badge
            variant="outline"
            className={cn(
              "capitalize text-xs",
              client.is_active
                ? "border-primary/30 text-primary bg-primary/10"
                : "border-outline-variant text-muted-foreground bg-muted/30",
            )}
          >
            {client.is_active ? "Active" : "Inactive"}
          </Badge>
          <Badge variant="outline" className={cn("capitalize text-xs", planBadge(client.plan))}>
            {client.plan}
          </Badge>
          {client.shop_subdomain ? (
            <Button variant="outline" size="sm" asChild>
              <Link href={`/shop/${client.shop_subdomain}`} target="_blank" rel="noopener noreferrer">
                <Store className="mr-2 size-4" /> Visit store
              </Link>
            </Button>
          ) : null}
          <Button
            variant="secondary"
            size="sm"
            onClick={impersonateClient}
            disabled={impersonating}
          >
            {impersonating ? <Loader2 className="mr-2 size-4 animate-spin" /> : <ShieldCheck className="mr-2 size-4" />}
            View as client
          </Button>
        </div>
      </div>

      {error ? (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      ) : null}
      {success ? (
        <Alert>
          <Check className="size-4" />
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      ) : null}
      {client.shop_custom_domain && client.custom_domain_grace_until ? (
        (() => {
          const graceDate = new Date(client.custom_domain_grace_until);
          const now = new Date();
          const daysLeft = Math.max(
            0,
            Math.ceil((graceDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)),
          );
          if (daysLeft <= 0) return null;
          return (
            <Alert variant="default" className="border-warning/40 bg-warning/10 text-warning">
              <ShieldOff className="size-4" />
              <AlertDescription>
                Plan was downgraded — custom domain{" "}
                <span className="font-semibold">{client.shop_custom_domain}</span>{" "}
                stays live for <span className="font-semibold">{daysLeft} day{daysLeft === 1 ? "" : "s"}</span>{" "}
                (grace ends {graceDate.toLocaleDateString()}). Upgrade the plan to keep it after that.
              </AlertDescription>
            </Alert>
          );
        })()
      ) : null}

      {/* Profile card */}
      <div className="border border-border bg-background p-6">
        <h3 className="text-headline-md mb-5 text-lg font-semibold">Profile</h3>
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
          <div className="space-y-2">
            <label className="text-label-sm text-sm font-medium text-foreground">Name</label>
            <Input
              className="h-10 border-border bg-background"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <label className="text-label-sm text-sm font-medium text-foreground">Phone</label>
            <Input
              className="h-10 border-border bg-background"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>
        </div>
        <div className="mt-6 flex items-center gap-3 border-t border-border pt-6">
          <Button onClick={saveProfile} disabled={saving}>
            {saving ? <Loader2 className="mr-2 size-4 animate-spin" /> : null}
            Save changes
          </Button>
          <Button variant="outline" onClick={toggleActive}>
            {client.is_active ? (
              <>
                <X className="mr-2 size-4" /> Deactivate
              </>
            ) : (
              <>
                <Check className="mr-2 size-4" /> Activate
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Subscription manager */}
      <div className="border border-border bg-background p-6">
        <div className="mb-5 flex items-center justify-between">
          <h3 className="text-headline-md text-lg font-semibold">Subscription</h3>
          <Badge variant="outline" className={cn("capitalize text-xs", planBadge(client.plan))}>
            Current: {client.plan}
          </Badge>
        </div>

        <div className="mb-6 space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-label-sm text-sm font-medium text-foreground">Change plan</label>
            <Select
              value={selectedPlan}
              onChange={(e) => setSelectedPlan(e.target.value)}
              options={[
                { value: "free", label: "Free" },
                { value: "starter", label: "Starter" },
                { value: "business", label: "Business" },
                { value: "enterprise", label: "Enterprise" },
              ]}
              placeholder="Select plan"
            />
          </div>

          {planChanged ? (
            <div className="border border-primary/20 bg-primary/5 p-4">
              <p className="text-sm text-foreground">
                Changing from <strong className="capitalize">{client.plan}</strong> to{" "}
                <strong>{PLANS[selectedPlan]?.label ?? selectedPlan}</strong>.
              </p>
              <ul className="mt-2 space-y-1 text-xs text-muted-foreground">
                <li>
                  Max products: {client.max_products} → {PLANS[selectedPlan]?.max_products ?? "?"}
                </li>
                <li>
                  Max orders: {client.max_orders} → {PLANS[selectedPlan]?.max_orders ?? "?"}
                </li>
              </ul>
            </div>
          ) : null}

          <div className="mt-2 flex justify-between text-sm">
            <span className="text-muted-foreground">Max products</span>
            <span className="font-medium">{client.max_products}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Max orders</span>
            <span className="font-medium">{client.max_orders}</span>
          </div>
        </div>

        <div className="border-t border-border pt-4">
          <Button onClick={upgradePlan} disabled={!planChanged || saving} className="w-full">
            {saving ? <Loader2 className="mr-2 size-4 animate-spin" /> : null}
            {planChanged
              ? `Change to ${PLANS[selectedPlan]?.label ?? selectedPlan}`
              : "No plan changes"}
          </Button>
          <p className="mt-2 text-center text-xs text-muted-foreground">
            This bypasses payment. The client&apos;s plan and limits update immediately.
          </p>
        </div>
      </div>
    </div>
  );
}