import Link from "next/link";
import { ArrowRight, BarChart3, CreditCard, Globe, HeadphonesIcon, Shield, Store, Users, Zap } from "lucide-react";
import { PromotionStrip } from "@/components/layout/promotion-strip";
import { Button } from "@/components/ui/button";

const FEATURES = [
  { icon: Store, title: "Your store, ready to sell", description: "Launch a seller-led storefront with your products, delivery details, and direct order flow." },
  { icon: CreditCard, title: "Bangladesh-ready payments", description: "Give customers the payment choices they already use, including cash on delivery." },
  { icon: BarChart3, title: "Operate with clarity", description: "Keep products, orders, customers, and growth signals together in one merchant workspace." },
  { icon: HeadphonesIcon, title: "Built for local teams", description: "Use Bengali- and English-ready commerce tools without a complicated setup." },
];

const STEPS = [
  { number: "01", title: "Open your account", description: "Create an account and begin setting up your merchant workspace." },
  { number: "02", title: "Build your catalog", description: "Add products, delivery rules, payment methods, and your shop identity." },
  { number: "03", title: "Share and sell", description: "Publish your storefront link and manage incoming orders from one place." },
];

const TRUST = [
  { icon: Shield, value: "Seller-led", label: "Your identity stays visible" },
  { icon: Globe, value: "Bangladesh-ready", label: "Commerce for local customers" },
  { icon: Zap, value: "Fast setup", label: "Start with the essentials" },
  { icon: Users, value: "Team-ready", label: "Grow merchant operations" },
];

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <PromotionStrip />
      <section className="border-b border-foreground">
        <div className="container-bd grid min-h-[560px] items-end gap-10 py-16 sm:py-24 lg:grid-cols-[1.35fr_0.65fr] lg:py-28">
          <div className="max-w-3xl">
            <p className="mb-5 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">ShopiBD commerce platform</p>
            <h1 className="max-w-3xl text-5xl font-bold leading-[0.95] tracking-tight text-foreground sm:text-6xl lg:text-7xl">Build a storefront.<br />Run the business.</h1>
            <p className="mt-6 max-w-xl text-base leading-7 text-muted-foreground sm:text-lg">ShopiBD gives Bangladeshi merchants a direct path from catalog to customer order—without adding operational complexity.</p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Button size="lg" asChild><Link href="/auth/register">Open your shop <ArrowRight className="size-4" /></Link></Button>
              <Button size="lg" variant="outline" asChild><Link href="/pricing">See plans</Link></Button>
            </div>
          </div>
          <aside className="border border-foreground bg-foreground p-6 text-primary-foreground sm:p-8">
            <p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-primary-foreground/60">Merchant essentials</p>
            <ul className="mt-6 space-y-4 border-t border-primary-foreground/30 pt-5 text-sm leading-6">
              <li>Storefront, products, and direct orders</li><li>Delivery and payment configuration</li><li>Order operations and customer management</li><li>Plans that scale with your business</li>
            </ul>
          </aside>
        </div>
      </section>

      <section className="border-b border-border py-16 sm:py-24"><div className="container-bd"><div className="mb-10 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between"><div><p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">Commerce, not clutter</p><h2 className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">The tools that move your shop forward.</h2></div><p className="max-w-md text-sm leading-6 text-muted-foreground">A sharp, practical platform for the work merchants perform every day.</p></div><div className="grid border-l border-t border-border sm:grid-cols-2 lg:grid-cols-4">{FEATURES.map((feature) => <article key={feature.title} className="border-b border-r border-border p-5 sm:p-6"><feature.icon className="size-5" /><h3 className="mt-8 text-base font-semibold">{feature.title}</h3><p className="mt-2 text-sm leading-6 text-muted-foreground">{feature.description}</p></article>)}</div></div></section>

      <section className="py-16 sm:py-24"><div className="container-bd"><p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">Launch sequence</p><div className="mt-5 grid gap-8 lg:grid-cols-[0.8fr_1.2fr]"><h2 className="text-3xl font-bold tracking-tight sm:text-4xl">From first product to first order.</h2><div className="grid border-l border-t border-border sm:grid-cols-3">{STEPS.map((step) => <article key={step.number} className="border-b border-r border-border p-5"><p className="text-xs font-bold text-destructive">{step.number}</p><h3 className="mt-8 font-semibold">{step.title}</h3><p className="mt-2 text-sm leading-6 text-muted-foreground">{step.description}</p></article>)}</div></div></div></section>

      <section className="border-y border-border bg-muted py-12"><div className="container-bd grid grid-cols-2 border-l border-t border-border sm:grid-cols-4">{TRUST.map((item) => <div key={item.label} className="border-b border-r border-border p-4 sm:p-5"><item.icon className="size-4" /><p className="mt-6 text-sm font-semibold">{item.value}</p><p className="mt-1 text-xs text-muted-foreground">{item.label}</p></div>)}</div></section>

      <section className="py-20 text-center sm:py-28"><div className="container-bd"><h2 className="mx-auto max-w-2xl text-3xl font-bold tracking-tight sm:text-4xl">Open the next chapter of your shop.</h2><p className="mx-auto mt-4 max-w-xl text-sm leading-6 text-muted-foreground">Start with a focused storefront and add the operational depth your business needs.</p><Button className="mt-8" size="lg" asChild><Link href="/auth/register">Create free account <ArrowRight className="size-4" /></Link></Button></div></section>
    </main>
  );
}
