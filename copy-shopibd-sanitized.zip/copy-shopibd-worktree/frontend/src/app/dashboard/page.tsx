import { Metadata } from "next";
import { redirect } from "next/navigation";
import { getServerSession } from "@/lib/auth";
import DashboardHomeClient from "./page-client";

export const metadata: Metadata = {
  title: "Dashboard | ShopiBD",
  description: "Operational summary for your shop — orders, revenue, alerts, and quick actions.",
};

export default async function DashboardHomePage() {
  const session = await getServerSession();
  if (!session) {
    redirect("/auth/login");
  }

  return <DashboardHomeClient />;
}
