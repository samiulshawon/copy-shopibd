"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  AlertCircle,
  ArrowRight,
  Banknote,
  CheckCircle2,
  ClipboardList,
  CreditCard,
  FileScan,
  Hash,
  Inbox,
  Link2,
  Loader2,
  Phone,
  RefreshCw,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Wallet,
  X,
  XCircle,
} from "lucide-react";

import { paymentApi, dashboardApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Select } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { cn, formatCurrency } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  MetricCard,
  MetricStrip,
  PageActions,
  PageDescription,
  PageEyebrow,
  PageFrame,
  PageHeader,
  PageHeaderContent,
  PageTitle,
  SectionDescription,
  SectionHeader,
  SectionTitle,
  SurfaceSection,
} from "@/components/layout/page-structure";
import type { OrderListItem } from "@/types/order";
import type {
  PaymentFilters,
  PaymentMethod,
  PaymentStatus,
  PaymentTransactionCreate,
  PaymentTransactionListItem,
  ParsedSmsData,
  MatchSuggestion,
  ReconciliationSummary,
} from "@/types/payment";

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const PAGE_SIZE = 20;

const METHOD_OPTIONS: { value: PaymentMethod | ""; label: string }[] = [
  { value: "", label: "All methods" },
  { value: "bkash", label: "bKash" },
  { value: "nagad", label: "Nagad" },
  { value: "rocket", label: "Rocket" },
  { value: "cod", label: "Cash on Delivery" },
  { value: "bank", label: "Bank" },
];

const STATUS_OPTIONS: { value: PaymentStatus | ""; label: string }[] = [
  { value: "", label: "All statuses" },
  { value: "pending", label: "Pending" },
  { value: "verified", label: "Verified" },
  { value: "mismatched", label: "Mismatched" },
  { value: "unmatched", label: "Unmatched" },
];

const METHOD_ICON: Record<PaymentMethod, React.ComponentType<{ className?: string }>> = {
  bkash: Wallet,
  nagad: Wallet,
  rocket: Wallet,
  cod: Banknote,
  bank: CreditCard,
};

const METHOD_BADGE: Record<PaymentMethod, "default" | "info" | "secondary" | "warning" | "outline"> = {
  bkash: "default",
  nagad: "info",
  rocket: "secondary",
  cod: "warning",
  bank: "outline",
};

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function statusBadgeVariant(
  status: PaymentStatus,
): "default" | "success" | "warning" | "destructive" | "secondary" | "info" {
  switch (status) {
    case "verified":
      return "success";
    case "unmatched":
      return "destructive";
    case "pending":
      return "warning";
    case "mismatched":
      return "info";
    default:
      return "secondary";
  }
}

function statusLabel(status: PaymentStatus): string {
  return status.charAt(0).toUpperCase() + status.slice(1);
}

function methodLabel(method: PaymentMethod): string {
  if (method === "cod") return "COD";
  return method.charAt(0).toUpperCase() + method.slice(1);
}

function formatAmount(value: number | null | undefined): string {
  if (value == null) return "—";
  return formatCurrency(value);
}

function formatDate(dateStr: string | null | undefined): string {
  if (!dateStr) return "—";
  return new Date(dateStr).toLocaleString("en-BD", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function formatShortDate(dateStr: string | null | undefined): string {
  if (!dateStr) return "—";
  return new Date(dateStr).toLocaleDateString("en-BD", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

// ---------------------------------------------------------------------------
// Subcomponents
// ---------------------------------------------------------------------------

function PaymentsSummary({
  reconciliation,
}: {
  reconciliation: ReconciliationSummary | null;
}) {
  const stats = useMemo(() => {
    if (!reconciliation) {
      return {
        total: "—",
        totalAmount: "—",
        matched: "—",
        matchedAmount: "—",
        unmatched: "—",
        unmatchedAmount: "—",
        pending: "—",
        pendingAmount: "—",
      };
    }
    return {
      total: reconciliation.total_transactions.toLocaleString(),
      totalAmount: formatAmount(reconciliation.total_amount),
      matched: reconciliation.matched.toLocaleString(),
      matchedAmount: formatAmount(reconciliation.matched_amount),
      unmatched: reconciliation.unmatched.toLocaleString(),
      unmatchedAmount: formatAmount(reconciliation.unmatched_amount),
      pending: reconciliation.pending.toLocaleString(),
      pendingAmount: formatAmount(reconciliation.pending_amount),
    };
  }, [reconciliation]);

  return (
    <MetricStrip>
      <MetricCard>
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 space-y-1">
            <p className="text-sm font-medium text-muted-foreground">Total transactions</p>
            <p className="text-2xl font-semibold tracking-tight text-foreground">
              {stats.total}
            </p>
            <p className="text-xs text-muted-foreground">{stats.totalAmount} processed</p>
          </div>
          <div className="flex size-9 shrink-0 items-center justify-center border border-border/80 bg-primary/10 text-primary">
            <ClipboardList className="size-4" />
          </div>
        </div>
      </MetricCard>

      <MetricCard>
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 space-y-1">
            <p className="text-sm font-medium text-muted-foreground">Verified</p>
            <p className="text-2xl font-semibold tracking-tight text-success">
              {stats.matched}
            </p>
            <p className="text-xs text-muted-foreground">{stats.matchedAmount} matched</p>
          </div>
          <div className="flex size-9 shrink-0 items-center justify-center border border-border/80 bg-success/10 text-success">
            <CheckCircle2 className="size-4" />
          </div>
        </div>
      </MetricCard>

      <MetricCard>
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 space-y-1">
            <p className="text-sm font-medium text-muted-foreground">Unmatched</p>
            <p className="text-2xl font-semibold tracking-tight text-destructive">
              {stats.unmatched}
            </p>
            <p className="text-xs text-muted-foreground">{stats.unmatchedAmount} need review</p>
          </div>
          <div className="flex size-9 shrink-0 items-center justify-center border border-border/80 bg-destructive/10 text-destructive">
            <XCircle className="size-4" />
          </div>
        </div>
      </MetricCard>

      <MetricCard>
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 space-y-1">
            <p className="text-sm font-medium text-muted-foreground">Pending</p>
            <p className="text-2xl font-semibold tracking-tight text-warning">
              {stats.pending}
            </p>
            <p className="text-xs text-muted-foreground">{stats.pendingAmount} awaiting</p>
          </div>
          <div className="flex size-9 shrink-0 items-center justify-center border border-border/80 bg-warning/10 text-warning">
            <Loader2 className="size-4" />
          </div>
        </div>
      </MetricCard>
    </MetricStrip>
  );
}

function PaymentsLoadingState() {
  return (
    <PageFrame>
      <PageHeader>
        <PageHeaderContent>
          <PageEyebrow>Payments &amp; reconciliation</PageEyebrow>
          <PageTitle>Payments workspace</PageTitle>
          <PageDescription>Loading transactions and reconciliation status…</PageDescription>
        </PageHeaderContent>
      </PageHeader>
      <MetricStrip>
        {[1, 2, 3, 4].map((i) => (
          <MetricCard key={i}>
            <Skeleton className="h-3 w-24" />
            <Skeleton className="mt-3 h-7 w-32" />
            <Skeleton className="mt-2 h-3 w-20" />
          </MetricCard>
        ))}
      </MetricStrip>
      <SurfaceSection className="space-y-3">
        <Skeleton className="h-4 w-40" />
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
      </SurfaceSection>
    </PageFrame>
  );
}

function PaymentsEmptyState({
  hasFilters,
  onClear,
}: {
  hasFilters: boolean;
  onClear: () => void;
}) {
  return (
    <SurfaceSection className="text-center">
      <div className="mx-auto flex max-w-md flex-col items-center gap-4 py-6">
        <div className="flex size-14 items-center justify-center border border-border/80 bg-muted/40 text-muted-foreground">
          <Inbox className="size-6" />
        </div>
        <div className="space-y-2">
          <SectionTitle>No transactions found</SectionTitle>
          <SectionDescription>
            {hasFilters
              ? "Try adjusting the filters to see more results."
              : "Parsed bKash or Nagad SMS messages will appear here once you save them."}
          </SectionDescription>
        </div>
        {hasFilters ? (
          <Button variant="outline" onClick={onClear}>
            Clear filters
          </Button>
        ) : null}
      </div>
    </SurfaceSection>
  );
}

function TransactionCard({
  tx,
  onMatch,
  onUnmatch,
  isUnmatching,
}: {
  tx: PaymentTransactionListItem;
  onMatch: () => void;
  onUnmatch: () => void;
  isUnmatching: boolean;
}) {
  const MethodIcon = METHOD_ICON[tx.payment_method];
  const isVerified = tx.status === "verified";

  return (
    <div className="border border-border/80 bg-background/70 p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 space-y-1">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Hash className="size-3" />
            <span className="font-mono">#{tx.id}</span>
            <span>·</span>
            <span>{formatShortDate(tx.created_at)}</span>
          </div>
          <p className="text-xl font-semibold tracking-tight text-foreground">
            {formatAmount(tx.amount)}
          </p>
        </div>
        <Badge variant={statusBadgeVariant(tx.status)} className="shrink-0 capitalize">
          {statusLabel(tx.status)}
        </Badge>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-3 text-sm">
        <div className="space-y-0.5">
          <p className="text-[11px] uppercase tracking-wide text-muted-foreground">Method</p>
          <Badge variant={METHOD_BADGE[tx.payment_method]} className="gap-1">
            <MethodIcon className="size-3" />
            {methodLabel(tx.payment_method)}
          </Badge>
        </div>
        <div className="space-y-0.5">
          <p className="text-[11px] uppercase tracking-wide text-muted-foreground">Sender</p>
          <p className="flex items-center gap-1 truncate font-medium text-foreground">
            <Phone className="size-3 text-muted-foreground" />
            {tx.sender_phone || "—"}
          </p>
        </div>
        <div className="col-span-2 space-y-0.5">
          <p className="text-[11px] uppercase tracking-wide text-muted-foreground">
            Reference
          </p>
          <p className="truncate font-mono text-xs text-foreground">
            {tx.reference || "—"}
          </p>
        </div>
        {tx.matched_order_id ? (
          <div className="col-span-2 space-y-0.5">
            <p className="text-[11px] uppercase tracking-wide text-muted-foreground">
              Matched order
            </p>
            <p className="flex items-center gap-1 font-medium text-success">
              <Link2 className="size-3" /> #{tx.matched_order_id}
            </p>
          </div>
        ) : null}
      </div>

      <div className="mt-4 flex items-center gap-2">
        {isVerified ? (
          <Button
            size="sm"
            variant="outline"
            className="flex-1"
            onClick={onUnmatch}
            disabled={isUnmatching}
          >
            {isUnmatching ? (
              <Loader2 className="mr-1.5 size-3.5 animate-spin" />
            ) : (
              <X className="mr-1.5 size-3.5" />
            )}
            Unmatch
          </Button>
        ) : (
          <Button
            size="sm"
            className="flex-1"
            onClick={onMatch}
          >
            <Link2 className="mr-1.5 size-3.5" />
            Match to order
          </Button>
        )}
      </div>
    </div>
  );
}

function SuggestionCard({
  suggestion,
  onAccept,
  isAccepting,
}: {
  suggestion: MatchSuggestion;
  onAccept: () => void;
  isAccepting: boolean;
}) {
  const MethodIcon = METHOD_ICON[suggestion.transaction_method];
  const highConfidence = suggestion.confidence >= 80;

  return (
    <div
      className={cn(
        "border bg-background/70 p-4",
        highConfidence ? "border-success/30" : "border-warning/30",
      )}
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0 space-y-2">
          <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
            <Hash className="size-3" />
            <span className="font-mono">TX #{suggestion.transaction_id}</span>
            <ArrowRight className="size-3" />
            <span className="font-mono">Order #{suggestion.order_number}</span>
          </div>
          <p className="text-base font-semibold text-foreground">
            {suggestion.customer_name}{" "}
            <span className="text-sm font-normal text-muted-foreground">
              ({suggestion.customer_phone})
            </span>
          </p>
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant={METHOD_BADGE[suggestion.transaction_method]} className="gap-1">
              <MethodIcon className="size-3" />
              {methodLabel(suggestion.transaction_method)}
            </Badge>
            <Badge variant="outline" className="font-mono">
              TX: {formatAmount(suggestion.transaction_amount)}
            </Badge>
            <Badge variant="outline" className="font-mono">
              Order: {formatAmount(suggestion.order_amount)}
            </Badge>
            <Badge variant={highConfidence ? "success" : "warning"} className="gap-1">
              <Sparkles className="size-3" />
              {suggestion.confidence}% match
            </Badge>
          </div>
          {suggestion.match_reasons.length > 0 ? (
            <ul className="space-y-1 text-xs text-muted-foreground">
              {suggestion.match_reasons.map((reason, i) => (
                <li key={i} className="flex items-start gap-1.5">
                  <CheckCircle2 className="mt-0.5 size-3 shrink-0 text-success" />
                  <span>{reason}</span>
                </li>
              ))}
            </ul>
          ) : null}
        </div>
        <Button
          size="sm"
          onClick={onAccept}
          disabled={isAccepting}
        >
          {isAccepting ? (
            <Loader2 className="mr-1.5 size-3.5 animate-spin" />
          ) : (
            <CheckCircle2 className="mr-1.5 size-3.5" />
          )}
          Accept match
        </Button>
      </div>
    </div>
  );
}

function Pagination({
  page,
  total,
  totalPages,
  onPageChange,
}: {
  page: number;
  total: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}) {
  const start = total === 0 ? 0 : (page - 1) * PAGE_SIZE + 1;
  const end = Math.min(page * PAGE_SIZE, total);

  return (
    <div className="flex flex-col gap-3 border border-border/80 bg-background/70 p-3 sm:flex-row sm:items-center sm:justify-between sm:p-4">
      <p className="text-sm text-muted-foreground">
        Showing {start} to {end} of {total} transactions
      </p>
      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => onPageChange(page - 1)}
          disabled={page <= 1}
        >
          Previous
        </Button>
        <span className="px-1 text-sm text-muted-foreground">
          Page {page} of {totalPages || 1}
        </span>
        <Button
          variant="outline"
          size="sm"
          onClick={() => onPageChange(page + 1)}
          disabled={page >= totalPages}
        >
          Next
        </Button>
      </div>
    </div>
  );
}

function FilterFields({
  search,
  status,
  method,
  onSearchChange,
  onStatusChange,
  onMethodChange,
}: {
  search: string;
  status: PaymentStatus | "";
  method: PaymentMethod | "";
  onSearchChange: (v: string) => void;
  onStatusChange: (v: PaymentStatus | "") => void;
  onMethodChange: (v: PaymentMethod | "") => void;
}) {
  return (
    <div className="grid gap-3 sm:grid-cols-3">
      <div className="relative sm:col-span-1">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          className="pl-9"
          placeholder="Search reference or phone…"
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
        />
      </div>
      <Select
        options={STATUS_OPTIONS}
        value={status}
        onChange={(e) => onStatusChange(e.target.value as PaymentStatus | "")}
      />
      <Select
        options={METHOD_OPTIONS}
        value={method}
        onChange={(e) => onMethodChange(e.target.value as PaymentMethod | "")}
      />
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main component
// ---------------------------------------------------------------------------

export default function PaymentsPageClient() {
  const { toast } = useToast();

  // Shared data
  const [reconciliation, setReconciliation] = useState<ReconciliationSummary | null>(null);
  const [suggestions, setSuggestions] = useState<MatchSuggestion[]>([]);

  // Transactions
  const [transactions, setTransactions] = useState<PaymentTransactionListItem[]>([]);
  const [txTotal, setTxTotal] = useState(0);
  const [txPage, setTxPage] = useState(1);
  const [txTotalPages, setTxTotalPages] = useState(0);
  const [txStatusFilter, setTxStatusFilter] = useState<PaymentStatus | "">("");
  const [txMethodFilter, setTxMethodFilter] = useState<PaymentMethod | "">("");
  const [txSearch, setTxSearch] = useState("");
  const [isLoadingTx, setIsLoadingTx] = useState(false);
  const [isLoadingSummary, setIsLoadingSummary] = useState(true);
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);

  // SMS parser
  const [smsOpen, setSmsOpen] = useState(false);
  const [smsText, setSmsText] = useState("");
  const [parsedData, setParsedData] = useState<ParsedSmsData | null>(null);
  const [isParsing, setIsParsing] = useState(false);
  const [parseError, setParseError] = useState<string | null>(null);
  const [isConfirming, setIsConfirming] = useState(false);

  // Match dialog
  const [orders, setOrders] = useState<OrderListItem[]>([]);
  const [selectedOrderId, setSelectedOrderId] = useState<string>("");
  const [matchingTxId, setMatchingTxId] = useState<number | null>(null);
  const [isMatching, setIsMatching] = useState(false);
  const [isUnmatching, setIsUnmatching] = useState<number | null>(null);
  const [acceptingSuggestionId, setAcceptingSuggestionId] = useState<number | null>(null);

  // Filter sheet (mobile)
  const [filterOpen, setFilterOpen] = useState(false);

  // ---- Fetchers ---------------------------------------------------------

  const fetchSummary = useCallback(async () => {
    setIsLoadingSummary(true);
    try {
      const recResp = await paymentApi.getReconciliation();
      setReconciliation(recResp.data);
    } catch (error: any) {
      toast({
        message: "Error",
        description:
          error?.response?.data?.detail || "Failed to load reconciliation summary.",
        variant: "error",
      });
    } finally {
      setIsLoadingSummary(false);
    }
  }, [toast]);

  const fetchTransactions = useCallback(async () => {
    setIsLoadingTx(true);
    try {
      const filters: PaymentFilters = {
        page: txPage,
        limit: PAGE_SIZE,
        status: txStatusFilter || undefined,
        payment_method: txMethodFilter || undefined,
        search: txSearch || undefined,
      };
      const response = await paymentApi.listTransactions(filters);
      const data = response.data;
      setTransactions(data.items);
      setTxTotal(data.total);
      setTxTotalPages(data.total_pages);
    } catch (error: any) {
      toast({
        message: "Error",
        description:
          error?.response?.data?.detail || "Failed to load transactions.",
        variant: "error",
      });
    } finally {
      setIsLoadingTx(false);
    }
  }, [txPage, txStatusFilter, txMethodFilter, txSearch, toast]);

  const fetchSuggestions = useCallback(async () => {
    setIsLoadingSuggestions(true);
    try {
      const sugResp = await paymentApi.getSuggestions();
      setSuggestions(sugResp.data);
    } catch (error: any) {
      toast({
        message: "Error",
        description:
          error?.response?.data?.detail || "Failed to load suggestions.",
        variant: "error",
      });
    } finally {
      setIsLoadingSuggestions(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchSummary();
  }, [fetchSummary]);

  useEffect(() => {
    fetchTransactions();
  }, [fetchTransactions]);

  useEffect(() => {
    fetchSuggestions();
  }, [fetchSuggestions]);

  // ---- SMS parser handlers ---------------------------------------------

  const handleParseSms = useCallback(async () => {
    if (!smsText.trim()) {
      toast({
        message: "Error",
        description: "Please paste an SMS text first.",
        variant: "error",
      });
      return;
    }
    setIsParsing(true);
    setParseError(null);
    setParsedData(null);
    try {
      const response = await paymentApi.parseSms(smsText.trim());
      setParsedData(response.data);
    } catch (error: any) {
      const msg =
        error?.response?.data?.detail || "Could not parse the SMS text.";
      setParseError(msg);
      toast({ message: "Parse Error", description: msg, variant: "error" });
    } finally {
      setIsParsing(false);
    }
  }, [smsText, toast]);

  const handleConfirmAndSave = useCallback(async () => {
    if (!parsedData) return;
    setIsConfirming(true);
    try {
      const payload: PaymentTransactionCreate = {
        raw_sms_text: smsText.trim(),
        amount: parsedData.amount ?? undefined,
        sender_phone: parsedData.sender_phone ?? undefined,
        reference: parsedData.trx_id ?? undefined,
        payment_method:
          parsedData.provider === "nagad" ? "nagad" : "bkash",
      };
      await paymentApi.createTransaction(payload);
      toast({
        message: "Saved",
        description: "Payment transaction saved successfully.",
        variant: "success",
      });
      setSmsText("");
      setParsedData(null);
      setSmsOpen(false);
      // Refresh lists
      await Promise.all([fetchTransactions(), fetchSummary(), fetchSuggestions()]);
    } catch (error: any) {
      toast({
        message: "Error",
        description:
          error?.response?.data?.detail || "Failed to save transaction.",
        variant: "error",
      });
    } finally {
      setIsConfirming(false);
    }
  }, [parsedData, smsText, toast, fetchTransactions, fetchSummary, fetchSuggestions]);

  // ---- Match handlers ---------------------------------------------------

  const fetchOrders = useCallback(async () => {
    try {
      const response = await dashboardApi.getOrders({ limit: 100 });
      setOrders(response.data.items);
    } catch {
      // Silent fail; user will see empty select.
    }
  }, []);

  const handleStartMatch = useCallback(
    (txId: number) => {
      setMatchingTxId(txId);
      setSelectedOrderId("");
      fetchOrders();
    },
    [fetchOrders],
  );

  const handleConfirmMatch = useCallback(async () => {
    if (!matchingTxId || !selectedOrderId) return;
    setIsMatching(true);
    try {
      await paymentApi.matchTransaction(
        matchingTxId,
        parseInt(selectedOrderId, 10),
      );
      toast({
        message: "Matched",
        description: "Transaction matched to order.",
        variant: "success",
      });
      setMatchingTxId(null);
      setSelectedOrderId("");
      await Promise.all([fetchTransactions(), fetchSummary(), fetchSuggestions()]);
    } catch (error: any) {
      toast({
        message: "Error",
        description:
          error?.response?.data?.detail || "Failed to match transaction.",
        variant: "error",
      });
    } finally {
      setIsMatching(false);
    }
  }, [matchingTxId, selectedOrderId, toast, fetchTransactions, fetchSummary, fetchSuggestions]);

  const handleUnmatch = useCallback(
    async (txId: number) => {
      setIsUnmatching(txId);
      try {
        await paymentApi.unmatchTransaction(txId);
        toast({
          message: "Unmatched",
          description: "Transaction unmatched.",
          variant: "success",
        });
        await Promise.all([fetchTransactions(), fetchSummary(), fetchSuggestions()]);
      } catch (error: any) {
        toast({
          message: "Error",
          description:
            error?.response?.data?.detail || "Failed to unmatch transaction.",
          variant: "error",
        });
      } finally {
        setIsUnmatching(null);
      }
    },
    [toast, fetchTransactions, fetchSummary, fetchSuggestions],
  );

  const handleAcceptSuggestion = useCallback(
    async (suggestion: MatchSuggestion) => {
      setAcceptingSuggestionId(suggestion.transaction_id);
      try {
        await paymentApi.matchTransaction(
          suggestion.transaction_id,
          suggestion.order_id,
        );
        toast({
          message: "Matched",
          description: "Transaction matched!",
          variant: "success",
        });
        await Promise.all([fetchTransactions(), fetchSummary(), fetchSuggestions()]);
      } catch (error: any) {
        toast({
          message: "Error",
          description:
            error?.response?.data?.detail || "Match failed.",
          variant: "error",
        });
      } finally {
        setAcceptingSuggestionId(null);
      }
    },
    [toast, fetchTransactions, fetchSummary, fetchSuggestions],
  );

  // ---- Filter helpers ---------------------------------------------------

  const clearFilters = useCallback(() => {
    setTxStatusFilter("");
    setTxMethodFilter("");
    setTxSearch("");
    setTxPage(1);
  }, []);

  const hasActiveFilters = Boolean(
    txStatusFilter || txMethodFilter || txSearch.trim(),
  );

  // Render skeleton on first summary load only
  if (isLoadingSummary && !reconciliation) {
    return <PaymentsLoadingState />;
  }

  return (
    <PageFrame>
      <PageHeader>
        <PageHeaderContent>
          <PageEyebrow>Business / reconciliation</PageEyebrow>
          <PageTitle>Payments</PageTitle>
          <PageDescription>
            Track payment records, reconcile transactions, and resolve unmatched orders.
          </PageDescription>
        </PageHeaderContent>
        <PageActions>
          <Button
            variant="outline"
            onClick={() => {
              fetchSummary();
              fetchTransactions();
              fetchSuggestions();
            }}
          >
            <RefreshCw className="mr-1.5 size-4" />
            Refresh
          </Button>
          <Button onClick={() => setSmsOpen(true)}>
            <FileScan className="mr-1.5 size-4" />
            Parse SMS
          </Button>
        </PageActions>
      </PageHeader>

      <PaymentsSummary reconciliation={reconciliation} />

      {/* Transactions */}
      <SurfaceSection className="space-y-4">
        <SectionHeader>
          <div className="space-y-1">
            <SectionTitle>Transactions</SectionTitle>
            <SectionDescription>
              {txTotal > 0
                ? `${txTotal} transaction${txTotal === 1 ? "" : "s"} in your history.`
                : "Search, filter, and match payments to orders."}
            </SectionDescription>
          </div>
        </SectionHeader>

        {/* Desktop inline filters */}
        <div className="hidden md:block">
          <FilterFields
            search={txSearch}
            status={txStatusFilter}
            method={txMethodFilter}
            onSearchChange={(v) => {
              setTxSearch(v);
              setTxPage(1);
            }}
            onStatusChange={(v) => {
              setTxStatusFilter(v);
              setTxPage(1);
            }}
            onMethodChange={(v) => {
              setTxMethodFilter(v);
              setTxPage(1);
            }}
          />
        </div>

        {/* Mobile filter trigger */}
        <div className="flex items-center gap-2 md:hidden">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              className="pl-9"
              placeholder="Search reference or phone…"
              value={txSearch}
              onChange={(e) => {
                setTxSearch(e.target.value);
                setTxPage(1);
              }}
            />
          </div>
          <Sheet open={filterOpen} onOpenChange={setFilterOpen}>
            <SheetTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                aria-label="Open transaction filters"
                className={cn(
                  "shrink-0",
                  (txStatusFilter || txMethodFilter) &&
                    "border-primary text-primary",
                )}
              >
                <SlidersHorizontal className="size-4" />
              </Button>
            </SheetTrigger>
            <SheetContent
              side="right"
              className="flex w-full flex-col gap-4 sm:max-w-md"
            >
              <DialogTitle className="sr-only">Filter transactions</DialogTitle>
              <DialogDescription className="sr-only">Narrow down by status or method.</DialogDescription>
              <div className="space-y-1">
                <p className="text-base font-semibold text-foreground">
                  Filter transactions
                </p>
                <p className="text-sm text-muted-foreground">
                  Narrow down by status or method.
                </p>
              </div>
              <FilterFields
                search={txSearch}
                status={txStatusFilter}
                method={txMethodFilter}
                onSearchChange={(v) => {
                  setTxSearch(v);
                  setTxPage(1);
                }}
                onStatusChange={(v) => {
                  setTxStatusFilter(v);
                  setTxPage(1);
                }}
                onMethodChange={(v) => {
                  setTxMethodFilter(v);
                  setTxPage(1);
                }}
              />
              <div className="mt-auto flex items-center gap-2">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => {
                    clearFilters();
                  }}
                >
                  Clear
                </Button>
                <Button
                  className="flex-1"
                  onClick={() => setFilterOpen(false)}
                >
                  Apply
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>

        {/* Active filter chips */}
        {hasActiveFilters ? (
          <div className="flex flex-wrap items-center gap-2 text-xs">
            {txStatusFilter ? (
              <Badge variant="info" className="gap-1">
                Status: {txStatusFilter}
                <button
                  onClick={() => {
                    setTxStatusFilter("");
                    setTxPage(1);
                  }}
                  className="ml-0.5"
                >
                  <X className="size-3" />
                </button>
              </Badge>
            ) : null}
            {txMethodFilter ? (
              <Badge variant="info" className="gap-1">
                Method: {txMethodFilter}
                <button
                  onClick={() => {
                    setTxMethodFilter("");
                    setTxPage(1);
                  }}
                  className="ml-0.5"
                >
                  <X className="size-3" />
                </button>
              </Badge>
            ) : null}
            {txSearch.trim() ? (
              <Badge variant="info" className="gap-1">
                Search: {txSearch.trim()}
                <button
                  onClick={() => {
                    setTxSearch("");
                    setTxPage(1);
                  }}
                  className="ml-0.5"
                >
                  <X className="size-3" />
                </button>
              </Badge>
            ) : null}
            <button
              onClick={clearFilters}
              className="text-xs font-medium text-primary hover:underline"
            >
              Clear all
            </button>
          </div>
        ) : null}

        {/* Loading state (initial / refetch) */}
        {isLoadingTx && transactions.length === 0 ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="border border-border/80 bg-background/70 p-4"
              >
                <Skeleton className="h-4 w-32" />
                <Skeleton className="mt-3 h-6 w-24" />
                <Skeleton className="mt-3 h-3 w-48" />
              </div>
            ))}
          </div>
        ) : transactions.length === 0 ? (
          <PaymentsEmptyState
            hasFilters={hasActiveFilters}
            onClear={clearFilters}
          />
        ) : (
          <>
            {/* Mobile cards */}
            <div className="grid gap-3 md:hidden">
              {transactions.map((tx) => (
                <TransactionCard
                  key={tx.id}
                  tx={tx}
                  onMatch={() => handleStartMatch(tx.id)}
                  onUnmatch={() => handleUnmatch(tx.id)}
                  isUnmatching={isUnmatching === tx.id}
                />
              ))}
            </div>

            {/* Desktop table */}
            <div className="hidden overflow-hidden border border-border/80 bg-background/70 md:block">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Method</TableHead>
                    <TableHead>Sender</TableHead>
                    <TableHead>Reference</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Order</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transactions.map((tx) => {
                    const MethodIcon = METHOD_ICON[tx.payment_method];
                    return (
                      <TableRow key={tx.id}>
                        <TableCell className="font-mono text-xs">
                          #{tx.id}
                        </TableCell>
                        <TableCell className="font-semibold">
                          {formatAmount(tx.amount)}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={METHOD_BADGE[tx.payment_method]}
                            className="gap-1"
                          >
                            <MethodIcon className="size-3" />
                            {methodLabel(tx.payment_method)}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm">
                          {tx.sender_phone || "—"}
                        </TableCell>
                        <TableCell className="font-mono text-xs">
                          {tx.reference || "—"}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={statusBadgeVariant(tx.status)}
                            className="capitalize"
                          >
                            {statusLabel(tx.status)}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm">
                          {tx.matched_order_id ? (
                            <span className="font-mono text-success">
                              #{tx.matched_order_id}
                            </span>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </TableCell>
                        <TableCell className="text-xs">
                          {formatDate(tx.created_at)}
                        </TableCell>
                        <TableCell className="text-right">
                          {tx.status === "verified" ? (
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleUnmatch(tx.id)}
                              disabled={isUnmatching === tx.id}
                            >
                              {isUnmatching === tx.id ? (
                                <Loader2 className="mr-1.5 size-3.5 animate-spin" />
                              ) : (
                                <X className="mr-1.5 size-3.5" />
                              )}
                              Unmatch
                            </Button>
                          ) : (
                            <Button
                              size="sm"
                              onClick={() => handleStartMatch(tx.id)}
                            >
                              <Link2 className="mr-1.5 size-3.5" />
                              Match
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>

            {txTotalPages > 1 ? (
              <Pagination
                page={txPage}
                total={txTotal}
                totalPages={txTotalPages}
                onPageChange={(p) => setTxPage(p)}
              />
            ) : null}
          </>
        )}
      </SurfaceSection>

      {/* Reconciliation & auto-match suggestions */}
      <SurfaceSection className="space-y-4">
        <SectionHeader>
          <div className="space-y-1">
            <SectionTitle>Auto-match suggestions</SectionTitle>
            <SectionDescription>
              Unmatched payments that may correspond to recent orders. Review and accept
              to keep your books tidy.
            </SectionDescription>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={fetchSuggestions}
            disabled={isLoadingSuggestions}
          >
            <RefreshCw
              className={cn(
                "mr-1.5 h-3.5 w-3.5",
                isLoadingSuggestions && "animate-spin",
              )}
            />
            Refresh
          </Button>
        </SectionHeader>

        {isLoadingSuggestions && suggestions.length === 0 ? (
          <div className="space-y-3">
            {[1, 2].map((i) => (
              <div
                key={i}
                className="border border-border/80 bg-background/70 p-4"
              >
                <Skeleton className="h-4 w-40" />
                <Skeleton className="mt-3 h-3 w-60" />
                <Skeleton className="mt-2 h-3 w-32" />
              </div>
            ))}
          </div>
        ) : suggestions.length === 0 ? (
          <div className="flex flex-col items-center gap-3 border border-dashed border-border/80 bg-muted/30 p-6 text-center">
            <div className="flex size-12 items-center justify-center border border-border/80 bg-muted/40 text-muted-foreground">
              <CheckCircle2 className="size-5 text-success" />
            </div>
            <div className="space-y-1">
              <p className="text-sm font-semibold text-foreground">
                All caught up
              </p>
              <p className="text-xs text-muted-foreground">
                No suggestions right now. All payments may already be matched, or there
                are no pending orders to match against.
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {suggestions.map((s) => (
              <SuggestionCard
                key={`${s.transaction_id}-${s.order_id}`}
                suggestion={s}
                onAccept={() => handleAcceptSuggestion(s)}
                isAccepting={acceptingSuggestionId === s.transaction_id}
              />
            ))}
          </div>
        )}
      </SurfaceSection>

      {/* Match dialog */}
      <Dialog
        open={matchingTxId !== null}
        onOpenChange={(open) => {
          if (!open) {
            setMatchingTxId(null);
            setSelectedOrderId("");
          }
        }}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <div className="mx-auto mb-2 flex size-12 items-center justify-center border border-primary/30 bg-primary/10 text-primary">
              <Link2 className="size-5" />
            </div>
            <DialogTitle className="text-center">
              Match transaction #{matchingTxId}
            </DialogTitle>
            <DialogDescription className="text-center">
              Pick the order this payment corresponds to. The order will be marked as
              paid once matched.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Order
            </label>
            <select
              className="flex h-10 w-full border border-input bg-background px-3 py-2 text-sm focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-ring"
              value={selectedOrderId}
              onChange={(e) => setSelectedOrderId(e.target.value)}
            >
              <option value="" disabled>
                Select an order…
              </option>
              {orders.map((order) => (
                <option key={order.id} value={String(order.id)}>
                  #{order.order_number} · {order.customer_name} ·{" "}
                  {formatAmount(order.total_amount)}
                </option>
              ))}
            </select>
          </div>
          <DialogFooter className="flex-col-reverse gap-2 sm:flex-row sm:justify-end">
            <Button
              variant="outline"
              onClick={() => {
                setMatchingTxId(null);
                setSelectedOrderId("");
              }}
              disabled={isMatching}
            >
              Cancel
            </Button>
            <Button
              onClick={handleConfirmMatch}
              disabled={!selectedOrderId || isMatching}
            >
              {isMatching ? (
                <>
                  <Loader2 className="mr-1.5 size-4 animate-spin" />
                  Matching...
                </>
              ) : (
                <>
                  <CheckCircle2 className="mr-1.5 size-4" />
                  Confirm match
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Parse SMS dialog */}
      <Dialog
        open={smsOpen}
        onOpenChange={(open) => {
          if (!open) {
            setSmsOpen(false);
            setSmsText("");
            setParsedData(null);
            setParseError(null);
          }
        }}
      >
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <div className="mx-auto mb-2 flex size-12 items-center justify-center border border-primary/30 bg-primary/10 text-primary">
              <FileScan className="size-5" />
            </div>
            <DialogTitle className="text-center">Parse bKash / Nagad SMS</DialogTitle>
            <DialogDescription className="text-center">
              Paste the confirmation SMS to extract amount, sender, and TrxID. We&apos;ll
              create a transaction you can match to an order.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-2">
            <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              SMS text
            </label>
            <textarea
              className="min-h-[120px] w-full border border-input bg-background px-3 py-2 text-sm focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-ring"
              placeholder='Paste SMS here, e.g. "BDT 1,200 received from 017XXXXXXXX. TrxID: ABC123..."'
              value={smsText}
              onChange={(e) => setSmsText(e.target.value)}
            />
            <p className="flex items-center gap-1 text-[11px] text-muted-foreground">
              <ShieldCheck className="size-3" />
              We never store the raw SMS text on the client.
            </p>
          </div>

          <Button
            className="w-full"
            onClick={handleParseSms}
            disabled={isParsing || !smsText.trim()}
          >
            {isParsing ? (
              <>
                <Loader2 className="mr-1.5 size-4 animate-spin" />
                Parsing…
              </>
            ) : (
              <>
                <Sparkles className="mr-1.5 size-4" />
                Parse SMS
              </>
            )}
          </Button>

          {parseError ? (
            <div className="flex items-start gap-2 border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive">
              <AlertCircle className="mt-0.5 size-4 shrink-0" />
              <span>{parseError}</span>
            </div>
          ) : null}

          {parsedData ? (
            <div className="space-y-3 border border-border/80 bg-muted/40 p-3">
              <div className="flex items-center justify-between gap-2">
                <p className="text-sm font-semibold text-foreground">
                  Parsed result
                </p>
                {parsedData.provider ? (
                  <Badge variant="info" className="capitalize">
                    {parsedData.provider}
                  </Badge>
                ) : null}
              </div>
              <dl className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <dt className="text-[11px] uppercase tracking-wide text-muted-foreground">
                    Amount
                  </dt>
                  <dd className="font-semibold text-foreground">
                    {formatAmount(parsedData.amount)}
                  </dd>
                </div>
                <div>
                  <dt className="text-[11px] uppercase tracking-wide text-muted-foreground">
                    Sender
                  </dt>
                  <dd className="text-foreground">
                    {parsedData.sender_phone || "—"}
                  </dd>
                </div>
                <div>
                  <dt className="text-[11px] uppercase tracking-wide text-muted-foreground">
                    TrxID
                  </dt>
                  <dd className="font-mono text-xs text-foreground">
                    {parsedData.trx_id || "—"}
                  </dd>
                </div>
                <div>
                  <dt className="text-[11px] uppercase tracking-wide text-muted-foreground">
                    Balance
                  </dt>
                  <dd className="text-foreground">
                    {parsedData.balance != null
                      ? formatAmount(parsedData.balance)
                      : "—"}
                  </dd>
                </div>
              </dl>
            </div>
          ) : null}

          <DialogFooter className="flex-col-reverse gap-2 sm:flex-row sm:justify-end">
            <Button
              variant="outline"
              onClick={() => {
                setSmsOpen(false);
                setSmsText("");
                setParsedData(null);
                setParseError(null);
              }}
              disabled={isConfirming}
            >
              Cancel
            </Button>
            <Button
              onClick={handleConfirmAndSave}
              disabled={!parsedData || isConfirming}
            >
              {isConfirming ? (
                <>
                  <Loader2 className="mr-1.5 size-4 animate-spin" />
                  Saving…
                </>
              ) : (
                <>
                  <CheckCircle2 className="mr-1.5 size-4" />
                  Confirm &amp; save
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageFrame>
  );
}
