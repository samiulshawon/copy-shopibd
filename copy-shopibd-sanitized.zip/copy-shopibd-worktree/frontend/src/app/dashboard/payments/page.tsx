import { Metadata } from "next";
import { redirect } from "next/navigation";
import { getServerSession } from "@/lib/auth";
import PaymentsPageClient from "./page-client";

export const metadata: Metadata = {
  title: "Payments | ShopiBD Dashboard",
  description: "Payment reconciliation dashboard",
};

export default async function PaymentsPage() {
  const session = await getServerSession();
  if (!session) {
    redirect("/auth/login");
  }

  return <PaymentsPageClient />;
}
