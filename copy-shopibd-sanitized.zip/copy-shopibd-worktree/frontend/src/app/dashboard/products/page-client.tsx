"use client";

import React, { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowRight,
  Download,
  Filter,
  MoreHorizontal,
  Package2,
  Plus,
  Search,
  SlidersHorizontal,
  Upload,
} from "lucide-react";
import { productApi, api } from "@/lib/api";
import type {
  Product,
  ProductListParams,
  BulkStockItem,
  BulkPriceUpdateRequest,
} from "@/types/product";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { BulkAddForm } from "@/components/dashboard/bulk-add-form";
import { CsvImportWizard } from "@/components/dashboard/csv-import-wizard";
import { Select } from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { formatCurrency, isPlanLimitError, getPlanLimitMessage } from "@/lib/utils";
import {
  MetricCard,
  MetricStrip,
  PageActions,
  PageDescription,
  PageEyebrow,
  PageFrame,
  PageHeader,
  PageHeaderContent,
  PageTitle,
  SectionDescription,
  SectionHeader,
  SectionTitle,
  SurfaceSection,
} from "@/components/layout/page-structure";

function ProductStatusBadge({ product }: { product: Product }) {
  if (!product.is_active) {
    return <Badge variant="secondary">Inactive</Badge>;
  }

  if (product.stock <= 5) {
    return <Badge variant="warning">Low stock</Badge>;
  }

  return <Badge variant="success">Active</Badge>;
}

function SelectionCheckbox({
  checked,
  onChange,
}: {
  checked: boolean;
  onChange: () => void;
}) {
  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation();
        onChange();
      }}
      className={`flex size-5 items-center justify-center border transition-colors ${
        checked
          ? "border-primary bg-primary text-primary-foreground"
          : "border-border bg-muted text-transparent"
      }`}
      aria-pressed={checked}
      aria-label={checked ? "Deselect product" : "Select product"}
    >
      <span className="text-xs">✓</span>
    </button>
  );
}

function ProductsSummary({ products, total }: { products: Product[]; total: number }) {
  const summary = useMemo(() => {
    const active = products.filter((product) => product.is_active).length;
    const lowStock = products.filter((product) => product.stock <= 5).length;
    const catalogValue = products.reduce((sum, product) => sum + Number(product.price) * product.stock, 0);

    return { active, lowStock, catalogValue };
  }, [products]);

  return (
    <MetricStrip>
      <MetricCard>
        <p className="text-sm font-medium text-muted-foreground">Visible products</p>
        <p className="mt-2 text-2xl font-semibold tracking-tight text-foreground">{total}</p>
        <p className="mt-1 text-xs text-muted-foreground">Products matching your current view.</p>
      </MetricCard>
      <MetricCard>
        <p className="text-sm font-medium text-muted-foreground">Active in view</p>
        <p className="mt-2 text-2xl font-semibold tracking-tight text-success">{summary.active}</p>
        <p className="mt-1 text-xs text-muted-foreground">Currently sellable products.</p>
      </MetricCard>
      <MetricCard>
        <p className="text-sm font-medium text-muted-foreground">Low stock</p>
        <p className="mt-2 text-2xl font-semibold tracking-tight text-warning">{summary.lowStock}</p>
        <p className="mt-1 text-xs text-muted-foreground">Items that may need restocking soon.</p>
      </MetricCard>
      <MetricCard>
        <p className="text-sm font-medium text-muted-foreground">Catalog value</p>
        <p className="mt-2 text-2xl font-semibold tracking-tight text-foreground">{formatCurrency(summary.catalogValue)}</p>
        <p className="mt-1 text-xs text-muted-foreground">Loaded inventory value based on price × stock.</p>
      </MetricCard>
    </MetricStrip>
  );
}

function BulkActionRail({
  selectedCount,
  onStock,
  onPrice,
  onDelete,
  onClear,
}: {
  selectedCount: number;
  onStock: () => void;
  onPrice: () => void;
  onDelete: () => void;
  onClear: () => void;
}) {
  if (selectedCount === 0) return null;

  return (
    <SurfaceSection className="border-primary/20 bg-primary/5">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <p className="text-sm font-semibold text-foreground">{selectedCount} product{selectedCount > 1 ? "s" : ""} selected</p>
          <p className="mt-1 text-sm text-muted-foreground">Run bulk stock, price, or delete actions from one place.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" onClick={onStock}>Update stock</Button>
          <Button variant="outline" onClick={onPrice}>Update price</Button>
          <Button variant="destructive" onClick={onDelete}>Delete selected</Button>
          <Button variant="ghost" onClick={onClear}>Clear</Button>
        </div>
      </div>
    </SurfaceSection>
  );
}

function ProductCard({
  product,
  selected,
  onSelect,
  onOpen,
  onDuplicate,
  onDelete,
  index = 0,
}: {
  product: Product;
  selected: boolean;
  onSelect: (id: number) => void;
  onOpen: (id: number) => void;
  onDuplicate: (product: Product) => void;
  onDelete: (id: number) => void;
  index?: number;
}) {
  return (
    <Card
      className={`animate-fade-up cursor-pointer border-border/80 bg-muted transition-all duration-200 ease-premium hover:border-success/40 hover:bg-background ${selected ? "border-success bg-success/5" : ""}`}
      style={{ animationDelay: `${index * 60}ms` }}
      onClick={() => onOpen(product.id)}
    >
      <CardContent className="space-y-4 p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex min-w-0 flex-1 items-start gap-3">
            <SelectionCheckbox checked={selected} onChange={() => onSelect(product.id)} />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold text-foreground sm:text-base">{product.name}</p>
              <p className="mt-1 text-sm text-muted-foreground">{product.sku || "No SKU"}</p>
            </div>
          </div>
          <ProductStatusBadge product={product} />
        </div>

        <div className="grid grid-cols-2 gap-3 text-sm">
          <div>
            <p className="text-muted-foreground">Price</p>
            <p className="mt-1 font-semibold text-foreground">{formatCurrency(Number(product.price))}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Stock</p>
            <p className="mt-1 font-medium text-foreground">{product.stock}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Category</p>
            <p className="mt-1 text-foreground">{product.category?.name || product.category_id || "—"}</p>
          </div>
          <div>
            <p className="text-muted-foreground">State</p>
            <p className="mt-1 text-foreground">{product.is_active ? "Active" : "Inactive"}</p>
          </div>
        </div>

        <div className="flex items-center justify-between pt-1">
          <Badge variant="secondary" className="px-3 py-1">
            {product.stock <= 5 ? "Restock soon" : "Stock healthy"}
          </Badge>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="size-9"
                onClick={(e) => e.stopPropagation()}
              >
                <MoreHorizontal className="size-4" />
                <span className="sr-only">Product actions</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem
                onClick={(e) => {
                  e.stopPropagation();
                  onOpen(product.id);
                }}
              >
                Edit product
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={(e) => {
                  e.stopPropagation();
                  onDuplicate(product);
                }}
              >
                Duplicate
              </DropdownMenuItem>
              <DropdownMenuItem
                className="text-destructive"
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(product.id);
                }}
              >
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardContent>
    </Card>
  );
}

function ProductsTable({
  products,
  selectedIds,
  allSelected,
  onToggleAll,
  onToggleOne,
  onOpen,
  onDuplicate,
  onDelete,
}: {
  products: Product[];
  selectedIds: Set<number>;
  allSelected: boolean;
  onToggleAll: () => void;
  onToggleOne: (id: number) => void;
  onOpen: (id: number) => void;
  onDuplicate: (product: Product) => void;
  onDelete: (id: number) => void;
}) {
  return (
    <div className="border border-border/80 bg-background/60 ">
      <Table>
        <TableHeader>
          <TableRow className="hover:bg-transparent">
            <TableHead className="w-12">
              <SelectionCheckbox checked={allSelected} onChange={onToggleAll} />
            </TableHead>
            <TableHead>Name</TableHead>
            <TableHead>Price</TableHead>
            <TableHead>Stock</TableHead>
            <TableHead>Category</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {products.map((product) => {
                const selected = selectedIds.has(product.id);
                return (
                  <TableRow key={product.id} className={`${selected ? "bg-primary/5" : ""} border-l-2 border-l-transparent hover:border-l-success/60`} onClick={() => onOpen(product.id)}>
                <TableCell>
                  <SelectionCheckbox checked={selected} onChange={() => onToggleOne(product.id)} />
                </TableCell>
                <TableCell>
                  <div>
                    <p className="font-medium text-foreground">{product.name}</p>
                    <p className="text-xs text-muted-foreground">{product.sku || "No SKU"}</p>
                  </div>
                </TableCell>
                <TableCell className="font-medium text-foreground">{formatCurrency(Number(product.price))}</TableCell>
                <TableCell>{product.stock}</TableCell>
                <TableCell>{product.category?.name || product.category_id || "—"}</TableCell>
                <TableCell>
                  <ProductStatusBadge product={product} />
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-8"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <MoreHorizontal className="size-4" />
                        <span className="sr-only">Actions</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpen(product.id);
                        }}
                      >
                        Edit product
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={(e) => {
                          e.stopPropagation();
                          onDuplicate(product);
                        }}
                      >
                        Duplicate
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        className="text-destructive"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDelete(product.id);
                        }}
                      >
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}

function Pagination({
  page,
  pageSize,
  total,
  totalPages,
  onPageChange,
  onPageSizeChange,
}: {
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (size: number) => void;
}) {
  return (
    <div className="flex flex-col gap-3 border border-border/80 bg-muted p-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="text-sm text-muted-foreground">
        Showing {total === 0 ? 0 : (page - 1) * pageSize + 1} to {Math.min(page * pageSize, total)} of {total} products
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <Button variant="outline" size="sm" onClick={() => onPageChange(page - 1)} disabled={page <= 1}>
          Previous
        </Button>
        <div className="px-2 text-sm text-muted-foreground">Page {page} of {totalPages || 1}</div>
        <Button variant="outline" size="sm" onClick={() => onPageChange(page + 1)} disabled={page >= totalPages}>
          Next
        </Button>
        <Select
          className="h-9 min-w-[110px] bg-muted"
          value={String(pageSize)}
          onChange={(e) => onPageSizeChange(Number(e.target.value))}
          options={[
            { value: "10", label: "10 / page" },
            { value: "20", label: "20 / page" },
            { value: "50", label: "50 / page" },
          ]}
        />
      </div>
    </div>
  );
}

function ProductsEmptyState({ hasActiveFilters, onClear }: { hasActiveFilters: boolean; onClear: () => void }) {
  return (
    <SurfaceSection className="text-center">
      <div className="mx-auto flex max-w-md flex-col items-center gap-4 py-6">
        <div className="flex size-14 items-center justify-center border border-border/80 bg-muted/40 text-muted-foreground">
          <Package2 className="size-6" />
        </div>
        <div className="space-y-2">
          <SectionTitle>No products found</SectionTitle>
          <SectionDescription>
            {hasActiveFilters
              ? "Try changing your search or category filter to reveal more products."
              : "Start building the catalog by adding your first product or importing a CSV."}
          </SectionDescription>
        </div>
        <div className="flex flex-wrap justify-center gap-2">
          {hasActiveFilters ? (
            <Button variant="outline" onClick={onClear}>
              Clear filters
            </Button>
          ) : null}
          <Button asChild>
            <Link href="/dashboard/products/new">Add product</Link>
          </Button>
        </div>
      </div>
    </SurfaceSection>
  );
}

function ProductsLoadingState() {
  return (
    <div className="space-y-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <Card key={i} className="border-border/80 bg-background/60 ">
          <CardContent className="space-y-4 p-4">
            <div className="h-5 w-36 animate-pulse bg-muted" />
            <div className="grid grid-cols-2 gap-3">
              <div className="h-4 animate-pulse bg-muted" />
              <div className="h-4 animate-pulse bg-muted" />
              <div className="h-4 animate-pulse bg-muted" />
              <div className="h-4 animate-pulse bg-muted" />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function FilterFields({
  searchQuery,
  categoryFilter,
  categories,
  onSearchChange,
  onCategoryChange,
  onClear,
  hasActiveFilters,
}: {
  searchQuery: string;
  categoryFilter: string;
  categories: { id: number; name_bn: string }[];
  onSearchChange: (value: string) => void;
  onCategoryChange: (value: string) => void;
  onClear: () => void;
  hasActiveFilters: boolean;
}) {
  return (
    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
      <div className="space-y-2 xl:col-span-2">
        <label className="text-sm font-medium text-foreground">Search</label>
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            className="h-11 bg-muted pl-10"
            placeholder="Search by name or SKU..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
          />
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium text-foreground">Category</label>
        <Select
          className="h-11 bg-muted"
          value={categoryFilter}
          onChange={(e) => onCategoryChange(e.target.value)}
          options={[
            { value: "", label: "All categories" },
            ...categories.map((category) => ({ value: String(category.id), label: category.name_bn })),
          ]}
        />
      </div>

      <div className="flex items-end">
        <Button variant="outline" className="h-11 w-full" onClick={onClear} disabled={!hasActiveFilters}>
          Clear filters
        </Button>
      </div>
    </div>
  );
}

export default function ProductsPageClient() {
  const router = useRouter();
  const { toast } = useToast();

  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [totalPages, setTotalPages] = useState(0);

  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());

  const [isBulkAddOpen, setIsBulkAddOpen] = useState(false);
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [isStockDialogOpen, setIsStockDialogOpen] = useState(false);
  const [isPriceDialogOpen, setIsPriceDialogOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [stockValue, setStockValue] = useState("");
  const [priceType, setPriceType] = useState<"fixed" | "percentage">("fixed");
  const [priceValue, setPriceValue] = useState("");

  const [categories, setCategories] = useState<{ id: number; name_bn: string }[]>([]);

  const shopId = 1;

  useEffect(() => {
    api
      .get("/categories/", { params: { page: 1, page_size: 100 } })
      .then((response) => {
        const data = response.data;
        const items = data?.items ?? [];
        setCategories(items);
      })
      .catch(() => {});
  }, []);

  const fetchProducts = useCallback(async () => {
    setIsLoading(true);
    try {
      const params: ProductListParams = {
        shop_id: shopId,
        page,
        limit: pageSize,
        search: searchQuery || undefined,
        category_id: categoryFilter ? Number(categoryFilter) : undefined,
      };
      const response = await productApi.list(params);
      const data = response.data;
      setProducts(data as unknown as Product[]);
      setTotal(data.length);
      setTotalPages(Math.ceil(data.length / pageSize) || 1);
    } catch (error: any) {
      toast({
        message: "Error",
        description: error?.response?.data?.detail || "Failed to load products",
        variant: "error",
      });
    } finally {
      setIsLoading(false);
    }
  }, [page, pageSize, searchQuery, categoryFilter, shopId, toast]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  const allSelected = useMemo(
    () => products.length > 0 && selectedIds.size === products.length,
    [products, selectedIds],
  );

  const toggleSelectAll = useCallback(() => {
    if (allSelected) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(products.map((p) => p.id)));
    }
  }, [allSelected, products]);

  const toggleSelect = useCallback((id: number) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  }, []);

  const clearSelection = useCallback(() => setSelectedIds(new Set()), []);

  const handleBulkStockUpdate = useCallback(async () => {
    if (selectedIds.size === 0 || !stockValue) return;
    try {
      const items: BulkStockItem[] = Array.from(selectedIds).map((id) => ({
        id,
        stock: parseInt(stockValue, 10) || 0,
      }));
      await productApi.bulkUpdateStock(items);
      toast({ message: "Success", description: "Stock updated", variant: "success" });
      setIsStockDialogOpen(false);
      setStockValue("");
      clearSelection();
      fetchProducts();
    } catch (error: any) {
      toast({
        message: "Error",
        description: error?.response?.data?.detail || "Failed to update stock",
        variant: "error",
      });
    }
  }, [selectedIds, stockValue, toast, clearSelection, fetchProducts]);

  const handleBulkPriceUpdate = useCallback(async () => {
    if (selectedIds.size === 0 || !priceValue) return;
    try {
      const data: BulkPriceUpdateRequest = {
        type: priceType,
        value: parseFloat(priceValue) || 0,
        product_ids: Array.from(selectedIds),
      };
      await productApi.bulkUpdatePrice(data);
      toast({ message: "Success", description: "Prices updated", variant: "success" });
      setIsPriceDialogOpen(false);
      setPriceValue("");
      clearSelection();
      fetchProducts();
    } catch (error: any) {
      toast({
        message: "Error",
        description: error?.response?.data?.detail || "Failed to update prices",
        variant: "error",
      });
    }
  }, [selectedIds, priceType, priceValue, toast, clearSelection, fetchProducts]);

  const handleBulkDelete = useCallback(async () => {
    if (selectedIds.size === 0) return;
    try {
      await productApi.bulkDelete(Array.from(selectedIds));
      toast({ message: "Success", description: "Products deleted", variant: "success" });
      setIsDeleteConfirmOpen(false);
      clearSelection();
      fetchProducts();
    } catch (error: any) {
      toast({
        message: "Error",
        description: error?.response?.data?.detail || "Failed to delete products",
        variant: "error",
      });
    }
  }, [selectedIds, toast, clearSelection, fetchProducts]);

  const handleExportCsv = useCallback(async () => {
    try {
      const response = await productApi.exportCsv(shopId);
      const blob = new Blob([response.data as unknown as BlobPart], { type: "text/csv" });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "products_export.csv";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      toast({ message: "Success", description: "CSV exported", variant: "success" });
    } catch (error: any) {
      toast({
        message: "Error",
        description: error?.response?.data?.detail || "Failed to export CSV",
        variant: "error",
      });
    }
  }, [shopId, toast]);

  const handleDuplicate = useCallback(
    async (product: Product) => {
      try {
        await productApi.create(
          {
            name: product.name + " (Copy)",
            description: product.description,
            price: Number(product.price),
            stock: product.stock,
            sku: product.sku ? product.sku + "-copy" : undefined,
          },
          shopId,
        );
        toast({ message: "Success", description: "Product duplicated", variant: "success" });
      fetchProducts();
    } catch (error: any) {
      if (isPlanLimitError(error)) {
        toast({
          message: "Plan limit reached",
          description: getPlanLimitMessage(
            error,
            "You've reached your plan's product limit. Upgrade to create more products.",
          ),
          variant: "error",
          duration: 8000,
        });
      } else {
        toast({
          message: "Error",
          description: error?.response?.data?.detail || "Failed to duplicate",
          variant: "error",
        });
      }
    }
    },
    [shopId, toast, fetchProducts],
  );

  const handleDeleteSingle = useCallback(
    async (id: number) => {
      try {
        await productApi.delete(id);
        toast({ message: "Success", description: "Product deleted", variant: "success" });
        fetchProducts();
      } catch (error: any) {
        toast({
          message: "Error",
          description: error?.response?.data?.detail || "Failed to delete",
          variant: "error",
        });
      }
    },
    [toast, fetchProducts],
  );

  const clearFilters = useCallback(() => {
    setSearchQuery("");
    setCategoryFilter("");
    setPage(1);
  }, []);

  const hasActiveFilters = useMemo(() => Boolean(searchQuery || categoryFilter), [searchQuery, categoryFilter]);

  const openProduct = useCallback(
    (id: number) => {
      router.push(`/dashboard/products/${id}`);
    },
    [router],
  );

  return (
    <PageFrame>
      <PageHeader>
        <PageHeaderContent>
          <PageEyebrow>Commerce / catalog</PageEyebrow>
          <PageTitle>Products</PageTitle>
          <PageDescription>
            Manage catalog, inventory, and pricing from one operational view.
          </PageDescription>
        </PageHeaderContent>
        <PageActions>
          <Button variant="outline" onClick={handleExportCsv}>
            <Download className="size-4" />
            Export CSV
          </Button>
          <Button variant="outline" onClick={() => setIsImportOpen(true)}>
            <Upload className="size-4" />
            Import CSV
          </Button>
          <Button variant="outline" onClick={() => setIsBulkAddOpen(true)}>
            <Plus className="size-4" />
            Bulk add
          </Button>
          <Button asChild>
            <Link href="/dashboard/products/new">Add product</Link>
          </Button>
        </PageActions>
      </PageHeader>

      <ProductsSummary products={products} total={total} />

      <BulkActionRail
        selectedCount={selectedIds.size}
        onStock={() => {
          setStockValue("");
          setIsStockDialogOpen(true);
        }}
        onPrice={() => {
          setPriceValue("");
          setPriceType("fixed");
          setIsPriceDialogOpen(true);
        }}
        onDelete={() => setIsDeleteConfirmOpen(true)}
        onClear={clearSelection}
      />

      <SurfaceSection>
        <SectionHeader>
          <div>
            <SectionTitle>Search and filter</SectionTitle>
            <SectionDescription>Use a compact desktop toolbar and move category filtering into a mobile sheet when space is tight.</SectionDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {hasActiveFilters ? (
              <Badge variant="secondary" className="px-3 py-1">Filters active</Badge>
            ) : null}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" className="md:hidden">
                  <SlidersHorizontal className="size-4" />
                  Filters
                </Button>
              </SheetTrigger>
              <SheetContent side="bottom" className="max-h-[85vh] border-t border-border bg-background p-0">
                <DialogTitle className="sr-only">Filter products</DialogTitle>
                <DialogDescription className="sr-only">Refine catalog results without crowding the mobile workspace.</DialogDescription>
                <div className="space-y-5 p-5">
                  <div>
                    <p className="text-lg font-semibold text-foreground">Filter products</p>
                    <p className="mt-1 text-sm text-muted-foreground">Refine catalog results without crowding the mobile workspace.</p>
                  </div>
                  <FilterFields
                    searchQuery={searchQuery}
                    categoryFilter={categoryFilter}
                    categories={categories}
                    onSearchChange={(value) => {
                      setSearchQuery(value);
                      setPage(1);
                    }}
                    onCategoryChange={(value) => {
                      setCategoryFilter(value);
                      setPage(1);
                    }}
                    onClear={clearFilters}
                    hasActiveFilters={hasActiveFilters}
                  />
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </SectionHeader>

        <div className="mt-4 hidden md:block">
          <FilterFields
            searchQuery={searchQuery}
            categoryFilter={categoryFilter}
            categories={categories}
            onSearchChange={(value) => {
              setSearchQuery(value);
              setPage(1);
            }}
            onCategoryChange={(value) => {
              setCategoryFilter(value);
              setPage(1);
            }}
            onClear={clearFilters}
            hasActiveFilters={hasActiveFilters}
          />
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-2 md:hidden">
          {searchQuery ? <Badge variant="secondary" className="px-3 py-1">Search: {searchQuery}</Badge> : null}
          {categoryFilter ? <Badge variant="secondary" className="px-3 py-1">Category filtered</Badge> : null}
          {!hasActiveFilters ? (
            <Badge variant="outline" className="px-3 py-1">
              <Filter className="mr-1 size-3.5" />
              No filters
            </Badge>
          ) : null}
        </div>
      </SurfaceSection>

      {isLoading ? <ProductsLoadingState /> : null}

      {!isLoading && products.length === 0 ? (
        <ProductsEmptyState hasActiveFilters={hasActiveFilters} onClear={clearFilters} />
      ) : null}

      {!isLoading && products.length > 0 ? (
        <>
          <div className="space-y-4 md:hidden">
            {products.map((product, index) => (
              <ProductCard
                key={product.id}
                product={product}
                index={index}
                selected={selectedIds.has(product.id)}
                onSelect={toggleSelect}
                onOpen={openProduct}
                onDuplicate={handleDuplicate}
                onDelete={handleDeleteSingle}
              />
            ))}
          </div>

          <div className="hidden md:block">
            <ProductsTable
              products={products}
              selectedIds={selectedIds}
              allSelected={allSelected}
              onToggleAll={toggleSelectAll}
              onToggleOne={toggleSelect}
              onOpen={openProduct}
              onDuplicate={handleDuplicate}
              onDelete={handleDeleteSingle}
            />
          </div>

          <Pagination
            page={page}
            pageSize={pageSize}
            total={total}
            totalPages={totalPages}
            onPageChange={setPage}
            onPageSizeChange={(size) => {
              setPageSize(size);
              setPage(1);
            }}
          />
        </>
      ) : null}

      <Dialog open={isBulkAddOpen} onOpenChange={setIsBulkAddOpen}>
        <DialogContent className="max-h-[80vh] max-w-3xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Bulk add products</DialogTitle>
            <DialogDescription>Add multiple products at once from one workflow.</DialogDescription>
          </DialogHeader>
          <BulkAddForm
            shopId={shopId}
            onSuccess={() => {
              setIsBulkAddOpen(false);
              fetchProducts();
            }}
            onCancel={() => setIsBulkAddOpen(false)}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={isImportOpen} onOpenChange={setIsImportOpen}>
        <DialogContent className="max-h-[80vh] max-w-4xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Import products from CSV</DialogTitle>
            <DialogDescription>Upload catalog data and preview it before importing.</DialogDescription>
          </DialogHeader>
          <CsvImportWizard
            shopId={shopId}
            onSuccess={() => {
              setIsImportOpen(false);
              fetchProducts();
            }}
            onCancel={() => setIsImportOpen(false)}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={isStockDialogOpen} onOpenChange={setIsStockDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update stock</DialogTitle>
            <DialogDescription>Set a new stock value for {selectedIds.size} selected product(s).</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">New stock value</label>
              <Input type="number" min="0" placeholder="Enter stock value..." value={stockValue} onChange={(e) => setStockValue(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsStockDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleBulkStockUpdate} disabled={!stockValue}>Update stock</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isPriceDialogOpen} onOpenChange={setIsPriceDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update price</DialogTitle>
            <DialogDescription>Update prices for {selectedIds.size} selected product(s).</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Update type</label>
              <Select
                className="h-10 bg-muted"
                value={priceType}
                onChange={(e) => setPriceType(e.target.value as "fixed" | "percentage")}
                options={[
                  { value: "fixed", label: "Fixed (+ add to price)" },
                  { value: "percentage", label: "Percentage (+%)" },
                ]}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">
                {priceType === "fixed" ? "Amount to add (৳)" : "Percentage to add (%)"}
              </label>
              <Input type="number" step="0.01" placeholder="Enter value..." value={priceValue} onChange={(e) => setPriceValue(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsPriceDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleBulkPriceUpdate} disabled={!priceValue}>Update price</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isDeleteConfirmOpen} onOpenChange={setIsDeleteConfirmOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete products</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete {selectedIds.size} selected product(s)? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteConfirmOpen(false)}>Cancel</Button>
            <Button variant="destructive" onClick={handleBulkDelete}>Delete {selectedIds.size} product(s)</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageFrame>
  );
}
