import { Metadata } from "next";
import { redirect } from "next/navigation";
import { getServerSession } from "@/lib/auth";
import ProductsPageClient from "./page-client";

export const metadata: Metadata = {
  title: "Products | ShopiBD Dashboard",
  description: "Manage your shop products",
};

export default async function ProductsPage() {
  const session = await getServerSession();
  if (!session) {
    redirect("/auth/login");
  }

  return <ProductsPageClient />;
}
