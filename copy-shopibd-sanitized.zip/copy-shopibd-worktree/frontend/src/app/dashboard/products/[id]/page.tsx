import { Metadata } from "next";
import { redirect, notFound } from "next/navigation";
import { cookies } from "next/headers";
import { getServerSession } from "@/lib/auth";
import { get } from "@/lib/api";
import type { Product } from "@/types/product";
import { ProductForm } from "@/components/dashboard/product-form";

export const metadata: Metadata = {
  title: "Edit Product | ShopiBD Dashboard",
  description: "Edit a product in your ShopiBD catalog",
};

interface EditProductPageProps {
  params: Promise<{ id: string }>;
}

export default async function EditProductPage({ params }: EditProductPageProps) {
  const session = await getServerSession();

  if (!session) {
    redirect("/auth/login");
  }

  const { id } = await params;
  const cookieStore = await cookies();
  const token = cookieStore.get("shopibd_access_token")?.value;

  try {
    const response = await get<Product>(`/products/${Number(id)}`, {
      headers: token ? { Authorization: `Bearer ${token}` } : undefined,
    });
    return <ProductForm product={response.data} />;
  } catch {
    notFound();
  }
}
