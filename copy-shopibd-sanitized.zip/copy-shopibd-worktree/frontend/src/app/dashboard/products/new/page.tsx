import { Metadata } from "next";
import { redirect } from "next/navigation";
import { getServerSession } from "@/lib/auth";
import { ProductForm } from "@/components/dashboard/product-form";

export const metadata: Metadata = {
  title: "Add Product | ShopiBD Dashboard",
  description: "Create a new product for your ShopiBD catalog",
};

export default async function NewProductPage() {
  const session = await getServerSession();

  if (!session) {
    redirect("/auth/login");
  }

  return <ProductForm />;
}
