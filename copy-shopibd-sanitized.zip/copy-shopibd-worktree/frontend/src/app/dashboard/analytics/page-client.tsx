"use client";

import React, { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { ArrowRight, Package, ShoppingBag, Sparkles } from "lucide-react";
import { analyticsApi } from "@/lib/api";
import type {
  DashboardStats,
  SalesDataPoint,
  TopProduct,
  StatusBreakdown,
} from "@/types/analytics";
import { StatsCards } from "@/components/dashboard/stats-cards";
import { SalesChart } from "@/components/dashboard/sales-chart";
import { TopProducts } from "@/components/dashboard/top-products";
import { OrderStatusPie } from "@/components/dashboard/order-status-pie";
import { UpgradePrompt } from "@/components/dashboard/upgrade-prompt";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  PageActions,
  PageDescription,
  PageEyebrow,
  PageFrame,
  PageHeader,
  PageHeaderContent,
  PageTitle,
  SectionDescription,
  SectionHeader,
  SectionTitle,
  SurfaceSection,
} from "@/components/layout/page-structure";

interface AnalyticsState {
  dashboard: DashboardStats | null;
  sales: SalesDataPoint[] | null;
  topProducts: TopProduct[] | null;
  orderStatus: StatusBreakdown[] | null;
}

interface LoadingState {
  dashboard: boolean;
  sales: boolean;
  topProducts: boolean;
  orderStatus: boolean;
}

interface ErrorState {
  dashboard: string | null;
  sales: string | null;
  topProducts: string | null;
  orderStatus: string | null;
}

function QuickActions() {
  const actions = [
    {
      href: "/dashboard/orders",
      label: "Review orders",
      description: "Check pending and newly placed orders.",
      icon: ShoppingBag,
    },
    {
      href: "/dashboard/products",
      label: "Manage products",
      description: "Update pricing, inventory, and catalog details.",
      icon: Package,
    },
  ];

  return (
    <SurfaceSection>
      <SectionHeader>
        <div>
          <SectionTitle>Quick actions</SectionTitle>
          <SectionDescription>Jump into the highest-frequency merchant workflows.</SectionDescription>
        </div>
      </SectionHeader>
      <div className="mt-4 space-y-3">
        {actions.map((action) => {
          const Icon = action.icon;
          return (
            <Link
              key={action.href}
              href={action.href}
              className="group flex items-center gap-3 border border-border/80 bg-muted/30 p-4 transition-all duration-200 ease-premium hover:bg-muted/60"
            >
              <div className="flex size-11 shrink-0 items-center justify-center border border-primary/20 bg-primary/10 text-primary">
                <Icon className="size-5" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="font-medium text-foreground">{action.label}</p>
                <p className="mt-1 text-sm text-muted-foreground">{action.description}</p>
              </div>
              <ArrowRight className="size-4 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:text-foreground" />
            </Link>
          );
        })}
      </div>
    </SurfaceSection>
  );
}

function OverviewPulse({ stats }: { stats: DashboardStats | null }) {
  const todayOrders = stats?.today_orders ?? 0;
  const pendingOrders = stats?.pending_orders ?? 0;
  const lowStock = stats?.low_stock_count ?? 0;

  const priorityMessage =
    pendingOrders > 0
      ? `${pendingOrders} orders need review before fulfillment slows down.`
      : todayOrders > 0
        ? `${todayOrders} new orders came in today.`
        : "No new orders yet today.";

  const stockMessage =
    lowStock > 0
      ? `${lowStock} products are running low on stock.`
      : "Inventory levels are looking stable right now.";

  return (
    <SurfaceSection>
      <SectionHeader>
        <div>
          <SectionTitle>Today&apos;s pulse</SectionTitle>
          <SectionDescription>Daily operating signals that matter before you dive into reports.</SectionDescription>
        </div>
      </SectionHeader>
      <div className="mt-4 space-y-3">
        <div className="border border-border/80 bg-muted/30 p-4">
          <p className="text-sm font-medium text-foreground">Operations</p>
          <p className="mt-2 text-sm leading-6 text-muted-foreground">{priorityMessage}</p>
        </div>
        <div className="border border-border/80 bg-muted/30 p-4">
          <p className="text-sm font-medium text-foreground">Inventory</p>
          <p className="mt-2 text-sm leading-6 text-muted-foreground">{stockMessage}</p>
        </div>
      </div>
    </SurfaceSection>
  );
}

export default function AnalyticsPageClient() {
  const [data, setData] = useState<AnalyticsState>({
    dashboard: null,
    sales: null,
    topProducts: null,
    orderStatus: null,
  });

  const [loading, setLoading] = useState<LoadingState>({
    dashboard: true,
    sales: true,
    topProducts: true,
    orderStatus: true,
  });

  const [error, setError] = useState<ErrorState>({
    dashboard: null,
    sales: null,
    topProducts: null,
    orderStatus: null,
  });

  const [salesPeriod, setSalesPeriod] = useState("7d");

  const fetchDashboard = useCallback(async () => {
    setLoading((prev) => ({ ...prev, dashboard: true }));
    setError((prev) => ({ ...prev, dashboard: null }));
    try {
      const response = await analyticsApi.getDashboard();
      setData((prev) => ({ ...prev, dashboard: response.data }));
    } catch (err: any) {
      setError((prev) => ({
        ...prev,
        dashboard:
          err?.response?.data?.detail ||
          err?.message ||
          "Failed to load dashboard stats",
      }));
    } finally {
      setLoading((prev) => ({ ...prev, dashboard: false }));
    }
  }, []);

  const fetchSales = useCallback(async (period: string) => {
    setLoading((prev) => ({ ...prev, sales: true }));
    setError((prev) => ({ ...prev, sales: null }));
    try {
      const response = await analyticsApi.getSales(period);
      setData((prev) => ({ ...prev, sales: response.data }));
    } catch (err: any) {
      setError((prev) => ({
        ...prev,
        sales:
          err?.response?.data?.detail ||
          err?.message ||
          "Failed to load sales data",
      }));
    } finally {
      setLoading((prev) => ({ ...prev, sales: false }));
    }
  }, []);

  const fetchTopProducts = useCallback(async () => {
    setLoading((prev) => ({ ...prev, topProducts: true }));
    setError((prev) => ({ ...prev, topProducts: null }));
    try {
      const response = await analyticsApi.getTopProducts();
      setData((prev) => ({ ...prev, topProducts: response.data }));
    } catch (err: any) {
      setError((prev) => ({
        ...prev,
        topProducts:
          err?.response?.data?.detail ||
          err?.message ||
          "Failed to load top products",
      }));
    } finally {
      setLoading((prev) => ({ ...prev, topProducts: false }));
    }
  }, []);

  const fetchOrderStatus = useCallback(async () => {
    setLoading((prev) => ({ ...prev, orderStatus: true }));
    setError((prev) => ({ ...prev, orderStatus: null }));
    try {
      const response = await analyticsApi.getOrderStatusBreakdown();
      setData((prev) => ({ ...prev, orderStatus: response.data }));
    } catch (err: any) {
      setError((prev) => ({
        ...prev,
        orderStatus:
          err?.response?.data?.detail ||
          err?.message ||
          "Failed to load order status",
      }));
    } finally {
      setLoading((prev) => ({ ...prev, orderStatus: false }));
    }
  }, []);

  useEffect(() => {
    fetchDashboard();
    fetchTopProducts();
    fetchOrderStatus();
  }, [fetchDashboard, fetchTopProducts, fetchOrderStatus]);

  useEffect(() => {
    fetchSales(salesPeriod);
  }, [fetchSales, salesPeriod]);

  const handlePeriodChange = useCallback((period: string) => {
    setSalesPeriod(period);
  }, []);

  const planSignals = useMemo(() => {
    const stats = data.dashboard;
    if (!stats) {
      return {
        productCount: 0,
        maxProducts: 100,
        orderCount: 0,
        maxOrders: 500,
        plan: "starter",
      };
    }

    return {
      productCount: stats.total_products,
      maxProducts: 100,
      orderCount: stats.total_orders,
      maxOrders: 500,
      plan: "starter",
    };
  }, [data.dashboard]);

  return (
    <PageFrame>
      <PageHeader>
        <PageHeaderContent>
          <PageEyebrow>Merchant overview</PageEyebrow>
          <PageTitle>Run today&apos;s store from one screen</PageTitle>
          <PageDescription>
            Start with the signals that need attention now, then move into sales momentum, product performance, and order health.
          </PageDescription>
        </PageHeaderContent>
        <PageActions>
          <Badge variant="info" className="px-3 py-1">Live analytics</Badge>
          <Button asChild>
            <Link href="/dashboard/orders">Open orders</Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/dashboard/products">Manage products</Link>
          </Button>
        </PageActions>
      </PageHeader>

      <StatsCards
        data={data.dashboard}
        isLoading={loading.dashboard}
        error={error.dashboard}
      />

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_340px]">
        <div className="space-y-6">
          <SalesChart
            data={data.sales}
            isLoading={loading.sales}
            error={error.sales}
            period={salesPeriod}
            onPeriodChange={handlePeriodChange}
          />

          <div className="grid gap-6 2xl:grid-cols-2">
            <TopProducts
              data={data.topProducts}
              isLoading={loading.topProducts}
              error={error.topProducts}
            />
            <OrderStatusPie
              data={data.orderStatus}
              isLoading={loading.orderStatus}
              error={error.orderStatus}
            />
          </div>
        </div>

        <div className="space-y-6">
          <OverviewPulse stats={data.dashboard} />
          <QuickActions />
          <SurfaceSection>
            <SectionHeader>
              <div>
                <SectionTitle>Growth watch</SectionTitle>
                <SectionDescription>Plan usage and growth signals that can affect daily operations.</SectionDescription>
              </div>
            </SectionHeader>
            <div className="mt-4">
              <UpgradePrompt
                productCount={planSignals.productCount}
                maxProducts={planSignals.maxProducts}
                orderCount={planSignals.orderCount}
                maxOrders={planSignals.maxOrders}
                plan={planSignals.plan}
              />
              {!loading.dashboard && !error.dashboard && !data.dashboard ? (
                <div className="border border-dashed border-border/80 bg-muted/30 p-4 text-sm text-muted-foreground">
                  No dashboard signals available yet.
                </div>
              ) : null}
              {!loading.dashboard && data.dashboard ? (
                <div className="border border-border/80 bg-muted/30 p-4">
                  <div className="flex items-start gap-3">
                    <div className="flex size-10 items-center justify-center border border-primary/20 bg-primary/10 text-primary">
                      <Sparkles className="size-4" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">Balanced growth mode</p>
                      <p className="mt-2 text-sm leading-6 text-muted-foreground">
                        Keep product count and order throughput moving together so catalog growth does not slow fulfillment quality.
                      </p>
                    </div>
                  </div>
                </div>
              ) : null}
            </div>
          </SurfaceSection>
        </div>
      </div>
    </PageFrame>
  );
}
