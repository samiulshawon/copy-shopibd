import { Metadata } from "next";
import { redirect } from "next/navigation";
import { getServerSession } from "@/lib/auth";
import AnalyticsPageClient from "./page-client";

export const metadata: Metadata = {
  title: "Analytics Dashboard | ShopiBD",
  description: "View your shop's sales analytics, top products, and order statistics",
};

export default async function AnalyticsPage() {
  // Server-side auth check
  const session = await getServerSession();
  if (!session) {
    redirect("/auth/login");
  }

  return <AnalyticsPageClient />;
}
