"use client";

import React, { useCallback, useEffect, useState } from "react";
import { staffApi } from "@/lib/api";
import { StaffList } from "@/components/dashboard/staff-list";
import { InviteStaffForm } from "@/components/dashboard/invite-staff-form";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import type { Staff } from "@/types/staff";
import {
  PageActions,
  PageDescription,
  PageEyebrow,
  PageFrame,
  PageHeader,
  PageHeaderContent,
  PageTitle,
} from "@/components/layout/page-structure";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface StaffState {
  members: Staff[];
  loading: boolean;
  error: string | null;
}

// ---------------------------------------------------------------------------
// Main component
// ---------------------------------------------------------------------------

export default function StaffPageClient() {
  const [state, setState] = useState<StaffState>({
    members: [],
    loading: true,
    error: null,
  });
  const [inviteOpen, setInviteOpen] = useState(false);

  // -------------------------------------------------------------------------
  // Data fetching
  // -------------------------------------------------------------------------

  const fetchStaff = useCallback(async () => {
    setState((prev) => ({ ...prev, loading: true, error: null }));
    try {
      const response = await staffApi.list();
      setState((prev) => ({
        ...prev,
        members: response.data,
        loading: false,
      }));
    } catch (err: any) {
      setState((prev) => ({
        ...prev,
        loading: false,
        error:
          err?.response?.data?.detail ||
          err?.message ||
          "Failed to load staff members",
      }));
    }
  }, []);

  useEffect(() => {
    fetchStaff();
  }, [fetchStaff]);

  // -------------------------------------------------------------------------
  // Handlers
  // -------------------------------------------------------------------------

  const handleInviteSuccess = useCallback(() => {
    setInviteOpen(false);
    fetchStaff();
  }, [fetchStaff]);

  const handleUpdate = useCallback(
    async (id: number, data: { role?: string; is_active?: boolean }) => {
      try {
        await staffApi.update(id, data as any);
        fetchStaff();
      } catch (err: any) {
        throw err;
      }
    },
    [fetchStaff],
  );

  const handleRemove = useCallback(
    async (id: number) => {
      try {
        await staffApi.remove(id);
        fetchStaff();
      } catch (err: any) {
        throw err;
      }
    },
    [fetchStaff],
  );

  // -------------------------------------------------------------------------
  // Render
  // -------------------------------------------------------------------------

  if (state.loading) {
    return (
      <PageFrame>
        <PageHeader>
          <PageHeaderContent>
            <Skeleton className="h-4 w-32" />
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-5 w-72" />
          </PageHeaderContent>
        </PageHeader>
        <div className="space-y-4">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </PageFrame>
    );
  }

  if (state.error) {
    return (
      <PageFrame>
        <PageHeader>
          <PageHeaderContent>
            <PageEyebrow>Configuration / team</PageEyebrow>
            <PageTitle>Staff</PageTitle>
            <PageDescription>
              Manage your team members and their roles.
            </PageDescription>
          </PageHeaderContent>
        </PageHeader>
        <Alert variant="destructive">
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{state.error}</AlertDescription>
        </Alert>
        <Button variant="outline" className="" onClick={fetchStaff}>Retry</Button>
      </PageFrame>
    );
  }

  return (
    <PageFrame>
      <PageHeader>
        <PageHeaderContent>
          <PageEyebrow>Configuration / team</PageEyebrow>
          <PageTitle>Staff</PageTitle>
          <PageDescription>
            Manage your team members and their roles.
          </PageDescription>
        </PageHeaderContent>
        <PageActions>
          <Button className="" onClick={() => setInviteOpen(true)}>Invite Member</Button>
        </PageActions>
      </PageHeader>

      <StaffList
        members={state.members}
        onUpdate={handleUpdate}
        onRemove={handleRemove}
      />

      <InviteStaffForm
        open={inviteOpen}
        onOpenChange={setInviteOpen}
        onSuccess={handleInviteSuccess}
      />
    </PageFrame>
  );
}