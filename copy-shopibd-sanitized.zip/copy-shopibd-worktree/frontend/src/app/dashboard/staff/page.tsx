import { Metadata } from "next";
import { redirect } from "next/navigation";
import { getServerSession } from "@/lib/auth";
import StaffPageClient from "./page-client";

export const metadata: Metadata = {
  title: "Staff Management | ShopiBD",
  description: "Manage your staff members, invite new team members, and control roles",
};

export default async function StaffPage() {
  // Server-side auth check
  const session = await getServerSession();
  if (!session) {
    redirect("/auth/login");
  }

  return <StaffPageClient />;
}