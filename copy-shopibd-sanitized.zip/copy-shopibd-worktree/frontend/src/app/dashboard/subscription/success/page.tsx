import { Metadata } from "next";
import { redirect } from "next/navigation";
import SubscriptionSuccessPageClient from "./page-client";

export const metadata: Metadata = {
  title: "Subscription Activated | ShopiBD",
  description: "Your subscription has been successfully activated",
};

export default async function SubscriptionSuccessPage({
  searchParams,
}: {
  searchParams: Promise<{ plan?: string; session_id?: string }>;
}) {
  const params = await searchParams;
  if (!params.plan) {
    redirect("/dashboard/subscription");
  }

  return <SubscriptionSuccessPageClient plan={params.plan} />;
}