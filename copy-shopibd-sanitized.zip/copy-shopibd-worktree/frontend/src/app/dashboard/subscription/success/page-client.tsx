"use client";

import Link from "next/link";
import { CreditCard, ArrowRight } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

interface SubscriptionSuccessPageClientProps {
  plan: string;
}

export default function SubscriptionSuccessPageClient({ plan }: SubscriptionSuccessPageClientProps) {
  const planNames: Record<string, string> = {
    starter: "Starter",
    business: "Business",
    enterprise: "Enterprise",
  };
  const planName = planNames[plan] || plan;

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4 py-12">
      <div className="w-full max-w-md">
        <Card className="animate-fade-up">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 flex size-16 items-center justify-center bg-success/15 text-success">
              <CreditCard className="size-8" />
            </div>
            <CardTitle className="text-2xl">Subscription Activated!</CardTitle>
            <p className="text-muted-foreground">
              Your {planName} plan is now active.
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="border border-success/30 bg-success/10 p-4">
              <div className="flex items-center gap-3">
                <CreditCard className="size-5 text-success" />
                <div>
                  <p className="font-medium text-success">Payment Confirmed</p>
                  <p className="text-sm text-muted-foreground">
                    Your subscription has been successfully activated.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-2 text-sm">
              <p>
                <strong>Plan:</strong> {planName}
              </p>
              <p>
                <strong>Status:</strong>{" "}
                <span className="font-medium text-success">Active</span>
              </p>
              <p>
                <strong>Auto-renewal:</strong> Enabled
              </p>
            </div>

            <div className="pt-4">
              <Link href="/dashboard/subscription">
                <Button className="w-full" size="lg">
                  <ArrowRight className="mr-2 size-4" />
                  Manage Subscription
                </Button>
              </Link>
            </div>

            <p className="text-center text-xs text-muted-foreground">
              A confirmation email has been sent to your registered email address.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}