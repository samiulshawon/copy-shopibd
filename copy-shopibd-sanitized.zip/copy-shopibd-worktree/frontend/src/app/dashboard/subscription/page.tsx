import { Metadata } from "next";
import { redirect } from "next/navigation";
import { getServerSession } from "@/lib/auth";
import SubscriptionPageClient from "./page-client";

export const metadata: Metadata = {
  title: "Subscription | ShopiBD Dashboard",
  description: "Manage your subscription plan and billing",
};

export default async function SubscriptionPage() {
  // Server-side auth check
  const session = await getServerSession();
  if (!session) {
    redirect("/auth/login");
  }

  return <SubscriptionPageClient />;
}