"use client";

import Link from "next/link";
import { CreditCard, X, ArrowLeft, RefreshCw } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface CancelPageProps {
  searchParams: Promise<{ plan?: string }>;
}

export default async function SubscriptionCancelPage({ searchParams }: CancelPageProps) {
  const params = await searchParams;
  const planId = params.plan || "business";
  const planNames: Record<string, string> = {
    starter: "Starter",
    business: "Business",
    enterprise: "Enterprise",
  };
  const planName = planNames[planId] || planId;

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4 py-12">
      <div className="w-full max-w-md">
        <Card className="animate-fade-up">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 flex size-16 items-center justify-center bg-warning/15 text-warning">
              <X className="size-8" />
            </div>
            <CardTitle className="text-2xl">Subscription Change Canceled</CardTitle>
            <p className="text-muted-foreground">
              Your {planName} plan upgrade was not completed.
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="border border-warning/30 bg-warning/10 p-4">
              <div className="flex items-center gap-3">
                <X className="size-5 text-warning" />
                <div>
                  <p className="font-medium text-warning">No Changes Made</p>
                  <p className="text-sm text-muted-foreground">
                    You can try again anytime from your subscription dashboard.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-2 text-sm">
              <p>
                <strong>Current Plan:</strong>{" "}
                <Badge variant="secondary">{planName}</Badge>
              </p>
            </div>

            <div className="flex gap-2">
              <Link href="/dashboard/subscription">
                <Button variant="outline" className="flex-1">
                  <ArrowLeft className="mr-2 size-4" />
                  Back to Subscription
                </Button>
              </Link>
              <Link href="/pricing">
                <Button className="flex-1">
                  <RefreshCw className="mr-2 size-4" />
                  Try Again
                </Button>
              </Link>
            </div>

            <p className="text-center text-xs text-muted-foreground">
              If you experienced any issues, please contact our support team.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}