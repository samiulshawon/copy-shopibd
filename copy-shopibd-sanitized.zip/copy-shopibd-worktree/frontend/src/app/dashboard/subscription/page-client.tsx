"use client";

import { useEffect, useState, useCallback, useMemo } from "react";
import {
  AlertCircle,
  ArrowDownToLine,
  ArrowUp,
  ArrowUpRight,
  CalendarClock,
  Check,
  ChevronRight,
  CircleDot,
  CreditCard,
  Loader2,
  Lock,
  Package,
  PackageOpen,
  Receipt,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  Wallet,
  X,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Select } from "@/components/ui/select";
import { PlanBadge } from "@/components/dashboard/plan-badge";
import { UsageBar } from "@/components/dashboard/usage-bar";
import { UpgradePrompt } from "@/components/dashboard/upgrade-prompt";
import { useToast } from "@/hooks/use-toast";
import {
  MetricCard,
  MetricStrip,
  MobileStickyActions,
  PageActions,
  PageDescription,
  PageEyebrow,
  PageFrame,
  PageHeader,
  PageHeaderContent,
  PageTitle,
  SectionDescription,
  SectionHeader,
  SectionTitle,
  SurfaceSection,
} from "@/components/layout/page-structure";
import { cn } from "@/lib/utils";
import { subscriptionApi } from "@/lib/api";
import type {
  PlanInfo,
  SubscriptionWithPlanResponse,
  SubscriptionCreate,
} from "@/types/subscription";
import {
  formatPlanPrice,
  formatPlanLimit,
  getStatusLabel,
  getStatusColor,
} from "@/types/subscription";

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const PLAN_ORDER: string[] = ["free", "starter", "business", "enterprise"];

const PLAN_TAGLINES: Record<string, string> = {
  free: "Get started with the essentials.",
  starter: "For solo sellers ready to grow.",
  business: "For established shops scaling up.",
  enterprise: "Custom volume, dedicated support.",
};

const GATEWAY_OPTIONS = [
  { value: "bkash", label: "bKash" },
  { value: "nagad", label: "Nagad" },
  { value: "sslcommerz", label: "SSLCommerz (Card / Bank)" },
  { value: "manual", label: "Manual / Bank Transfer" },
] as const;

type GatewayValue = (typeof GATEWAY_OPTIONS)[number]["value"];

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function getPlanIndex(plan: string): number {
  return PLAN_ORDER.indexOf(plan);
}

function isUpgrade(current: string, target: string): boolean {
  return getPlanIndex(target) > getPlanIndex(current);
}

function isDowngrade(current: string, target: string): boolean {
  return getPlanIndex(target) < getPlanIndex(current);
}

function formatDate(value?: string | null): string {
  if (!value) return "—";
  return new Date(value).toLocaleDateString("en-BD", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function resolveLimit(value: number, current: number): { label: string; max: number } {
  const unlimited = value >= 99999;
  return {
    label: unlimited ? "Unlimited" : value.toLocaleString(),
    max: unlimited ? current : value,
  };
}

// ---------------------------------------------------------------------------
// Subcomponents
// ---------------------------------------------------------------------------

function SubscriptionOverview({
  subscription,
  currentPlanInfo,
}: {
  subscription: SubscriptionWithPlanResponse;
  currentPlanInfo?: PlanInfo;
}) {
  const productLimit = resolveLimit(
    subscription.plan_info.max_products,
    subscription.current_products,
  );
  const orderLimit = resolveLimit(
    subscription.plan_info.max_orders,
    subscription.current_orders,
  );

  return (
    <MetricStrip>
      <MetricCard>
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 space-y-1">
            <p className="text-sm font-medium text-muted-foreground">Current plan</p>
            <p className="text-2xl font-semibold tracking-tight text-foreground">
              {currentPlanInfo?.name || subscription.plan}
            </p>
            <p className="text-xs text-muted-foreground">
              {formatPlanPrice(subscription.plan_info.price_bdt)}
            </p>
          </div>
          <div className="flex size-9 shrink-0 items-center justify-center border border-border/80 bg-primary/10 text-primary">
            <Sparkles className="size-4" />
          </div>
        </div>
      </MetricCard>

      <MetricCard>
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 space-y-1">
            <p className="text-sm font-medium text-muted-foreground">Status</p>
            <Badge variant={getStatusColor(subscription.status as any)} className="capitalize">
              {getStatusLabel(subscription.status as any)}
            </Badge>
          </div>
          <div className="flex size-9 shrink-0 items-center justify-center border border-border bg-success/10 text-success">
            <CircleDot className="size-4" />
          </div>
        </div>
        <p className="mt-3 text-xs text-muted-foreground">
          {subscription.auto_renew
            ? `Renews on ${formatDate(subscription.current_period_end)}`
            : "Auto-renew is off"}
        </p>
      </MetricCard>

      <MetricCard>
        <p className="text-sm font-medium text-muted-foreground">Products used</p>
        <p className="mt-2 text-2xl font-semibold tracking-tight text-foreground">
          {subscription.current_products}
          <span className="ml-1 text-sm font-medium text-muted-foreground">
            / {productLimit.label}
          </span>
        </p>
        <UsageBar
          className="mt-3"
          label=""
          current={subscription.current_products}
          max={productLimit.max}
        />
      </MetricCard>

      <MetricCard>
        <p className="text-sm font-medium text-muted-foreground">Orders this period</p>
        <p className="mt-2 text-2xl font-semibold tracking-tight text-foreground">
          {subscription.current_orders}
          <span className="ml-1 text-sm font-medium text-muted-foreground">
            / {orderLimit.label}
          </span>
        </p>
        <UsageBar
          className="mt-3"
          label=""
          current={subscription.current_orders}
          max={orderLimit.max}
        />
      </MetricCard>
    </MetricStrip>
  );
}

function CurrentPlanCard({
  subscription,
  currentPlanInfo,
  onAutoRenewToggle,
  isProcessing,
}: {
  subscription: SubscriptionWithPlanResponse;
  currentPlanInfo?: PlanInfo;
  onAutoRenewToggle: () => void;
  isProcessing: boolean;
}) {
  return (
    <SurfaceSection className="space-y-4">
      <SectionHeader>
        <div className="space-y-1">
          <SectionTitle>Current plan details</SectionTitle>
          <SectionDescription>
            {currentPlanInfo?.name || subscription.plan} —{" "}
            {formatPlanPrice(subscription.plan_info.price_bdt)}
          </SectionDescription>
        </div>
        <div className="flex items-center gap-2">
          <PlanBadge plan={subscription.plan} />
          <Badge variant={getStatusColor(subscription.status as any)} className="capitalize">
            {getStatusLabel(subscription.status as any)}
          </Badge>
        </div>
      </SectionHeader>

      <div className="grid gap-3 sm:grid-cols-2">
        <div className="border border-border bg-muted p-4">
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            <CalendarClock className="size-3.5" />
            Billing period
          </div>
          <p className="mt-2 text-base font-semibold text-foreground">
            {formatDate(subscription.current_period_start)} —{" "}
            {formatDate(subscription.current_period_end)}
          </p>
          <p className="mt-1 text-xs text-muted-foreground">
            {subscription.auto_renew
              ? `Next renewal on ${formatDate(subscription.current_period_end)}`
              : "Auto-renew is disabled — service ends at period end."}
          </p>
        </div>

        <div className="border border-border bg-muted p-4">
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            <RefreshCw className="size-3.5" />
            Auto-renewal
          </div>
          <div className="mt-2 flex items-center justify-between gap-2">
            <p className="text-sm text-muted-foreground">
              {subscription.auto_renew
                ? "Subscription will renew automatically."
                : "Renew manually before the period ends."}
            </p>
            <Button
              size="sm"
              variant={subscription.auto_renew ? "outline" : "default"}
              onClick={onAutoRenewToggle}
              disabled={isProcessing}
              className=""
            >
              {subscription.auto_renew ? (
                <>
                  <X className="mr-1.5 size-3.5" />
                  Disable
                </>
              ) : (
                <>
                  <Check className="mr-1.5 size-3.5" />
                  Enable
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </SurfaceSection>
  );
}

function PlanCard({
  plan,
  currentPlan,
  isSelected,
  isCurrent,
  isUpgradePlan,
  isDowngradePlan,
  onSelect,
  selectedGateway,
  onGatewayChange,
  autoRenew,
  onAutoRenewChange,
  onConfirm,
  isProcessing,
}: {
  plan: PlanInfo;
  currentPlan: string;
  isSelected: boolean;
  isCurrent: boolean;
  isUpgradePlan: boolean;
  isDowngradePlan: boolean;
  onSelect: () => void;
  selectedGateway: GatewayValue;
  onGatewayChange: (value: GatewayValue) => void;
  autoRenew: boolean;
  onAutoRenewChange: (value: boolean) => void;
  onConfirm: () => void;
  isProcessing: boolean;
}) {
  const isUnlimitedProducts = plan.max_products >= 99999;
  const isUnlimitedOrders = plan.max_orders >= 99999;
  const isPopular = plan.id === "business";

  return (
    <div
      className={cn(
        "relative flex flex-col border bg-background p-4  transition sm:p-5",
        isCurrent
          ? "border-success bg-success/5"
          : isSelected
            ? "border-primary bg-primary/5"
            : "border-border/80",
      )}
    >
      {/* Badges row */}
      <div className="flex flex-wrap items-center gap-2">
        {isCurrent ? (
          <Badge variant="success" className="gap-1">
            <Check className="size-3" />
            Current
          </Badge>
        ) : isUpgradePlan ? (
          <Badge variant="default" className="gap-1">
            <ArrowUp className="size-3" />
            Upgrade
          </Badge>
        ) : isDowngradePlan ? (
          <Badge variant="secondary" className="gap-1">
            <ArrowDownToLine className="size-3" />
            Downgrade
          </Badge>
        ) : null}
        {isPopular && !isCurrent ? (
          <Badge variant="info" className="gap-1">
            <Sparkles className="size-3" />
            Most popular
          </Badge>
        ) : null}
      </div>

      {/* Plan name + tagline */}
      <div className="mt-3 space-y-1">
        <h3 className="text-lg font-semibold text-foreground">{plan.name}</h3>
        <p className="text-xs text-muted-foreground">{PLAN_TAGLINES[plan.id] || ""}</p>
      </div>

      {/* Price */}
      <div className="mt-3 flex items-baseline gap-1.5">
        <span className="text-3xl font-bold tracking-tight text-foreground">
          {formatPlanPrice(plan.price_bdt)}
        </span>
        {plan.price_bdt > 0 ? (
          <span className="text-sm text-muted-foreground">/ month</span>
        ) : null}
      </div>

      {/* Limits */}
      <dl className="mt-4 space-y-2 border border-border/60 bg-muted/40 p-3 text-sm">
        <div className="flex items-center justify-between">
          <dt className="flex items-center gap-1.5 text-muted-foreground">
            <Package className="size-3.5" />
            Products
          </dt>
          <dd className="font-semibold text-foreground">
            {formatPlanLimit(plan.max_products)}
          </dd>
        </div>
        <div className="flex items-center justify-between">
          <dt className="flex items-center gap-1.5 text-muted-foreground">
            <PackageOpen className="size-3.5" />
            Monthly orders
          </dt>
          <dd className="font-semibold text-foreground">
            {formatPlanLimit(plan.max_orders)}
          </dd>
        </div>
      </dl>

      {/* Features */}
      <ul className="mt-4 flex-1 space-y-2 text-sm">
        {plan.features.map((feature, i) => (
          <li key={i} className="flex items-start gap-2 text-muted-foreground">
            <Check className="mt-0.5 size-4 shrink-0 text-success" />
            <span className="leading-snug">{feature}</span>
          </li>
        ))}
        {plan.features.length === 0 ? (
          <li className="text-xs italic text-muted-foreground">
            Includes core ShopiBD essentials.
          </li>
        ) : null}
        {isUnlimitedProducts && isUnlimitedOrders ? (
          <li className="flex items-start gap-2 text-muted-foreground">
            <Check className="mt-0.5 size-4 shrink-0 text-success" />
            <span className="leading-snug">Unlimited products and orders</span>
          </li>
        ) : null}
      </ul>

      {/* CTA / inline payment panel */}
      <div className="mt-5 space-y-2">
        {isCurrent ? (
          <Button variant="outline" className="w-full" disabled>
            <Check className="mr-1.5 size-4" />
            Your current plan
          </Button>
        ) : isSelected ? (
          <div className="space-y-3 border border-primary/40 bg-primary/5 p-3">
            <div className="space-y-1.5">
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Payment method
              </label>
              <Select
                value={selectedGateway}
                onChange={(e) => onGatewayChange(e.target.value as GatewayValue)}
                options={GATEWAY_OPTIONS.map((g) => ({ value: g.value, label: g.label }))}
                className="w-full"
              />
            </div>
            <label className="flex cursor-pointer items-center gap-2 text-sm text-muted-foreground">
              <input
                type="checkbox"
                checked={autoRenew}
                onChange={(e) => onAutoRenewChange(e.target.checked)}
                className="size-4 border-border text-primary focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-ring"
              />
              <span>Auto-renew this plan every month</span>
            </label>
            <Button
              className="w-full"
              onClick={onConfirm}
              disabled={isProcessing}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="mr-1.5 size-4 animate-spin" />
                  Processing...
                </>
              ) : isUpgradePlan ? (
                <>
                  <ArrowUpRight className="mr-1.5 size-4" />
                  Continue to payment
                </>
              ) : isDowngradePlan ? (
                <>
                  <ArrowDownToLine className="mr-1.5 size-4" />
                  Switch to {plan.name}
                </>
              ) : (
                <>
                  <CreditCard className="mr-1.5 size-4" />
                  Continue with {plan.name}
                </>
              )}
            </Button>
            <p className="text-center text-[11px] text-muted-foreground">
              You will be redirected to {GATEWAY_OPTIONS.find((g) => g.value === selectedGateway)?.label || "the payment provider"} to complete payment securely.
            </p>
          </div>
        ) : (
          <Button
            variant={isUpgradePlan ? "default" : "outline"}
            className="w-full"
            onClick={onSelect}
            disabled={isProcessing}
          >
            {isUpgradePlan ? (
              <>
                <ArrowUp className="mr-1.5 size-4" />
                Upgrade to {plan.name}
              </>
            ) : isDowngradePlan ? (
              <>
                <ArrowDownToLine className="mr-1.5 size-4" />
                Switch to {plan.name}
              </>
            ) : (
              <>
                <ChevronRight className="mr-1.5 size-4" />
                Choose {plan.name}
              </>
            )}
          </Button>
        )}
      </div>
    </div>
  );
}

function SubscriptionLoadingState() {
  return (
    <PageFrame>
      <PageHeader>
        <PageHeaderContent>
          <PageEyebrow>Subscription &amp; billing</PageEyebrow>
          <PageTitle>Subscription workspace</PageTitle>
          <PageDescription>Loading your plan and billing details…</PageDescription>
        </PageHeaderContent>
      </PageHeader>
      <MetricStrip>
        {[1, 2, 3, 4].map((i) => (
          <MetricCard key={i}>
            <Skeleton className="h-3 w-24" />
            <Skeleton className="mt-3 h-7 w-32" />
            <Skeleton className="mt-2 h-3 w-20" />
          </MetricCard>
        ))}
      </MetricStrip>
      <SurfaceSection className="space-y-3">
        <Skeleton className="h-4 w-40" />
        <Skeleton className="h-20 w-full" />
      </SurfaceSection>
    </PageFrame>
  );
}

function SubscriptionEmptyState() {
  return (
    <PageFrame>
      <PageHeader>
        <PageHeaderContent>
          <PageEyebrow>Subscription &amp; billing</PageEyebrow>
          <PageTitle>Subscription workspace</PageTitle>
          <PageDescription>Manage your plan, billing, and renewal settings.</PageDescription>
        </PageHeaderContent>
      </PageHeader>
      <SurfaceSection className="text-center">
        <div className="mx-auto flex max-w-md flex-col items-center gap-4 py-6">
          <div className="flex size-14 items-center justify-center border border-border bg-muted text-muted-foreground">
            <AlertCircle className="size-6" />
          </div>
          <div className="space-y-2">
            <SectionTitle>No subscription found</SectionTitle>
            <SectionDescription>
              We could not load your subscription. Please contact support if this keeps happening.
            </SectionDescription>
          </div>
        </div>
      </SurfaceSection>
    </PageFrame>
  );
}

// ---------------------------------------------------------------------------
// Main component
// ---------------------------------------------------------------------------

export default function SubscriptionPageClient() {
  const { toast } = useToast();
  const [subscription, setSubscription] = useState<SubscriptionWithPlanResponse | null>(null);
  const [plans, setPlans] = useState<PlanInfo[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [selectedGateway, setSelectedGateway] = useState<GatewayValue>("bkash");
  const [autoRenew, setAutoRenew] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [cancelOpen, setCancelOpen] = useState(false);

  const currentPlan = subscription?.plan || "free";

  const fetchData = useCallback(async () => {
    try {
      const [subRes, plansRes] = await Promise.all([
        subscriptionApi.getSubscription(),
        subscriptionApi.listPlans(),
      ]);
      setSubscription(subRes.data);
      setPlans(plansRes.data);
    } catch (error: any) {
      console.error("Failed to load subscription:", error);
      toast({
        message: "Error",
        description: error?.response?.data?.detail || "Failed to load subscription",
        variant: "error",
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Sync local auto-renew state with the fetched subscription.
  useEffect(() => {
    if (subscription) {
      setAutoRenew(subscription.auto_renew);
    }
  }, [subscription?.auto_renew]); // eslint-disable-line react-hooks/exhaustive-deps

  const handlePlanSelect = (planId: string) => {
    if (planId === currentPlan) return;
    setSelectedPlan(planId);
  };

  const handleCreateSubscription = async () => {
    if (!selectedPlan) return;

    setIsProcessing(true);
    try {
      const payload: SubscriptionCreate = {
        plan: selectedPlan,
        auto_renew: autoRenew,
        payment_gateway: selectedGateway,
      };
      await subscriptionApi.createSubscription(payload);

      const paymentRes = await subscriptionApi.createPayment();
      const paymentUrl = paymentRes.data.payment_url;
      if (paymentUrl) {
        window.location.href = paymentUrl;
        return;
      }

      toast({
        message: "Success",
        description: `Plan change to ${selectedPlan} initiated. Complete payment to activate.`,
        variant: "success",
      });
      setSelectedPlan(null);
      await fetchData();
    } catch (error: any) {
      toast({
        message: "Error",
        description: error?.response?.data?.detail || "Failed to change plan",
        variant: "error",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleAutoRenewToggle = async () => {
    if (!subscription) return;
    setIsProcessing(true);
    try {
      await subscriptionApi.updateSubscription({ auto_renew: !autoRenew });
      setAutoRenew(!autoRenew);
      toast({
        message: "Updated",
        description: `Auto-renewal ${!autoRenew ? "enabled" : "disabled"}`,
        variant: "success",
      });
      // Refresh to keep server state in sync.
      await fetchData();
    } catch (error: any) {
      toast({
        message: "Error",
        description: error?.response?.data?.detail || "Failed to update auto-renewal",
        variant: "error",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCancelSubscription = async () => {
    setIsProcessing(true);
    try {
      await subscriptionApi.cancelSubscription();
      toast({
        message: "Subscription Canceled",
        description: "Your plan has been downgraded to Free. You can upgrade anytime.",
        variant: "success",
      });
      setCancelOpen(false);
      setSelectedPlan(null);
      await fetchData();
    } catch (error: any) {
      toast({
        message: "Error",
        description: error?.response?.data?.detail || "Failed to cancel subscription",
        variant: "error",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const currentPlanInfo = useMemo(
    () => plans.find((p) => p.id === currentPlan),
    [plans, currentPlan],
  );

  const selectedPlanInfo = useMemo(
    () => (selectedPlan ? plans.find((p) => p.id === selectedPlan) : null),
    [plans, selectedPlan],
  );

  if (isLoading) {
    return <SubscriptionLoadingState />;
  }

  if (!subscription) {
    return <SubscriptionEmptyState />;
  }

  const canCancel = currentPlan !== "free";

  return (
    <PageFrame>
      <PageHeader>
        <PageHeaderContent>
          <PageEyebrow>Subscription &amp; billing</PageEyebrow>
          <PageTitle>Subscription workspace</PageTitle>
          <PageDescription>
            Manage your plan, track usage, and control renewals. All payments are secured
            through bKash, Nagad, and SSLCommerz.
          </PageDescription>
        </PageHeaderContent>
        {canCancel ? (
          <PageActions>
            <Button
              variant="outline"
            onClick={() => setCancelOpen(true)}
              disabled={isProcessing}
            >
              <X className="mr-1.5 size-4" />
              Cancel subscription
            </Button>
          </PageActions>
        ) : null}
      </PageHeader>

      <SubscriptionOverview
        subscription={subscription}
        currentPlanInfo={currentPlanInfo}
      />

      <UpgradePrompt
        productCount={subscription.current_products}
        maxProducts={subscription.plan_info.max_products}
        orderCount={subscription.current_orders}
        maxOrders={subscription.plan_info.max_orders}
        plan={currentPlan}
      />

      <CurrentPlanCard
        subscription={subscription}
        currentPlanInfo={currentPlanInfo}
        onAutoRenewToggle={handleAutoRenewToggle}
        isProcessing={isProcessing}
      />

      {/* Available plans */}
      <SurfaceSection className="space-y-5">
        <SectionHeader>
          <div className="space-y-1">
            <SectionTitle>Available plans</SectionTitle>
            <SectionDescription>
              Pick a plan and continue to secure payment. You can change or cancel anytime.
            </SectionDescription>
          </div>
          {selectedPlan ? (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSelectedPlan(null)}
            >
              <X className="mr-1.5 size-3.5" />
              Clear selection
            </Button>
          ) : null}
        </SectionHeader>

        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          {PLAN_ORDER.map((planId) => {
            const plan = plans.find((p) => p.id === planId);
            if (!plan) return null;

            const isCurrent = planId === currentPlan;
            const isUpgradePlan = isUpgrade(currentPlan, planId);
            const isDowngradePlan = isDowngrade(currentPlan, planId);
            const isSelected = selectedPlan === planId;

            return (
              <PlanCard
                key={planId}
                plan={plan}
                currentPlan={currentPlan}
                isSelected={isSelected}
                isCurrent={isCurrent}
                isUpgradePlan={isUpgradePlan}
                isDowngradePlan={isDowngradePlan}
                onSelect={() => handlePlanSelect(planId)}
                selectedGateway={selectedGateway}
                onGatewayChange={setSelectedGateway}
                autoRenew={autoRenew}
                onAutoRenewChange={setAutoRenew}
                onConfirm={handleCreateSubscription}
                isProcessing={isProcessing}
              />
            );
          })}
        </div>
      </SurfaceSection>

      {/* Trust footer */}
      <SurfaceSection className="bg-muted/40">
        <div className="flex items-start gap-3">
          <div className="flex size-9 shrink-0 items-center justify-center border border-border/80 bg-primary/10 text-primary">
            <ShieldCheck className="size-4" />
          </div>
          <div className="space-y-1">
            <p className="text-sm font-semibold text-foreground">Secure payments</p>
            <p className="text-sm leading-relaxed text-muted-foreground">
              All transactions are encrypted and PCI-DSS compliant. We never store your
              card or mobile-wallet credentials. bKash, Nagad, and SSLCommerz handle the
              transfer; we only confirm the result.
            </p>
            <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1 border border-border/80 bg-muted/60 px-2.5 py-1">
                <Lock className="size-3" /> 256-bit SSL
              </span>
              <span className="inline-flex items-center gap-1 border border-border/80 bg-muted/60 px-2.5 py-1">
                <Wallet className="size-3" /> bKash · Nagad
              </span>
              <span className="inline-flex items-center gap-1 border border-border/80 bg-muted/60 px-2.5 py-1">
                <Receipt className="size-3" /> Invoices by email
              </span>
            </div>
          </div>
        </div>
      </SurfaceSection>

      {/* Mobile sticky actions — confirm selected plan or back to top */}
      {selectedPlan && selectedPlanInfo ? (
        <MobileStickyActions className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div className="min-w-0">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">
              Selected plan
            </p>
            <p className="truncate text-sm font-semibold text-foreground">
              {selectedPlanInfo.name} · {formatPlanPrice(selectedPlanInfo.price_bdt)}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              className=""
              onClick={() => setSelectedPlan(null)}
              disabled={isProcessing}
            >
              Cancel
            </Button>
            <Button
              className=""
              onClick={handleCreateSubscription}
              disabled={isProcessing}
            >
              {isProcessing ? (
                <Loader2 className="mr-1.5 size-4 animate-spin" />
              ) : (
                <ArrowUpRight className="mr-1.5 size-4" />
              )}
              Continue to payment
            </Button>
          </div>
        </MobileStickyActions>
      ) : null}

      {/* Cancel confirmation dialog */}
      <Dialog open={cancelOpen} onOpenChange={setCancelOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <div className="mx-auto mb-2 flex size-12 items-center justify-center border border-warning/30 bg-warning/10 text-warning">
              <AlertCircle className="size-5" />
            </div>
            <DialogTitle className="text-center">Cancel subscription?</DialogTitle>
            <DialogDescription className="text-center">
              You will be downgraded to the Free plan immediately. Your current
              {" "}
              {currentPlanInfo?.name || currentPlan} plan features will no longer be available.
            </DialogDescription>
          </DialogHeader>
          <div className="border border-border bg-muted p-3 text-sm text-muted-foreground">
            <p>
              You can re-subscribe anytime. Your products and orders will remain safe on the
              Free tier.
            </p>
          </div>
          <DialogFooter className="flex-col-reverse gap-2 sm:flex-row sm:justify-end">
            <Button
              variant="outline"
              className=""
              onClick={() => setCancelOpen(false)}
              disabled={isProcessing}
            >
              Keep my plan
            </Button>
            <Button
              variant="destructive"
              className=""
              onClick={handleCancelSubscription}
              disabled={isProcessing}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="mr-1.5 size-4 animate-spin" />
                  Canceling...
                </>
              ) : (
                <>
                  <X className="mr-1.5 size-4" />
                  Confirm cancellation
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageFrame>
  );
}
