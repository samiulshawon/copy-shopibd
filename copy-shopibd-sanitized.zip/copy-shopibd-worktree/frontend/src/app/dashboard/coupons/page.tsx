import { Metadata } from "next";
import { redirect } from "next/navigation";
import { getServerSession } from "@/lib/auth";
import CouponsPageClient from "./page-client";

export const metadata: Metadata = {
  title: "Coupons | ShopiBD Dashboard",
  description: "Manage your discount coupons",
};

export default async function CouponsPage() {
  // Server-side auth check
  const session = await getServerSession();
  if (!session) {
    redirect("/auth/login");
  }

  return <CouponsPageClient />;
}
