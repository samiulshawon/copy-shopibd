"use client";

import React, { useCallback, useEffect, useMemo, useState } from "react";
import { couponApi } from "@/lib/api";
import type { Coupon, CouponCreate, CouponUpdate } from "@/types/coupon";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Select } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Plus, Search, Tag, Trash2, ToggleLeft, ToggleRight } from "lucide-react";
import {
  MetricCard,
  MetricStrip,
  PageActions,
  PageDescription,
  PageEyebrow,
  PageFrame,
  PageHeader,
  PageHeaderContent,
  PageTitle,
  SectionDescription,
  SectionHeader,
  SectionTitle,
  SurfaceSection,
} from "@/components/layout/page-structure";

const INITIAL_FORM: CouponCreate = {
  code: "",
  discount_type: "percentage",
  discount_value: 0,
  min_order_amount: null,
  max_discount: null,
  usage_limit: null,
  per_customer_limit: 1,
  applies_to: "all",
  product_ids: null,
  category_ids: null,
  is_active: true,
  starts_at: null,
  expires_at: null,
};

export default function CouponsPageClient() {
  const { toast } = useToast();

  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [total, setTotal] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState<CouponCreate>({ ...INITIAL_FORM });
  const [saving, setSaving] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);

  const fetchCoupons = useCallback(async () => {
    setIsLoading(true);
    try {
      const res = await couponApi.list({
        page,
        limit: 20,
        search: search || undefined,
      });
      setCoupons(res.data.items);
      setTotal(res.data.total);
    } catch (err: any) {
      toast({
        message: "Error",
        description: err?.response?.data?.detail || "Failed to load coupons",
        variant: "error",
      });
    } finally {
      setIsLoading(false);
    }
  }, [page, search, toast]);

  useEffect(() => {
    fetchCoupons();
  }, [fetchCoupons]);

  const handleCreate = useCallback(async () => {
    setSaving(true);
    try {
      await couponApi.create(form);
      toast({
        message: "Success",
        description: "Coupon created successfully",
        variant: "success",
      });
      setShowCreate(false);
      setForm({ ...INITIAL_FORM });
      fetchCoupons();
    } catch (err: any) {
      toast({
        message: "Error",
        description: err?.response?.data?.detail || "Failed to create coupon",
        variant: "error",
      });
    } finally {
      setSaving(false);
    }
  }, [form, fetchCoupons, toast]);

  const handleToggleActive = useCallback(
    async (coupon: Coupon) => {
      try {
        await couponApi.update(coupon.id, { is_active: !coupon.is_active });
        toast({
          message: "Success",
          description: `Coupon ${coupon.is_active ? "deactivated" : "activated"}`,
          variant: "success",
        });
        fetchCoupons();
      } catch (err: any) {
        toast({
          message: "Error",
          description: err?.response?.data?.detail || "Failed to update coupon",
          variant: "error",
        });
      }
    },
    [fetchCoupons, toast],
  );

  const handleDelete = useCallback(
    async (id: number) => {
      try {
        await couponApi.delete(id);
        toast({
          message: "Success",
          description: "Coupon deleted",
          variant: "success",
        });
        setDeleteConfirm(null);
        fetchCoupons();
      } catch (err: any) {
        toast({
          message: "Error",
          description: err?.response?.data?.detail || "Failed to delete coupon",
          variant: "error",
        });
      }
    },
    [fetchCoupons, toast],
  );

  const isExpired = useCallback((coupon: Coupon) => {
    if (!coupon.expires_at) return false;
    return new Date(coupon.expires_at) < new Date();
  }, []);

  const isActive = useCallback(
    (coupon: Coupon) => coupon.is_active && !isExpired(coupon),
    [isExpired],
  );

  const activeCount = useMemo(
    () => coupons.filter((c) => isActive(c)).length,
    [coupons, isActive],
  );

  return (
    <PageFrame>
      <PageHeader>
        <PageHeaderContent>
          <PageEyebrow>Commerce / pricing</PageEyebrow>
          <PageTitle>Coupons</PageTitle>
          <PageDescription>
            Create and manage discount coupons for your storefront.
          </PageDescription>
        </PageHeaderContent>
        <PageActions>
          <Dialog open={showCreate} onOpenChange={setShowCreate}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-1.5 size-4" />
                New Coupon
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>Create Coupon</DialogTitle>
                <DialogDescription>
                  Set up a new discount coupon for your customers.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div>
                  <label className="text-sm font-medium">Coupon Code</label>
                  <Input
                    value={form.code}
                    onChange={(e) =>
                      setForm({ ...form, code: e.target.value.toUpperCase() })
                    }
                    placeholder="e.g. SUMMER20"
                    className="bg-muted"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Discount Type</label>
                    <Select
                      value={form.discount_type}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          discount_type: e.target.value as "percentage" | "fixed",
                        })
                      }
                      options={[
                        { value: "percentage", label: "Percentage (%)" },
                        { value: "fixed", label: "Fixed (৳)" },
                      ]}
                      className="bg-muted"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Discount Value</label>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      value={form.discount_value || ""}
                      onChange={(e) =>
                        setForm({ ...form, discount_value: parseFloat(e.target.value) || 0 })
                      }
                      className="bg-muted"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Min Order (optional)</label>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      value={form.min_order_amount ?? ""}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          min_order_amount: e.target.value ? parseFloat(e.target.value) : null,
                        })
                      }
                      placeholder="e.g. 500"
                      className="bg-muted"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Max Discount (optional)</label>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      value={form.max_discount ?? ""}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          max_discount: e.target.value ? parseFloat(e.target.value) : null,
                        })
                      }
                      placeholder="For percentage type"
                      className="bg-muted"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Usage Limit (optional)</label>
                    <Input
                      type="number"
                      min="0"
                      value={form.usage_limit ?? ""}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          usage_limit: e.target.value ? parseInt(e.target.value) : null,
                        })
                      }
                      className="bg-muted"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Per Customer Limit</label>
                    <Input
                      type="number"
                      min="1"
                      value={form.per_customer_limit}
                      onChange={(e) =>
                        setForm({ ...form, per_customer_limit: parseInt(e.target.value) || 1 })
                      }
                      className="bg-muted"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Start Date (optional)</label>
                    <Input
                      type="datetime-local"
                      value={form.starts_at ? form.starts_at.slice(0, 16) : ""}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          starts_at: e.target.value ? new Date(e.target.value).toISOString() : null,
                        })
                      }
                      className="bg-muted"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Expiry Date (optional)</label>
                    <Input
                      type="datetime-local"
                      value={form.expires_at ? form.expires_at.slice(0, 16) : ""}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          expires_at: e.target.value ? new Date(e.target.value).toISOString() : null,
                        })
                      }
                      className="bg-muted"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium">Applies To</label>
                  <Select
                    value={form.applies_to}
                    onChange={(e) => setForm({ ...form, applies_to: e.target.value })}
                    options={[
                      { value: "all", label: "All Products" },
                      { value: "specific_products", label: "Specific Products" },
                      { value: "specific_categories", label: "Specific Categories" },
                    ]}
                    className="bg-muted"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setShowCreate(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreate} disabled={saving || !form.code}>
                  {saving && <Loader2 className="mr-1.5 size-4 animate-spin" />}
                  Create Coupon
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </PageActions>
      </PageHeader>

      {/* Summary */}
      <MetricStrip>
        <MetricCard>
          <p className="text-sm font-medium text-muted-foreground">Total coupons</p>
          <p className="mt-2 text-2xl font-semibold tracking-tight text-foreground">{total}</p>
          <p className="mt-1 text-xs text-muted-foreground">Across all statuses.</p>
        </MetricCard>
        <MetricCard>
          <p className="text-sm font-medium text-muted-foreground">Active coupons</p>
          <p className="mt-2 text-2xl font-semibold tracking-tight text-success">{activeCount}</p>
          <p className="mt-1 text-xs text-muted-foreground">Currently live and valid.</p>
        </MetricCard>
      </MetricStrip>

      {/* Search */}
      <SurfaceSection>
        <SectionHeader>
          <div>
            <SectionTitle>Search</SectionTitle>
            <SectionDescription>Filter by coupon code.</SectionDescription>
          </div>
        </SectionHeader>
        <div className="mt-3">
          <div className="relative max-w-sm">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search by code..."
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              className="bg-muted pl-9"
            />
          </div>
        </div>
      </SurfaceSection>

      {/* Table */}
      <SurfaceSection>
        <SectionHeader>
          <div>
            <SectionTitle>All coupons</SectionTitle>
            <SectionDescription>
              {total} coupon{total !== 1 ? "s" : ""} found
            </SectionDescription>
          </div>
        </SectionHeader>

        <div className="mt-4">
          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="size-8 animate-spin text-muted-foreground" />
            </div>
          ) : coupons.length === 0 ? (
            <div className="flex flex-col items-center gap-3 py-12 text-center">
              <div className="flex size-14 items-center justify-center border border-border bg-background text-muted-foreground">
                <Tag className="size-6" />
              </div>
              <p className="text-sm text-muted-foreground">
                No coupons yet. Create your first coupon!
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto border border-border">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted text-left">
                    <th className="py-3 pl-4 pr-3 font-medium">Code</th>
                    <th className="p-3 font-medium">Type</th>
                    <th className="p-3 font-medium">Value</th>
                    <th className="p-3 font-medium">Usage</th>
                    <th className="p-3 font-medium">Status</th>
                    <th className="p-3 font-medium">Expiry</th>
                    <th className="py-3 pl-3 pr-4 text-right font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {coupons.map((coupon) => (
                    <tr key={coupon.id} className="border-b border-border last:border-0 hover:bg-muted/50">
                      <td className="py-3 pl-4 pr-3 font-mono font-medium text-foreground">
                        {coupon.code}
                      </td>
                      <td className="p-3 capitalize text-muted-foreground">
                        {coupon.discount_type === "percentage" ? "Percentage" : "Fixed"}
                      </td>
                      <td className="p-3 font-medium text-foreground">
                        {coupon.discount_type === "percentage"
                          ? `${coupon.discount_value}%`
                          : `৳${coupon.discount_value}`}
                      </td>
                      <td className="p-3 text-muted-foreground">
                        {coupon.usage_count}
                        {coupon.usage_limit ? ` / ${coupon.usage_limit}` : ""}
                      </td>
                      <td className="p-3">
                        <Badge
                          variant={isActive(coupon) ? "success" : isExpired(coupon) ? "destructive" : "secondary"}
                        >
                          {isActive(coupon) ? "Active" : isExpired(coupon) ? "Expired" : "Inactive"}
                        </Badge>
                      </td>
                      <td className="p-3 text-muted-foreground">
                        {coupon.expires_at
                          ? new Date(coupon.expires_at).toLocaleDateString()
                          : "No expiry"}
                      </td>
                      <td className="py-3 pl-3 pr-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-8"
                            onClick={() => handleToggleActive(coupon)}
                            aria-label={coupon.is_active ? "Deactivate coupon" : "Activate coupon"}
                            title={coupon.is_active ? "Deactivate" : "Activate"}
                          >
                            {coupon.is_active ? (
                              <ToggleRight className="size-4" />
                            ) : (
                              <ToggleLeft className="size-4" />
                            )}
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-8"
                            onClick={() => setDeleteConfirm(coupon.id)}
                            aria-label="Delete coupon"
                            title="Delete"
                          >
                            <Trash2 className="size-4 text-destructive" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </SurfaceSection>

      {/* Delete confirmation dialog */}
      <Dialog
        open={deleteConfirm !== null}
        onOpenChange={(open) => !open && setDeleteConfirm(null)}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Coupon?</DialogTitle>
            <DialogDescription>
              This action cannot be undone. The coupon and its usage records
              will be permanently deleted.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteConfirm(null)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => deleteConfirm && handleDelete(deleteConfirm)}
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageFrame>
  );
}
