"use client";

import React, { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import {
  PageDescription,
  PageEyebrow,
  PageFrame,
  PageHeader,
  PageHeaderContent,
  PageTitle,
  SectionDescription,
  SectionHeader,
  SectionTitle,
  SurfaceSection,
  MetricCard,
  MetricStrip,
} from "@/components/layout/page-structure";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface NotificationPreferences {
  newOrder: boolean;
  orderStatus: boolean;
  lowStock: boolean;
}

const STORAGE_KEY = "shopibd_notification_preferences";

const DEFAULT_PREFERENCES: NotificationPreferences = {
  newOrder: true,
  orderStatus: true,
  lowStock: true,
};

// ---------------------------------------------------------------------------
// Notification toggle item component
// ---------------------------------------------------------------------------

function ToggleItem({
  id,
  label,
  description,
  checked,
  onChange,
}: {
  id: string;
  label: string;
  description: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between border border-border bg-background p-4">
      <div className="space-y-0.5">
        <label
          htmlFor={id}
          className="cursor-pointer text-sm font-medium leading-none text-foreground"
        >
          {label}
        </label>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
      <button
        id={id}
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={`
          relative inline-flex h-6 w-11 shrink-0 cursor-pointer items-center border-2 border-transparent transition-colors
          focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring
          ${checked ? "bg-primary" : "bg-secondary"}
        `}
      >
        <span
          className={`
            pointer-events-none block size-5 bg-background transition-transform
            ${checked ? "translate-x-5" : "translate-x-0"}
          `}
        />
      </button>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main component
// ---------------------------------------------------------------------------

export default function NotificationsPageClient() {
  const [preferences, setPreferences] = useState<NotificationPreferences>(
    DEFAULT_PREFERENCES,
  );
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);

  // -------------------------------------------------------------------------
  // Load saved preferences from localStorage
  // -------------------------------------------------------------------------

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as Partial<NotificationPreferences>;
        setPreferences((prev) => ({ ...prev, ...parsed }));
      }
    } catch {
      // Ignore corrupt data, use defaults
    } finally {
      setLoading(false);
    }
  }, []);

  // -------------------------------------------------------------------------
  // Save preferences to localStorage (simulated API call)
  // -------------------------------------------------------------------------

  const savePreferences = useCallback(async () => {
    setSaving(true);
    setSaveMessage(null);

    try {
      await new Promise((resolve) => setTimeout(resolve, 600));

      localStorage.setItem(STORAGE_KEY, JSON.stringify(preferences));

      setSaveMessage({
        type: "success",
        text: "Notification preferences saved successfully.",
      });

      setTimeout(() => setSaveMessage(null), 3000);
    } catch {
      setSaveMessage({
        type: "error",
        text: "Failed to save preferences. Please try again.",
      });
    } finally {
      setSaving(false);
    }
  }, [preferences]);

  // -------------------------------------------------------------------------
  // Update a single preference
  // -------------------------------------------------------------------------

  const updatePreference = useCallback(
    (key: keyof NotificationPreferences, value: boolean) => {
      setPreferences((prev) => ({ ...prev, [key]: value }));
    },
    [],
  );

  // -------------------------------------------------------------------------
  // Render
  // -------------------------------------------------------------------------

  if (loading) {
    return (
      <PageFrame>
        <PageHeader>
          <PageHeaderContent>
            <Skeleton className="h-4 w-32" />
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-5 w-80" />
          </PageHeaderContent>
        </PageHeader>
        <div className="space-y-4">
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-20 w-full" />
        </div>
      </PageFrame>
    );
  }

  const activeCount =
    (preferences.newOrder ? 1 : 0) +
    (preferences.orderStatus ? 1 : 0) +
    (preferences.lowStock ? 1 : 0);

  return (
    <PageFrame>
      <PageHeader>
        <PageHeaderContent>
          <PageEyebrow>Configuration / notifications</PageEyebrow>
          <PageTitle>Notification settings</PageTitle>
          <PageDescription>
            Configure WhatsApp notification preferences for your shop.
          </PageDescription>
        </PageHeaderContent>
      </PageHeader>

      {/* Summary */}
      <MetricStrip>
        <MetricCard>
          <p className="text-sm font-medium text-muted-foreground">Active notifications</p>
          <p className="mt-2 text-2xl font-semibold tracking-tight text-success">{activeCount} of 3</p>
          <p className="mt-1 text-xs text-muted-foreground">Enabled notification types.</p>
        </MetricCard>
      </MetricStrip>

      {/* Provider info card */}
      <div className="border border-warning/30 bg-warning/10 p-4">
        <p className="text-sm font-semibold text-warning">WhatsApp Provider</p>
        <p className="mt-1 text-sm text-muted-foreground">
          Currently using the <strong>mock provider</strong> for WhatsApp
          notifications. Notifications are logged to the console but not
          actually sent. To enable real WhatsApp messaging, configure a
          provider in your backend settings.
        </p>
      </div>

      {/* Notification toggles */}
      <SurfaceSection>
        <SectionHeader>
          <div>
            <SectionTitle>Notification types</SectionTitle>
            <SectionDescription>
              Choose which events trigger WhatsApp notifications.
            </SectionDescription>
          </div>
        </SectionHeader>
        <div className="mt-4 space-y-3">
          <ToggleItem
            id="notify-new-order"
            label="New Order Alert"
            description="Get notified via WhatsApp when a new order is placed"
            checked={preferences.newOrder}
            onChange={(v) => updatePreference("newOrder", v)}
          />
          <ToggleItem
            id="notify-order-status"
            label="Order Status Update"
            description="Send WhatsApp updates to buyers when order status changes"
            checked={preferences.orderStatus}
            onChange={(v) => updatePreference("orderStatus", v)}
          />
          <ToggleItem
            id="notify-low-stock"
            label="Low Stock Alert"
            description="Get alerted via WhatsApp when product stock drops below threshold"
            checked={preferences.lowStock}
            onChange={(v) => updatePreference("lowStock", v)}
          />
        </div>
      </SurfaceSection>

      {/* Save section */}
      <div className="flex items-center gap-4">
        <Button className="" onClick={savePreferences} disabled={saving}>
          {saving ? "Saving..." : "Save Preferences"}
        </Button>

        {saveMessage && (
          <Alert
            variant={saveMessage.type === "error" ? "destructive" : "default"}
            className="m-0 inline-flex items-center px-4 py-2"
          >
            <AlertTitle className="mr-2 text-sm font-medium">
              {saveMessage.type === "success" ? "\u2713" : "\u2717"}
            </AlertTitle>
            <AlertDescription className="text-sm">
              {saveMessage.text}
            </AlertDescription>
          </Alert>
        )}
      </div>

      {/* Info footer */}
      <p className="text-xs text-muted-foreground">
        Preferences are stored locally. When a real WhatsApp provider is
        configured, preferences will sync with the backend.
      </p>
    </PageFrame>
  );
}