import { Metadata } from "next";
import { redirect } from "next/navigation";
import { getServerSession } from "@/lib/auth";
import NotificationsPageClient from "./page-client";

export const metadata: Metadata = {
  title: "Notification Settings | ShopiBD",
  description:
    "Manage your WhatsApp notification preferences for orders, status updates, and low stock alerts",
};

export default async function NotificationsPage() {
  // Server-side auth check
  const session = await getServerSession();
  if (!session) {
    redirect("/auth/login");
  }

  return <NotificationsPageClient />;
}
