"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  AlertCircle,
  ArrowRight,
  ArrowUpRight,
  Banknote,
  Bell,
  CheckCircle2,
  Clock3,
  CreditCard,
  Hash,
  Inbox,
  Lightbulb,
  Link2,
  Loader2,
  Package,
  Plus,
  RefreshCw,
  ShoppingBag,
  Sparkles,
  Store,
  TrendingUp,
  Truck,
  Users,
  Wallet,
  XCircle,
} from "lucide-react";

import {
  analyticsApi,
  abandonedCartApi,
  dashboardApi,
  paymentApi,
  subscriptionApi,
} from "@/lib/api";
import type { OrderListItem, AbandonedOrderItem } from "@/types/order";
import type {
  DashboardStats,
  TopProduct,
} from "@/types/analytics";
import type {
  MatchSuggestion,
  ReconciliationSummary,
} from "@/types/payment";
import type {
  SubscriptionWithPlanResponse,
} from "@/types/subscription";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { cn, formatCurrency } from "@/lib/utils";
import { UsageBar } from "@/components/dashboard/usage-bar";
import { UpgradePrompt } from "@/components/dashboard/upgrade-prompt";
import { StatusBadge } from "@/components/dashboard/status-badge";
import {
  MetricCard,
  MetricStrip,
  MobileStickyActions,
  PageActions,
  PageDescription,
  PageEyebrow,
  PageFrame,
  PageHeader,
  PageHeaderContent,
  PageTitle,
  SectionDescription,
  SectionHeader,
  SectionTitle,
  SurfaceSection,
} from "@/components/layout/page-structure";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function resolveLimit(value: number, current: number): { label: string; max: number } {
  const unlimited = value >= 99999;
  return {
    label: unlimited ? "Unlimited" : value.toLocaleString(),
    max: unlimited ? current : value,
  };
}

function greetingFor(date: Date): string {
  const hour = date.getHours();
  if (hour < 5) return "Working late";
  if (hour < 12) return "Good morning";
  if (hour < 17) return "Good afternoon";
  if (hour < 21) return "Good evening";
  return "Working late";
}

function formatDate(dateStr?: string | null): string {
  if (!dateStr) return "—";
  return new Date(dateStr).toLocaleDateString("en-BD", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function formatTime(dateStr?: string | null): string {
  if (!dateStr) return "—";
  return new Date(dateStr).toLocaleTimeString("en-BD", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

// ---------------------------------------------------------------------------
// Subcomponents
// ---------------------------------------------------------------------------

function TodayOverview({
  stats,
  isLoading,
}: {
  stats: DashboardStats | null;
  isLoading: boolean;
}) {
  if (isLoading) {
    return (
      <MetricStrip>
        {[1, 2, 3, 4].map((i) => (
          <MetricCard key={i}>
            <Skeleton className="h-3 w-24" />
            <Skeleton className="mt-3 h-7 w-32" />
            <Skeleton className="mt-2 h-3 w-20" />
          </MetricCard>
        ))}
      </MetricStrip>
    );
  }

  const safe = stats ?? {
    today_orders: 0,
    today_revenue: 0,
    pending_orders: 0,
    low_stock_count: 0,
    total_products: 0,
    total_orders: 0,
  };

  return (
    <MetricStrip>
      <MetricCard>
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 space-y-1">
            <p className="text-sm font-medium text-muted-foreground">
              Today&apos;s orders
            </p>
            <p className="text-2xl font-semibold tracking-tight text-foreground">
              {safe.today_orders.toLocaleString()}
            </p>
            <p className="text-xs text-muted-foreground">
              Since midnight
            </p>
          </div>
          <div className="flex size-9 shrink-0 items-center justify-center border border-primary/20 bg-primary/10 text-primary">
            <ShoppingBag className="size-4" />
          </div>
        </div>
      </MetricCard>

      <MetricCard>
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 space-y-1">
            <p className="text-sm font-medium text-muted-foreground">
              Today&apos;s revenue
            </p>
            <p className="text-2xl font-semibold tracking-tight text-success">
              {formatCurrency(safe.today_revenue)}
            </p>
            <p className="text-xs text-muted-foreground">
              Gross collected today
            </p>
          </div>
          <div className="flex size-9 shrink-0 items-center justify-center border border-success/25 bg-success/10 text-success">
            <Wallet className="size-4" />
          </div>
        </div>
      </MetricCard>

      <MetricCard>
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 space-y-1">
            <p className="text-sm font-medium text-muted-foreground">
              Pending orders
            </p>
            <p
              className={cn(
                "text-2xl font-semibold tracking-tight",
                safe.pending_orders > 0 ? "text-warning" : "text-foreground",
              )}
            >
              {safe.pending_orders.toLocaleString()}
            </p>
            <p className="text-xs text-muted-foreground">
              Awaiting review & fulfillment
            </p>
          </div>
          <div
            className={cn(
              "flex h-9 w-9 shrink-0 items-center justify-center border",
              safe.pending_orders > 0
                ? "border-warning/25 bg-warning/10 text-warning"
                : "border-border/80 bg-muted/40 text-muted-foreground",
            )}
          >
            <Clock3 className="size-4" />
          </div>
        </div>
      </MetricCard>

      <MetricCard>
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 space-y-1">
            <p className="text-sm font-medium text-muted-foreground">
              Low stock alerts
            </p>
            <p
              className={cn(
                "text-2xl font-semibold tracking-tight",
                safe.low_stock_count > 0 ? "text-destructive" : "text-foreground",
              )}
            >
              {safe.low_stock_count.toLocaleString()}
            </p>
            <p className="text-xs text-muted-foreground">
              {safe.low_stock_count > 0
                ? "Restock before demand slips"
                : "Inventory is healthy"}
            </p>
          </div>
          <div
            className={cn(
              "flex h-9 w-9 shrink-0 items-center justify-center border",
              safe.low_stock_count > 0
                ? "border-destructive/25 bg-destructive/10 text-destructive"
                : "border-success/25 bg-success/10 text-success",
            )}
          >
            {safe.low_stock_count > 0 ? (
              <AlertCircle className="size-4" />
            ) : (
              <CheckCircle2 className="size-4" />
            )}
          </div>
        </div>
      </MetricCard>
    </MetricStrip>
  );
}

function QuickActions() {
  const actions = [
    {
      href: "/dashboard/products/new",
      label: "Add product",
      description: "List a new item in your catalog.",
      icon: Plus,
      tone: "primary" as const,
    },
    {
      href: "/dashboard/orders",
      label: "Review orders",
      description: "Check pending and newly placed orders.",
      icon: ShoppingBag,
      tone: "neutral" as const,
    },
    {
      href: "/dashboard/payments",
      label: "Reconcile payments",
      description: "Match bKash / Nagad / bank payments to orders.",
      icon: Banknote,
      tone: "neutral" as const,
    },
    {
      href: "/dashboard/customers",
      label: "Customer pulse",
      description: "See your VIP, repeat, and dormant buyers.",
      icon: Users,
      tone: "neutral" as const,
    },
  ];

  return (
    <SurfaceSection>
      <SectionHeader>
        <div className="space-y-1">
          <SectionTitle>Quick actions</SectionTitle>
          <SectionDescription>
            Jump into the highest-frequency merchant workflows.
          </SectionDescription>
        </div>
      </SectionHeader>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {actions.map((action) => {
          const Icon = action.icon;
          return (
            <Link
              key={action.href}
              href={action.href}
              className="group flex items-center gap-3 border border-border/80 bg-muted/30 p-3 transition-all duration-200 ease-premium hover:bg-muted/60 sm:p-4"
            >
              <div
                className={cn(
                  "flex h-11 w-11 shrink-0 items-center justify-center border",
                  action.tone === "primary"
                    ? "border-primary/25 bg-primary/10 text-primary"
                    : "border-border/80 bg-background/70 text-muted-foreground group-hover:border-primary/20 group-hover:bg-primary/10 group-hover:text-primary",
                )}
              >
                <Icon className="size-5" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="font-medium text-foreground">{action.label}</p>
                <p className="mt-1 text-xs leading-snug text-muted-foreground sm:text-sm">
                  {action.description}
                </p>
              </div>
              <ArrowRight className="size-4 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:text-foreground" />
            </Link>
          );
        })}
      </div>
    </SurfaceSection>
  );
}

function RecentOrdersCard({
  orders,
  isLoading,
}: {
  orders: OrderListItem[];
  isLoading: boolean;
}) {
  return (
    <SurfaceSection>
      <SectionHeader>
        <div className="space-y-1">
          <SectionTitle>Recent orders</SectionTitle>
          <SectionDescription>
            The last 5 orders placed in your shop.
          </SectionDescription>
        </div>
        <Button asChild variant="ghost" size="sm" className="">
          <Link href="/dashboard/orders">
            View all
            <ArrowRight className="ml-1.5 size-3.5" />
          </Link>
        </Button>
      </SectionHeader>

      {isLoading ? (
        <div className="mt-4 space-y-2">
          {[1, 2, 3, 4, 5].map((i) => (
            <div
              key={i}
              className="border border-border/80 bg-muted/30 p-3"
            >
              <Skeleton className="h-4 w-32" />
              <Skeleton className="mt-2 h-3 w-48" />
            </div>
          ))}
        </div>
      ) : orders.length === 0 ? (
        <div className="mt-4 flex flex-col items-center gap-2 border border-dashed border-border/80 bg-muted/30 p-6 text-center">
          <div className="flex size-10 items-center justify-center border border-border/80 bg-background/70 text-muted-foreground">
            <Inbox className="size-4" />
          </div>
          <div>
            <p className="text-sm font-semibold text-foreground">No orders yet</p>
            <p className="text-xs text-muted-foreground">
              New orders from Facebook and your storefront will appear here.
            </p>
          </div>
        </div>
      ) : (
        <ul className="mt-4 divide-y divide-border/60">
          {orders.map((order) => (
            <li key={order.id}>
              <Link
                href={`/dashboard/orders/${order.id}`}
                className="group -mx-2 flex items-center gap-3 px-2 py-3 transition-colors hover:bg-muted/30"
              >
                <div className="flex size-9 shrink-0 items-center justify-center border border-border/80 bg-background/70 text-muted-foreground">
                  <Hash className="size-3.5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="truncate text-sm font-semibold text-foreground">
                      #{order.order_number}
                    </p>
                    <StatusBadge status={order.status} />
                  </div>
                  <p className="truncate text-xs text-muted-foreground">
                    {order.customer_name} · {order.item_count} item
                    {order.item_count === 1 ? "" : "s"} ·{" "}
                    {formatDate(order.created_at)} · {formatTime(order.created_at)}
                  </p>
                </div>
                <p className="shrink-0 text-sm font-semibold text-foreground">
                  {formatCurrency(order.total_amount)}
                </p>
                <ArrowRight className="size-3.5 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-0.5" />
              </Link>
            </li>
          ))}
        </ul>
      )}
    </SurfaceSection>
  );
}

function TopProductsCard({
  products,
  isLoading,
}: {
  products: TopProduct[];
  isLoading: boolean;
}) {
  return (
    <SurfaceSection>
      <SectionHeader>
        <div className="space-y-1">
          <SectionTitle>Top products</SectionTitle>
          <SectionDescription>
            Best sellers by revenue this period.
          </SectionDescription>
        </div>
        <Button asChild variant="ghost" size="sm" className="">
          <Link href="/dashboard/products">
            View all
            <ArrowRight className="ml-1.5 size-3.5" />
          </Link>
        </Button>
      </SectionHeader>

      {isLoading ? (
        <div className="mt-4 space-y-2">
          {[1, 2, 3].map((i) => (
            <div
              key={i}
              className="border border-border/80 bg-muted/30 p-3"
            >
              <Skeleton className="h-4 w-40" />
              <Skeleton className="mt-2 h-3 w-24" />
            </div>
          ))}
        </div>
      ) : products.length === 0 ? (
        <div className="mt-4 flex flex-col items-center gap-2 border border-dashed border-border/80 bg-muted/30 p-6 text-center">
          <div className="flex size-10 items-center justify-center border border-border/80 bg-background/70 text-muted-foreground">
            <Package className="size-4" />
          </div>
          <div>
            <p className="text-sm font-semibold text-foreground">
              No sales yet
            </p>
            <p className="text-xs text-muted-foreground">
              Once orders roll in, your best sellers will show up here.
            </p>
          </div>
        </div>
      ) : (
        <ol className="mt-4 space-y-2">
          {products.slice(0, 5).map((product, idx) => (
            <li
              key={product.product_id}
              className="flex items-center gap-3 border border-border/80 bg-muted/30 p-3"
            >
              <div
                className={cn(
                  "flex h-9 w-9 shrink-0 items-center justify-center border text-sm font-semibold",
                  idx === 0
                    ? "border-primary/30 bg-primary/10 text-primary"
                    : "border-border/80 bg-background/70 text-muted-foreground",
                )}
              >
                #{idx + 1}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-foreground">
                  {product.product_name}
                </p>
                <p className="text-xs text-muted-foreground">
                  {product.total_quantity.toLocaleString()} sold ·{" "}
                  {product.order_count} order
                  {product.order_count === 1 ? "" : "s"}
                </p>
              </div>
              <p className="shrink-0 text-sm font-semibold text-foreground">
                {formatCurrency(product.total_revenue)}
              </p>
            </li>
          ))}
        </ol>
      )}
    </SurfaceSection>
  );
}

function PlanUsageCard({
  subscription,
  isLoading,
}: {
  subscription: SubscriptionWithPlanResponse | null;
  isLoading: boolean;
}) {
  if (isLoading) {
    return (
      <SurfaceSection>
        <Skeleton className="h-4 w-32" />
        <Skeleton className="mt-3 h-8 w-40" />
        <Skeleton className="mt-3 h-3 w-full" />
        <Skeleton className="mt-2 h-3 w-full" />
      </SurfaceSection>
    );
  }

  if (!subscription) {
    return (
      <SurfaceSection>
        <SectionHeader>
          <div className="space-y-1">
            <SectionTitle>Plan usage</SectionTitle>
            <SectionDescription>
              Subscription details couldn&apos;t be loaded.
            </SectionDescription>
          </div>
        </SectionHeader>
      </SurfaceSection>
    );
  }

  const productLimit = resolveLimit(
    subscription.plan_info.max_products,
    subscription.current_products,
  );
  const orderLimit = resolveLimit(
    subscription.plan_info.max_orders,
    subscription.current_orders,
  );
  const planName = subscription.plan_info.name || subscription.plan;
  const planPrice = formatCurrency(subscription.plan_info.price_bdt);

  return (
    <SurfaceSection className="space-y-4">
      <SectionHeader>
        <div className="space-y-1">
          <SectionTitle>Plan usage</SectionTitle>
          <SectionDescription>
            Current billing period · {planName}
          </SectionDescription>
        </div>
        <Badge variant="info" className="gap-1">
          <Sparkles className="size-3" />
          {planName}
        </Badge>
      </SectionHeader>

      <div className="border border-border/80 bg-muted/30 p-3">
        <div className="flex items-center justify-between">
          <p className="text-sm font-medium text-foreground">{planName}</p>
          <p className="text-sm font-semibold text-foreground">{planPrice}</p>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">
          Renews on {formatDate(subscription.current_period_end)}
        </p>
      </div>

      <UsageBar
        label="Products"
        current={subscription.current_products}
        max={productLimit.max}
      />
      <UsageBar
        label="Orders this period"
        current={subscription.current_orders}
        max={orderLimit.max}
      />

      <Button asChild variant="outline" className="w-full">
        <Link href="/dashboard/subscription">
          Manage plan
          <ArrowUpRight className="ml-1.5 size-3.5" />
        </Link>
      </Button>
    </SurfaceSection>
  );
}

function ActionNeededCard({
  abandonedCount,
  suggestions,
  reconciliation,
  isLoadingAbandoned,
  isLoadingSuggestions,
}: {
  abandonedCount: number;
  suggestions: MatchSuggestion[];
  reconciliation: ReconciliationSummary | null;
  isLoadingAbandoned: boolean;
  isLoadingSuggestions: boolean;
}) {
  const unmatched =
    reconciliation?.unmatched ?? 0;
  const suggestionCount = suggestions.length;
  const hasAlerts = abandonedCount > 0 || unmatched > 0 || suggestionCount > 0;

  return (
    <SurfaceSection className="space-y-3">
      <SectionHeader>
        <div className="space-y-1">
          <SectionTitle>Action needed</SectionTitle>
          <SectionDescription>
            Things that benefit from a quick merchant check.
          </SectionDescription>
        </div>
        <div className="flex size-9 shrink-0 items-center justify-center border border-warning/25 bg-warning/10 text-warning">
          <Bell className="size-4" />
        </div>
      </SectionHeader>

      <ul className="space-y-2">
        <li>
          <Link
            href="/dashboard/abandoned"
            className="flex items-center gap-3 border border-border/80 bg-muted/30 p-3 transition-colors hover:bg-muted/60"
          >
            <div className="flex size-9 shrink-0 items-center justify-center border border-warning/25 bg-warning/10 text-warning">
              <Clock3 className="size-4" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium text-foreground">
                Abandoned checkouts
              </p>
              <p className="text-xs text-muted-foreground">
                Send a WhatsApp reminder to recover the order.
              </p>
            </div>
            {isLoadingAbandoned ? (
              <Skeleton className="h-5 w-8" />
            ) : (
              <Badge
                variant={abandonedCount > 0 ? "warning" : "secondary"}
                className="shrink-0"
              >
                {abandonedCount}
              </Badge>
            )}
          </Link>
        </li>

        <li>
          <Link
            href="/dashboard/payments"
            className="flex items-center gap-3 border border-border/80 bg-muted/30 p-3 transition-colors hover:bg-muted/60"
          >
            <div className="flex size-9 shrink-0 items-center justify-center border border-destructive/25 bg-destructive/10 text-destructive">
              <XCircle className="size-4" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium text-foreground">
                Unmatched payments
              </p>
              <p className="text-xs text-muted-foreground">
                Match bKash / Nagad transactions to orders.
              </p>
            </div>
            {reconciliation ? (
              <Badge
                variant={unmatched > 0 ? "destructive" : "secondary"}
                className="shrink-0"
              >
                {unmatched}
              </Badge>
            ) : (
              <Skeleton className="h-5 w-8" />
            )}
          </Link>
        </li>

        <li>
          <Link
            href="/dashboard/payments"
            className="flex items-center gap-3 border border-border/80 bg-muted/30 p-3 transition-colors hover:bg-muted/60"
          >
            <div className="flex size-9 shrink-0 items-center justify-center border border-primary/20 bg-primary/10 text-primary">
              <Lightbulb className="size-4" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium text-foreground">
                Auto-match suggestions
              </p>
              <p className="text-xs text-muted-foreground">
                High-confidence matches waiting for review.
              </p>
            </div>
            {isLoadingSuggestions ? (
              <Skeleton className="h-5 w-8" />
            ) : (
              <Badge
                variant={suggestionCount > 0 ? "info" : "secondary"}
                className="shrink-0"
              >
                {suggestionCount}
              </Badge>
            )}
          </Link>
        </li>
      </ul>

      {!hasAlerts ? (
        <div className="flex items-center gap-2 border border-success/30 bg-success/10 p-3 text-sm">
          <CheckCircle2 className="size-4 shrink-0 text-success" />
          <p className="text-foreground">All clear — nothing to chase right now.</p>
        </div>
      ) : null}
    </SurfaceSection>
  );
}

function StorefrontCard() {
  return (
    <SurfaceSection className="space-y-3">
      <SectionHeader>
        <div className="space-y-1">
          <SectionTitle>Your storefront</SectionTitle>
          <SectionDescription>
            Open the buyer-facing shop or share it on Facebook.
          </SectionDescription>
        </div>
        <div className="flex size-9 shrink-0 items-center justify-center border border-border/80 bg-primary/10 text-primary">
          <Store className="size-4" />
        </div>
      </SectionHeader>
      <div className="grid gap-2 sm:grid-cols-2">
        <Button asChild variant="outline" className="">
          <Link href="/dashboard/branding">
            <Store className="mr-1.5 size-4" />
            Customize branding
          </Link>
        </Button>
        <Button asChild className="">
          <Link href="/dashboard/orders">
            <Truck className="mr-1.5 size-4" />
            View orders
          </Link>
        </Button>
      </div>
    </SurfaceSection>
  );
}

function DashboardHomeSkeleton() {
  return (
    <PageFrame>
      <PageHeader>
        <PageHeaderContent>
          <Skeleton className="h-3 w-32" />
          <Skeleton className="mt-2 h-7 w-64" />
          <Skeleton className="mt-2 h-4 w-96 max-w-full" />
        </PageHeaderContent>
      </PageHeader>
      <MetricStrip>
        {[1, 2, 3, 4].map((i) => (
          <MetricCard key={i}>
            <Skeleton className="h-3 w-24" />
            <Skeleton className="mt-3 h-7 w-32" />
            <Skeleton className="mt-2 h-3 w-20" />
          </MetricCard>
        ))}
      </MetricStrip>
      <div className="grid gap-4 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <SurfaceSection>
            <Skeleton className="h-4 w-40" />
            <Skeleton className="mt-4 h-12 w-full" />
            <Skeleton className="mt-2 h-12 w-full" />
          </SurfaceSection>
        </div>
        <SurfaceSection>
          <Skeleton className="h-4 w-32" />
          <Skeleton className="mt-3 h-8 w-40" />
          <Skeleton className="mt-3 h-3 w-full" />
        </SurfaceSection>
      </div>
    </PageFrame>
  );
}

// ---------------------------------------------------------------------------
// Main component
// ---------------------------------------------------------------------------

export default function DashboardHomeClient() {
  const { toast } = useToast();

  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentOrders, setRecentOrders] = useState<OrderListItem[]>([]);
  const [topProducts, setTopProducts] = useState<TopProduct[]>([]);
  const [abandoned, setAbandoned] = useState<AbandonedOrderItem[]>([]);
  const [suggestions, setSuggestions] = useState<MatchSuggestion[]>([]);
  const [reconciliation, setReconciliation] = useState<ReconciliationSummary | null>(null);
  const [subscription, setSubscription] = useState<SubscriptionWithPlanResponse | null>(null);

  const [isInitialLoading, setIsInitialLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const [isLoadingStats, setIsLoadingStats] = useState(true);
  const [isLoadingOrders, setIsLoadingOrders] = useState(true);
  const [isLoadingProducts, setIsLoadingProducts] = useState(true);
  const [isLoadingAbandoned, setIsLoadingAbandoned] = useState(true);
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(true);
  const [isLoadingReconciliation, setIsLoadingReconciliation] = useState(true);
  const [isLoadingSubscription, setIsLoadingSubscription] = useState(true);

  // ---- Fetchers ---------------------------------------------------------

  const fetchAll = useCallback(async () => {
    setIsRefreshing(true);
    try {
      const [
        statsRes,
        ordersRes,
        topProductsRes,
        abandonedRes,
        suggestionsRes,
        reconciliationRes,
        subscriptionRes,
      ] = await Promise.allSettled([
        analyticsApi.getDashboard(),
        dashboardApi.getOrders({ page: 1, limit: 5 }),
        analyticsApi.getTopProducts(5),
        abandonedCartApi.list({ hours: 24, limit: 5 }),
        paymentApi.getSuggestions(),
        paymentApi.getReconciliation(),
        subscriptionApi.getSubscription(),
      ]);

      if (statsRes.status === "fulfilled") {
        setStats(statsRes.value.data as DashboardStats);
      }
      if (ordersRes.status === "fulfilled") {
        setRecentOrders(ordersRes.value.data.items);
      }
      if (topProductsRes.status === "fulfilled") {
        const raw = topProductsRes.value.data;
        const list: TopProduct[] = Array.isArray(raw)
          ? (raw as TopProduct[])
          : (raw?.items as TopProduct[]) || [];
        setTopProducts(list);
      }
      if (abandonedRes.status === "fulfilled") {
        setAbandoned(abandonedRes.value.data.items);
      }
      if (suggestionsRes.status === "fulfilled") {
        setSuggestions(suggestionsRes.value.data);
      }
      if (reconciliationRes.status === "fulfilled") {
        setReconciliation(reconciliationRes.value.data);
      }
      if (subscriptionRes.status === "fulfilled") {
        setSubscription(subscriptionRes.value.data);
      }

      // Toast on a global failure if everything rejected.
      if (
        statsRes.status === "rejected" &&
        ordersRes.status === "rejected" &&
        topProductsRes.status === "rejected"
      ) {
        toast({
          message: "Could not load dashboard",
          description: "Check your connection and try again.",
          variant: "error",
        });
      }
    } catch (error) {
      // Silent — Promise.allSettled swallows rejections.
    } finally {
      setIsRefreshing(false);
      setIsLoadingStats(false);
      setIsLoadingOrders(false);
      setIsLoadingProducts(false);
      setIsLoadingAbandoned(false);
      setIsLoadingSuggestions(false);
      setIsLoadingReconciliation(false);
      setIsLoadingSubscription(false);
      setIsInitialLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  // ---- Derived data -----------------------------------------------------

  const greeting = useMemo(() => greetingFor(new Date()), []);

  const upgradeEligible = useMemo(() => {
    if (!subscription) return false;
    return (
      subscription.current_products >=
        subscription.plan_info.max_products * 0.8 ||
      subscription.current_orders >=
        subscription.plan_info.max_orders * 0.8
    );
  }, [subscription]);

  // Show skeleton only on first cold load.
  if (isInitialLoading) {
    return <DashboardHomeSkeleton />;
  }

  return (
    <PageFrame>
      <PageHeader>
        <PageHeaderContent>
          <PageEyebrow>{greeting} / overview</PageEyebrow>
          <PageTitle>Dashboard</PageTitle>
          <PageDescription>
            Your store&apos;s live orders, revenue, inventory alerts, and priorities.
          </PageDescription>
        </PageHeaderContent>
        <PageActions>
          <Button
            variant="outline"
            className=""
            onClick={fetchAll}
            disabled={isRefreshing}
          >
            <RefreshCw
              className={cn(
                "mr-1.5 h-4 w-4",
                isRefreshing && "animate-spin",
              )}
            />
            Refresh
          </Button>
          <Button asChild className="">
            <Link href="/dashboard/products/new">
              <Plus className="mr-1.5 size-4" />
              Add product
            </Link>
          </Button>
        </PageActions>
      </PageHeader>

      <TodayOverview stats={stats} isLoading={isLoadingStats} />

      {subscription && upgradeEligible ? (
        <UpgradePrompt
          productCount={subscription.current_products}
          maxProducts={subscription.plan_info.max_products}
          orderCount={subscription.current_orders}
          maxOrders={subscription.plan_info.max_orders}
          plan={subscription.plan}
        />
      ) : null}

      <QuickActions />

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <RecentOrdersCard orders={recentOrders} isLoading={isLoadingOrders} />
          <TopProductsCard products={topProducts} isLoading={isLoadingProducts} />
        </div>
        <div className="space-y-4">
          <PlanUsageCard
            subscription={subscription}
            isLoading={isLoadingSubscription}
          />
          <ActionNeededCard
            abandonedCount={abandoned.length}
            suggestions={suggestions}
            reconciliation={reconciliation}
            isLoadingAbandoned={isLoadingAbandoned}
            isLoadingSuggestions={isLoadingSuggestions}
          />
        </div>
      </div>

      <StorefrontCard />

      <MobileStickyActions className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div className="min-w-0">
          <p className="text-xs uppercase tracking-wide text-muted-foreground">
            Today
          </p>
          <p className="truncate text-sm font-semibold text-foreground">
            {stats?.today_orders ?? 0} orders ·{" "}
            {formatCurrency(stats?.today_revenue ?? 0)}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button asChild variant="outline" className="">
            <Link href="/dashboard/orders">
              <ShoppingBag className="mr-1.5 size-4" />
              View orders
            </Link>
          </Button>
          <Button asChild className="">
            <Link href="/dashboard/products/new">
              <Plus className="mr-1.5 size-4" />
              Add product
            </Link>
          </Button>
        </div>
      </MobileStickyActions>
    </PageFrame>
  );
}
