import { Metadata } from "next";
import { redirect } from "next/navigation";
import { getServerSession } from "@/lib/auth";
import CustomersPageClient from "./page-client";

export const metadata: Metadata = {
  title: "Customers | ShopiBD Dashboard",
  description: "Manage your customers and CRM",
};

export default async function CustomersPage() {
  const session = await getServerSession();
  if (!session) {
    redirect("/auth/login");
  }

  return <CustomersPageClient />;
}
