"use client";

import React, { useCallback, useEffect, useMemo, useState } from "react";
import { MoreHorizontal, Search, SlidersHorizontal, Users } from "lucide-react";
import { customerApi } from "@/lib/api";
import type {
  Customer,
  CustomerListItem,
  CustomerFilters,
  CustomerUpdate,
} from "@/types/customer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Select } from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import {
  MetricCard,
  MetricStrip,
  PageActions,
  PageDescription,
  PageEyebrow,
  PageFrame,
  PageHeader,
  PageHeaderContent,
  PageTitle,
  SectionDescription,
  SectionHeader,
  SectionTitle,
  SurfaceSection,
} from "@/components/layout/page-structure";

// ---------------------------------------------------------------------------
// Segment config
// ---------------------------------------------------------------------------

const SEGMENT_OPTIONS = [
  { value: "", label: "All Segments" },
  { value: "new", label: "New" },
  { value: "repeat", label: "Repeat" },
  { value: "vip", label: "VIP" },
  { value: "inactive", label: "Inactive" },
  { value: "dormant", label: "Dormant" },
];

const SEGMENT_BADGE: Record<string, "default" | "success" | "info" | "warning" | "secondary"> = {
  new: "info",
  repeat: "success",
  vip: "default",
  inactive: "warning",
  dormant: "secondary",
};

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function formatCurrency(amount: number): string {
  return "৳" + amount.toFixed(2);
}

function formatDate(dateStr?: string): string {
  if (!dateStr) return "—";
  return new Date(dateStr).toLocaleDateString("en-BD", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

// ---------------------------------------------------------------------------
// Subcomponents
// ---------------------------------------------------------------------------

function CustomersSummary({ customers, total }: { customers: CustomerListItem[]; total: number }) {
  const summary = useMemo(() => {
    const vip = customers.filter((c) => c.segment === "vip").length;
    const repeat = customers.filter((c) => c.segment === "repeat").length;
    const totalSpent = customers.reduce((sum, c) => sum + c.total_spent, 0);

    return { vip, repeat, totalSpent };
  }, [customers]);

  return (
    <MetricStrip>
      <MetricCard>
        <p className="text-sm font-medium text-muted-foreground">Visible customers</p>
        <p className="mt-2 text-2xl font-semibold tracking-tight text-foreground">{total}</p>
        <p className="mt-1 text-xs text-muted-foreground">Customers matching your filters.</p>
      </MetricCard>
      <MetricCard>
        <p className="text-sm font-medium text-muted-foreground">VIP in view</p>
        <p className="mt-2 text-2xl font-semibold tracking-tight text-primary">{summary.vip}</p>
        <p className="mt-1 text-xs text-muted-foreground">Highest-value customer signals.</p>
      </MetricCard>
      <MetricCard>
        <p className="text-sm font-medium text-muted-foreground">Repeat buyers</p>
        <p className="mt-2 text-2xl font-semibold tracking-tight text-success">{summary.repeat}</p>
        <p className="mt-1 text-xs text-muted-foreground">Customers who order more than once.</p>
      </MetricCard>
      <MetricCard>
        <p className="text-sm font-medium text-muted-foreground">Revenue in view</p>
        <p className="mt-2 text-2xl font-semibold tracking-tight text-foreground">{formatCurrency(summary.totalSpent)}</p>
        <p className="mt-1 text-xs text-muted-foreground">Total spent by the visible customers.</p>
      </MetricCard>
    </MetricStrip>
  );
}

function CustomersEmptyState({ hasActiveFilters, onClear }: { hasActiveFilters: boolean; onClear: () => void }) {
  return (
    <SurfaceSection className="text-center">
      <div className="mx-auto flex max-w-md flex-col items-center gap-4 py-6">
        <div className="flex size-14 items-center justify-center border border-border bg-background text-muted-foreground">
          <Users className="size-6" />
        </div>
        <div className="space-y-2">
          <SectionTitle>No customers found</SectionTitle>
          <SectionDescription>
            {hasActiveFilters
              ? "Try adjusting the filters to broaden the result set."
              : "New customers will appear here once they place their first order."}
          </SectionDescription>
        </div>
        {hasActiveFilters ? (
          <Button variant="outline" onClick={onClear}>
            Clear filters
          </Button>
        ) : null}
      </div>
    </SurfaceSection>
  );
}

function CustomersLoadingState() {
  return (
    <div className="space-y-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <Card key={i} className="border-border/80 bg-background/60 ">
          <CardContent className="space-y-4 p-4">
            <div className="h-5 w-36 animate-pulse bg-muted" />
            <div className="grid grid-cols-3 gap-3">
              <div className="h-4 animate-pulse bg-muted" />
              <div className="h-4 animate-pulse bg-muted" />
              <div className="h-4 animate-pulse bg-muted" />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function CustomerCard({
  customer,
  onOpen,
}: {
  customer: CustomerListItem;
  onOpen: (id: number) => void;
}) {
  return (
    <Card
      className="cursor-pointer border-border/80 bg-background/70  transition-all duration-200 ease-premium hover:bg-background"
      onClick={() => onOpen(customer.id)}
    >
      <CardContent className="space-y-4 p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold text-foreground sm:text-base">{customer.name}</p>
            <p className="mt-1 text-sm text-muted-foreground">{customer.phone}</p>
          </div>
          <Badge variant={SEGMENT_BADGE[customer.segment] || "secondary"} className="shrink-0 capitalize">
            {customer.segment}
          </Badge>
        </div>

        <div className="grid grid-cols-3 gap-3 text-sm">
          <div>
            <p className="text-muted-foreground">Orders</p>
            <p className="mt-1 font-semibold text-foreground">{customer.total_orders}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Spent</p>
            <p className="mt-1 font-semibold text-foreground">{formatCurrency(customer.total_spent)}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Last order</p>
            <p className="mt-1 text-foreground">{formatDate(customer.last_order_date)}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function CustomersTable({
  customers,
  onOpen,
}: {
  customers: CustomerListItem[];
  onOpen: (id: number) => void;
}) {
  return (
    <div className="border border-border bg-background ">
      <Table>
        <TableHeader>
          <TableRow className="hover:bg-transparent">
            <TableHead>Name</TableHead>
            <TableHead>Phone</TableHead>
            <TableHead>Orders</TableHead>
            <TableHead>Total Spent</TableHead>
            <TableHead>Segment</TableHead>
            <TableHead>Last Order</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {customers.map((customer) => (
            <TableRow key={customer.id} className="cursor-pointer" onClick={() => onOpen(customer.id)}>
              <TableCell className="font-medium text-foreground">{customer.name}</TableCell>
              <TableCell>{customer.phone}</TableCell>
              <TableCell>{customer.total_orders}</TableCell>
              <TableCell className="font-medium text-foreground">{formatCurrency(customer.total_spent)}</TableCell>
              <TableCell>
                <Badge variant={SEGMENT_BADGE[customer.segment] || "secondary"} className="capitalize">
                  {customer.segment}
                </Badge>
              </TableCell>
              <TableCell>{formatDate(customer.last_order_date)}</TableCell>
              <TableCell className="text-right">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="size-8"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <MoreHorizontal className="size-4" />
                      <span className="sr-only">Actions</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpen(customer.id);
                      }}
                    >
                      View details
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

function Pagination({
  page,
  pageSize,
  total,
  totalPages,
  onPageChange,
}: {
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}) {
  return (
    <div className="flex flex-col gap-3 border border-border bg-background p-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="text-sm text-muted-foreground">
        Showing {total === 0 ? 0 : (page - 1) * pageSize + 1} to {Math.min(page * pageSize, total)} of {total} customers
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <Button variant="outline" size="sm" onClick={() => onPageChange(page - 1)} disabled={page <= 1}>
          Previous
        </Button>
        <div className="px-2 text-sm text-muted-foreground">Page {page} of {totalPages || 1}</div>
        <Button variant="outline" size="sm" onClick={() => onPageChange(page + 1)} disabled={page >= totalPages}>
          Next
        </Button>
      </div>
    </div>
  );
}

function FilterFields({
  searchQuery,
  segmentFilter,
  onSearchChange,
  onSegmentChange,
  onClear,
  hasActiveFilters,
}: {
  searchQuery: string;
  segmentFilter: string;
  onSearchChange: (value: string) => void;
  onSegmentChange: (value: string) => void;
  onClear: () => void;
  hasActiveFilters: boolean;
}) {
  return (
    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
      <div className="space-y-2 xl:col-span-2">
        <label className="text-sm font-medium text-foreground">Search</label>
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input className="h-11 bg-muted pl-10" placeholder="Name or phone..." value={searchQuery} onChange={(e) => onSearchChange(e.target.value)} />
        </div>
      </div>
      <div className="space-y-2">
        <label className="text-sm font-medium text-foreground">Segment</label>
        <Select
          className="h-11 bg-muted"
          value={segmentFilter}
          onChange={(e) => onSegmentChange(e.target.value)}
          options={SEGMENT_OPTIONS}
        />
      </div>
      <div className="flex items-end">
        <Button variant="outline" className="h-11 w-full" onClick={onClear} disabled={!hasActiveFilters}>
          Clear filters
        </Button>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Page Component
// ---------------------------------------------------------------------------

export default function CustomersPageClient() {
  const { toast } = useToast();

  const [customers, setCustomers] = useState<CustomerListItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const pageSize = 20;
  const [totalPages, setTotalPages] = useState(0);

  const [searchQuery, setSearchQuery] = useState("");
  const [segmentFilter, setSegmentFilter] = useState("");

  const [selectedCustomerId, setSelectedCustomerId] = useState<number | null>(null);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [isDetailLoading, setIsDetailLoading] = useState(false);

  const [customerOrders, setCustomerOrders] = useState<any[]>([]);
  const [ordersPage, setOrdersPage] = useState(1);
  const [ordersTotal, setOrdersTotal] = useState(0);
  const [ordersLoading, setOrdersLoading] = useState(false);

  const [editingNotes, setEditingNotes] = useState("");
  const [editingTags, setEditingTags] = useState("");
  const [isEditing, setIsEditing] = useState(false);

  const [isBroadcastOpen, setIsBroadcastOpen] = useState(false);
  const [broadcastSegment, setBroadcastSegment] = useState("");
  const [broadcastMessage, setBroadcastMessage] = useState("");
  const [isSending, setIsSending] = useState(false);

  const [isRecalculating, setIsRecalculating] = useState(false);

  const fetchCustomers = useCallback(async () => {
    setIsLoading(true);
    try {
      const params: CustomerFilters = {
        page,
        page_size: pageSize,
        search: searchQuery || undefined,
        segment: segmentFilter || undefined,
      };
      const response = await customerApi.list(params);
      const data = response.data;
      setCustomers(data.items);
      setTotal(data.total);
      setTotalPages(data.total_pages);
    } catch (error: any) {
      toast({
        message: "Error",
        description: error?.response?.data?.detail || "Failed to load customers",
        variant: "error",
      });
    } finally {
      setIsLoading(false);
    }
  }, [page, searchQuery, segmentFilter, toast]);

  useEffect(() => {
    fetchCustomers();
  }, [fetchCustomers]);

  const openDetail = useCallback(async (customerId: number) => {
    setSelectedCustomerId(customerId);
    setIsDetailOpen(true);
    setIsDetailLoading(true);
    setCustomerOrders([]);
    setOrdersPage(1);
    setOrdersTotal(0);
    try {
      const [customerResp, ordersResp] = await Promise.all([
        customerApi.get(customerId),
        customerApi.getOrders(customerId, 1, 10),
      ]);
      setSelectedCustomer(customerResp.data);
      setEditingNotes(customerResp.data.notes || "");
      setEditingTags(customerResp.data.tags || "");
      setCustomerOrders(ordersResp.data.items);
      setOrdersTotal(ordersResp.data.total);
    } catch (error: any) {
      toast({
        message: "Error",
        description: error?.response?.data?.detail || "Failed to load customer details",
        variant: "error",
      });
    } finally {
      setIsDetailLoading(false);
    }
  }, [toast]);

  const closeDetail = useCallback(() => {
    setIsDetailOpen(false);
    setSelectedCustomerId(null);
    setSelectedCustomer(null);
    setCustomerOrders([]);
    setIsEditing(false);
  }, []);

  const loadMoreOrders = useCallback(async () => {
    if (!selectedCustomerId) return;
    const nextPage = ordersPage + 1;
    setOrdersLoading(true);
    try {
      const resp = await customerApi.getOrders(selectedCustomerId, nextPage, 10);
      setCustomerOrders((prev) => [...prev, ...resp.data.items]);
      setOrdersPage(nextPage);
      setOrdersTotal(resp.data.total);
    } catch (error: any) {
      toast({
        message: "Error",
        description: "Failed to load more orders",
        variant: "error",
      });
    } finally {
      setOrdersLoading(false);
    }
  }, [selectedCustomerId, ordersPage, toast]);

  const saveNotes = useCallback(async () => {
    if (!selectedCustomerId) return;
    try {
      const data: CustomerUpdate = {
        notes: editingNotes,
        tags: editingTags,
      };
      const resp = await customerApi.updateNotes(selectedCustomerId, data);
      setSelectedCustomer(resp.data);
      setIsEditing(false);
      toast({
        message: "Success",
        description: "Customer notes updated",
        variant: "success",
      });
      fetchCustomers();
    } catch (error: any) {
      toast({
        message: "Error",
        description: error?.response?.data?.detail || "Failed to save notes",
        variant: "error",
      });
    }
  }, [selectedCustomerId, editingNotes, editingTags, toast, fetchCustomers]);

  const handleBroadcast = useCallback(async () => {
    if (!broadcastSegment || !broadcastMessage.trim()) return;
    setIsSending(true);
    try {
      const resp = await customerApi.broadcast({
        segment: broadcastSegment,
        message: broadcastMessage.trim(),
      });
      toast({
        message: "Broadcast Sent",
        description: resp.data.message,
        variant: "success",
      });
      setIsBroadcastOpen(false);
      setBroadcastSegment("");
      setBroadcastMessage("");
    } catch (error: any) {
      toast({
        message: "Error",
        description: error?.response?.data?.detail || "Failed to send broadcast",
        variant: "error",
      });
    } finally {
      setIsSending(false);
    }
  }, [broadcastSegment, broadcastMessage, toast]);

  const handleRecalculate = useCallback(async () => {
    setIsRecalculating(true);
    try {
      const resp = await customerApi.recalculateSegments();
      toast({
        message: "Segments Updated",
        description: resp.data.message,
        variant: "success",
      });
      fetchCustomers();
    } catch (error: any) {
      toast({
        message: "Error",
        description: error?.response?.data?.detail || "Failed to recalculate segments",
        variant: "error",
      });
    } finally {
      setIsRecalculating(false);
    }
  }, [toast, fetchCustomers]);

  const clearFilters = useCallback(() => {
    setSearchQuery("");
    setSegmentFilter("");
    setPage(1);
  }, []);

  const hasActiveFilters = useMemo(
    () => Boolean(searchQuery || segmentFilter),
    [searchQuery, segmentFilter],
  );

  return (
    <PageFrame>
      <PageHeader>
        <PageHeaderContent>
          <PageEyebrow>Customer relationships</PageEyebrow>
          <PageTitle>Customers workspace</PageTitle>
          <PageDescription>
            Scan customer signals, update notes and tags, and run broadcasts without leaving a mobile-first workflow.
          </PageDescription>
        </PageHeaderContent>
        <PageActions>
          <Button variant="outline" onClick={handleRecalculate} disabled={isRecalculating}>
            {isRecalculating ? "Recalculating..." : "Recalculate Segments"}
          </Button>
          <Button onClick={() => setIsBroadcastOpen(true)}>
            Broadcast Message
          </Button>
        </PageActions>
      </PageHeader>

      <CustomersSummary customers={customers} total={total} />

      <SurfaceSection>
        <SectionHeader>
          <div>
            <SectionTitle>Search and filter</SectionTitle>
            <SectionDescription>Compact desktop toolbar and a mobile filter sheet for narrow screens.</SectionDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {hasActiveFilters ? (
              <Badge variant="secondary" className="px-3 py-1">Filters active</Badge>
            ) : null}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" className="md:hidden">
                  <SlidersHorizontal className="size-4" />
                  Filters
                </Button>
              </SheetTrigger>
              <SheetContent side="bottom" className="max-h-[85vh] border-t border-border bg-background p-0">
                <DialogTitle className="sr-only">Filter customers</DialogTitle>
                <DialogDescription className="sr-only">Narrow the list by search term or customer segment.</DialogDescription>
                <div className="space-y-5 p-5">
                  <div>
                    <p className="text-lg font-semibold text-foreground">Filter customers</p>
                    <p className="mt-1 text-sm text-muted-foreground">Narrow the list by search term or customer segment.</p>
                  </div>
                  <FilterFields
                    searchQuery={searchQuery}
                    segmentFilter={segmentFilter}
                    onSearchChange={(value) => {
                      setSearchQuery(value);
                      setPage(1);
                    }}
                    onSegmentChange={(value) => {
                      setSegmentFilter(value);
                      setPage(1);
                    }}
                    onClear={clearFilters}
                    hasActiveFilters={hasActiveFilters}
                  />
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </SectionHeader>

        <div className="mt-4 hidden md:block">
          <FilterFields
            searchQuery={searchQuery}
            segmentFilter={segmentFilter}
            onSearchChange={(value) => {
              setSearchQuery(value);
              setPage(1);
            }}
            onSegmentChange={(value) => {
              setSegmentFilter(value);
              setPage(1);
            }}
            onClear={clearFilters}
            hasActiveFilters={hasActiveFilters}
          />
        </div>
      </SurfaceSection>

      {isLoading ? <CustomersLoadingState /> : null}

      {!isLoading && customers.length === 0 ? (
        <CustomersEmptyState hasActiveFilters={hasActiveFilters} onClear={clearFilters} />
      ) : null}

      {!isLoading && customers.length > 0 ? (
        <>
          <div className="space-y-4 md:hidden">
            {customers.map((customer) => (
              <CustomerCard key={customer.id} customer={customer} onOpen={openDetail} />
            ))}
          </div>

          <div className="hidden md:block">
            <CustomersTable customers={customers} onOpen={openDetail} />
          </div>

          <Pagination page={page} pageSize={pageSize} total={total} totalPages={totalPages} onPageChange={setPage} />
        </>
      ) : null}

      <Dialog open={isDetailOpen} onOpenChange={(open) => !open && closeDetail()}>
        <DialogContent className="max-h-[90vh] max-w-3xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {isDetailLoading ? "Loading..." : selectedCustomer ? selectedCustomer.name : "Customer Details"}
            </DialogTitle>
            <DialogDescription>{selectedCustomer?.phone}</DialogDescription>
          </DialogHeader>

          {isDetailLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-8 w-48" />
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-48 w-full" />
            </div>
          ) : selectedCustomer ? (
            <div className="space-y-6">
              <MetricStrip>
                <MetricCard>
                  <p className="text-sm font-medium text-muted-foreground">Total Orders</p>
                  <p className="mt-2 text-2xl font-semibold tracking-tight text-foreground">{selectedCustomer.total_orders}</p>
                </MetricCard>
                <MetricCard>
                  <p className="text-sm font-medium text-muted-foreground">Total Spent</p>
                  <p className="mt-2 text-2xl font-semibold tracking-tight text-foreground">{formatCurrency(selectedCustomer.total_spent)}</p>
                </MetricCard>
                <MetricCard>
                  <p className="text-sm font-medium text-muted-foreground">Segment</p>
                  <div className="mt-2">
                    <Badge variant={SEGMENT_BADGE[selectedCustomer.segment] || "secondary"} className="capitalize">
                      {selectedCustomer.segment}
                    </Badge>
                  </div>
                </MetricCard>
                <MetricCard>
                  <p className="text-sm font-medium text-muted-foreground">Last Order</p>
                  <p className="mt-2 text-sm font-semibold text-foreground">{formatDate(selectedCustomer.last_order_date)}</p>
                </MetricCard>
              </MetricStrip>

              <SurfaceSection>
                <SectionHeader>
                  <div>
                    <SectionTitle>Contact info</SectionTitle>
                    <SectionDescription>Verified contact and account details.</SectionDescription>
                  </div>
                </SectionHeader>
                <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Name:</span> {selectedCustomer.name}
                  </div>
                  <div>
                    <span className="font-medium">Phone:</span> {selectedCustomer.phone}
                  </div>
                  <div>
                    <span className="font-medium">Email:</span> {selectedCustomer.email || "—"}
                  </div>
                  <div>
                    <span className="font-medium">Customer since:</span> {formatDate(selectedCustomer.created_at)}
                  </div>
                </div>
              </SurfaceSection>

              <SurfaceSection>
                <SectionHeader>
                  <div>
                    <SectionTitle>Notes and tags</SectionTitle>
                    <SectionDescription>Keep context for the next conversation with this customer.</SectionDescription>
                  </div>
                  {!isEditing ? (
                    <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
                      Edit
                    </Button>
                  ) : (
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setEditingNotes(selectedCustomer.notes || "");
                          setEditingTags(selectedCustomer.tags || "");
                          setIsEditing(false);
                        }}
                      >
                        Cancel
                      </Button>
                      <Button size="sm" onClick={saveNotes}>
                        Save
                      </Button>
                    </div>
                  )}
                </SectionHeader>
                <div className="mt-4 space-y-4">
                  <div>
                    <label className="text-sm font-medium">Tags</label>
                    {isEditing ? (
                      <Input className="mt-2 h-11 bg-muted" value={editingTags} onChange={(e) => setEditingTags(e.target.value)} placeholder="Comma-separated tags" />
                    ) : (
                      <p className="mt-2 text-sm text-muted-foreground">{selectedCustomer.tags || "No tags"}</p>
                    )}
                  </div>
                  <div>
                    <label className="text-sm font-medium">Notes</label>
                    {isEditing ? (
                      <textarea
                        value={editingNotes}
                        onChange={(e) => setEditingNotes(e.target.value)}
                        placeholder="Add notes about this customer..."
                        className="mt-2 min-h-32 w-full border border-border bg-muted p-3 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
                      />
                    ) : (
                      <p className="mt-2 whitespace-pre-wrap text-sm text-muted-foreground">{selectedCustomer.notes || "No notes"}</p>
                    )}
                  </div>
                </div>
              </SurfaceSection>

              <SurfaceSection>
                <SectionHeader>
                  <div>
                    <SectionTitle>Order history ({ordersTotal})</SectionTitle>
                    <SectionDescription>Recent orders placed by this customer.</SectionDescription>
                  </div>
                </SectionHeader>
                <div className="mt-4 space-y-3">
                  {customerOrders.length === 0 ? (
                    <p className="border border-dashed border-border/80 bg-muted/30 p-4 text-sm text-muted-foreground">
                      No orders found
                    </p>
                  ) : (
                    customerOrders.map((order: any) => (
                      <div key={order.id} className="border border-border bg-background p-4">
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0 flex-1">
                            <p className="font-mono text-sm font-semibold text-foreground">#{order.order_number}</p>
                            <p className="mt-1 text-sm text-muted-foreground">{formatDate(order.created_at)}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold text-foreground">{formatCurrency(order.total_amount)}</p>
                            <div className="mt-2 flex flex-wrap justify-end gap-2">
                              <Badge variant="secondary">{order.status}</Badge>
                              <Badge variant="outline">{order.payment_status}</Badge>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                  {customerOrders.length < ordersTotal ? (
                    <div className="pt-2 text-center">
                      <Button variant="outline" size="sm" onClick={loadMoreOrders} disabled={ordersLoading}>
                        {ordersLoading ? "Loading..." : "Load More Orders"}
                      </Button>
                    </div>
                  ) : null}
                </div>
              </SurfaceSection>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>

      <Dialog open={isBroadcastOpen} onOpenChange={setIsBroadcastOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Broadcast WhatsApp Message</DialogTitle>
            <DialogDescription>
              Send a message to all customers in a specific segment.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Target Segment</label>
              <Select
                className="h-11 bg-muted"
                value={broadcastSegment}
                onChange={(e) => setBroadcastSegment(e.target.value)}
                options={[
                  { value: "", label: "Select a segment..." },
                  ...SEGMENT_OPTIONS.filter((o) => o.value).map((opt) => ({ value: opt.value, label: opt.label })),
                ]}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Message</label>
              <textarea
                className="min-h-32 w-full border border-border bg-muted p-3 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
                placeholder="Type your WhatsApp message here..."
                value={broadcastMessage}
                onChange={(e) => setBroadcastMessage(e.target.value)}
                maxLength={4096}
                rows={5}
              />
              <p className="text-right text-xs text-muted-foreground">
                {broadcastMessage.length} / 4096
              </p>
            </div>

            {broadcastSegment ? (
              <p className="border border-border/80 bg-muted/30 p-3 text-sm text-muted-foreground">
                This message will be sent to all customers in the <strong>{broadcastSegment}</strong> segment via WhatsApp.
              </p>
            ) : null}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsBroadcastOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleBroadcast} disabled={!broadcastSegment || !broadcastMessage.trim() || isSending}>
              {isSending ? "Sending..." : "Send Broadcast"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageFrame>
  );
}
