import { Metadata } from "next";
import { redirect } from "next/navigation";
import { getServerSession } from "@/lib/auth";
import BrandingPageClient from "./page-client";

export const metadata: Metadata = {
  title: "Branding & Domain | ShopiBD",
  description:
    "Configure your custom domain, subdomain, and branding settings",
};

export default async function BrandingPage() {
  // Server-side auth check
  const session = await getServerSession();
  if (!session) {
    redirect("/auth/login");
  }

  return <BrandingPageClient />;
}
