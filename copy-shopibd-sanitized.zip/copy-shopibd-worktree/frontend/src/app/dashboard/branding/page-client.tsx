"use client";

import React, { useCallback, useEffect, useState } from "react";
import { whitelabelApi } from "@/lib/api";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import BrandPreview from "@/components/dashboard/brand-preview";
import type {
  WhiteLabelStatus,
  BrandingSettings,
  DomainVerifyResponse,
  DnsRecord,
} from "@/types/whitelabel";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

type TabId = "domain" | "branding";

interface PageState {
  status: WhiteLabelStatus | null;
  loading: boolean;
  error: string | null;
  success: string | null;
}

// Default branding
const DEFAULT_BRANDING: BrandingSettings = {
  primary_color: "#1a73e8",
  secondary_color: "#34a853",
  font_family: "Inter, sans-serif",
  logo_url: null,
  favicon_url: null,
  custom_css: null,
};

// ---------------------------------------------------------------------------
// Main component
// ---------------------------------------------------------------------------

export default function BrandingPageClient() {
  // Tab state
  const [activeTab, setActiveTab] = useState<TabId>("domain");

  // Data state
  const [state, setState] = useState<PageState>({
    status: null,
    loading: true,
    error: null,
    success: null,
  });

  // Domain inputs
  const [domainInput, setDomainInput] = useState("");
  const [subdomainInput, setSubdomainInput] = useState("");

  // Verification
  const [verifyResult, setVerifyResult] =
    useState<DomainVerifyResponse | null>(null);
  const [verifying, setVerifying] = useState(false);

  // Branding form
  const [brandingForm, setBrandingForm] =
    useState<BrandingSettings>(DEFAULT_BRANDING);
  const [hideBranding, setHideBranding] = useState(false);
  const [savingBranding, setSavingBranding] = useState(false);

  // Shop name for preview
  const [shopName, setShopName] = useState("Your Shop");

  // ---------------------------------------------------------------------------
  // Data fetching
  // ---------------------------------------------------------------------------

  const fetchStatus = useCallback(async () => {
    setState((prev) => ({ ...prev, loading: true, error: null }));
    try {
      const response = await whitelabelApi.getStatus();
      const status = response.data;
      setState((prev) => ({ ...prev, status, loading: false }));

      // Populate form fields from existing data
      if (status.custom_domain) setDomainInput(status.custom_domain);
      if (status.subdomain) setSubdomainInput(status.subdomain);
      if (status.branding) setBrandingForm(status.branding);
      setHideBranding(status.hide_branding);
    } catch (err: any) {
      setState((prev) => ({
        ...prev,
        loading: false,
        error:
          err?.response?.data?.detail ||
          err?.message ||
          "Failed to load branding status",
      }));
    }
  }, []);

  useEffect(() => {
    fetchStatus();
  }, [fetchStatus]);

  // ---------------------------------------------------------------------------
  // Domain handlers
  // ---------------------------------------------------------------------------

  const handleSetDomain = async () => {
    if (!domainInput.trim()) return;
    setState((prev) => ({ ...prev, error: null, success: null }));
    try {
      const response = await whitelabelApi.setDomain({
        domain: domainInput.trim(),
      });
      setState((prev) => ({
        ...prev,
        status: response.data,
        success: "Custom domain saved! Verify it below.",
      }));
    } catch (err: any) {
      setState((prev) => ({
        ...prev,
        error:
          err?.response?.data?.detail ||
          err?.message ||
          "Failed to set domain",
      }));
    }
  };

  const handleSetSubdomain = async () => {
    if (!subdomainInput.trim()) return;
    setState((prev) => ({ ...prev, error: null, success: null }));
    try {
      const response = await whitelabelApi.setSubdomain({
        subdomain: subdomainInput.trim(),
      });
      setState((prev) => ({
        ...prev,
        status: response.data,
        success: `Subdomain "${subdomainInput.trim()}" saved!`,
      }));
    } catch (err: any) {
      setState((prev) => ({
        ...prev,
        error:
          err?.response?.data?.detail ||
          err?.message ||
          "Failed to set subdomain",
      }));
    }
  };

  const handleCheckVerification = async () => {
    setVerifying(true);
    setState((prev) => ({ ...prev, error: null, success: null }));
    try {
      const response = await whitelabelApi.checkDomainVerification();
      setVerifyResult(response.data);
    } catch (err: any) {
      setState((prev) => ({
        ...prev,
        error:
          err?.response?.data?.detail ||
          err?.message ||
          "Failed to check verification",
      }));
    } finally {
      setVerifying(false);
    }
  };

  const handleTriggerVerification = async () => {
    setVerifying(true);
    setState((prev) => ({ ...prev, error: null, success: null }));
    try {
      const response = await whitelabelApi.triggerDomainVerification();
      setVerifyResult(response.data);
      // Refresh status
      fetchStatus();
      if (response.data.verified) {
        setState((prev) => ({
          ...prev,
          success: "Domain verified successfully! SSL is being provisioned.",
        }));
      }
    } catch (err: any) {
      setState((prev) => ({
        ...prev,
        error:
          err?.response?.data?.detail ||
          err?.message ||
          "Verification failed",
      }));
    } finally {
      setVerifying(false);
    }
  };

  // ---------------------------------------------------------------------------
  // Branding handlers
  // ---------------------------------------------------------------------------

  const handleBrandingChange = (
    field: keyof BrandingSettings,
    value: string | null
  ) => {
    setBrandingForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSaveBranding = async () => {
    setSavingBranding(true);
    setState((prev) => ({ ...prev, error: null, success: null }));
    try {
      const response = await whitelabelApi.updateBranding(brandingForm);
      setState((prev) => ({
        ...prev,
        status: response.data,
        success: "Branding settings saved!",
      }));
    } catch (err: any) {
      setState((prev) => ({
        ...prev,
        error:
          err?.response?.data?.detail ||
          err?.message ||
          "Failed to save branding",
      }));
    } finally {
      setSavingBranding(false);
    }
  };

  const handleToggleHideBranding = async () => {
    setState((prev) => ({ ...prev, error: null, success: null }));
    try {
      const response = await whitelabelApi.toggleHideBranding();
      setHideBranding(response.data.hide_branding);
      setState((prev) => ({
        ...prev,
        status: response.data,
        success: response.data.hide_branding
          ? '"Powered by ShopiBD" is now hidden'
          : '"Powered by ShopiBD" is now visible',
      }));
    } catch (err: any) {
      setState((prev) => ({
        ...prev,
        error:
          err?.response?.data?.detail ||
          err?.message ||
          "Failed to toggle",
      }));
    }
  };

  // ---------------------------------------------------------------------------
  // Render helpers
  // ---------------------------------------------------------------------------

  const tabs: { id: TabId; label: string }[] = [
    { id: "domain", label: "Custom Domain" },
    { id: "branding", label: "Branding" },
  ];

  const status = state.status;

  // ---------------------------------------------------------------------------
  // Render: Domain Tab
  // ---------------------------------------------------------------------------

  const renderDomainTab = () => (
    <div className="space-y-8">
      {/* Current status card */}
      <div className="border border-border bg-background p-6 ">
        <h3 className="mb-4 text-lg font-semibold">Current Status</h3>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          <StatusBadge
            label="Custom Domain"
            value={status?.custom_domain || "Not set"}
            verified={!!status?.custom_domain}
          />
          <StatusBadge
            label="Subdomain"
            value={status?.subdomain || "Not set"}
            verified={!!status?.subdomain}
          />
          <StatusBadge
            label="Domain Verified"
            value={status?.domain_verified ? "Yes" : "No"}
            verified={!!status?.domain_verified}
          />
          <StatusBadge
            label="SSL"
            value={status?.ssl_provisioned ? "Active" : "Pending"}
            verified={!!status?.ssl_provisioned}
          />
        </div>
      </div>

      {/* Custom domain input */}
      <div className="border border-border bg-background p-6 ">
        <h3 className="mb-4 text-lg font-semibold">Custom Domain</h3>
        <p className="mb-4 text-sm text-muted-foreground">
          Point your own domain (e.g. rinascollection.com) to your ShopiBD
          store.
        </p>
        <div className="flex gap-3">
          <div className="flex-1">
            <label className="mb-1 block text-sm font-medium text-foreground">
              Domain
            </label>
            <input
              type="text"
              className="w-full border border-border px-3 py-2 text-sm focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-ring"
              placeholder="rinascollection.com"
              value={domainInput}
              onChange={(e) => setDomainInput(e.target.value)}
            />
          </div>
        </div>
        <button
          onClick={handleSetDomain}
          disabled={!domainInput.trim() || state.loading}
          className="mt-3 bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"
        >
          Save Domain
        </button>
      </div>

      {/* Subdomain input */}
      <div className="border border-border bg-background p-6 ">
        <h3 className="mb-4 text-lg font-semibold">Subdomain</h3>
        <p className="mb-4 text-sm text-muted-foreground">
          Choose a subdomain like &quot;rina&quot; for rina.shopibd.com.
        </p>
        <div className="flex items-end gap-3">
          <div className="flex-1">
            <label className="mb-1 block text-sm font-medium text-foreground">
              Subdomain
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                className="flex-1 border border-border px-3 py-2 text-sm focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-ring"
                placeholder="rina"
                value={subdomainInput}
                onChange={(e) => setSubdomainInput(e.target.value)}
              />
              <span className="text-sm text-muted-foreground">.shopibd.com</span>
            </div>
          </div>
        </div>
        <button
          onClick={handleSetSubdomain}
          disabled={!subdomainInput.trim() || state.loading}
          className="mt-3 bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"
        >
          Save Subdomain
        </button>
      </div>

      {/* Domain verification */}
      <div className="border border-border bg-background p-6 ">
        <h3 className="mb-4 text-lg font-semibold">
          Domain Verification
          {status?.domain_verified && (
            <span className="ml-2 inline-flex items-center gap-1 text-sm font-normal text-success">
              <svg
                className="size-4"
                fill="currentColor"
                viewBox="0 0 20 20"
              >
                <path
                  fillRule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                  clipRule="evenodd"
                />
              </svg>
              Verified
            </span>
          )}
        </h3>

        <div className="mb-6 flex gap-3">
          <button
            onClick={handleCheckVerification}
            disabled={!status?.custom_domain || verifying}
            className="border border-border px-4 py-2 text-sm font-medium hover:bg-muted disabled:opacity-50"
          >
            {verifying ? "Checking..." : "Check Status"}
          </button>
          <button
            onClick={handleTriggerVerification}
            disabled={!status?.custom_domain || verifying}
            className="bg-success px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-success/90 disabled:opacity-50"
          >
            {verifying ? "Verifying..." : "Verify Now"}
          </button>
        </div>

        {/* DNS records wizard */}
        {verifyResult && (
          <div className="space-y-4">
            {verifyResult.verified ? (
              <div className="border-success/30 bg-success/10 p-4 text-sm text-success">
                {verifyResult.message}
              </div>
            ) : (
              <div>
                <p className="mb-3 text-sm font-medium text-foreground">
                  Add the following DNS records to your domain provider:
                </p>
                <div className="space-y-3">
                  {verifyResult.dns_records.map((record, index) => (
                    <DnsRecordCard key={index} record={record} />
                  ))}
                </div>
                <p className="mt-3 text-xs text-muted-foreground">
                  DNS changes may take up to 48 hours to propagate. Click
                  &quot;Verify Now&quot; after adding the records.
                </p>
              </div>
            )}
          </div>
        )}

        {/* SSL status */}
        {status?.custom_domain && (
          <div className="mt-4 border-t border-border pt-4">
            <div className="flex items-center gap-2 text-sm">
              <span className="text-muted-foreground">SSL Certificate:</span>
              {status.ssl_provisioned ? (
                <span className="flex items-center gap-1 font-medium text-success">
                  <svg
                    className="size-4"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path
                      fillRule="evenodd"
                      d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z"
                      clipRule="evenodd"
                    />
                  </svg>
                  Active
                </span>
              ) : (
                <span className="font-medium text-warning">
                  Provisioning...
                </span>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );

  // ---------------------------------------------------------------------------
  // Render: Branding Tab
  // ---------------------------------------------------------------------------

  const renderBrandingTab = () => (
    <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
      {/* Settings form */}
      <div className="space-y-6">
        <div className="border border-border bg-background p-6 ">
          <h3 className="mb-4 text-lg font-semibold">Colors</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">
                Primary Color
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  className="size-9 cursor-pointer border border-border"
                  value={brandingForm.primary_color}
                  onChange={(e) =>
                    handleBrandingChange("primary_color", e.target.value)
                  }
                />
                <input
                  type="text"
                  className="flex-1 border border-border px-3 py-2 font-mono text-sm focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-ring"
                  value={brandingForm.primary_color}
                  onChange={(e) =>
                    handleBrandingChange("primary_color", e.target.value)
                  }
                />
              </div>
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">
                Secondary Color
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  className="size-9 cursor-pointer border border-border"
                  value={brandingForm.secondary_color}
                  onChange={(e) =>
                    handleBrandingChange("secondary_color", e.target.value)
                  }
                />
                <input
                  type="text"
                  className="flex-1 border border-border px-3 py-2 font-mono text-sm focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-ring"
                  value={brandingForm.secondary_color}
                  onChange={(e) =>
                    handleBrandingChange("secondary_color", e.target.value)
                  }
                />
              </div>
            </div>
          </div>
        </div>

        <div className="border border-border bg-background p-6 ">
          <h3 className="mb-4 text-lg font-semibold">Logo &amp; Favicon</h3>
          <div className="space-y-4">
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">
                Logo URL
              </label>
              <input
                type="text"
                className="w-full border border-border px-3 py-2 text-sm focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-ring"
                placeholder="https://example.com/logo.png"
                value={brandingForm.logo_url || ""}
                onChange={(e) =>
                  handleBrandingChange("logo_url", e.target.value || null)
                }
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">
                Favicon URL
              </label>
              <input
                type="text"
                className="w-full border border-border px-3 py-2 text-sm focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-ring"
                placeholder="https://example.com/favicon.ico"
                value={brandingForm.favicon_url || ""}
                onChange={(e) =>
                  handleBrandingChange("favicon_url", e.target.value || null)
                }
              />
            </div>
          </div>
        </div>

        <div className="border border-border bg-background p-6">
          <h3 className="mb-4 text-lg font-semibold">Typography</h3>
          <div>
            <label className="mb-1 block text-sm font-medium text-foreground">
              Font Family
            </label>
            <select
              className="w-full border border-border px-3 py-2 text-sm focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-ring"
              value={brandingForm.font_family}
              onChange={(e) =>
                handleBrandingChange("font_family", e.target.value)
              }
            >
              <option value="Inter, sans-serif">Inter</option>
              <option value="system-ui, sans-serif">System UI</option>
              <option value="Arial, sans-serif">Arial</option>
              <option value="'Helvetica Neue', sans-serif">
                Helvetica Neue
              </option>
              <option value="Georgia, serif">Georgia</option>
              <option value="'Times New Roman', serif">Times New Roman</option>
              <option value="'Courier New', monospace">Courier New</option>
            </select>
          </div>
        </div>

        <div className="border border-border bg-background p-6 ">
          <h3 className="mb-4 text-lg font-semibold">Custom CSS</h3>
          <textarea
            className="w-full border border-border px-3 py-2 font-mono text-sm focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-ring"
            rows={6}
            placeholder="/* Your custom CSS here */"
            value={brandingForm.custom_css || ""}
            onChange={(e) =>
              handleBrandingChange("custom_css", e.target.value || null)
            }
          />
        </div>

        <div className="border border-border bg-background p-6">
          <h3 className="mb-4 text-lg font-semibold">Branding Options</h3>
          <label className="flex cursor-pointer items-center gap-3">
            <button
              type="button"
              role="switch"
              aria-checked={hideBranding}
              onClick={handleToggleHideBranding}
              className={`relative inline-flex h-6 w-11 items-center transition-colors ${
                hideBranding ? "bg-primary" : "bg-secondary"
              }`}
            >
              <span
                className={`inline-block size-4 transform bg-background transition-transform ${
                  hideBranding ? "translate-x-6" : "translate-x-1"
                }`}
              />
            </button>
            <div>
              <span className="text-sm font-medium text-foreground">
                Hide &quot;Powered by ShopiBD&quot;
              </span>
              <p className="text-xs text-muted-foreground">
                Remove the ShopiBD attribution from your storefront footer.
              </p>
            </div>
          </label>
        </div>

        <button
          onClick={handleSaveBranding}
          disabled={savingBranding}
          className="w-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
        >
          {savingBranding ? "Saving..." : "Save Branding Settings"}
        </button>
      </div>

      {/* Preview panel */}
      <div className="self-start lg:sticky lg:top-6">
        <h3 className="mb-4 text-lg font-semibold">Preview</h3>
        <BrandPreview
          branding={brandingForm}
          hideBranding={hideBranding}
          shopName={shopName}
        />
        <div className="mt-4">
          <label className="mb-1 block text-sm font-medium text-foreground">
            Shop Name (for preview)
          </label>
          <input
            type="text"
            className="w-full border border-border px-3 py-2 text-sm focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-ring"
            value={shopName}
            onChange={(e) => setShopName(e.target.value)}
          />
        </div>
      </div>
    </div>
  );

  // ---------------------------------------------------------------------------
  // Render: Main
  // ---------------------------------------------------------------------------

  return (
    <div className="mx-auto max-w-6xl space-y-6 px-4 py-8">
      {/* Header */}
      <div className="border border-border bg-background p-5  sm:p-6">
        <div className="min-w-0 space-y-2">
          <p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">Configuration / storefront identity</p>
          <h1 className="text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">Branding &amp; Domain</h1>
          <p className="max-w-2xl text-sm leading-6 text-muted-foreground sm:text-[15px]">Set up your custom domain and customize your storefront appearance.</p>
        </div>
      </div>

      {/* Message alerts */}
      {state.error && (
        <Alert variant="destructive" className="mb-6">
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{state.error}</AlertDescription>
        </Alert>
      )}
      {state.success && (
        <Alert className="mb-6 border-success/30 bg-success/10 text-success">
          <AlertTitle>Success</AlertTitle>
          <AlertDescription>{state.success}</AlertDescription>
        </Alert>
      )}

      {/* Loading */}
      {state.loading && (
        <div className="space-y-4">
          <Skeleton className="h-10 w-64" />
          <Skeleton className="h-64 w-full" />
        </div>
      )}

      {/* Content */}
      {!state.loading && (
        <>
          {/* Tabs */}
          <div className="mb-8 flex gap-1 border-b border-border">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`border-b-2 px-4 py-2.5 text-sm font-medium transition-colors ${
                  activeTab === tab.id
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Tab content */}
          {activeTab === "domain" && renderDomainTab()}
          {activeTab === "branding" && renderBrandingTab()}
        </>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Sub-components
// ---------------------------------------------------------------------------

function StatusBadge({
  label,
  value,
  verified,
}: {
  label: string;
  value: string;
  verified: boolean;
}) {
  return (
    <div className="bg-muted p-3">
      <p className="mb-1 text-xs text-muted-foreground">{label}</p>
      <p className="truncate text-sm font-medium text-foreground">{value}</p>
      <div className="mt-1">
        {verified ? (
          <span className="inline-flex items-center gap-1 text-xs text-success">
            <svg className="size-3" fill="currentColor" viewBox="0 0 20 20">
              <path
                fillRule="evenodd"
                d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                clipRule="evenodd"
              />
            </svg>
            Active
          </span>
        ) : (
          <span className="text-xs text-muted-foreground">Inactive</span>
        )}
      </div>
    </div>
  );
}

function DnsRecordCard({ record }: { record: DnsRecord }) {
  return (
    <div className="border border-border bg-muted p-4">
      <div className="grid grid-cols-3 gap-4 text-sm">
        <div>
          <span className="block text-xs text-muted-foreground">Type</span>
          <span className="font-mono font-medium text-foreground">
            {record.type}
          </span>
        </div>
        <div>
          <span className="block text-xs text-muted-foreground">Name</span>
          <span className="break-all font-mono text-foreground">
            {record.name}
          </span>
        </div>
        <div>
          <span className="block text-xs text-muted-foreground">Value</span>
          <span className="break-all font-mono text-foreground">
            {record.value}
          </span>
        </div>
      </div>
      <p className="mt-2 text-xs text-muted-foreground">{record.description}</p>
      <button
        onClick={() => {
          const text = `${record.type}\t${record.name}\t${record.value}`;
          navigator.clipboard.writeText(text);
        }}
        className="mt-2 text-xs text-primary hover:text-primary"
      >
        Copy to clipboard
      </button>
    </div>
  );
}
