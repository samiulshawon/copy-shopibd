import { Metadata } from "next";
import { redirect } from "next/navigation";
import { getServerSession } from "@/lib/auth";
import SettingsPageClient from "./page-client";

export const metadata: Metadata = {
  title: "Settings | ShopiBD",
  description: "Manage your shop profile, payment methods, and delivery settings",
};

export default async function SettingsPage() {
  // Server-side auth check
  const session = await getServerSession();
  if (!session) {
    redirect("/auth/login");
  }

  return <SettingsPageClient />;
}
