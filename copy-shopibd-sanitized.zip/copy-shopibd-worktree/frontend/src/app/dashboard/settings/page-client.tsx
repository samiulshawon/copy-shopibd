"use client";

import React, { useCallback, useEffect, useState } from "react";
import { settingsApi } from "@/lib/api";
import { ShopProfileForm } from "@/components/dashboard/shop-profile-form";
import { PaymentMethodsForm } from "@/components/dashboard/payment-methods-form";
import { DeliverySettingsForm } from "@/components/dashboard/delivery-settings-form";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import type { Shop, DeliverySettings } from "@/types/shop";
import {
  PageEyebrow,
  PageDescription,
  PageFrame,
  PageHeader,
  PageHeaderContent,
  PageTitle,
} from "@/components/layout/page-structure";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface SettingsState {
  shop: Shop | null;
  loading: boolean;
  error: string | null;
}

// ---------------------------------------------------------------------------
// Main component
// ---------------------------------------------------------------------------

export default function SettingsPageClient() {
  const [state, setState] = useState<SettingsState>({
    shop: null,
    loading: true,
    error: null,
  });

  const [activeTab, setActiveTab] = useState<
    "profile" | "payment" | "delivery"
  >("profile");

  // -------------------------------------------------------------------------
  // Data fetching
  // -------------------------------------------------------------------------

  const fetchShop = useCallback(async () => {
    setState((prev) => ({ ...prev, loading: true, error: null }));
    try {
      const response = await settingsApi.getShop();
      setState((prev) => ({ ...prev, shop: response.data, loading: false }));
    } catch (err: any) {
      setState((prev) => ({
        ...prev,
        loading: false,
        error:
          err?.response?.data?.detail ||
          err?.message ||
          "Failed to load shop settings",
      }));
    }
  }, []);

  useEffect(() => {
    fetchShop();
  }, [fetchShop]);

  // -------------------------------------------------------------------------
  // Render helpers
  // -------------------------------------------------------------------------

  const tabs = [
    { id: "profile" as const, label: "Shop Profile" },
    { id: "payment" as const, label: "Payment Methods" },
    { id: "delivery" as const, label: "Delivery Settings" },
  ];

  // -------------------------------------------------------------------------
  // Render
  // -------------------------------------------------------------------------

  if (state.loading) {
    return (
      <PageFrame>
        <PageHeader>
          <PageHeaderContent>
            <Skeleton className="h-4 w-32" />
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-5 w-72" />
          </PageHeaderContent>
        </PageHeader>
        <div className="space-y-4">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </PageFrame>
    );
  }

  if (state.error) {
    return (
      <PageFrame>
        <PageHeader>
          <PageHeaderContent>
            <PageEyebrow>Configuration / shop settings</PageEyebrow>
            <PageTitle>Settings</PageTitle>
            <PageDescription>
              Manage your shop profile, payment methods, and delivery settings.
            </PageDescription>
          </PageHeaderContent>
        </PageHeader>
        <Alert variant="destructive">
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{state.error}</AlertDescription>
        </Alert>
      </PageFrame>
    );
  }

  if (!state.shop) {
    return (
      <PageFrame>
        <PageHeader>
          <PageHeaderContent>
            <PageEyebrow>Configuration / shop settings</PageEyebrow>
            <PageTitle>Settings</PageTitle>
            <PageDescription>
              Manage your shop profile, payment methods, and delivery settings.
            </PageDescription>
          </PageHeaderContent>
        </PageHeader>
        <Alert variant="destructive">
          <AlertTitle>No Shop Found</AlertTitle>
          <AlertDescription>
            You need to create a shop before configuring settings.
          </AlertDescription>
        </Alert>
      </PageFrame>
    );
  }

  return (
    <PageFrame>
      <PageHeader>
        <PageHeaderContent>
          <PageEyebrow>Configuration / shop settings</PageEyebrow>
          <PageTitle>Settings</PageTitle>
          <PageDescription>
            Manage your shop profile, payment methods, and delivery settings.
          </PageDescription>
        </PageHeaderContent>
      </PageHeader>

      {/* Tab Navigation */}
      <div className="flex flex-wrap gap-1 border border-border bg-background p-1">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 text-sm font-medium transition-colors ${
              activeTab === tab.id
                ? "bg-muted text-foreground "
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === "profile" && (
        <ShopProfileForm
          shop={state.shop}
          onSuccess={fetchShop}
        />
      )}
      {activeTab === "payment" && (
        <PaymentMethodsForm
          shop={state.shop}
          onSuccess={fetchShop}
        />
      )}
      {activeTab === "delivery" && (
        <DeliverySettingsForm
          shop={state.shop}
          onSuccess={fetchShop}
        />
      )}
    </PageFrame>
  );
}