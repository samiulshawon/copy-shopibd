import { Metadata } from "next";
import { redirect } from "next/navigation";
import { getServerSession } from "@/lib/auth";
import { OrderDetailClient } from "./page-client";

interface OrderDetailPageProps {
  params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: OrderDetailPageProps): Promise<Metadata> {
  const { id } = await params;
  return {
    title: `Order #${id} | ShopiBD Dashboard`,
    description: "Order details",
  };
}

export default async function OrderDetailPage({ params }: OrderDetailPageProps) {
  const session = await getServerSession();
  if (!session) {
    redirect("/auth/login");
  }

  const { id } = await params;
  return <OrderDetailClient orderId={Number(id)} />;
}
