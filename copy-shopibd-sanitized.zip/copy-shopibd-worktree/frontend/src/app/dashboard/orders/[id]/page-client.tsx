"use client";

import React, { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowLeft,
  CalendarDays,
  MapPin,
  PackageCheck,
  Phone,
  ReceiptText,
  Truck,
  User,
} from "lucide-react";
import { dashboardApi, deliveryApi, settingsApi } from "@/lib/api";
import type { Order, OrderItem } from "@/types/order";
import type {
  CourierName,
  CourierProvider,
  Delivery,
  ShipmentStatus,
} from "@/types/delivery";
import { StatusBadge } from "@/components/dashboard/status-badge";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import type { Shop } from "@/types/shop";
import { Badge } from "@/components/ui/badge";
import {
  MetricCard,
  MetricStrip,
  MobileStickyActions,
  PageActions,
  PageDescription,
  PageEyebrow,
  PageFrame,
  PageHeader,
  PageHeaderContent,
  PageTitle,
  SectionDescription,
  SectionHeader,
  SectionTitle,
  SurfaceSection,
} from "@/components/layout/page-structure";

const SHIPMENT_STATUS_STEPS: { status: ShipmentStatus; label: string }[] = [
  { status: "pending", label: "Pending" },
  { status: "picked_up", label: "Picked Up" },
  { status: "in_transit", label: "In Transit" },
  { status: "delivered", label: "Delivered" },
];

function getTrackingUrl(
  courier: CourierName,
  trackingNumber: string,
): string | null {
  const urls: Partial<Record<CourierName, string>> = {
    steadfast: `https://steadfast.com.bd/track/${trackingNumber}`,
    ecourier: `https://ecourier.com.bd/track/${trackingNumber}`,
    pathao: `https://pathao.com/track/${trackingNumber}`,
    redx: `https://redx.com.bd/track/${trackingNumber}`,
  };
  return urls[courier] ?? null;
}

interface OrderDetailClientProps {
  orderId: number;
}

function DetailRow({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: React.ReactNode;
}) {
  return (
    <div className="flex items-start gap-3 border border-outline-variant bg-muted p-4">
      <div className="flex size-9 shrink-0 items-center justify-center border border-border/80 bg-background text-muted-foreground">
        <Icon className="size-4" />
      </div>
      <div className="min-w-0">
        <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground/80">{label}</p>
        <div className="mt-2 text-sm leading-6 text-foreground">{value}</div>
      </div>
    </div>
  );
}

export function OrderDetailClient({ orderId }: OrderDetailClientProps) {
  const router = useRouter();
  const { toast } = useToast();

  const [order, setOrder] = useState<Order | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState(false);

  const [delivery, setDelivery] = useState<Delivery | null>(null);
  const [deliveryLoading, setDeliveryLoading] = useState(false);

  const [showCreateShipment, setShowCreateShipment] = useState(false);
  const [couriers, setCouriers] = useState<CourierProvider[]>([]);
  const [selectedCourier, setSelectedCourier] = useState<CourierName>("manual");
  const [pickupAddress, setPickupAddress] = useState("");
  const [weightKg, setWeightKg] = useState("");
  const [codAmount, setCodAmount] = useState("");
  const [creating, setCreating] = useState(false);

  const fetchOrder = useCallback(async () => {
    setIsLoading(true);
    try {
      const response = await dashboardApi.getOrder(orderId);
      const fetchedOrder = response.data;
      setOrder(fetchedOrder);
      if (fetchedOrder.delivery) {
        setDelivery(fetchedOrder.delivery);
      }
    } catch (error: any) {
      toast({
        message: "Error",
        description:
          error?.response?.data?.detail || "Failed to load order",
        variant: "error",
      });
    } finally {
      setIsLoading(false);
    }
  }, [orderId, toast]);

  const fetchDelivery = useCallback(async () => {
    if (delivery) return;
    setDeliveryLoading(true);
    try {
      const resp = await deliveryApi.listShipments({ order_id: orderId, limit: 1 });
      const items = resp.data.items;
      if (items.length > 0) {
        const detailResp = await deliveryApi.getShipment(items[0].id);
        setDelivery(detailResp.data);
      }
    } catch {
    } finally {
      setDeliveryLoading(false);
    }
  }, [orderId, delivery]);

  useEffect(() => {
    fetchOrder();
  }, [fetchOrder]);

  useEffect(() => {
    if (order && !delivery) {
      fetchDelivery();
    }
  }, [order, delivery, fetchDelivery]);

  const fetchShopPickupAddress = useCallback(async () => {
    try {
      const resp = await settingsApi.getShop();
      const shop: Shop = resp.data;
      const address =
        (shop as any).address || shop.contact_phone || "Your Shop Address";
      setPickupAddress(address);
    } catch {
    }
  }, []);

  useEffect(() => {
    if (showCreateShipment) {
      deliveryApi.listCouriers().then((res) => {
        setCouriers(res.data.couriers);
      });
      fetchShopPickupAddress();
    }
  }, [showCreateShipment, fetchShopPickupAddress]);

  const handleStatusChange = useCallback(
    async (newStatus: string) => {
      if (!order || newStatus === order.status) return;

      setIsUpdating(true);
      try {
        const response = await dashboardApi.updateOrderStatus(
          order.id,
          newStatus,
        );
        setOrder(response.data);
        toast({
          message: "Success",
          description: `Order status updated to ${newStatus}`,
          variant: "success",
        });
      } catch (error: any) {
        toast({
          message: "Error",
          description:
            error?.response?.data?.detail || "Failed to update status",
          variant: "error",
        });
      } finally {
        setIsUpdating(false);
      }
    },
    [order, toast],
  );

  const handleCreateShipment = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();
      if (!order) return;

      setCreating(true);
      try {
        const resp = await deliveryApi.createShipment({
          order_id: order.id,
          courier_name: selectedCourier,
          pickup_address: pickupAddress,
          weight_kg: weightKg ? parseFloat(weightKg) : null,
          cod_amount: codAmount ? parseFloat(codAmount) : null,
        });
        setDelivery(resp.data);
        setShowCreateShipment(false);
        toast({
          message: "Success",
          description: "Shipment created successfully",
          variant: "success",
        });
      } catch (error: any) {
        toast({
          message: "Error",
          description:
            error?.response?.data?.detail || "Failed to create shipment",
          variant: "error",
        });
      } finally {
        setCreating(false);
      }
    },
    [order, selectedCourier, pickupAddress, weightKg, codAmount, toast],
  );

  const handleCancelShipment = useCallback(async () => {
    if (!delivery) return;
    try {
      const resp = await deliveryApi.cancelShipment(delivery.id);
      setDelivery(resp.data);
      toast({
        message: "Success",
        description: "Shipment cancelled",
        variant: "success",
      });
    } catch (error: any) {
      toast({
        message: "Error",
        description:
          error?.response?.data?.detail || "Failed to cancel shipment",
        variant: "error",
      });
    }
  }, [delivery, toast]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-BD", {
      style: "currency",
      currency: "BDT",
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-BD", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const shipmentStatusVariant = (
    status: ShipmentStatus,
  ): "success" | "warning" | "secondary" | "destructive" | "info" => {
    const map: Record<
      string,
      "success" | "warning" | "secondary" | "destructive" | "info"
    > = {
      pending: "warning",
      picked_up: "info",
      in_transit: "info",
      delivered: "success",
      returned: "secondary",
      failed: "destructive",
    };
    return map[status] || "secondary";
  };

  const currentStepIndex = delivery
    ? SHIPMENT_STATUS_STEPS.findIndex(
        (s) => s.status === delivery.shipment_status,
      )
    : -1;

  const orderMetrics = useMemo(() => {
    if (!order) {
      return {
        itemsCount: 0,
        statusLabel: "—",
        paymentLabel: "—",
      };
    }

    return {
      itemsCount: (order.items ?? []).length,
      statusLabel: order.status,
      paymentLabel: order.payment_status,
    };
  }, [order]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="h-10 animate-pulse bg-muted" />
        <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_320px]">
          <div className="space-y-4">
            <div className="h-56 animate-pulse bg-muted" />
            <div className="h-80 animate-pulse bg-muted" />
          </div>
          <div className="h-64 animate-pulse bg-muted" />
        </div>
      </div>
    );
  }

  if (!order) {
    return (
      <PageFrame>
        <PageHeader>
          <PageHeaderContent>
            <PageEyebrow>Order detail</PageEyebrow>
            <PageTitle>Order not found</PageTitle>
            <PageDescription>
              The order does not exist or is no longer available in this account.
            </PageDescription>
          </PageHeaderContent>
          <PageActions>
            <Button asChild>
              <Link href="/dashboard/orders">Back to orders</Link>
            </Button>
          </PageActions>
        </PageHeader>
      </PageFrame>
    );
  }

  return (
    <PageFrame>
      <PageHeader>
        <PageHeaderContent>
          <PageEyebrow>Commerce / fulfillment</PageEyebrow>
          <PageTitle>Order {order.order_number}</PageTitle>
          <PageDescription>
            Review buyer, payment, items, and shipment progress in one place.
          </PageDescription>
        </PageHeaderContent>
        <PageActions>
          <Badge variant="secondary" className="px-3 py-1">
            {formatDate(order.created_at)}
          </Badge>
          <Button variant="outline" onClick={() => dashboardApi.downloadInvoice(order.id)}>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="size-4"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>
            Download Invoice
          </Button>
          <Button variant="outline" asChild>
            <Link href="/dashboard/orders">
              <ArrowLeft className="size-4" />
              Back to orders
            </Link>
          </Button>
        </PageActions>
      </PageHeader>

      <MetricStrip className="animate-fade-up">
        <MetricCard>
          <p className="text-sm font-medium text-muted-foreground">Order total</p>
          <p className="mt-2 text-2xl font-semibold tracking-tight text-foreground">
            {formatCurrency(order.total_amount)}
          </p>
        </MetricCard>
        <MetricCard>
          <p className="text-sm font-medium text-muted-foreground">Order status</p>
          <div className="mt-3">
            <StatusBadge status={orderMetrics.statusLabel} />
          </div>
        </MetricCard>
        <MetricCard>
          <p className="text-sm font-medium text-muted-foreground">Payment</p>
          <p className="mt-2 text-lg font-semibold capitalize text-foreground">
            {orderMetrics.paymentLabel}
          </p>
        </MetricCard>
        <MetricCard>
          <p className="text-sm font-medium text-muted-foreground">Items</p>
          <p className="mt-2 text-2xl font-semibold tracking-tight text-foreground">
            {orderMetrics.itemsCount}
          </p>
        </MetricCard>
      </MetricStrip>

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_340px]">
        <div className="space-y-6">
          <SurfaceSection className="animate-fade-up" style={{ animationDelay: "60ms" }}>
            <SectionHeader>
              <div>
                <SectionTitle>Buyer and order summary</SectionTitle>
                <SectionDescription>
                  The essential details needed to verify, contact, and ship the order.
                </SectionDescription>
              </div>
            </SectionHeader>
            <div className="mt-4 grid gap-4 md:grid-cols-2">
              <DetailRow icon={User} label="Customer" value={order.customer_name} />
              <DetailRow icon={Phone} label="Phone" value={order.customer_phone} />
              <DetailRow icon={MapPin} label="Address" value={order.customer_address} />
              <DetailRow icon={ReceiptText} label="Payment status" value={<span className="capitalize">{order.payment_status}</span>} />
            </div>
            {order.notes ? (
              <div className="mt-4 border border-outline-variant bg-muted p-4">
                <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground/80">Notes</p>
                <p className="mt-2 text-sm leading-6 text-foreground">{order.notes}</p>
              </div>
            ) : null}
          </SurfaceSection>

          <SurfaceSection className="animate-fade-up" style={{ animationDelay: "120ms" }}>
            <SectionHeader>
              <div>
                <SectionTitle>Ordered items</SectionTitle>
                <SectionDescription>
                  Line items are stacked for readability on mobile and still easy to scan on larger screens.
                </SectionDescription>
              </div>
            </SectionHeader>
            <div className="mt-4 space-y-3">
              {(order.items ?? []).map((item: OrderItem) => (
                <div key={item.id} className="group relative border border-outline-variant bg-muted p-4 pl-5 transition-colors duration-200 ease-premium hover:border-outline-variant hover:bg-secondary">
                  <span className="pointer-events-none absolute left-0 top-0 h-full w-1 bg-success opacity-0 transition-opacity duration-200 ease-premium group-hover:opacity-100" />
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <p className="font-medium text-foreground">{item.product_name}</p>
                      <p className="mt-1 text-sm text-muted-foreground">Quantity: {item.quantity}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">Unit</p>
                      <p className="mt-1 font-medium text-foreground">{formatCurrency(item.unit_price)}</p>
                    </div>
                  </div>
                  <div className="mt-4 flex items-center justify-between border-t border-border/80 pt-3 text-sm">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span className="font-semibold text-foreground">{formatCurrency(item.subtotal)}</span>
                  </div>
                </div>
              ))}
            </div>
          </SurfaceSection>

          <SurfaceSection className="animate-fade-up" style={{ animationDelay: "180ms" }}>
            <SectionHeader>
              <div>
                <SectionTitle>Delivery and shipment</SectionTitle>
                <SectionDescription>
                  Track courier progress, pickup details, and shipment state without leaving the order.
                </SectionDescription>
              </div>
            </SectionHeader>
            <div className="mt-4 space-y-4">
              {deliveryLoading ? (
                <div className="h-14 animate-pulse bg-muted" />
              ) : null}

              {!deliveryLoading && !delivery ? (
                <div className="border border-dashed border-border/80 bg-muted/20 p-6 text-center">
                  <p className="text-sm text-muted-foreground">
                    No shipment has been created for this order yet.
                  </p>
                  <Button className="mt-4" onClick={() => setShowCreateShipment(true)}>
                    Create shipment
                  </Button>
                </div>
              ) : null}

              {delivery ? (
                <>
                  <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                    <DetailRow icon={Truck} label="Courier" value={<span className="capitalize">{delivery.courier_name}</span>} />
                    <DetailRow
                      icon={PackageCheck}
                      label="Tracking"
                      value={delivery.tracking_number ? (
                        <a
                          href={
                            getTrackingUrl(
                              delivery.courier_name,
                              delivery.tracking_number,
                            ) ?? "#"
                          }
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-primary underline underline-offset-2"
                        >
                          {delivery.tracking_number}
                        </a>
                      ) : (
                        "—"
                      )}
                    />
                    <DetailRow
                      icon={CalendarDays}
                      label="Estimated delivery"
                      value={delivery.estimated_delivery_date ? formatDate(delivery.estimated_delivery_date) : "—"}
                    />
                    <DetailRow
                      icon={ReceiptText}
                      label="Shipment status"
                      value={<Badge variant={shipmentStatusVariant(delivery.shipment_status)}>{delivery.shipment_status.replace(/_/g, " ")}</Badge>}
                    />
                  </div>

                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="border border-outline-variant bg-muted p-4 md:col-span-2">
                      <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground/80">Pickup address</p>
                      <p className="mt-2 text-sm leading-6 text-foreground">{delivery.pickup_address}</p>
                    </div>
                    <div className="space-y-4">
                      {delivery.cod_amount !== null && delivery.cod_amount !== undefined ? (
                        <div className="border border-outline-variant bg-muted p-4">
                          <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground/80">COD amount</p>
                          <p className="mt-2 text-sm font-semibold text-foreground">{formatCurrency(delivery.cod_amount)}</p>
                        </div>
                      ) : null}
                      {delivery.shipping_cost !== null && delivery.shipping_cost !== undefined ? (
                        <div className="border border-outline-variant bg-muted p-4">
                          <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground/80">Shipping cost</p>
                          <p className="mt-2 text-sm font-semibold text-foreground">{formatCurrency(delivery.shipping_cost)}</p>
                        </div>
                      ) : null}
                    </div>
                  </div>

                  <div className="border border-outline-variant bg-muted/40 p-4">
                    <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground/80">Shipment timeline</p>
                    <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                      {SHIPMENT_STATUS_STEPS.map((step, idx) => {
                        const isActive = idx <= currentStepIndex;
                        return (
                          <div
                            key={step.status}
                            className={`border p-4 ${
                              isActive
                                ? "border-primary/30 bg-primary/10"
                                : "border-outline-variant bg-muted"
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <div
                                className={`flex size-8 items-center justify-center text-xs font-semibold ${
                                  isActive
                                    ? "bg-primary text-primary-foreground"
                                    : "bg-background text-muted-foreground"
                                }`}
                              >
                                {idx + 1}
                              </div>
                              <div>
                                <p className={`text-sm font-medium ${isActive ? "text-foreground" : "text-muted-foreground"}`}>
                                  {step.label}
                                </p>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </>
              ) : null}
            </div>
          </SurfaceSection>
        </div>

        <div className="space-y-6 xl:sticky xl:top-6 xl:h-fit">
          <SurfaceSection className="animate-fade-up" style={{ animationDelay: "240ms" }}>
            <SectionHeader>
              <div>
                <SectionTitle>Fulfillment actions</SectionTitle>
                <SectionDescription>
                  Keep order and shipment actions together so merchants can move the order forward quickly.
                </SectionDescription>
              </div>
            </SectionHeader>
            <div className="mt-5 space-y-5">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Current status</label>
                <div>
                  <StatusBadge status={order.status} />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Change order status</label>
                <Select
                  value={order.status}
                  onChange={(e) => handleStatusChange(e.target.value)}
                  disabled={isUpdating}
                  className="h-11 bg-muted"
                  options={[
                    { value: "pending", label: "Pending" },
                    { value: "confirmed", label: "Confirmed" },
                    { value: "shipped", label: "Shipped" },
                    { value: "delivered", label: "Delivered" },
                    { value: "cancelled", label: "Cancelled" },
                  ]}
                />
              </div>

              {!delivery ? (
                <Button className="w-full" onClick={() => setShowCreateShipment(true)}>
                  Create shipment
                </Button>
              ) : null}

              {delivery &&
              delivery.shipment_status !== "delivered" &&
              delivery.shipment_status !== "returned" &&
              delivery.shipment_status !== "failed" ? (
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={handleCancelShipment}
                >
                  Cancel shipment
                </Button>
              ) : null}
            </div>
          </SurfaceSection>
        </div>
      </div>

      <MobileStickyActions className="flex gap-2 xl:hidden">
        <Button variant="outline" className="flex-1" onClick={() => router.push("/dashboard/orders")}>
          Back
        </Button>
        {!delivery ? (
          <Button className="flex-1" onClick={() => setShowCreateShipment(true)}>
            Create shipment
          </Button>
        ) : (
          <Button className="flex-1" asChild>
            <Link href="/dashboard/orders">Open orders</Link>
          </Button>
        )}
      </MobileStickyActions>

      <Dialog open={showCreateShipment} onOpenChange={setShowCreateShipment}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create shipment</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleCreateShipment} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Courier provider</label>
              <Select
                value={selectedCourier}
                onChange={(e) => setSelectedCourier(e.target.value as CourierName)}
                className="h-11 bg-muted"
                disabled={creating}
                options={couriers.map((courier) => ({
                  value: courier.value,
                  label: courier.name,
                }))}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Pickup address</label>
              <textarea
                value={pickupAddress}
                onChange={(e) => setPickupAddress(e.target.value)}
                className="min-h-[96px] w-full border border-border bg-muted p-3 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
                placeholder="Enter pickup address"
                required
                disabled={creating}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">
                  Weight (kg) <span className="text-muted-foreground">(opt)</span>
                </label>
                <Input
                  type="number"
                  min="0"
                  step="0.1"
                  value={weightKg}
                  onChange={(e) => setWeightKg(e.target.value)}
                  placeholder="0.5"
                  disabled={creating}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">
                  COD amount <span className="text-muted-foreground">(opt)</span>
                </label>
                <Input
                  type="number"
                  min="0"
                  step="1"
                  value={codAmount}
                  onChange={(e) => setCodAmount(e.target.value)}
                  placeholder={String(order.total_amount)}
                  disabled={creating}
                />
              </div>
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowCreateShipment(false)}
                disabled={creating}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={creating}>
                {creating ? "Creating..." : "Create shipment"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </PageFrame>
  );
}
