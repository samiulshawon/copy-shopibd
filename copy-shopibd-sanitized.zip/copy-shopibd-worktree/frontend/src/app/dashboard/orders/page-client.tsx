"use client";

import React, { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowRight,
  CalendarRange,
  Filter,
  Search,
  ShoppingBag,
  SlidersHorizontal,
} from "lucide-react";
import { dashboardApi } from "@/lib/api";
import type { OrderListItem, OrderFilters } from "@/types/order";
import { OrdersTable } from "@/components/dashboard/orders-table";
import { StatusBadge } from "@/components/dashboard/status-badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Select } from "@/components/ui/select";
import { DialogTitle, DialogDescription, Sheet, SheetContent, SheetTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/utils";
import {
  MetricCard,
  MetricStrip,
  PageActions,
  PageDescription,
  PageEyebrow,
  PageFrame,
  PageHeader,
  PageHeaderContent,
  PageTitle,
  SectionDescription,
  SectionHeader,
  SectionTitle,
  SurfaceSection,
} from "@/components/layout/page-structure";

const STATUS_OPTIONS = [
  { value: "", label: "All statuses" },
  { value: "pending", label: "Pending" },
  { value: "confirmed", label: "Confirmed" },
  { value: "shipped", label: "Shipped" },
  { value: "delivered", label: "Delivered" },
  { value: "cancelled", label: "Cancelled" },
];

function formatDate(dateString: string) {
  return new Date(dateString).toLocaleDateString("en-BD", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

function Pagination({
  page,
  pageSize,
  total,
  totalPages,
  onPageChange,
  onPageSizeChange,
}: {
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (size: number) => void;
}) {
  return (
    <div className="flex flex-col gap-3 border border-border/80 bg-muted p-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="text-sm text-muted-foreground">
        Showing {total === 0 ? 0 : (page - 1) * pageSize + 1} to {Math.min(page * pageSize, total)} of {total} orders
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => onPageChange(page - 1)}
          disabled={page <= 1}
        >
          Previous
        </Button>
        <div className="px-2 text-sm text-muted-foreground">
          Page {page} of {totalPages || 1}
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => onPageChange(page + 1)}
          disabled={page >= totalPages}
        >
          Next
        </Button>
        <Select
          className="h-9 min-w-[88px] bg-muted"
          value={String(pageSize)}
          onChange={(e) => onPageSizeChange(Number(e.target.value))}
          options={[
            { value: "10", label: "10 / page" },
            { value: "20", label: "20 / page" },
            { value: "50", label: "50 / page" },
          ]}
        />
      </div>
    </div>
  );
}

function OrdersSummary({ orders, total }: { orders: OrderListItem[]; total: number }) {
  const summary = useMemo(() => {
    const pending = orders.filter((order) => order.status === "pending").length;
    const delivered = orders.filter((order) => order.status === "delivered").length;
    const revenue = orders.reduce((sum, order) => sum + order.total_amount, 0);

    return { pending, delivered, revenue };
  }, [orders]);

  return (
    <MetricStrip>
      <MetricCard>
        <p className="text-sm font-medium text-muted-foreground">Visible orders</p>
        <p className="mt-2 text-2xl font-semibold tracking-tight text-foreground">{total}</p>
        <p className="mt-1 text-xs text-muted-foreground">Orders matching the current filters.</p>
      </MetricCard>
      <MetricCard>
        <p className="text-sm font-medium text-muted-foreground">Pending review</p>
        <p className="mt-2 text-2xl font-semibold tracking-tight text-warning">{summary.pending}</p>
        <p className="mt-1 text-xs text-muted-foreground">Needs confirmation or follow-up.</p>
      </MetricCard>
      <MetricCard>
        <p className="text-sm font-medium text-muted-foreground">Delivered in view</p>
        <p className="mt-2 text-2xl font-semibold tracking-tight text-success">{summary.delivered}</p>
        <p className="mt-1 text-xs text-muted-foreground">Completed orders in the current result set.</p>
      </MetricCard>
      <MetricCard>
        <p className="text-sm font-medium text-muted-foreground">Visible revenue</p>
        <p className="mt-2 text-2xl font-semibold tracking-tight text-foreground">{formatCurrency(summary.revenue)}</p>
        <p className="mt-1 text-xs text-muted-foreground">Revenue represented by the loaded orders.</p>
      </MetricCard>
    </MetricStrip>
  );
}

function OrdersEmptyState({ hasActiveFilters, onClear }: { hasActiveFilters: boolean; onClear: () => void }) {
  return (
    <SurfaceSection className="text-center">
      <div className="mx-auto flex max-w-md flex-col items-center gap-4 py-6">
        <div className="flex size-14 items-center justify-center border border-border/80 bg-muted/40 text-muted-foreground">
          <ShoppingBag className="size-6" />
        </div>
        <div className="space-y-2">
          <SectionTitle>No orders found</SectionTitle>
          <SectionDescription>
            {hasActiveFilters
              ? "Try adjusting the current filters to broaden the result set."
              : "New orders will appear here once customers begin placing them."}
          </SectionDescription>
        </div>
        {hasActiveFilters ? (
          <Button variant="outline" onClick={onClear}>
            Clear filters
          </Button>
        ) : null}
      </div>
    </SurfaceSection>
  );
}

function OrdersLoadingState() {
  return (
    <div className="space-y-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <Card key={i} className="border-border/80 bg-background/60 ">
          <CardContent className="space-y-4 p-4">
            <div className="h-5 w-32 animate-pulse bg-muted" />
            <div className="grid grid-cols-2 gap-3">
              <div className="h-4 animate-pulse bg-muted" />
              <div className="h-4 animate-pulse bg-muted" />
              <div className="h-4 animate-pulse bg-muted" />
              <div className="h-4 animate-pulse bg-muted" />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function OrderCard({
  order,
  onOpen,
  onStatusChange,
}: {
  order: OrderListItem;
  onOpen: (orderId: number) => void;
  onStatusChange: (orderId: number, status: string) => void;
}) {
  return (
    <Card
      className="cursor-pointer border-border/80 bg-muted  transition-all duration-200 ease-premium hover:bg-background"
      onClick={() => onOpen(order.id)}
    >
      <CardContent className="space-y-4 p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="font-mono text-sm font-semibold text-foreground">{order.order_number}</p>
            <p className="mt-1 text-sm text-muted-foreground">{formatDate(order.created_at)}</p>
          </div>
          <StatusBadge status={order.status} className="shrink-0" />
        </div>

        <div className="grid grid-cols-2 gap-3 text-sm">
          <div>
            <p className="text-muted-foreground">Buyer</p>
            <p className="mt-1 font-medium text-foreground">{order.customer_name}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Phone</p>
            <p className="mt-1 text-foreground">{order.customer_phone}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Items</p>
            <p className="mt-1 text-foreground">{order.item_count}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Total</p>
            <p className="mt-1 font-semibold text-foreground">{formatCurrency(order.total_amount)}</p>
          </div>
        </div>

        <div className="space-y-2">
          <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground/80">Quick status change</p>
          <Select
            className="h-11 bg-muted"
            value={order.status}
            onChange={(e) => {
              const value = e.target.value;
              if (value !== order.status) {
                onStatusChange(order.id, value);
              }
            }}
            options={STATUS_OPTIONS.filter((option) => option.value !== "")}
            onClick={(e) => e.stopPropagation()}
          />
        </div>

        <div className="flex items-center justify-between pt-1">
          <Badge variant="secondary" className="px-3 py-1">
            {order.payment_status}
          </Badge>
          <div className="flex items-center gap-1 text-sm font-medium text-primary">
            Open order
            <ArrowRight className="size-4" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function FilterFields({
  statusFilter,
  searchQuery,
  dateFrom,
  dateTo,
  onStatusChange,
  onSearchChange,
  onDateFromChange,
  onDateToChange,
  onClear,
  hasActiveFilters,
}: {
  statusFilter: string;
  searchQuery: string;
  dateFrom: string;
  dateTo: string;
  onStatusChange: (value: string) => void;
  onSearchChange: (value: string) => void;
  onDateFromChange: (value: string) => void;
  onDateToChange: (value: string) => void;
  onClear: () => void;
  hasActiveFilters: boolean;
}) {
  return (
    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
      <div className="space-y-2 xl:col-span-2">
        <label className="text-sm font-medium text-foreground">Search</label>
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            className="h-11 bg-muted pl-10"
            placeholder="Order ID, buyer name, phone..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
          />
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium text-foreground">Status</label>
        <Select
          className="h-11 bg-muted"
          value={statusFilter}
          onChange={(e) => onStatusChange(e.target.value)}
          options={STATUS_OPTIONS}
        />
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium text-foreground">From</label>
        <Input className="h-11 bg-muted" type="date" value={dateFrom} onChange={(e) => onDateFromChange(e.target.value)} />
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium text-foreground">To</label>
        <Input className="h-11 bg-muted" type="date" value={dateTo} onChange={(e) => onDateToChange(e.target.value)} />
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3 pt-1 xl:col-span-5">
        <div className="flex flex-wrap items-center gap-2">
          {statusFilter ? <Badge variant="secondary" className="px-3 py-1">{statusFilter}</Badge> : null}
          {dateFrom ? <Badge variant="secondary" className="px-3 py-1">From {dateFrom}</Badge> : null}
          {dateTo ? <Badge variant="secondary" className="px-3 py-1">To {dateTo}</Badge> : null}
        </div>
        <Button variant="outline" onClick={onClear} disabled={!hasActiveFilters}>
          Clear filters
        </Button>
      </div>
    </div>
  );
}

export default function OrdersPageClient() {
  const router = useRouter();
  const { toast } = useToast();

  const [orders, setOrders] = useState<OrderListItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [totalPages, setTotalPages] = useState(0);

  const [statusFilter, setStatusFilter] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");

  const fetchOrders = useCallback(async () => {
    setIsLoading(true);
    try {
      const params: OrderFilters = {
        page,
        limit: pageSize,
        status: statusFilter || undefined,
        search: searchQuery || undefined,
        date_from: dateFrom || undefined,
        date_to: dateTo || undefined,
      };

      const response = await dashboardApi.getOrders(params);
      const data = response.data;
      setOrders(data.items);
      setTotal(data.total);
      setTotalPages(data.total_pages);
    } catch (error: any) {
      toast({
        message: "Error",
        description: error?.response?.data?.detail || "Failed to load orders",
        variant: "error",
      });
    } finally {
      setIsLoading(false);
    }
  }, [page, pageSize, statusFilter, searchQuery, dateFrom, dateTo, toast]);

  useEffect(() => {
    fetchOrders();
  }, [fetchOrders]);

  const handleStatusChange = useCallback(
    async (orderId: number, newStatus: string) => {
      try {
        await dashboardApi.updateOrderStatus(orderId, newStatus);
        toast({
          message: "Success",
          description: `Order status updated to ${newStatus}`,
          variant: "success",
        });
        fetchOrders();
      } catch (error: any) {
        toast({
          message: "Error",
          description: error?.response?.data?.detail || "Failed to update status",
          variant: "error",
        });
      }
    },
    [fetchOrders, toast],
  );

  const handleRowClick = useCallback(
    (orderId: number) => {
      router.push(`/dashboard/orders/${orderId}`);
    },
    [router],
  );

  const updateStatusFilter = useCallback((value: string) => {
    setStatusFilter(value);
    setPage(1);
  }, []);

  const updateSearchQuery = useCallback((value: string) => {
    setSearchQuery(value);
    setPage(1);
  }, []);

  const updateDateFrom = useCallback((value: string) => {
    setDateFrom(value);
    setPage(1);
  }, []);

  const updateDateTo = useCallback((value: string) => {
    setDateTo(value);
    setPage(1);
  }, []);

  const clearFilters = useCallback(() => {
    setStatusFilter("");
    setSearchQuery("");
    setDateFrom("");
    setDateTo("");
    setPage(1);
  }, []);

  const hasActiveFilters = useMemo(
    () => Boolean(statusFilter || searchQuery || dateFrom || dateTo),
    [statusFilter, searchQuery, dateFrom, dateTo],
  );

  return (
    <PageFrame>
      <PageHeader>
        <PageHeaderContent>
          <PageEyebrow>Commerce / orders</PageEyebrow>
          <PageTitle>Orders</PageTitle>
          <PageDescription>
            Manage and track recent transactions across your storefront.
          </PageDescription>
        </PageHeaderContent>
        <PageActions>
          <Badge variant="warning" className="px-3 py-1">
            {total} total results
          </Badge>
          <Button asChild>
            <Link href="/dashboard/analytics">View dashboard</Link>
          </Button>
        </PageActions>
      </PageHeader>

      <OrdersSummary orders={orders} total={total} />

      <SurfaceSection>
        <SectionHeader>
          <div>
            <SectionTitle>Search and filter</SectionTitle>
            <SectionDescription>Keep the desktop toolbar compact and move full filtering into a sheet on mobile.</SectionDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {hasActiveFilters ? (
              <Badge variant="secondary" className="px-3 py-1">
                Filters active
              </Badge>
            ) : null}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" className="md:hidden">
                  <SlidersHorizontal className="size-4" />
                  Filters
                </Button>
              </SheetTrigger>
              <SheetContent side="bottom" className="max-h-[85vh] border-t border-border bg-background p-0">
                <DialogTitle className="sr-only">Filter orders</DialogTitle>
                <DialogDescription className="sr-only">Refine the order queue without crowding the mobile screen.</DialogDescription>
                <div className="space-y-5 p-5">
                  <div>
                    <p className="text-lg font-semibold text-foreground">Filter orders</p>
                    <p className="mt-1 text-sm text-muted-foreground">Refine the order queue without crowding the mobile screen.</p>
                  </div>
                  <FilterFields
                    statusFilter={statusFilter}
                    searchQuery={searchQuery}
                    dateFrom={dateFrom}
                    dateTo={dateTo}
                    onStatusChange={updateStatusFilter}
                    onSearchChange={updateSearchQuery}
                    onDateFromChange={updateDateFrom}
                    onDateToChange={updateDateTo}
                    onClear={clearFilters}
                    hasActiveFilters={hasActiveFilters}
                  />
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </SectionHeader>

        <div className="mt-4 hidden md:block">
          <FilterFields
            statusFilter={statusFilter}
            searchQuery={searchQuery}
            dateFrom={dateFrom}
            dateTo={dateTo}
            onStatusChange={updateStatusFilter}
            onSearchChange={updateSearchQuery}
            onDateFromChange={updateDateFrom}
            onDateToChange={updateDateTo}
            onClear={clearFilters}
            hasActiveFilters={hasActiveFilters}
          />
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-2 md:hidden">
          {searchQuery ? <Badge variant="secondary" className="px-3 py-1">Search: {searchQuery}</Badge> : null}
          {statusFilter ? <Badge variant="secondary" className="px-3 py-1">{statusFilter}</Badge> : null}
          {dateFrom || dateTo ? (
            <Badge variant="secondary" className="px-3 py-1">
              <CalendarRange className="mr-1 size-3.5" />
              Date range
            </Badge>
          ) : null}
          {!hasActiveFilters ? (
            <Badge variant="outline" className="px-3 py-1">
              <Filter className="mr-1 size-3.5" />
              No filters
            </Badge>
          ) : null}
        </div>
      </SurfaceSection>

      {isLoading ? <OrdersLoadingState /> : null}

      {!isLoading && orders.length === 0 ? (
        <OrdersEmptyState hasActiveFilters={hasActiveFilters} onClear={clearFilters} />
      ) : null}

      {!isLoading && orders.length > 0 ? (
        <>
          <div className="space-y-4 md:hidden">
            {orders.map((order) => (
              <OrderCard key={order.id} order={order} onOpen={handleRowClick} onStatusChange={handleStatusChange} />
            ))}
          </div>

          <div className="hidden md:block">
            <OrdersTable orders={orders} onRowClick={handleRowClick} onStatusChange={handleStatusChange} />
          </div>

          <Pagination
            page={page}
            pageSize={pageSize}
            total={total}
            totalPages={totalPages}
            onPageChange={setPage}
            onPageSizeChange={(size) => {
              setPageSize(size);
              setPage(1);
            }}
          />
        </>
      ) : null}
    </PageFrame>
  );
}
