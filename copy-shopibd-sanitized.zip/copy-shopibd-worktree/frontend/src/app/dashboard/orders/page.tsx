import { Metadata } from "next";
import { redirect } from "next/navigation";
import { getServerSession } from "@/lib/auth";
import OrdersPageClient from "./page-client";

export const metadata: Metadata = {
  title: "Orders | ShopiBD Dashboard",
  description: "Manage your shop orders",
};

export default async function OrdersPage() {
  // Server-side auth check
  const session = await getServerSession();
  if (!session) {
    redirect("/auth/login");
  }

  return <OrdersPageClient />;
}
