import { Metadata } from "next";
import { redirect } from "next/navigation";
import { getServerSession } from "@/lib/auth";
import AbandonedPageClient from "./page-client";

export const metadata: Metadata = {
  title: "Abandoned Cart | ShopiBD Dashboard",
  description: "Recover abandoned orders with WhatsApp reminders",
};

export default async function AbandonedPage() {
  // Server-side auth check
  const session = await getServerSession();
  if (!session) {
    redirect("/auth/login");
  }

  return <AbandonedPageClient />;
}
