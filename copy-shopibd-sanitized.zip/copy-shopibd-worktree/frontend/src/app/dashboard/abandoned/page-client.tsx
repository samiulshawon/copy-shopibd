"use client";

import React, { useCallback, useEffect, useState } from "react";
import { abandonedCartApi } from "@/lib/api";
import type { AbandonedOrderItem } from "@/types/order";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  Loader2,
  MessageSquare,
  ShoppingBag,
  CheckCircle2,
  Send,
  Clock,
  RefreshCw,
} from "lucide-react";
import {
  MetricCard,
  MetricStrip,
  PageActions,
  PageDescription,
  PageEyebrow,
  PageFrame,
  PageHeader,
  PageHeaderContent,
  PageTitle,
  SectionDescription,
  SectionHeader,
  SectionTitle,
  SurfaceSection,
} from "@/components/layout/page-structure";

export default function AbandonedPageClient() {
  const { toast } = useToast();

  const [orders, setOrders] = useState<AbandonedOrderItem[]>([]);
  const [total, setTotal] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [hours, setHours] = useState(24);
  const [sendingIds, setSendingIds] = useState<Set<number>>(new Set());
  const [sentIds, setSentIds] = useState<Set<number>>(new Set());
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());

  const fetchAbandoned = useCallback(async () => {
    setIsLoading(true);
    try {
      const res = await abandonedCartApi.list({ hours, limit: 100 });
      setOrders(res.data.items);
      setTotal(res.data.total);
    } catch (err: any) {
      toast({
        message: "Error",
        description: err?.response?.data?.detail || "Failed to load abandoned orders",
        variant: "error",
      });
    } finally {
      setIsLoading(false);
    }
  }, [hours, toast]);

  useEffect(() => {
    fetchAbandoned();
  }, [fetchAbandoned]);

  const handleSendReminder = useCallback(
    async (orderId: number) => {
      if (sendingIds.has(orderId)) return;
      setSendingIds((prev) => new Set(prev).add(orderId));
      try {
        const res = await abandonedCartApi.remind(orderId);
        if (res.data.sent) {
          setSentIds((prev) => new Set(prev).add(orderId));
          toast({
            message: "Reminder Sent",
            description: res.data.message || "WhatsApp reminder sent successfully",
            variant: "success",
          });
        }
      } catch (err: any) {
        toast({
          message: "Error",
          description: err?.response?.data?.detail || "Failed to send reminder",
          variant: "error",
        });
      } finally {
        setSendingIds((prev) => {
          const next = new Set(prev);
          next.delete(orderId);
          return next;
        });
      }
    },
    [sendingIds, toast],
  );

  const handleBulkRemind = useCallback(async () => {
    for (const id of selectedIds) {
      await handleSendReminder(id);
    }
    setSelectedIds(new Set());
  }, [selectedIds, handleSendReminder]);

  const toggleSelect = useCallback((id: number) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const toggleSelectAll = useCallback(() => {
    if (selectedIds.size === orders.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(orders.map((o) => o.id)));
    }
  }, [selectedIds, orders]);

  const hoursSince = useCallback((hours: number) => {
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ${hours % 24}h ago`;
  }, []);

  const pendingCount = orders.length;
  const alreadySent = sentIds.size;

  return (
    <PageFrame>
      <PageHeader>
        <PageHeaderContent>
          <PageEyebrow>Commerce / cart recovery</PageEyebrow>
          <PageTitle>Abandoned carts</PageTitle>
          <PageDescription>
            Recover lost sales by sending WhatsApp reminders to customers who left
            orders pending.
          </PageDescription>
        </PageHeaderContent>
        <PageActions>
          <div className="flex items-center gap-2">
            <label className="text-sm text-muted-foreground">
              Older than:
            </label>
            <Input
              type="number"
              min={1}
              value={hours}
              onChange={(e) => setHours(parseInt(e.target.value) || 24)}
              className="w-20 bg-muted"
            />
            <span className="text-xs text-muted-foreground">hours</span>
          </div>
          <Button variant="outline" onClick={fetchAbandoned}>
            <RefreshCw className="mr-1.5 size-4" />
            Refresh
          </Button>
        </PageActions>
      </PageHeader>

      {/* Summary metrics */}
      <MetricStrip>
        <MetricCard>
          <p className="text-sm font-medium text-muted-foreground">Pending carts</p>
          <p className="mt-2 text-2xl font-semibold tracking-tight text-warning">{pendingCount}</p>
          <p className="mt-1 text-xs text-muted-foreground">Older than {hours} hours.</p>
        </MetricCard>
        <MetricCard>
          <p className="text-sm font-medium text-muted-foreground">Reminders sent</p>
          <p className="mt-2 text-2xl font-semibold tracking-tight text-success">{alreadySent}</p>
          <p className="mt-1 text-xs text-muted-foreground">This session.</p>
        </MetricCard>
      </MetricStrip>

      {/* Bulk actions */}
      {selectedIds.size > 0 ? (
        <div className="flex items-center gap-3 border border-primary/30 bg-primary/10 p-3">
          <span className="text-sm font-medium text-foreground">
            {selectedIds.size} order{selectedIds.size !== 1 ? "s" : ""} selected
          </span>
          <Button
            size="sm"
            onClick={handleBulkRemind}
            disabled={sendingIds.size > 0}
          >
            <Send className="mr-1.5 size-4" />
            Remind Selected
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => setSelectedIds(new Set())}
          >
            Clear Selection
          </Button>
        </div>
      ) : null}

      {/* Table */}
      <SurfaceSection>
        <SectionHeader>
          <div>
            <SectionTitle>Abandoned orders</SectionTitle>
            <SectionDescription>
              {total} order{total !== 1 ? "s" : ""} pending for more than {hours} hours
            </SectionDescription>
          </div>
        </SectionHeader>

        <div className="mt-4">
          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="size-8 animate-spin text-muted-foreground" />
            </div>
          ) : orders.length === 0 ? (
            <div className="flex flex-col items-center gap-3 py-12 text-center">
              <div className="flex size-14 items-center justify-center border border-border bg-background text-muted-foreground">
                <ShoppingBag className="size-6" />
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">No abandoned orders found</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Orders with status &quot;pending&quot; for more than {hours} hours will appear here.
                </p>
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto border border-border">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted text-left">
                    <th className="w-8 py-3 pl-4 pr-2 font-medium">
                      <input
                        type="checkbox"
                        checked={
                          orders.length > 0 &&
                          selectedIds.size === orders.length
                        }
                        onChange={toggleSelectAll}
                        className="size-4 border-border text-primary focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-ring"
                      />
                    </th>
                    <th className="p-3 font-medium">Order #</th>
                    <th className="p-3 font-medium">Customer</th>
                    <th className="p-3 font-medium">Phone</th>
                    <th className="p-3 font-medium">Amount</th>
                    <th className="p-3 font-medium">Status</th>
                    <th className="p-3 font-medium">Time Since</th>
                    <th className="py-3 pl-3 pr-4 text-right font-medium">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map((order) => (
                    <tr key={order.id} className="border-b border-border last:border-0 hover:bg-muted/50">
                      <td className="py-3 pl-4 pr-2">
                        <input
                          type="checkbox"
                          checked={selectedIds.has(order.id)}
                          onChange={() => toggleSelect(order.id)}
                          className="size-4 border-border text-primary focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-ring"
                        />
                      </td>
                      <td className="p-3 font-mono font-medium text-foreground">
                        {order.order_number}
                      </td>
                      <td className="p-3 text-foreground">{order.customer_name}</td>
                      <td className="p-3 text-muted-foreground">{order.customer_phone}</td>
                      <td className="p-3 font-medium text-foreground">৳{order.total_amount.toFixed(2)}</td>
                      <td className="p-3">
                        <Badge variant="warning">Pending</Badge>
                      </td>
                      <td className="p-3">
                        <span className="flex items-center gap-1 text-muted-foreground">
                          <Clock className="size-3" />
                          {hoursSince(order.hours_since)}
                        </span>
                      </td>
                      <td className="py-3 pl-3 pr-4 text-right">
                        {sentIds.has(order.id) ? (
                          <span className="inline-flex items-center gap-1 text-xs font-medium text-success">
                            <CheckCircle2 className="size-4" />
                            Reminded
                          </span>
                        ) : (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleSendReminder(order.id)}
                            disabled={sendingIds.has(order.id) || sentIds.has(order.id)}
                          >
                            {sendingIds.has(order.id) ? (
                              <Loader2 className="mr-1 size-3 animate-spin" />
                            ) : (
                              <MessageSquare className="mr-1 size-3" />
                            )}
                            Send Reminder
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </SurfaceSection>
    </PageFrame>
  );
}
