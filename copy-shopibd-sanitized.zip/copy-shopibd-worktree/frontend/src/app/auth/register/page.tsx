import { Metadata } from "next";
import { RegisterPageClient } from "./page-client";

export const metadata: Metadata = {
  title: "Register | ShopiBD",
  description: "Create a ShopiBD account",
};

export default function RegisterPage() {
  return <RegisterPageClient />;
}
