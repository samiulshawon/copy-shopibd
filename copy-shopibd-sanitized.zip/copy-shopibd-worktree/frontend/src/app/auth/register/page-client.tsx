"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export function RegisterPageClient() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      await api.post("/auth/register", { name, email, phone, password });
      const loginResponse = await api.post<{ access_token: string; token_type: string }>("/auth/login", { email, password });
      const { access_token } = loginResponse.data;
      localStorage.setItem("shopibd_access_token", access_token);
      document.cookie = `shopibd_access_token=${access_token}; path=/; max-age=${60 * 60 * 24 * 8}; SameSite=Lax`;
      window.location.href = "/dashboard/orders";
    } catch (err: unknown) {
      const detail = (err as { response?: { data?: { detail?: string | Array<{ msg: string }> } } })?.response?.data?.detail;
      setError(Array.isArray(detail) ? detail.map((d) => d.msg).join("; ") : detail || "Registration failed. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="grid min-h-screen bg-background lg:grid-cols-[0.8fr_1.2fr]">
      <section className="hidden border-r border-foreground bg-foreground p-10 text-primary-foreground lg:flex lg:flex-col lg:justify-between">
        <Link href="/" className="text-xl font-bold tracking-tight">ShopiBD</Link>
        <div><p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-primary-foreground/60">Start selling</p><h1 className="mt-4 max-w-md text-5xl font-bold leading-tight">Open a shop.<br />Own the next order.</h1><p className="mt-5 max-w-sm text-sm leading-6 text-primary-foreground/70">Set up the merchant workspace behind your storefront, catalog, delivery, and customer operations.</p></div>
        <p className="text-xs uppercase tracking-widest text-primary-foreground/50">No credit card required to start</p>
      </section>
      <section className="flex items-center justify-center p-5 sm:p-8"><div className="w-full max-w-md"><Link href="/" className="text-xl font-bold tracking-tight lg:hidden">ShopiBD</Link><p className="mt-10 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Create account</p><h2 className="mt-2 text-3xl font-bold tracking-tight">Start your merchant workspace.</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">Enter the details needed to create your ShopiBD account.</p>
        <form onSubmit={handleSubmit} className="mt-8 space-y-5 border-t border-foreground pt-6" aria-busy={loading}>
          {error ? <Alert variant="destructive"><AlertTitle>Unable to create account</AlertTitle><AlertDescription>{error}</AlertDescription></Alert> : null}
          <div className="space-y-2"><label className="text-sm font-semibold" htmlFor="name">Full name</label><Input id="name" type="text" placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} required disabled={loading} autoComplete="name" /></div>
          <div className="space-y-2"><label className="text-sm font-semibold" htmlFor="email">Email</label><Input id="email" type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} required disabled={loading} autoComplete="email" /></div>
          <div className="space-y-2"><label className="text-sm font-semibold" htmlFor="phone">Phone number</label><Input id="phone" type="tel" placeholder="01XXXXXXXXX" value={phone} onChange={(e) => setPhone(e.target.value)} required disabled={loading} autoComplete="tel" /></div>
          <div className="space-y-2"><label className="text-sm font-semibold" htmlFor="password">Password</label><div className="relative"><Input id="password" type={showPassword ? "text" : "password"} placeholder="At least 6 characters" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} disabled={loading} autoComplete="new-password" className="pr-12" /><Button type="button" variant="ghost" size="icon" className="absolute right-0 top-0 size-10" aria-label={showPassword ? "Hide password" : "Show password"} onClick={() => setShowPassword((current) => !current)}>{showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}</Button></div></div>
          <Button type="submit" className="w-full" disabled={loading}>{loading ? <Loader2 className="size-4 animate-spin" /> : null}{loading ? "Creating account…" : "Create account"}</Button>
        </form>
        <p className="mt-6 text-sm text-muted-foreground">Already have an account? <Link href="/auth/login" className="font-semibold text-foreground underline underline-offset-4">Sign in</Link></p>
      </div></section>
    </main>
  );
}
