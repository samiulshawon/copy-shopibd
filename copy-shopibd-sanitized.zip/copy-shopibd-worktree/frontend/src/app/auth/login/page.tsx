import { Metadata } from "next";
import { LoginPageClient } from "./page-client";

export const metadata: Metadata = {
  title: "Login | ShopiBD",
  description: "Login to your ShopiBD account",
};

export default function LoginPage() {
  return <LoginPageClient />;
}
