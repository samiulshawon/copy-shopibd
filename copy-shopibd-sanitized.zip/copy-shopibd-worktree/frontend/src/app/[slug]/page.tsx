import { Metadata } from "next";
import { notFound } from "next/navigation";
import StorefrontPageClient from "./page-client";

interface StorefrontPageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: StorefrontPageProps): Promise<Metadata> {
  const { slug } = await params;
  return {
    title: `${slug.charAt(0).toUpperCase() + slug.slice(1)} - ShopiBD`,
    description: `Browse products from ${slug} on ShopiBD`,
  };
}

export default async function StorefrontPage({ params }: StorefrontPageProps) {
  const { slug } = await params;

  return <StorefrontPageClient slug={slug} />;
}
