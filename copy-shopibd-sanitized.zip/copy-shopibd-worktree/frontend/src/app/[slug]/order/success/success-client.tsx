"use client";

import { useState, type FormEvent } from "react";
import { storefrontApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { StarRating } from "@/components/ui/star-rating";
import { useToast } from "@/hooks/use-toast";
import { Copy, CheckCircle2, Search } from "lucide-react";

interface OrderSuccessClientProps {
  slug: string;
  orderNumber: string;
  productId?: number;
}

export function OrderSuccessClient({ slug, orderNumber, productId }: OrderSuccessClientProps) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  const [tracking, setTracking] = useState(false);
  const [trackPhone, setTrackPhone] = useState("");
  const [trackResult, setTrackResult] = useState<{
    order_number: string;
    status: string;
    payment_status: string;
    total_amount: number;
    created_at: string;
  } | null>(null);
  const [trackError, setTrackError] = useState<string | null>(null);

  // Review form state
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewTitle, setReviewTitle] = useState("");
  const [reviewBody, setReviewBody] = useState("");
  const [reviewName, setReviewName] = useState("");
  const [reviewPhone, setReviewPhone] = useState("");
  const [submittingReview, setSubmittingReview] = useState(false);
  const [reviewSubmitted, setReviewSubmitted] = useState(false);
  const [reviewError, setReviewError] = useState<string | null>(null);

  async function copyPaymentDetails() {
    const lines = [
      `Order: ${orderNumber}`,
      `Reference: ${orderNumber}`,
    ];
    await navigator.clipboard.writeText(lines.join("\n"));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  async function handleTrack(e: FormEvent) {
    e.preventDefault();
    setTrackError(null);
    setTrackResult(null);
    setTracking(true);
    try {
      const response = await storefrontApi.trackOrder(slug, trackPhone, orderNumber);
      const data = response.data as {
        order_number: string;
        status: string;
        payment_status: string;
        total_amount: number;
        created_at: string;
      };
      setTrackResult(data);
    } catch (err: unknown) {
      const message =
        (err as { response?: { data?: { detail?: string } } })?.response?.data
          ?.detail || "Unable to track order. Please check your phone number.";
      setTrackError(message);
    } finally {
      setTracking(false);
    }
  }

  async function handleSubmitReview(e: FormEvent) {
    e.preventDefault();
    if (!productId) {
      setReviewError("Product information is missing. Cannot submit review.");
      return;
    }
    if (!reviewBody.trim()) {
      setReviewError("Please write your review.");
      return;
    }
    setReviewError(null);
    setSubmittingReview(true);
    try {
      await storefrontApi.submitReview({
        product_id: productId,
        buyer_name: reviewName.trim() || "Anonymous",
        buyer_phone: reviewPhone.trim() || "00000000000",
        rating: reviewRating,
        title: reviewTitle.trim() || undefined,
        body: reviewBody.trim(),
      });
      setReviewSubmitted(true);
      toast({
        message: "Review submitted!",
        description: "Your review will be visible after approval.",
        variant: "success",
      });
    } catch (err: unknown) {
      const message =
        (err as { response?: { data?: { detail?: string } } })?.response?.data
          ?.detail || "Failed to submit review. Please try again.";
      setReviewError(message);
    } finally {
      setSubmittingReview(false);
    }
  }

  return (
    <main className="mx-auto max-w-2xl space-y-6">
      <Card className="border-success">
        <CardHeader className="border-b border-border bg-success/10">
          <CardTitle className="flex items-center gap-3 text-success">
            <span className="flex size-10 items-center justify-center border border-success bg-background text-success" aria-hidden="true">
              <CheckCircle2 className="size-5" />
            </span>
            Order confirmed
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <p className="text-sm text-muted-foreground">Order ID</p>
              <p className="font-mono font-semibold">{orderNumber}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Status</p>
              <p className="font-medium">Pending verification</p>
            </div>
          </div>

          <div className="border border-border bg-muted p-4">
            <p className="mb-2 text-sm font-medium">Payment Instructions</p>
            <p className="text-sm text-muted-foreground">
              Please send the exact amount to the number below and keep your order number as reference.
              Our team will verify and confirm your order.
            </p>
            <div className="mt-3 space-y-1 text-sm">
              <p>
                <span className="font-medium">Reference:</span> {orderNumber}
              </p>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col gap-3 border-t border-border sm:flex-row">
          <Button
            type="button"
            variant="outline"
            className="w-full sm:w-auto"
            onClick={copyPaymentDetails}
          >
            {copied ? (
              <>
                <CheckCircle2 className="mr-2 size-4" />
                Copied
              </>
            ) : (
              <>
                <Copy className="mr-2 size-4" />
                Copy Payment Details
              </>
            )}
          </Button>
        </CardFooter>
      </Card>

      {/* Review Card */}
      {productId && !reviewSubmitted && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-warning"
              >
                <path d="M11.48 3.499a.562.562 0 0 1 1.04 0l2.125 5.111a.563.563 0 0 0 .475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 0 0-.182.557l1.285 5.385a.562.562 0 0 1-.84.61l-4.725-2.885a.562.562 0 0 0-.586 0L6.982 20.54a.562.562 0 0 1-.84-.61l1.285-5.386a.562.562 0 0 0-.182-.557l-4.204-3.602a.562.562 0 0 1 .321-.988l5.518-.442a.563.563 0 0 0 .475-.345L11.48 3.5Z" />
              </svg>
              Rate Your Purchase
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmitReview} className="space-y-4" aria-describedby="review-guidance">
              <p id="review-guidance" className="text-sm text-muted-foreground">Reviews are published after seller approval.</p>
              <div className="space-y-2">
                <p className="text-sm font-medium" id="review-rating-label">Rating</p>
                <StarRating
                  value={reviewRating}
                  interactive
                  onChange={setReviewRating}
                  size="lg"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium" htmlFor="review-name">
                  Your Name
                </label>
                <Input
                  id="review-name"
                  placeholder="Your name (optional)"
                  value={reviewName}
                  onChange={(e) => setReviewName(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium" htmlFor="review-phone">
                  Phone Number
                </label>
                <Input
                  id="review-phone"
                  placeholder="+8801XXXXXXXXX (optional)"
                  value={reviewPhone}
                  onChange={(e) => setReviewPhone(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium" htmlFor="review-title">
                  Title
                </label>
                <Input
                  id="review-title"
                  placeholder="Summary of your experience (optional)"
                  value={reviewTitle}
                  onChange={(e) => setReviewTitle(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium" htmlFor="review-body">
                  Your Review *
                </label>
                <textarea
                  id="review-body"
                  rows={4}
                  placeholder="Tell others about your experience with this product..."
                  className="flex w-full border border-input bg-muted px-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring disabled:cursor-not-allowed disabled:opacity-50"
                  value={reviewBody}
                  onChange={(e) => setReviewBody(e.target.value)}
                  required
                />
              </div>

              {reviewError && (
                <Alert variant="destructive">
                  <AlertTitle>Review failed</AlertTitle>
                  <AlertDescription>{reviewError}</AlertDescription>
                </Alert>
              )}

              <Button type="submit" className="w-full" disabled={submittingReview}>
                {submittingReview ? "Submitting..." : "Submit Review"}
              </Button>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Thank you message after review submitted */}
      {reviewSubmitted && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-success">
            <CheckCircle2 className="size-6" />
            Review Submitted
          </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Thank you for your review! It will be visible on the product page after approval.
            </p>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="border-b border-border">
          <CardTitle>Track this order</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleTrack} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium" htmlFor="success-track-phone">Phone number</label>
              <Input
                id="success-track-phone"
                type="tel"
                inputMode="tel"
                placeholder="+8801XXXXXXXXX"
                value={trackPhone}
                onChange={(e) => setTrackPhone(e.target.value)}
                required
              />
            </div>
            <Button type="submit" className="w-full" disabled={tracking} aria-busy={tracking}>
              {tracking && <Search className="mr-2 size-4 animate-spin" />}
              Track Order
            </Button>
          </form>

          {trackError && (
            <Alert variant="destructive" className="mt-4">
              <AlertTitle>Tracking failed</AlertTitle>
              <AlertDescription>{trackError}</AlertDescription>
            </Alert>
          )}

          {trackResult && (
            <div className="mt-4 space-y-2 border border-foreground bg-background p-4" role="status" aria-live="polite">
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                <div>
                  <p className="text-sm text-muted-foreground">Order</p>
                  <p className="font-mono font-semibold">{trackResult.order_number}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total</p>
                  <p className="font-semibold">৳{trackResult.total_amount.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Status</p>
                  <p className="font-medium capitalize">{trackResult.status}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Payment</p>
                  <p className="font-medium capitalize">{trackResult.payment_status}</p>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </main>
  );
}
