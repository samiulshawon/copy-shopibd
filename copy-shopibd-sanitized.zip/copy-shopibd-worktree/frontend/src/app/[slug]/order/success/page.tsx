import { Metadata } from "next";
import { notFound } from "next/navigation";
import { OrderSuccessClient } from "./success-client";

interface OrderSuccessPageProps {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ order?: string; product_id?: string }>;
}

export async function generateMetadata({ params }: OrderSuccessPageProps): Promise<Metadata> {
  const { slug } = await params;
  return {
    title: `Order Confirmed - ${slug} - ShopiBD`,
    description: `Your order confirmation from ${slug} on ShopiBD`,
  };
}

export default async function OrderSuccessPage({ params, searchParams }: OrderSuccessPageProps) {
  const { slug } = await params;
  const { order, product_id } = await searchParams;

  if (!order) {
    notFound();
  }

  return (
    <OrderSuccessClient
      slug={slug}
      orderNumber={order}
      productId={product_id ? Number(product_id) : undefined}
    />
  );
}
