"use client";

import { useEffect, useState } from "react";
import { useStorefront } from "@/components/storefront/storefront-provider";
import { OrderForm } from "@/components/storefront/order-form";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

interface OrderPageClientProps {
  slug: string;
  productId: number;
}

function OrderLoading() {
  return (
    <div className="py-8">
      <div className="mx-auto max-w-2xl space-y-6">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-64 w-full" />
      </div>
    </div>
  );
}

function OrderError({ message }: { message: string }) {
  return (
    <div className="flex min-h-[60vh] items-center justify-center">
      <Alert variant="destructive" className="max-w-md">
        <AlertTitle>Unable to load order page</AlertTitle>
        <AlertDescription>{message}</AlertDescription>
      </Alert>
    </div>
  );
}

export function OrderPageClient({ slug, productId }: OrderPageClientProps) {
  const { shop, loading: shopLoading, error: shopError } = useStorefront();
  const [product, setProduct] = useState<{
    id: number;
    name: string;
    description?: string;
    price: number;
    stock: number;
    sku?: string;
    is_active: boolean;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function loadProduct() {
      setLoading(true);
      setError(null);
      try {
        const { storefrontApi } = await import("@/lib/api");
        const response = await storefrontApi.getProduct(slug, productId);
        if (!cancelled) {
          setProduct(response.data);
        }
      } catch (err: unknown) {
        if (!cancelled) {
          const status = (err as { response?: { status?: number } })?.response
            ?.status;
          if (status === 404) {
            setError("Product not found");
          } else {
            setError("Failed to load product. Please try again later.");
          }
          setProduct(null);
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    if (shop) {
      loadProduct();
    }

    return () => {
      cancelled = true;
    };
  }, [slug, productId, shop]);

  if (shopLoading) {
    return <OrderLoading />;
  }

  if (shopError || !shop) {
    return <OrderError message={shopError || "Shop not found"} />;
  }

  if (loading) {
    return <OrderLoading />;
  }

  if (error || !product) {
    return <OrderError message={error || "Product not found"} />;
  }

  return (
    <div className="py-8 sm:py-10">
      <OrderForm
        product={product}
        shopName={shop.name}
        shopSlug={slug}
        shopContactPhone={shop.contact_phone}
        bkashNumber={shop.bkash_number}
        nagadNumber={shop.nagad_number}
      />
    </div>
  );
}
