import { Metadata } from "next";
import { notFound } from "next/navigation";
import { OrderPageClient } from "./page-client";

interface OrderPageProps {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ product_id?: string }>;
}

export async function generateMetadata({ params }: OrderPageProps): Promise<Metadata> {
  const { slug } = await params;
  return {
    title: `Place Order - ${slug} - ShopiBD`,
    description: `Place an order at ${slug} on ShopiBD`,
  };
}

export default async function OrderPage({ params, searchParams }: OrderPageProps) {
  const { slug } = await params;
  const { product_id } = await searchParams;

  if (!product_id) {
    notFound();
  }

  return <OrderPageClient slug={slug} productId={Number(product_id)} />;
}
