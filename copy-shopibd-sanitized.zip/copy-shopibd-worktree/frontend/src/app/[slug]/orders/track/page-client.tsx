"use client";

import { useState, type FormEvent } from "react";
import { storefrontApi } from "@/lib/api";
import type { OrderTrackResponse } from "@/types/shop";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";

const STATUS_STEPS = [
  "pending",
  "confirmed",
  "shipped",
  "delivered",
] as const;

const STATUS_LABELS: Record<string, string> = {
  pending: "Pending",
  confirmed: "Confirmed",
  shipped: "Shipped",
  delivered: "Delivered",
  cancelled: "Cancelled",
};

const STATUS_BADGE: Record<string, "success" | "info" | "warning" | "destructive" | "secondary"> = {
  pending: "warning",
  confirmed: "info",
  shipped: "secondary",
  delivered: "success",
  cancelled: "destructive",
};

function formatCurrency(amount: number) {
  return new Intl.NumberFormat("en-BD", {
    style: "currency",
    currency: "BDT",
  }).format(amount);
}

function formatDate(dateString: string) {
  return new Intl.DateTimeFormat("en-BD", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(dateString));
}

function TrackOrderSkeleton() {
  return (
    <div className="mx-auto max-w-2xl space-y-6 py-8">
      <Skeleton className="h-8 w-64" />
      <Skeleton className="h-64 w-full" />
    </div>
  );
}

interface TrackOrderClientProps {
  slug: string;
}

export function TrackOrderClient({ slug }: TrackOrderClientProps) {
  const [phone, setPhone] = useState("");
  const [orderId, setOrderId] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [order, setOrder] = useState<OrderTrackResponse | null>(null);
  const [submitted, setSubmitted] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setOrder(null);
    setSubmitted(true);

    try {
      const response = await storefrontApi.trackOrder(slug, phone, orderId);
      setOrder(response.data);
    } catch (err: unknown) {
      const status = (err as { response?: { status?: number } })?.response?.status;
      if (status === 404) {
        setError("Order not found. Please check your phone number and order ID.");
      } else {
        setError("Failed to track order. Please try again later.");
      }
    } finally {
      setLoading(false);
    }
  }

  const currentStatusIndex = order
    ? STATUS_STEPS.indexOf(order.status as (typeof STATUS_STEPS)[number])
    : -1;

  return (
    <main className="mx-auto max-w-2xl py-8">
      <header className="mb-6 border-b border-foreground pb-4">
        <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">ShopiBD order desk</p>
        <h1 className="mt-2 text-2xl font-bold tracking-tight">Track your order</h1>
        <p className="mt-2 text-sm text-muted-foreground">Enter the phone number and order ID used at checkout.</p>
      </header>

      <form onSubmit={handleSubmit} className="mb-8 space-y-4 border border-border bg-background p-5" aria-busy={loading}>
        <div>
          <label
            htmlFor="phone"
            className="mb-1 block text-sm font-medium text-foreground"
          >
            Phone Number
          </label>
          <Input
            id="phone"
            type="tel"
            placeholder="01712345678"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            required
            disabled={loading}
          />
        </div>

        <div>
          <label
            htmlFor="orderId"
            className="mb-1 block text-sm font-medium text-foreground"
          >
            Order ID
          </label>
          <Input
            id="orderId"
            type="text"
            placeholder="SB-2026-000001"
            value={orderId}
            onChange={(e) => setOrderId(e.target.value)}
            required
            disabled={loading}
          />
        </div>

        <Button type="submit" disabled={loading} className="w-full">
          {loading ? "Tracking..." : "Track Order"}
        </Button>
      </form>

      {loading && <TrackOrderSkeleton />}

      {error && (
        <Alert variant="destructive">
          <AlertTitle>Order Not Found</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {order && !loading && (
        <section className="space-y-6 border border-foreground bg-background p-6" aria-labelledby="order-result-heading" aria-live="polite">
          <div className="flex items-center justify-between">
            <div>
              <h2 id="order-result-heading" className="text-lg font-semibold">Order #{order.order_number}</h2>
              <p className="text-sm text-muted-foreground">
                Placed on {formatDate(order.created_at)}
              </p>
            </div>
            <Badge variant={STATUS_BADGE[order.status] || "secondary"}>
              {STATUS_LABELS[order.status] || order.status}
            </Badge>
          </div>

          <div className="space-y-3">
            <h3 className="font-medium">Items</h3>
            {order.items.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between border border-border bg-muted p-3"
              >
                <div>
                  <p className="font-medium">{item.product_name}</p>
                  <p className="text-sm text-muted-foreground">
                    Qty: {item.quantity} × {formatCurrency(item.unit_price)}
                  </p>
                </div>
                <p className="font-medium">{formatCurrency(item.subtotal)}</p>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-between border-t pt-4">
            <span className="font-semibold">Total Amount</span>
            <span className="text-lg font-bold">{formatCurrency(order.total_amount)}</span>
          </div>

          <div className="space-y-3">
            <h3 className="font-medium">Status timeline</h3>
            <ol className="space-y-3">
              {STATUS_STEPS.map((step, index) => {
                const isCompleted = index <= currentStatusIndex;
                const isCurrent = index === currentStatusIndex;

                return (
                  <li key={step} className="flex items-center gap-3">
                    <div
                      className={`flex size-8 items-center justify-center border-2 text-sm font-semibold ${
                        isCompleted
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-border bg-muted text-muted-foreground"
                      }`}
                    >
                      {isCompleted ? "✓" : index + 1}
                    </div>
                    <div>
                      <p
                        className={`font-medium ${
                          isCurrent ? "text-foreground" : isCompleted ? "text-foreground" : "text-muted-foreground"
                        }`}
                      >
                        {STATUS_LABELS[step]}
                      </p>
                    </div>
                  </li>
                );
              })}
            </ol>
          </div>
        </section>
      )}
    </main>
  );
}
