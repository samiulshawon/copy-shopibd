import { Metadata } from "next";
import { TrackOrderClient } from "./page-client";

interface TrackOrderPageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({
  params,
}: TrackOrderPageProps): Promise<Metadata> {
  const { slug } = await params;
  return {
    title: `Track Order - ${slug} - ShopiBD`,
    description: `Track your order at ${slug} on ShopiBD`,
  };
}

export default async function TrackOrderPage({
  params,
}: TrackOrderPageProps) {
  const { slug } = await params;

  return <TrackOrderClient slug={slug} />;
}
