import React from "react";
import type { Metadata } from "next";
import { StorefrontProvider } from "@/components/storefront/storefront-provider";

interface StorefrontLayoutProps {
  children: React.ReactNode;
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: StorefrontLayoutProps): Promise<Metadata> {
  const { slug } = await params;
  return { title: `${slug.charAt(0).toUpperCase() + slug.slice(1)} - ShopiBD`, description: `Browse products from ${slug} on ShopiBD` };
}

export default async function StorefrontLayout({ children, params }: StorefrontLayoutProps) {
  const { slug } = await params;
  return <StorefrontProvider slug={slug}><div className="min-h-screen overflow-x-hidden bg-background text-foreground">{children}</div></StorefrontProvider>;
}
