import { Metadata } from "next";
import { notFound } from "next/navigation";
import { ProductDetailPageClient } from "./page-client";

interface ProductDetailPageProps {
  params: Promise<{ slug: string; id: string }>;
}

export async function generateMetadata({
  params,
}: ProductDetailPageProps): Promise<Metadata> {
  const { slug, id } = await params;
  return {
    title: `Product ${id} - ${slug} - ShopiBD`,
    description: `View product details from ${slug} on ShopiBD`,
  };
}

export default async function ProductDetailPage({
  params,
}: ProductDetailPageProps) {
  const { slug, id } = await params;

  return <ProductDetailPageClient slug={slug} productId={Number(id)} />;
}
