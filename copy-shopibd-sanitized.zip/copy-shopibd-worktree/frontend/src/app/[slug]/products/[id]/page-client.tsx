"use client";

import { useEffect, useState } from "react";
import { useStorefront } from "@/components/storefront/storefront-provider";
import { ProductDetail } from "@/components/storefront/product-detail";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import type { StorefrontShop } from "@/types/shop";

interface ProductDetailPageClientProps {
  slug: string;
  productId: number;
}

function ProductDetailLoading() {
  return (
    <div className="py-8">
      <div className="mx-auto max-w-4xl">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
          <Skeleton className="aspect-square w-full" />
          <div className="space-y-4">
            <Skeleton className="h-8 w-3/4" />
            <Skeleton className="h-6 w-1/4" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-2/3" />
            <Skeleton className="h-12 w-40" />
          </div>
        </div>
      </div>
    </div>
  );
}

function ProductDetailError({ message }: { message: string }) {
  return (
    <div className="flex min-h-[60vh] items-center justify-center">
      <Alert variant="destructive" className="max-w-md">
        <AlertTitle>Unable to load product</AlertTitle>
        <AlertDescription>{message}</AlertDescription>
      </Alert>
    </div>
  );
}

export function ProductDetailPageClient({
  slug,
  productId,
}: ProductDetailPageClientProps) {
  const { shop, loading: shopLoading, error: shopError } = useStorefront();
  const [product, setProduct] = useState<StorefrontShop["products"][number] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function loadProduct() {
      setLoading(true);
      setError(null);
      try {
        const { storefrontApi } = await import("@/lib/api");
        const response = await storefrontApi.getProduct(slug, productId);
        if (!cancelled) {
          setProduct(response.data as StorefrontShop["products"][number]);
        }
      } catch (err: unknown) {
        if (!cancelled) {
          const status = (err as { response?: { status?: number } })?.response?.status;
          if (status === 404) {
            setError("Product not found");
          } else {
            setError("Failed to load product. Please try again later.");
          }
          setProduct(null);
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    if (shop) {
      loadProduct();
    }

    return () => {
      cancelled = true;
    };
  }, [slug, productId, shop]);

  if (shopLoading) {
    return <ProductDetailLoading />;
  }

  if (shopError || !shop) {
    return <ProductDetailError message={shopError || "Shop not found"} />;
  }

  if (loading) {
    return <ProductDetailLoading />;
  }

  if (error || !product) {
    return <ProductDetailError message={error || "Product not found"} />;
  }

  return (
    <div className="py-8 sm:py-10">
      <ProductDetail product={product} shop={shop} />
    </div>
  );
}
