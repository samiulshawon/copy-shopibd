"use client";

import { useState, useEffect } from "react";
import { StorefrontProvider, useStorefront } from "@/components/storefront/storefront-provider";
import { ShopHeader } from "@/components/storefront/shop-header";
import { ProductGrid } from "@/components/storefront/product-grid";
import { StorefrontFooter } from "@/components/storefront/storefront-footer";
import { StorefrontMobileActions } from "@/components/storefront/storefront-mobile-actions";
import { RefreshCw, Store as StoreIcon } from "lucide-react";
import { Button } from "@/components/ui/button";

function StorefrontContent() {
  const { shop, loading, error } = useStorefront();

  if (loading) {
    return <StorefrontSkeleton />;
  }

  if (error || !shop) {
    return <StorefrontError message={error || "Shop not found"} />;
  }

  return (
    <>
      <ShopHeader shop={shop} />
      <div id="products" />
      <ProductGrid shop={shop} />
      <StorefrontFooter shopName={shop.name} />
      <StorefrontMobileActions shop={shop} />
    </>
  );
}

function StorefrontSkeleton() {
  return (
    <div className="animate-pulse">
      {/* Banner skeleton */}
      <div className="h-48 w-full bg-muted sm:h-64 md:h-72" />

      {/* Identity card skeleton */}
      <div className="relative mx-auto -mt-16 max-w-6xl px-4 sm:-mt-20 sm:px-6">
        <div className="border border-border/80 bg-background/85 p-5  sm:p-7">
          <div className="flex flex-col items-start gap-4 sm:flex-row sm:items-center sm:gap-6">
            <div className="-mt-14 size-20 bg-muted sm:-mt-16 sm:size-24" />
            <div className="flex-1 space-y-2">
              <div className="h-6 w-48 bg-muted" />
              <div className="h-4 w-72 max-w-full bg-muted" />
            </div>
          </div>
        </div>
      </div>

      {/* Products skeleton */}
      <section className="mx-auto max-w-6xl px-4 pb-24 pt-8 sm:px-6 sm:pt-10">
        <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
            <div
              key={i}
              className="overflow-hidden border border-border bg-background"
            >
              <div className="aspect-square w-full bg-muted" />
              <div className="space-y-2 p-3">
                <div className="h-4 w-3/4 bg-muted" />
                <div className="h-4 w-1/2 bg-muted" />
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function StorefrontError({ message }: { message: string }) {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center gap-4 px-4 py-20 text-center">
      <div className="flex size-14 items-center justify-center border border-border bg-background text-muted-foreground">
        <StoreIcon className="size-6" />
      </div>
      <div className="space-y-2">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          Shop unavailable
        </h1>
        <p className="text-sm text-muted-foreground">{message}</p>
      </div>
      <Button
        variant="outline"
        onClick={() => window.location.reload()}
      >
        <RefreshCw className="mr-1.5 size-4" />
        Try again
      </Button>
    </div>
  );
}

export default function StorefrontPageClient({ slug }: { slug: string }) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  return (
    <StorefrontProvider key={slug} slug={slug}>
      {mounted ? <StorefrontContent /> : <StorefrontSkeleton />}
    </StorefrontProvider>
  );
}
