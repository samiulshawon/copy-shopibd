"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Check, Loader2, ArrowRight, CreditCard, Shield, Zap, Globe, Users } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

import { subscriptionApi } from "@/lib/api";
import type { PlanInfo } from "@/types/subscription";
import { formatPlanPrice, formatPlanLimit } from "@/types/subscription";

const PLAN_ORDER = ["free", "starter", "business", "enterprise"] as const;

const FEATURES_DETAIL: Record<string, { title: string; description: string }[]> = {
  free: [
    { title: "Basic storefront", description: "Create your online shop with essential features" },
    { title: "Up to 50 products", description: "Showcase your inventory with images and descriptions" },
    { title: "200 orders/month", description: "Process customer orders seamlessly" },
    { title: "Email support", description: "Get help via email during business hours" },
  ],
  starter: [
    { title: "Everything in Free", description: "All basic features included" },
    { title: "Up to 200 products", description: "Scale your catalog as you grow" },
    { title: "1,000 orders/month", description: "Handle more customer transactions" },
    { title: "Coupon management", description: "Create and manage discount codes" },
    { title: "Staff accounts (3)", description: "Add team members to help manage your shop" },
    { title: "Email & chat support", description: "Priority support via email and live chat" },
  ],
  business: [
    { title: "Everything in Starter", description: "All starter features included" },
    { title: "Up to 1,000 products", description: "Large inventory management" },
    { title: "5,000 orders/month", description: "High-volume order processing" },
    { title: "Advanced analytics", description: "Sales reports, customer insights, trends" },
    { title: "Abandoned cart recovery", description: "Automated WhatsApp reminders for pending orders" },
    { title: "Priority support", description: "Faster response times, dedicated queue" },
  ],
  enterprise: [
    { title: "Everything in Business", description: "All business features included" },
    { title: "Unlimited products", description: "No limits on your catalog size" },
    { title: "Unlimited orders", description: "Process unlimited transactions" },
    { title: "Custom domain & whitelabel", description: "Use your own domain, remove ShopiBD branding" },
    { title: "Dedicated account manager", description: "Personal support for your business" },
    { title: "API access", description: "Integrate with your own systems" },
    { title: "Custom integrations", description: "Tailored solutions for enterprise needs" },
  ],
};

export default function PricingPage() {
  const [plans, setPlans] = useState<PlanInfo[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly");

  useEffect(() => {
    async function fetchPlans() {
      try {
        const res = await subscriptionApi.listPlans();
        setPlans(res.data);
      } catch (error) {
        console.error("Failed to load plans:", error);
      } finally {
        setIsLoading(false);
      }
    }
    fetchPlans();
  }, []);

  const getPlan = (id: string) => plans.find((p) => p.id === id);

  if (isLoading) {
    return (
      <main className="min-h-screen bg-background py-20" aria-busy="true" aria-label="Loading plans">
        <div className="container mx-auto px-4">
          <div className="space-y-8">
            <div className="mx-auto h-8 w-64 bg-muted" />
            <div className="grid gap-4 md:grid-cols-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-96 border border-border bg-muted" />
              ))}
            </div>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-background">
      <section className="border-b border-foreground bg-foreground py-16 text-primary-foreground lg:py-24">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center">
            <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-primary-foreground/70">ShopiBD plans</p>
            <h1 className="mt-4 text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl">Straightforward tools for every stage of trade.</h1>
            <p className="mx-auto mt-6 max-w-2xl text-lg leading-8 text-primary-foreground/75">Start with the essentials, then expand your storefront operations as your team, catalog, and order volume grow.</p>
            <div className="mt-8 inline-flex border border-primary-foreground/50 p-1" role="group" aria-label="Billing cycle">
              <Button variant={billingCycle === "monthly" ? "secondary" : "ghost"} onClick={() => setBillingCycle("monthly")} aria-pressed={billingCycle === "monthly"}>Monthly</Button>
              <Button variant={billingCycle === "yearly" ? "secondary" : "ghost"} onClick={() => setBillingCycle("yearly")} aria-pressed={billingCycle === "yearly"}>Yearly <span className="ml-2 text-xs">Save 20%</span></Button>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Cards */}
      <section id="plans" className="py-16 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="mb-10 flex flex-col gap-3 border-b border-foreground pb-5 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Plan selection</p>
              <h2 className="mt-2 text-3xl font-bold tracking-tight">Pick the operating capacity you need.</h2>
            </div>
            <p className="max-w-md text-sm text-muted-foreground">Every plan includes a merchant workspace and a customer-facing storefront.</p>
          </div>
          <Tabs value={billingCycle} onValueChange={(value) => setBillingCycle(value as "monthly" | "yearly")} className="w-full">
            <TabsList className="hidden">
              <TabsTrigger value="monthly">Monthly</TabsTrigger>
              <TabsTrigger value="yearly">Yearly</TabsTrigger>
            </TabsList>

            <TabsContent value="monthly" className="pt-0">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                {PLAN_ORDER.map((planId, index) => {
                  const plan = getPlan(planId);
                  if (!plan) return null;

                  const isPopular = planId === "business";
                  const price = billingCycle === "yearly"
                    ? Math.round(plan.price_bdt * 12 * 0.8)
                    : plan.price_bdt;

                  return (
                    <Card
                      key={planId}
                      style={{ animationDelay: `${index * 60}ms` }}
                      className={`relative flex flex-col border-foreground transition-[border-color,background-color] hover:bg-muted ${
                        isPopular ? "border-2" : ""
                      }`}
                    >
                      {isPopular && (
                        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                          <Badge variant="default" className="px-3 py-1 text-xs">
                            Most Popular
                          </Badge>
                        </div>
                      )}

                      <CardHeader className="border-b border-border pb-4 text-center">
                        <CardTitle className="text-xl">{plan.name}</CardTitle>
                        <div className="mt-2 flex items-baseline justify-center gap-1">
                          <span className="text-4xl font-bold">
                            {price === 0 ? "Free" : `৳${price.toLocaleString()}`}
                          </span>
                          <span className="text-muted-foreground">/month</span>
                        </div>
                        {billingCycle === "yearly" && price > 0 && (
                          <p className="mt-1 text-sm text-success">
                            ৳{(price * 12).toLocaleString()}/year (20% off)
                          </p>
                        )}
                      </CardHeader>

                      <CardContent className="flex-1 space-y-4">
                        <div className="space-y-3">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">Products</span>
                            <span className="font-medium">
                              {formatPlanLimit(plan.max_products)}
                            </span>
                          </div>
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">Monthly Orders</span>
                            <span className="font-medium">
                              {formatPlanLimit(plan.max_orders)}
                            </span>
                          </div>
                        </div>

                        <ul className="space-y-3">
                          {plan.features.map((feature, i) => (
                            <li key={i} className="flex items-start gap-3 text-sm">
                              <Check className="mt-0.5 size-5 flex-shrink-0 text-success" />
                              <span>{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>

                      <CardFooter className="flex flex-col gap-2 border-t border-border">
                        {planId === "free" ? (
                          <Link
                            href="/auth/register"
                            className="w-full"
                          >
                            <Button className="w-full" size="lg">
                              Get Started Free
                            </Button>
                          </Link>
                        ) : (
                          <Link
                            href={`/auth/login?redirect=/dashboard/subscription&plan=${planId}`}
                            className="w-full"
                          >
                            <Button
                              className={`w-full ${isPopular ? "bg-primary text-primary-foreground" : ""}`}
                              size="lg"
                            >
                              {planId === "starter" ? "Start Free Trial" : "Upgrade Now"}
                            </Button>
                          </Link>
                        )}
                        <p className="text-center text-xs text-muted-foreground">
                          No credit card required · Cancel anytime
                        </p>
                      </CardFooter>
                    </Card>
                  );
                })}
              </div>
            </TabsContent>

            <TabsContent value="yearly" className="pt-0">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                {PLAN_ORDER.map((planId, index) => {
                  const plan = getPlan(planId);
                  if (!plan) return null;

                  const isPopular = planId === "business";
                  const price = Math.round(plan.price_bdt * 12 * 0.8);

                  return (
                    <Card
                      key={planId}
                      style={{ animationDelay: `${index * 60}ms` }}
                      className={`relative flex flex-col border-foreground transition-[border-color,background-color] hover:bg-muted ${
                        isPopular ? "border-2" : ""
                      }`}
                    >
                      {isPopular && (
                        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                          <Badge variant="default" className="px-3 py-1 text-xs">
                            Most Popular · Save 20%
                          </Badge>
                        </div>
                      )}

                      <CardHeader className="border-b border-border pb-4 text-center">
                        <CardTitle className="text-xl">{plan.name}</CardTitle>
                        <div className="mt-2 flex items-baseline justify-center gap-1">
                          <span className="text-4xl font-bold">
                            {price === 0 ? "Free" : `৳${price.toLocaleString()}`}
                          </span>
                          <span className="text-muted-foreground">/year</span>
                        </div>
                        {price > 0 && (
                          <p className="mt-1 text-sm text-success">
                            ৳{(price / 12).toLocaleString()}/month equivalent
                          </p>
                        )}
                      </CardHeader>

                      <CardContent className="flex-1 space-y-4">
                        <div className="space-y-3">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">Products</span>
                            <span className="font-medium">
                              {formatPlanLimit(plan.max_products)}
                            </span>
                          </div>
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">Monthly Orders</span>
                            <span className="font-medium">
                              {formatPlanLimit(plan.max_orders)}
                            </span>
                          </div>
                        </div>

                        <ul className="space-y-3">
                          {plan.features.map((feature, i) => (
                            <li key={i} className="flex items-start gap-3 text-sm">
                              <Check className="mt-0.5 size-5 flex-shrink-0 text-success" />
                              <span>{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>

                      <CardFooter className="flex flex-col gap-2 border-t border-border">
                        {planId === "free" ? (
                          <Link
                            href="/auth/register"
                            className="w-full"
                          >
                            <Button className="w-full" size="lg">
                              Get Started Free
                            </Button>
                          </Link>
                        ) : (
                          <Link
                            href={`/auth/login?redirect=/dashboard/subscription&plan=${planId}`}
                            className="w-full"
                          >
                            <Button
                              className={`w-full ${isPopular ? "bg-primary text-primary-foreground" : ""}`}
                              size="lg"
                            >
                              {planId === "starter" ? "Start Free Trial" : "Upgrade Now"}
                            </Button>
                          </Link>
                        )}
                        <p className="text-center text-xs text-muted-foreground">
                          Billed annually · Cancel anytime
                        </p>
                      </CardFooter>
                    </Card>
                  );
                })}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Feature Comparison */}
      <section className="border-y border-border bg-muted py-16 lg:py-24">
       <div className="container mx-auto px-4">
         <div className="mb-10 border-b border-foreground pb-5">
           <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Capacity comparison</p>
           <h2 className="mt-2 text-3xl font-bold tracking-tight">Compare plan limits and operational tools.</h2>
         </div>

         <div className="overflow-x-auto border border-border bg-background">
           <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-foreground bg-foreground text-primary-foreground">
                  <th className="w-64 p-4 text-left font-medium">Feature</th>
                  {PLAN_ORDER.map((planId) => {
                    const plan = getPlan(planId);
                    if (!plan) return null;
                    return (
                      <th key={planId} className="p-4 text-center font-medium">
                        <div className="flex flex-col items-center">
                          <span className="font-semibold">{plan.name}</span>
                          <span className="text-xs text-muted-foreground">
                            {formatPlanPrice(plan.price_bdt)}/mo
                          </span>
                        </div>
                      </th>
                    );
                  })}
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-border">
                  <td className="p-4 font-medium">Products limit</td>
                  {PLAN_ORDER.map((planId) => {
                    const plan = getPlan(planId);
                    if (!plan) return null;
                    return (
                      <td key={planId} className="p-4 text-center font-medium">
                        {formatPlanLimit(plan.max_products)}
                      </td>
                    );
                  })}
                </tr>
                <tr className="border-b border-border">
                  <td className="p-4 font-medium">Monthly orders limit</td>
                  {PLAN_ORDER.map((planId) => {
                    const plan = getPlan(planId);
                    if (!plan) return null;
                    return (
                      <td key={planId} className="p-4 text-center font-medium">
                        {formatPlanLimit(plan.max_orders)}
                      </td>
                    );
                  })}
                </tr>
                <tr className="border-b border-border">
                  <td className="p-4 font-medium">Storefront</td>
                  {PLAN_ORDER.map((planId) => (
                    <td key={planId} className="p-4 text-center">
                      <Check className="mx-auto size-5 text-success" />
                    </td>
                  ))}
                </tr>
                <tr className="border-b border-border">
                  <td className="p-4 font-medium">Coupon management</td>
                  {PLAN_ORDER.map((planId) => (
                    <td key={planId} className="p-4 text-center">
                      {planId === "free" ? (
                        <span className="text-muted-foreground">—</span>
                      ) : (
                        <Check className="mx-auto size-5 text-success" />
                      )}
                    </td>
                  ))}
                </tr>
                <tr className="border-b border-border">
                  <td className="p-4 font-medium">Staff accounts</td>
                  {PLAN_ORDER.map((planId) => (
                    <td key={planId} className="p-4 text-center">
                      {planId === "free" ? (
                        <span className="text-muted-foreground">—</span>
                      ) : planId === "starter" ? (
                        <span>Up to 3</span>
                      ) : (
                        <span>Unlimited</span>
                      )}
                    </td>
                  ))}
                </tr>
                <tr className="border-b border-border">
                  <td className="p-4 font-medium">Advanced analytics</td>
                  {PLAN_ORDER.map((planId) => (
                    <td key={planId} className="p-4 text-center">
                      {planId === "business" || planId === "enterprise" ? (
                        <Check className="mx-auto size-5 text-success" />
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </td>
                  ))}
                </tr>
                <tr className="border-b border-border">
                  <td className="p-4 font-medium">Abandoned cart recovery</td>
                  {PLAN_ORDER.map((planId) => (
                    <td key={planId} className="p-4 text-center">
                      {planId === "business" || planId === "enterprise" ? (
                        <Check className="mx-auto size-5 text-success" />
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </td>
                  ))}
                </tr>
                <tr className="border-b border-border">
                  <td className="p-4 font-medium">Custom domain</td>
                  {PLAN_ORDER.map((planId) => (
                    <td key={planId} className="p-4 text-center">
                      {planId === "enterprise" ? (
                        <Check className="mx-auto size-5 text-success" />
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </td>
                  ))}
                </tr>
                <tr className="border-b border-border">
                  <td className="p-4 font-medium">API access</td>
                  {PLAN_ORDER.map((planId) => (
                    <td key={planId} className="p-4 text-center">
                      {planId === "enterprise" ? (
                        <Check className="mx-auto size-5 text-success" />
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </td>
                  ))}
                </tr>
                <tr className="border-b border-border">
                  <td className="p-4 font-medium">Support</td>
                  {PLAN_ORDER.map((planId) => {
                    const plan = getPlan(planId);
                    if (!plan) return null;
                    return (
                      <td key={planId} className="p-4 text-center text-xs">
                        {plan.features.find((f) => f.toLowerCase().includes("support"))?.split("(")[0] || "Email"}
                      </td>
                    );
                  })}
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="mb-10 border-b border-foreground pb-5">
            <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Plan guidance</p>
            <h2 className="mt-2 text-3xl font-bold tracking-tight">Questions before you commit.</h2>
          </div>

          <dl className="mx-auto max-w-3xl space-y-3">
            {[
              {
                q: "Can I change plans later?",
                a: "Yes, you can upgrade or downgrade at any time. Upgrades take effect immediately, while downgrades apply at the end of your current billing period.",
              },
              {
                q: "What payment methods do you accept?",
                a: "We accept bKash, Nagad, credit/debit cards via SSLCommerz, and manual bank transfers. All payments are processed securely.",
              },
              {
                q: "Is there a contract or long-term commitment?",
                a: "No. All plans are month-to-month. You can cancel anytime and your subscription will remain active until the end of the billing period.",
              },
              {
                q: "What happens when I reach my plan limits?",
                a: "You'll be notified when you approach your limits. If you exceed them, you won't be able to create new products or receive new orders until you upgrade or the next billing period starts.",
              },
              {
                q: "Do you offer refunds?",
                a: "We don't offer refunds for partial months, but you can cancel anytime to prevent future charges. Yearly plans include a 14-day money-back guarantee.",
              },
              {
                q: "Can I use my own domain?",
                a: "Custom domains are available on the Enterprise plan. Other plans use a shopibd.com subdomain (e.g., yourshop.shopibd.com).",
              },
            ].map((faq, i) => (
              <div key={i} className="border border-border bg-background p-6">
                <dt className="mb-2 font-medium">{faq.q}</dt>
                <dd className="text-muted-foreground">{faq.a}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      {/* CTA */}
      <section className="border-y border-foreground bg-foreground py-16 text-primary-foreground lg:py-24">
        <div className="container mx-auto px-4 text-center">
          <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-primary-foreground/70">Start operating</p>
          <h2 className="mx-auto mt-3 max-w-2xl text-3xl font-bold tracking-tight sm:text-4xl">
            Build the storefront your business is ready to run.
          </h2>
          <p className="mx-auto mb-8 mt-5 max-w-2xl text-lg text-primary-foreground/80">
            Create a ShopiBD account at no cost, then change plans from your merchant workspace as requirements grow.
          </p>
          <div className="flex items-center justify-center gap-4">
            <Link href="/auth/register">
              <Button size="lg" variant="secondary" className="w-auto">
                Create Free Account
              </Button>
            </Link>
            <Link href="/pricing#plans">
              <Button size="lg" variant="outline" className="w-auto border-primary-foreground/50 bg-transparent text-primary-foreground hover:bg-primary-foreground/10">
                View All Plans
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer Trust Badges */}
      <section className="bg-background py-12">
        <div className="container mx-auto px-4">
          <div className="grid gap-px border border-border bg-border md:grid-cols-4">
            <div className="flex flex-col items-center gap-2 bg-background p-6">
              <Shield className="size-8 text-primary" />
              <h3 className="font-medium">Secure Payments</h3>
              <p className="text-sm text-muted-foreground">PCI-DSS compliant</p>
            </div>
            <div className="flex flex-col items-center gap-2 bg-background p-6">
              <CreditCard className="size-8 text-primary" />
              <h3 className="font-medium">Multiple Methods</h3>
              <p className="text-sm text-muted-foreground">bKash, Nagad, Cards</p>
            </div>
            <div className="flex flex-col items-center gap-2 bg-background p-6">
              <Zap className="size-8 text-primary" />
              <h3 className="font-medium">Instant Setup</h3>
              <p className="text-sm text-muted-foreground">Start in minutes</p>
            </div>
            <div className="flex flex-col items-center gap-2 bg-background p-6">
              <Users className="size-8 text-primary" />
              <h3 className="font-medium">Local Support</h3>
              <p className="text-sm text-muted-foreground">Bengali & English</p>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}