"use client";

import * as React from "react";
import { cn, formatCurrency } from "@/lib/utils";

const EASE_UI = (() => {
  const cx = 3 * 0.2;
  const bx = 3 * (0 - 0.2) - cx;
  const ax = 1 - cx - bx;
  const cy = 0;
  const by = 3 * (1 - 0) - cy;
  const ay = 1 - cy - by;
  const solveT = (x: number) => {
    let t = x;
    for (let i = 0; i < 8; i++) {
      const f = ((ax * t + bx) * t + cx) * t - x;
      const d = (3 * ax * t + 2 * bx) * t + cx;
      if (Math.abs(d) < 1e-6) break;
      t -= f / d;
    }
    return t;
  };
  return (progress: number) => {
    const t = solveT(progress);
    return ((ay * t + by) * t + cy) * t;
  };
})();

function useCountUp(target: number, duration = 500) {
  const [display, setDisplay] = React.useState(0);

  React.useEffect(() => {
    if (typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setDisplay(target);
      return;
    }

    let raf = 0;
    let start: number | null = null;
    const tick = (now: number) => {
      if (start === null) start = now;
      const progress = Math.min((now - start) / duration, 1);
      setDisplay(target * EASE_UI(progress));
      if (progress < 1) raf = requestAnimationFrame(tick);
      else setDisplay(target);
    };

    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);

  return display;
}

export function PageFrame({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("flex flex-col gap-6", className)} {...props} />;
}

export function PageHeader({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("flex flex-col gap-4 border border-border bg-background p-5 sm:p-6 lg:flex-row lg:items-end lg:justify-between", className)} {...props} />;
}

export function PageHeaderContent({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("min-w-0 space-y-2", className)} {...props} />;
}

export function PageEyebrow({ className, ...props }: React.HTMLAttributes<HTMLParagraphElement>) {
  return <p className={cn("text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground", className)} {...props} />;
}

export function PageTitle({ className, ...props }: React.HTMLAttributes<HTMLHeadingElement>) {
  return <h1 className={cn("text-2xl font-semibold tracking-tight text-foreground sm:text-3xl", className)} {...props} />;
}

export function PageDescription({ className, ...props }: React.HTMLAttributes<HTMLParagraphElement>) {
  return <p className={cn("max-w-2xl text-sm leading-6 text-muted-foreground sm:text-[15px]", className)} {...props} />;
}

export function PageActions({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("flex flex-wrap items-center gap-3", className)} {...props} />;
}

export function FilterBar({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("flex flex-col gap-3 border border-border bg-background p-3 sm:flex-row sm:items-center", className)} {...props} />;
}

export function SectionHeader({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between", className)} {...props} />;
}

export function SectionTitle({ className, ...props }: React.HTMLAttributes<HTMLHeadingElement>) {
  return <h2 className={cn("text-lg font-semibold tracking-tight text-foreground", className)} {...props} />;
}

export function SectionDescription({ className, ...props }: React.HTMLAttributes<HTMLParagraphElement>) {
  return <p className={cn("text-sm leading-6 text-muted-foreground", className)} {...props} />;
}

export function SurfaceSection({ className, ...props }: React.HTMLAttributes<HTMLElement>) {
  return <section className={cn("border border-border bg-background p-5 sm:p-6", className)} {...props} />;
}

export function EmptyState({ className, children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("flex min-h-48 flex-col items-center justify-center border border-dashed border-border bg-background px-6 py-10 text-center", className)} {...props}>{children}</div>;
}

export function MetricStrip({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("grid gap-3 sm:grid-cols-2 xl:grid-cols-4", className)} {...props} />;
}

export interface MetricCardProps extends React.HTMLAttributes<HTMLDivElement> {
  value?: number | string;
  label?: React.ReactNode;
  helper?: React.ReactNode;
  index?: number;
  format?: "currency" | "number";
}

export function MetricCard({
  className,
  value,
  label,
  helper,
  index = 0,
  format = "currency",
  style,
  children,
  ...props
}: MetricCardProps) {
  const isNumeric = typeof value === "number" || (typeof value === "string" && value.trim() !== "" && !isNaN(Number(value)));
  const numericTarget = isNumeric ? Number(value as number | string) : 0;
  const display = useCountUp(numericTarget);
  const renderedValue = isNumeric ? (format === "number" ? Math.round(display).toLocaleString() : formatCurrency(display)) : (value as string);

  return (
    <div
      className={cn("animate-fade-up border border-border bg-background px-4 py-4 transition-[border-color,background-color] duration-150 ease-premium hover:border-foreground hover:bg-muted", className)}
      style={{ animationDelay: `${index * 60}ms`, ...style }}
      {...props}
    >
      {value !== undefined ? (
        <div className="space-y-1">
          {label ? <p className="text-sm font-medium text-muted-foreground">{label}</p> : null}
          <p className="text-2xl font-semibold tracking-tight text-foreground sm:text-[1.75rem]">{renderedValue}</p>
          {helper ? <p className="text-xs text-muted-foreground">{helper}</p> : null}
        </div>
      ) : children}
    </div>
  );
}

export function MobileStickyActions({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("sticky bottom-[calc(5.5rem+env(safe-area-inset-bottom))] z-30 -mx-1 mt-2 border border-foreground bg-popover p-3 md:bottom-4 md:mx-0", className)} {...props} />;
}
