import Link from "next/link";

const PUBLIC_LINKS = [
  { href: "/pricing", label: "Pricing" },
  { href: "/auth/login", label: "Sign in" },
  { href: "/auth/register", label: "Open a shop" },
];

export function Footer() {
  return (
    <footer className="border-t border-foreground bg-foreground text-primary-foreground">
      <div className="container-bd py-10 md:py-14">
        <div className="grid grid-cols-1 gap-8 border-b border-primary-foreground/30 pb-8 sm:grid-cols-2 md:grid-cols-[1.5fr_1fr_1fr]">
          <div>
            <Link href="/" className="text-xl font-bold tracking-tight">ShopiBD</Link>
            <p className="mt-3 max-w-sm text-sm leading-6 text-primary-foreground/70">Commerce operations and storefronts built for Bangladeshi merchants.</p>
          </div>
          <div>
            <h3 className="mb-3 text-[11px] font-semibold uppercase tracking-[0.12em] text-primary-foreground/60">Platform</h3>
            <ul className="space-y-2">{PUBLIC_LINKS.map((link) => <li key={link.href}><Link href={link.href} className="text-sm font-medium text-primary-foreground underline-offset-4 hover:underline">{link.label}</Link></li>)}</ul>
          </div>
          <div>
            <h3 className="mb-3 text-[11px] font-semibold uppercase tracking-[0.12em] text-primary-foreground/60">Merchant access</h3>
            <ul className="space-y-2"><li><Link href="/dashboard" className="text-sm font-medium text-primary-foreground underline-offset-4 hover:underline">Seller dashboard</Link></li><li><Link href="/auth/register" className="text-sm font-medium text-primary-foreground underline-offset-4 hover:underline">Start selling</Link></li></ul>
          </div>
        </div>
        <div className="pt-5 text-xs uppercase tracking-widest text-primary-foreground/60">© {new Date().getFullYear()} ShopiBD. All rights reserved.</div>
      </div>
    </footer>
  );
}
