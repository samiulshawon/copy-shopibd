"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useMemo, useState } from "react";
import {
  BadgePercent,
  BarChart3,
  Bell,
  Box,
  ChevronDown,
  ChevronRight,
  CircleUserRound,
  CreditCard,
  Gem,
  LayoutDashboard,
  Menu,
  Package,
  ReceiptText,
  Search,
  Settings,
  ShoppingBag,
  Store,
  UserRoundCog,
  Users,
  Wallet,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger, DialogTitle, DialogDescription } from "@/components/ui/dialog";

type Icon = React.ComponentType<{ className?: string }>;

interface NavItem {
  href: string;
  label: string;
  icon: Icon;
  match?: (pathname: string) => boolean;
}

interface NavSection {
  title: string;
  items: NavItem[];
}

const navSections: NavSection[] = [
  {
    title: "Workspace",
    items: [
      { href: "/dashboard", label: "Overview", icon: LayoutDashboard, match: (path) => path === "/dashboard" },
      { href: "/dashboard/analytics", label: "Analytics", icon: BarChart3, match: (path) => path.startsWith("/dashboard/analytics") },
    ],
  },
  {
    title: "Commerce",
    items: [
      { href: "/dashboard/orders", label: "Orders", icon: ShoppingBag, match: (path) => path.startsWith("/dashboard/orders") },
      { href: "/dashboard/products", label: "Products", icon: Package, match: (path) => path.startsWith("/dashboard/products") },
      { href: "/dashboard/customers", label: "Customers", icon: Users, match: (path) => path.startsWith("/dashboard/customers") },
      { href: "/dashboard/coupons", label: "Coupons", icon: BadgePercent, match: (path) => path.startsWith("/dashboard/coupons") },
      { href: "/dashboard/abandoned", label: "Abandoned carts", icon: Box, match: (path) => path.startsWith("/dashboard/abandoned") },
    ],
  },
  {
    title: "Business",
    items: [
      { href: "/dashboard/payments", label: "Payments", icon: Wallet, match: (path) => path.startsWith("/dashboard/payments") },
      { href: "/dashboard/subscription", label: "Subscription", icon: CreditCard, match: (path) => path.startsWith("/dashboard/subscription") },
      { href: "/dashboard/branding", label: "Storefront", icon: Store, match: (path) => path.startsWith("/dashboard/branding") },
    ],
  },
  {
    title: "Account",
    items: [
      { href: "/dashboard/staff", label: "Staff", icon: UserRoundCog, match: (path) => path.startsWith("/dashboard/staff") },
      { href: "/dashboard/notifications", label: "Notifications", icon: Bell, match: (path) => path.startsWith("/dashboard/notifications") },
      { href: "/dashboard/settings", label: "Settings", icon: Settings, match: (path) => path.startsWith("/dashboard/settings") },
    ],
  },
];

const mobileTabs: NavItem[] = [
  { href: "/dashboard", label: "Home", icon: LayoutDashboard, match: (path) => path === "/dashboard" || path.startsWith("/dashboard/analytics") },
  { href: "/dashboard/orders", label: "Orders", icon: ShoppingBag, match: (path) => path.startsWith("/dashboard/orders") },
  { href: "/dashboard/products", label: "Products", icon: Package, match: (path) => path.startsWith("/dashboard/products") },
  { href: "/dashboard/payments", label: "Payments", icon: Wallet, match: (path) => path.startsWith("/dashboard/payments") },
];

const pageTitles: Record<string, string> = {
  "/dashboard": "Overview",
  "/dashboard/analytics": "Analytics",
  "/dashboard/orders": "Orders",
  "/dashboard/products": "Products",
  "/dashboard/products/new": "Add product",
  "/dashboard/customers": "Customers",
  "/dashboard/coupons": "Coupons",
  "/dashboard/abandoned": "Abandoned carts",
  "/dashboard/payments": "Payments",
  "/dashboard/subscription": "Subscription",
  "/dashboard/branding": "Storefront",
  "/dashboard/staff": "Staff",
  "/dashboard/notifications": "Notifications",
  "/dashboard/settings": "Settings",
};

function isActive(pathname: string, item: NavItem) {
  return item.match ? item.match(pathname) : pathname === item.href || pathname.startsWith(`${item.href}/`);
}

function getPageTitle(pathname: string) {
  if (pageTitles[pathname]) return pageTitles[pathname];
  if (pathname.startsWith("/dashboard/orders/")) return "Order details";
  if (pathname.startsWith("/dashboard/products/")) return "Edit product";
  return "Merchant console";
}

function initials(name?: string | null) {
  return (name || "ShopiBD").split(" ").filter(Boolean).slice(0, 2).map((part) => part[0]).join("").toUpperCase();
}

function MerchantBrand({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/dashboard" className="flex items-center gap-3 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring">
      <span className="flex size-10 items-center justify-center border border-primary/30 bg-primary/10 text-sm font-bold tracking-tight text-primary">SB</span>
      {!compact ? <span className="min-w-0"><span className="block text-sm font-semibold tracking-tight text-foreground">ShopiBD</span><span className="block text-[11px] font-medium uppercase tracking-widest text-muted-foreground">Merchant console</span></span> : null}
    </Link>
  );
}

function NavContent({ pathname, onNavigate }: { pathname: string; onNavigate?: () => void }) {
  return (
    <nav aria-label="Merchant navigation" className="space-y-6">
      {navSections.map((section) => (
        <section key={section.title} className="space-y-2">
          <p className="px-3 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">{section.title}</p>
          <div className="space-y-1">
            {section.items.map((item) => {
              const active = isActive(pathname, item);
              const Icon = item.icon;
              return <Link key={item.href} href={item.href} onClick={onNavigate} aria-current={active ? "page" : undefined} className={cn("group relative flex min-h-10 items-center gap-3 px-3 py-2 text-sm font-medium transition-[background-color,color] duration-200 ease-premium focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring", active ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-muted hover:text-foreground")}>
                {active ? <span className="animate-fade-in absolute left-0 top-1/2 h-6 w-1 -translate-y-1/2 bg-primary" /> : null}
                <span className={cn("flex h-7 w-7 items-center justify-center transition-colors", active ? "bg-primary/12 text-primary" : "text-muted-foreground group-hover:bg-secondary group-hover:text-foreground")}><Icon className="size-4" /></span>
                <span className="min-w-0 flex-1 truncate">{item.label}</span>
                {active ? <ChevronRight className="size-3.5 text-primary" /> : null}
              </Link>;
            })}
          </div>
        </section>
      ))}
    </nav>
  );
}

function MerchantContext({ sellerName, plan }: { sellerName?: string; plan?: string }) {
  return <Link href="/dashboard/branding" className="block border border-border bg-muted p-3 transition-colors hover:border-primary/30 hover:bg-muted focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"><div className="flex items-center gap-3"><span className="flex size-9 items-center justify-center border border-primary/20 bg-primary/10 text-primary"><Store className="size-4" /></span><span className="min-w-0 flex-1"><span className="block truncate text-sm font-semibold text-foreground">{sellerName || "Your storefront"}</span><span className="block truncate text-xs text-muted-foreground">{plan ? `${plan} plan` : "Storefront settings"}</span></span><ChevronRight className="size-4 text-muted-foreground" /></div></Link>;
}

function AccountMenu() {
  const { user, isLoading, logout } = useAuth();
  const name = user?.name || "Merchant";

  return <DropdownMenu><DropdownMenuTrigger asChild><Button variant="ghost" className="h-auto gap-2 border border-border bg-background px-2.5 py-2 text-left hover:border-primary/30"><Avatar className="size-8 border border-primary/20"><AvatarFallback className="bg-primary/10 text-xs font-semibold text-primary">{initials(name)}</AvatarFallback></Avatar><span className="hidden min-w-0 sm:block"><span className="block max-w-32 truncate text-sm font-semibold text-foreground">{isLoading ? "Loading…" : name}</span><span className="block text-xs text-muted-foreground">Owner account</span></span><ChevronDown className="hidden size-4 text-muted-foreground sm:block" /></Button></DropdownMenuTrigger><DropdownMenuContent align="end" className="w-60"><DropdownMenuLabel><p className="truncate text-sm text-foreground">{name}</p><p className="mt-1 truncate text-xs font-normal normal-case tracking-normal text-muted-foreground">{user?.email || "Merchant account"}</p></DropdownMenuLabel><DropdownMenuSeparator /><DropdownMenuItem asChild><Link href="/dashboard/settings"><Settings className="mr-2 size-4" />Account settings</Link></DropdownMenuItem><DropdownMenuItem asChild><Link href="/dashboard/subscription"><Gem className="mr-2 size-4" />Subscription</Link></DropdownMenuItem><DropdownMenuSeparator /><DropdownMenuItem onSelect={() => void logout()} className="text-destructive focus:bg-destructive/10 focus:text-destructive"><CircleUserRound className="mr-2 size-4" />Sign out</DropdownMenuItem></DropdownMenuContent></DropdownMenu>;
}

function DesktopSidebar({ pathname }: { pathname: string }) {
  const { user } = useAuth();
  return <aside className="sticky top-0 hidden h-screen w-[280px] shrink-0 border-r border-border bg-background md:flex md:flex-col"><div className="border-b border-border p-5"><MerchantBrand /></div><div className="p-4"><MerchantContext sellerName={user?.name} plan={user?.plan} /></div><div className="min-h-0 flex-1 overflow-y-auto px-3 pb-5"><NavContent pathname={pathname} /></div><div className="border-t border-border p-4"><Link href="/dashboard/subscription" className="flex items-center gap-3 border border-primary/20 bg-primary/10 p-3 text-primary transition-colors hover:bg-primary/15"><ReceiptText className="size-4 shrink-0" /><span className="min-w-0"><span className="block text-xs font-semibold">Plan & usage</span><span className="block truncate text-[11px] text-primary/75">Manage your subscription</span></span></Link></div></aside>;
}

function DesktopTopbar({ pathname }: { pathname: string }) {
  const title = useMemo(() => getPageTitle(pathname), [pathname]);
  return <header className="sticky top-0 z-30 hidden border-b border-border bg-background px-6 py-3  md:block lg:px-8"><div className="flex items-center gap-4"><div className="min-w-0 flex-1"><p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Merchant workspace</p><h1 className="truncate text-base font-semibold tracking-tight text-foreground">{title}</h1></div><div className="relative hidden w-full max-w-sm xl:block"><Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" /><Input className="h-10 border-border bg-background pl-10" placeholder="Search orders, products, customers" aria-label="Search merchant data" /></div><Button variant="outline" size="icon" asChild aria-label="Notifications"><Link href="/dashboard/notifications"><Bell className="size-4" /></Link></Button><AccountMenu /></div></header>;
}

function MobileHeader({ pathname }: { pathname: string }) {
  const [open, setOpen] = useState(false);
  const { user } = useAuth();
  const title = useMemo(() => getPageTitle(pathname), [pathname]);
  return <header className="sticky top-0 z-30 border-b border-border bg-background  md:hidden"><div className="flex h-16 items-center gap-3 px-4"><Sheet open={open} onOpenChange={setOpen}><SheetTrigger asChild><Button variant="outline" size="icon" aria-label="Open merchant navigation"><Menu className="size-4" /></Button></SheetTrigger><SheetContent side="left" className="w-[88vw] max-w-sm overflow-y-auto p-0"><DialogTitle className="sr-only">Merchant navigation</DialogTitle><DialogDescription className="sr-only">Main navigation menu for the merchant dashboard.</DialogDescription><div className="border-b border-border p-5"><MerchantBrand /></div><div className="p-4"><MerchantContext sellerName={user?.name} plan={user?.plan} /></div><div className="px-3 pb-6"><NavContent pathname={pathname} onNavigate={() => setOpen(false)} /></div></SheetContent></Sheet><div className="min-w-0 flex-1"><p className="text-[10px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">Merchant</p><p className="truncate text-base font-semibold text-foreground">{title}</p></div><Button variant="ghost" size="icon" asChild aria-label="Notifications"><Link href="/dashboard/notifications"><Bell className="size-4" /></Link></Button></div></header>;
}

function MobileBottomNav({ pathname }: { pathname: string }) {
  return <nav aria-label="Primary merchant actions" className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background pb-[calc(env(safe-area-inset-bottom)+0.5rem)] pt-2  md:hidden"><div className="grid grid-cols-4 gap-1 px-3">{mobileTabs.map((item) => { const active = isActive(pathname, item); const Icon = item.icon; return <Link key={item.href} href={item.href} aria-current={active ? "page" : undefined} className={cn("flex min-h-[54px] flex-col items-center justify-center gap-1 px-2 text-[10px] font-semibold transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring", active ? "bg-secondary text-primary" : "text-muted-foreground hover:bg-muted hover:text-foreground")}><Icon className="size-4" /><span>{item.label}</span></Link>; })}</div></nav>;
}

export function DashboardShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  return <div className="min-h-screen bg-background text-foreground"><div className="flex min-h-screen"><DesktopSidebar pathname={pathname} /><div className="flex min-h-screen min-w-0 flex-1 flex-col"><MobileHeader pathname={pathname} /><DesktopTopbar pathname={pathname} /><main aria-label="Dashboard content" className="flex-1 pb-24 md:pb-0"><div className="mx-auto flex w-full max-w-[1680px] flex-col gap-6 px-4 py-5 sm:p-6 lg:px-8">{children}</div></main></div></div><MobileBottomNav pathname={pathname} /></div>;
}
