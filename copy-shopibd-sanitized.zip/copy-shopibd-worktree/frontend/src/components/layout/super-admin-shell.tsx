"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useMemo, useState } from "react";
import {
  Bell,
  Building2,
  ChevronDown,
  ChevronRight,
  CircleUserRound,
  ExternalLink,
  LayoutDashboard,
  Menu,
  ScrollText,
  Settings,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger, DialogTitle, DialogDescription } from "@/components/ui/dialog";

type Icon = React.ComponentType<{ className?: string }>;

interface NavItem {
  href: string;
  label: string;
  icon: Icon;
  match?: (pathname: string) => boolean;
}

interface NavSection {
  title: string;
  items: NavItem[];
}

const navSections: NavSection[] = [
  {
    title: "Platform",
    items: [
      {
        href: "/admin",
        label: "Dashboard",
        icon: LayoutDashboard,
        match: (path) => path === "/admin",
      },
      {
        href: "/admin/clients",
        label: "Clients",
        icon: Building2,
        match: (path) => path.startsWith("/admin/clients"),
      },
      {
        href: "/admin/activity",
        label: "Activity",
        icon: ScrollText,
        match: (path) => path.startsWith("/admin/activity"),
      },
    ],
  },
];

const mobileTabs: NavItem[] = [
  {
    href: "/admin",
    label: "Dashboard",
    icon: LayoutDashboard,
    match: (path) => path === "/admin",
  },
  {
    href: "/admin/clients",
    label: "Clients",
    icon: Building2,
    match: (path) => path.startsWith("/admin/clients"),
  },
];

const pageTitles: Record<string, string> = {
  "/admin": "Dashboard",
  "/admin/clients": "Clients",
  "/admin/activity": "Activity logs",
};

function isActive(pathname: string, item: NavItem) {
  return item.match ? item.match(pathname) : pathname === item.href || pathname.startsWith(`${item.href}/`);
}

function getPageTitle(pathname: string) {
  if (pageTitles[pathname]) return pageTitles[pathname];
  if (pathname.startsWith("/admin/clients/") && pathname === "/admin/clients/new") return "New client";
  if (pathname.startsWith("/admin/clients/")) return "Client details";
  return "Owner console";
}

function initials(name?: string | null) {
  return (name || "ShopiBD").split(" ").filter(Boolean).slice(0, 2).map((part) => part[0]).join("").toUpperCase();
}

function OwnerBrand() {
  return (
    <Link href="/admin" className="flex items-center gap-3 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring">
      <span className="flex size-10 items-center justify-center border border-primary/30 bg-primary/10 text-sm font-bold tracking-tight text-primary ">SB</span>
      <span className="min-w-0">
        <span className="block text-sm font-semibold tracking-tight text-foreground">ShopiBD</span>
        <span className="block text-[11px] font-medium uppercase tracking-widest text-muted-foreground">Owner console</span>
      </span>
    </Link>
  );
}

function NavContent({ pathname, onNavigate }: { pathname: string; onNavigate?: () => void }) {
  return (
    <nav aria-label="Owner navigation" className="space-y-6">
      {navSections.map((section) => (
        <section key={section.title} className="space-y-2">
          <p className="px-3 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">{section.title}</p>
          <div className="space-y-1">
            {section.items.map((item) => {
              const active = isActive(pathname, item);
              const Icon = item.icon;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={onNavigate}
                  aria-current={active ? "page" : undefined}
                  className={cn(
                    "group relative flex min-h-10 items-center gap-3 px-3 py-2 text-sm font-medium transition-[background-color,color] duration-200 ease-premium focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring",
                    active ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-muted hover:text-foreground",
                  )}
                >
                  {active ? <span className="absolute left-0 top-1/2 h-5 w-0.5 -translate-y-1/2 bg-primary" /> : null}
                  <span className={cn("flex h-7 w-7 items-center justify-center transition-colors", active ? "bg-primary/12 text-primary" : "text-muted-foreground group-hover:bg-secondary group-hover:text-foreground")}>
                    <Icon className="size-4" />
                  </span>
                  <span className="min-w-0 flex-1 truncate">{item.label}</span>
                  {active ? <ChevronRight className="size-3.5 text-primary" /> : null}
                </Link>
              );
            })}
          </div>
        </section>
      ))}
    </nav>
  );
}

function AccountMenu() {
  const { user, isLoading, logout } = useAuth();
  const name = user?.name || "Owner";

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="h-auto gap-2 border border-border bg-background px-2.5 py-2 text-left hover:border-primary/30">
          <Avatar className="size-8 border border-primary/20">
            <AvatarFallback className="bg-primary/10 text-xs font-semibold text-primary">{initials(name)}</AvatarFallback>
          </Avatar>
          <span className="hidden min-w-0 sm:block">
            <span className="block max-w-32 truncate text-sm font-semibold text-foreground">{isLoading ? "Loading..." : name}</span>
            <span className="block text-xs text-muted-foreground">Owner account</span>
          </span>
          <ChevronDown className="hidden size-4 text-muted-foreground sm:block" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-60">
        <DropdownMenuLabel>
          <p className="truncate text-sm text-foreground">{name}</p>
          <p className="mt-1 truncate text-xs font-normal normal-case tracking-normal text-muted-foreground">{user?.email || "Owner account"}</p>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <Link href="/admin/settings"><Settings className="mr-2 size-4" />Settings</Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <Link href="http://localhost:8000/admin" target="_blank" rel="noopener noreferrer"><ExternalLink className="mr-2 size-4" />SQLAdmin Panel</Link>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onSelect={() => void logout()} className="text-destructive focus:bg-destructive/10 focus:text-destructive">
          <CircleUserRound className="mr-2 size-4" />Sign out
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function DesktopSidebar({ pathname }: { pathname: string }) {
  return (
    <aside className="sticky top-0 hidden h-screen w-[280px] shrink-0 border-r border-border bg-background md:flex md:flex-col">
      <div className="border-b border-border p-5">
        <OwnerBrand />
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto px-3 py-4">
        <NavContent pathname={pathname} />
      </div>
      <div className="border-t border-border p-4">
        <Link
          href="http://localhost:8000/admin"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-3 border border-border bg-muted p-3 text-muted-foreground transition-colors hover:border-primary/30 hover:text-foreground"
        >
          <ExternalLink className="size-4 shrink-0" />
          <span className="min-w-0">
            <span className="block text-xs font-semibold">SQLAdmin Panel</span>
            <span className="block truncate text-[11px]">Direct database access</span>
          </span>
        </Link>
      </div>
    </aside>
  );
}

function DesktopTopbar({ pathname }: { pathname: string }) {
  const title = useMemo(() => getPageTitle(pathname), [pathname]);
  return (
    <header className="sticky top-0 z-30 hidden border-b border-border bg-background px-6 py-3  md:block lg:px-8">
      <div className="flex items-center gap-4">
        <div className="min-w-0 flex-1">
          <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Platform owner</p>
          <h1 className="truncate text-base font-semibold tracking-tight text-foreground">{title}</h1>
        </div>
        <Button variant="outline" size="icon" asChild aria-label="Notifications">
          <Link href="/dashboard/notifications"><Bell className="size-4" /></Link>
        </Button>
        <AccountMenu />
      </div>
    </header>
  );
}

function MobileHeader({ pathname }: { pathname: string }) {
  const [open, setOpen] = useState(false);
  const title = useMemo(() => getPageTitle(pathname), [pathname]);
  return (
    <header className="sticky top-0 z-30 border-b border-border bg-background  md:hidden">
      <div className="flex h-16 items-center gap-3 px-4">
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" aria-label="Open owner navigation">
              <Menu className="size-4" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[88vw] max-w-sm overflow-y-auto p-0">
            <DialogTitle className="sr-only">Owner navigation</DialogTitle>
            <DialogDescription className="sr-only">Main navigation menu for the platform owner console.</DialogDescription>
            <div className="border-b border-border p-5"><OwnerBrand /></div>
            <div className="px-3 pb-6"><NavContent pathname={pathname} onNavigate={() => setOpen(false)} /></div>
          </SheetContent>
        </Sheet>
        <div className="min-w-0 flex-1">
          <p className="text-[10px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">Platform</p>
          <p className="truncate text-base font-semibold text-foreground">{title}</p>
        </div>
        <Button variant="ghost" size="icon" asChild aria-label="Notifications">
          <Link href="/dashboard/notifications"><Bell className="size-4" /></Link>
        </Button>
      </div>
    </header>
  );
}

function MobileBottomNav({ pathname }: { pathname: string }) {
  return (
    <nav aria-label="Primary owner actions" className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background pb-[calc(env(safe-area-inset-bottom)+0.5rem)] pt-2  md:hidden">
      <div className="grid grid-cols-2 gap-1 px-3">
        {mobileTabs.map((item) => {
          const active = isActive(pathname, item);
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              aria-current={active ? "page" : undefined}
              className={cn(
                "flex min-h-[54px] flex-col items-center justify-center gap-1 px-2 text-[10px] font-semibold transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring",
                active ? "bg-secondary text-primary" : "text-muted-foreground hover:bg-muted hover:text-foreground",
              )}
            >
              <Icon className="size-4" />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

export function SuperAdminShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="flex min-h-screen">
        <DesktopSidebar pathname={pathname} />
        <div className="flex min-h-screen min-w-0 flex-1 flex-col">
          <MobileHeader pathname={pathname} />
          <DesktopTopbar pathname={pathname} />
          <main aria-label="Owner console content" className="flex-1 pb-24 md:pb-0">
            <div className="mx-auto flex w-full max-w-[1680px] flex-col gap-6 px-4 py-5 sm:p-6 lg:px-8">{children}</div>
          </main>
        </div>
      </div>
      <MobileBottomNav pathname={pathname} />
    </div>
  );
}