"use client";

import { useEffect, useState } from "react";

const MESSAGES = [
  "Launch your ShopiBD storefront and start taking direct orders.",
  "Configure delivery, payments, products, and merchant operations in one place.",
];

export function PromotionStrip() {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (paused || reducedMotion) return;

    const timer = window.setInterval(() => setIndex((current) => (current + 1) % MESSAGES.length), 6000);
    return () => window.clearInterval(timer);
  }, [paused]);

  return (
    <aside className="border-b border-foreground bg-foreground px-4 py-2 text-center text-[11px] font-semibold uppercase tracking-[0.08em] text-primary-foreground" aria-label="ShopiBD announcements">
      <span aria-live="polite">{MESSAGES[index]}</span>
      <button type="button" className="ml-3 underline underline-offset-2 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-foreground" onClick={() => setPaused((current) => !current)} aria-pressed={paused}>
        {paused ? "Play" : "Pause"}
      </button>
    </aside>
  );
}
