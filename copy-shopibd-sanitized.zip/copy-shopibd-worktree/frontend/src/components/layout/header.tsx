"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { Menu } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { useMobile } from "@/hooks/use-mobile";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger, DialogTitle, DialogDescription } from "@/components/ui/dialog";

const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/pricing", label: "Pricing" },
  { href: "/auth/register", label: "Open a Shop" },
];

export function Header() {
  const pathname = usePathname();
  const { user, isAuthenticated, logout, isLoading } = useAuth();
  const isMobile = useMobile();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-foreground bg-background">
      <div className="container-bd flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-2 text-xl font-bold tracking-tight focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring">
          <span>ShopiBD</span>
        </Link>

        {!isMobile && (
          <nav aria-label="Public navigation" className="flex items-center gap-6">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "border-b-2 border-transparent py-1 text-sm font-semibold uppercase tracking-[0.08em] transition-colors hover:border-foreground hover:text-foreground",
                  pathname === link.href ? "border-foreground text-foreground" : "text-muted-foreground",
                )}
              >
                {link.label}
              </Link>
            ))}
          </nav>
        )}

        <div className="flex items-center gap-2">
          {isLoading ? (
            <div className="size-8 border border-border bg-muted" aria-label="Loading account" />
          ) : isAuthenticated && user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="size-9" data-testid="user-menu" aria-label="Open account menu">
                  <Avatar className="size-8">
                    <AvatarImage src="" alt={user.name} />
                    <AvatarFallback>{user.name?.charAt(0)?.toUpperCase() || "U"}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1"><p className="text-sm font-medium leading-none">{user.name}</p><p className="text-xs leading-none text-muted-foreground">{user.phone}</p></div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild><Link href="/dashboard">Dashboard</Link></DropdownMenuItem>
                <DropdownMenuItem asChild><Link href="/dashboard/settings">Settings</Link></DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={logout}>Logout</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" asChild><Link href="/auth/login">Sign In</Link></Button>
              <Button size="sm" asChild><Link href="/auth/register">Get Started</Link></Button>
            </div>
          )}

          {isMobile && (
            <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
              <SheetTrigger asChild><Button variant="outline" size="icon" aria-label="Open menu"><Menu className="size-5" /></Button></SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                <DialogTitle className="sr-only">Site menu</DialogTitle>
                <DialogDescription className="sr-only">Public site navigation menu.</DialogDescription>
                <nav aria-label="Mobile public navigation" className="mt-8 flex flex-col border-t border-border">
                  {NAV_LINKS.map((link) => (
                    <Link key={link.href} href={link.href} onClick={() => setMobileOpen(false)} className={cn("border-b border-border px-1 py-4 text-base font-semibold uppercase tracking-[0.08em]", pathname === link.href ? "text-foreground" : "text-muted-foreground")}>
                      {link.label}
                    </Link>
                  ))}
                  {isAuthenticated ? <Link href="/dashboard" onClick={() => setMobileOpen(false)} className="border-b border-border px-1 py-4 text-base font-semibold uppercase tracking-[0.08em]">Dashboard</Link> : null}
                </nav>
              </SheetContent>
            </Sheet>
          )}
        </div>
      </div>
    </header>
  );
}
