"use client";

import React, { useCallback, useEffect, useState } from "react";
import { deliveryApi, settingsApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import type { Shop, DeliverySettings, DeliveryArea } from "@/types/shop";
import type { CourierProvider } from "@/types/delivery";
import {
  SectionDescription,
  SectionHeader,
  SectionTitle,
  SurfaceSection,
} from "@/components/layout/page-structure";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface DeliverySettingsFormProps {
  shop: Shop;
  onSuccess: () => void;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function parseDeliverySettings(shop: Shop): DeliverySettings {
  const raw = (shop as any).delivery_settings;
  if (raw && typeof raw === "object") {
    return {
      areas: Array.isArray(raw.areas) ? raw.areas : [],
      fee: typeof raw.fee === "number" ? raw.fee : 0,
      free_threshold:
        typeof raw.free_threshold === "number" ? raw.free_threshold : 0,
      default_courier:
        typeof raw.default_courier === "string" ? raw.default_courier : "manual",
      pickup_address:
        typeof raw.pickup_address === "string" ? raw.pickup_address : "",
      cod_enabled:
        typeof raw.cod_enabled === "boolean" ? raw.cod_enabled : true,
    };
  }
  return {
    areas: [],
    fee: 0,
    free_threshold: 0,
    default_courier: "manual",
    pickup_address: "",
    cod_enabled: true,
  };
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export function DeliverySettingsForm({
  shop,
  onSuccess,
}: DeliverySettingsFormProps) {
  const { toast } = useToast();
  const initialSettings = parseDeliverySettings(shop);

  const [settings, setSettings] = useState<DeliverySettings>(initialSettings);
  const [saving, setSaving] = useState(false);
  const [couriers, setCouriers] = useState<CourierProvider[]>([]);

  useEffect(() => {
    deliveryApi
      .listCouriers()
      .then((res) => setCouriers(res.data.couriers))
      .catch(() => {
        setCouriers([
          { name: "Steadfast", value: "steadfast" },
          { name: "eCourier", value: "ecourier" },
          { name: "Pathao", value: "pathao" },
          { name: "Redx", value: "redx" },
          { name: "Manual", value: "manual" },
        ]);
      });
  }, []);

  // -------------------------------------------------------------------------
  // Handlers
  // -------------------------------------------------------------------------

  const handleFeeChange = useCallback((value: string) => {
    const num = parseFloat(value) || 0;
    setSettings((prev) => ({ ...prev, fee: num }));
  }, []);

  const handleFreeThresholdChange = useCallback((value: string) => {
    const num = parseFloat(value) || 0;
    setSettings((prev) => ({ ...prev, free_threshold: num }));
  }, []);

  const handleAreaNameChange = useCallback(
    (index: number, value: string) => {
      setSettings((prev) => {
        const areas = [...prev.areas];
        areas[index] = { ...areas[index], name: value };
        return { ...prev, areas };
      });
    },
    [],
  );

  const handleAreaFeeChange = useCallback(
    (index: number, value: string) => {
      const num = parseFloat(value) || 0;
      setSettings((prev) => {
        const areas = [...prev.areas];
        areas[index] = { ...areas[index], fee: num };
        return { ...prev, areas };
      });
    },
    [],
  );

  const addArea = useCallback(() => {
    setSettings((prev) => ({
      ...prev,
      areas: [...prev.areas, { name: "", fee: 0 }],
    }));
  }, []);

  const removeArea = useCallback((index: number) => {
    setSettings((prev) => ({
      ...prev,
      areas: prev.areas.filter((_, i) => i !== index),
    }));
  }, []);

  const handleSubmit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();

      const validAreas = settings.areas.filter((a) => a.name.trim());

      const payload = {
        delivery_settings: {
          areas: validAreas,
          fee: settings.fee,
          free_threshold: settings.free_threshold,
          default_courier: settings.default_courier || "manual",
          pickup_address: settings.pickup_address || "",
          cod_enabled: settings.cod_enabled,
        },
      };

      setSaving(true);
      try {
        await settingsApi.updateSettings(payload);
        toast({
          message: "Delivery settings updated successfully",
          variant: "success",
        });
        onSuccess();
      } catch (err: any) {
        const message =
          err?.response?.data?.detail ||
          err?.message ||
          "Failed to update delivery settings";
        toast({
          message,
          variant: "error",
        });
      } finally {
        setSaving(false);
      }
    },
    [settings, onSuccess, toast],
  );

  // -------------------------------------------------------------------------
  // Render
  // -------------------------------------------------------------------------

  return (
    <SurfaceSection>
      <SectionHeader>
        <div>
          <SectionTitle>Delivery Settings</SectionTitle>
          <SectionDescription>
            Configure courier provider, pickup address, COD options, delivery areas, and fees.
          </SectionDescription>
        </div>
      </SectionHeader>
      <form onSubmit={handleSubmit}>
        <div className="mt-4 space-y-6">
          {/* ---------- Default Courier ---------- */}
          <div className="space-y-2">
            <label
              htmlFor="default-courier"
              className="text-sm font-medium leading-none"
            >
              Default Courier Provider
            </label>
            <select
              id="default-courier"
              value={settings.default_courier || "manual"}
              onChange={(e) =>
                setSettings((prev) => ({
                  ...prev,
                  default_courier: e.target.value,
                }))
              }
              className="flex h-10 w-full border border-border bg-muted px-3 py-2 text-sm text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
              disabled={saving}
            >
              {couriers.map((c) => (
                <option key={c.value} value={c.value}>
                  {c.name}
                </option>
              ))}
            </select>
            <p className="text-xs text-muted-foreground">
              Default courier used when creating shipments from orders.
            </p>
          </div>

          {/* ---------- Pickup Address ---------- */}
          <div className="space-y-2">
            <label
              htmlFor="pickup-address"
              className="text-sm font-medium leading-none"
            >
              Default Pickup Address
            </label>
            <textarea
              id="pickup-address"
              value={settings.pickup_address || ""}
              onChange={(e) =>
                setSettings((prev) => ({
                  ...prev,
                  pickup_address: e.target.value,
                }))
              }
              className="flex min-h-[80px] w-full border border-border bg-muted px-3 py-2 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
              placeholder="Your shop's pickup address for courier collection"
              disabled={saving}
            />
            <p className="text-xs text-muted-foreground">
              This address will be pre-filled when creating a new shipment.
            </p>
          </div>

          {/* ---------- COD Settings ---------- */}
          <div className="space-y-2">
            <label className="text-sm font-medium leading-none">
              Cash on Delivery (COD)
            </label>
            <div className="mt-1 flex items-center gap-3">
              <label className="flex cursor-pointer items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={settings.cod_enabled ?? true}
                  onChange={(e) =>
                    setSettings((prev) => ({
                      ...prev,
                      cod_enabled: e.target.checked,
                    }))
                  }
                  disabled={saving}
                  className="size-4 border-border text-primary focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-ring"
                />
                Enable COD for this shop
              </label>
            </div>
            <p className="text-xs text-muted-foreground">
              When enabled, the COD amount will be pre-filled from the order total when creating shipments.
            </p>
          </div>

          <hr className="border-t border-border" />

          {/* ---------- Default Delivery Fee ---------- */}
          <div className="space-y-2">
            <label
              htmlFor="delivery-fee"
              className="text-sm font-medium leading-none"
            >
              Default Delivery Fee (BDT)
            </label>
            <Input
              id="delivery-fee"
              type="number"
              min="0"
              step="0.5"
              value={settings.fee}
              onChange={(e) => handleFeeChange(e.target.value)}
              placeholder="60"
              disabled={saving}
              className="bg-muted"
            />
            <p className="text-xs text-muted-foreground">
              Standard delivery charge for orders.
            </p>
          </div>

          {/* ---------- Free Delivery Threshold ---------- */}
          <div className="space-y-2">
            <label
              htmlFor="free-threshold"
              className="text-sm font-medium leading-none"
            >
              Free Delivery Threshold (BDT)
            </label>
            <Input
              id="free-threshold"
              type="number"
              min="0"
              step="10"
              value={settings.free_threshold}
              onChange={(e) => handleFreeThresholdChange(e.target.value)}
              placeholder="500"
              disabled={saving}
              className="bg-muted"
            />
            <p className="text-xs text-muted-foreground">
              Orders above this amount get free delivery. Set to 0 to disable.
            </p>
          </div>

          {/* ---------- Delivery Areas ---------- */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium leading-none">
                Delivery Areas
              </label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addArea}
                disabled={saving}
              >
                + Add Area
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Define specific areas and their delivery fees.
            </p>

            {settings.areas.length === 0 && (
              <p className="text-sm italic text-muted-foreground">
                No delivery areas defined yet. Click &quot;+ Add Area&quot; to add one.
              </p>
            )}

            {settings.areas.map((area, index) => (
              <div
                key={index}
                className="flex flex-col gap-2 border border-border bg-muted p-3 sm:flex-row"
              >
                <div className="flex-1 space-y-1">
                  <label className="text-xs text-muted-foreground">
                    Area Name
                  </label>
                  <Input
                    value={area.name}
                    onChange={(e) =>
                      handleAreaNameChange(index, e.target.value)
                    }
                    placeholder="e.g., Dhaka, Chattogram"
                    disabled={saving}
                    className="bg-background"
                  />
                </div>
                <div className="w-full space-y-1 sm:w-32">
                  <label className="text-xs text-muted-foreground">
                    Fee (BDT)
                  </label>
                  <Input
                    type="number"
                    min="0"
                    step="0.5"
                    value={area.fee}
                    onChange={(e) =>
                      handleAreaFeeChange(index, e.target.value)
                    }
                    placeholder="60"
                    disabled={saving}
                    className="bg-background"
                  />
                </div>
                <div className="flex items-end pb-1">
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => removeArea(index)}
                    disabled={saving}
                    className="text-destructive hover:text-destructive"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="size-4"
                    >
                      <path d="M3 6h18" />
                      <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                      <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                    </svg>
                    <span className="sr-only">Remove area</span>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-6 flex justify-end gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => {
              setSettings(initialSettings);
            }}
            disabled={saving}
          >
            Reset
          </Button>
          <Button type="submit" disabled={saving}>
            {saving ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </form>
    </SurfaceSection>
  );
}