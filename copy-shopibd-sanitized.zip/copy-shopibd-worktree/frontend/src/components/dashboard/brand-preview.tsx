"use client";

import React from "react";
import type { BrandingSettings } from "@/types/whitelabel";

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

interface BrandPreviewProps {
  branding: BrandingSettings;
  hideBranding: boolean;
  shopName?: string;
}

// ---------------------------------------------------------------------------
// Default branding
// ---------------------------------------------------------------------------

const DEFAULT_BRANDING: BrandingSettings = {
  primary_color: "#1a73e8",
  secondary_color: "#34a853",
  font_family: "Inter, sans-serif",
  logo_url: null,
  favicon_url: null,
  custom_css: null,
};

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export default function BrandPreview({
  branding,
  hideBranding,
  shopName = "Your Shop",
}: BrandPreviewProps) {
  const b = { ...DEFAULT_BRANDING, ...branding };

  return (
    <div className="overflow-hidden border border-border bg-background ">
      {/* Mock browser chrome */}
      <div className="flex items-center gap-2 border-b border-border bg-muted px-4 py-2">
        <div className="flex gap-1.5">
          <div className="size-3 bg-red-400" />
          <div className="size-3 bg-yellow-400" />
          <div className="size-3 bg-green-400" />
        </div>
        <div className="mx-4 flex-1">
          <div
            className="truncate border border-border bg-background px-2 py-1 text-center text-xs text-muted-foreground"
            style={{ fontFamily: b.font_family }}
          >
            {shopName.toLowerCase().replace(/\s+/g, "-")}.shopibd.com
          </div>
        </div>
      </div>

      {/* Mock storefront */}
      <div
        className="flex min-h-[300px] flex-col"
        style={{ fontFamily: b.font_family }}
      >
        {/* Header */}
        <header
          className="flex items-center justify-between px-6 py-4"
          style={{ backgroundColor: "#111111", color: "#f0ece6", borderBottom: `1px solid ${b.primary_color}55` }}
        >
          <div className="flex items-center gap-3">
            {b.logo_url ? (
              <img
                src={b.logo_url}
                alt="Logo"
                className="size-8 bg-background object-contain"
              />
            ) : (
              <div className="flex size-8 items-center justify-center bg-background/10 text-sm font-bold">
                {shopName.charAt(0)}
              </div>
            )}
            <span className="text-lg font-semibold">{shopName}</span>
          </div>
          <nav className="flex gap-4 text-sm">
            <span className="cursor-default opacity-90 hover:opacity-100">
              Home
            </span>
            <span className="cursor-default opacity-90 hover:opacity-100">
              Shop
            </span>
            <span className="cursor-default opacity-90 hover:opacity-100">
              Contact
            </span>
          </nav>
        </header>

        {/* Hero / Banner */}
        <div
          className="px-6 py-8 text-center"
          style={{ backgroundColor: b.secondary_color + "15" }}
        >
          <h2
            className="mb-2 text-2xl font-bold"
            style={{ color: b.primary_color }}
          >
            Welcome to {shopName}
          </h2>
          <p className="mx-auto max-w-md text-sm text-muted-foreground">
            Discover amazing products at great prices. Your one-stop shop for
            everything you need.
          </p>
          <button
            className="mt-4 px-6 py-2 text-sm font-medium text-white transition-opacity hover:opacity-90"
            style={{ backgroundColor: b.primary_color }}
          >
            Shop Now
          </button>
        </div>

        {/* Product Grid (mock) */}
        <div className="flex-1 p-6">
          <div className="grid grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="border border-border p-3 text-center"
              >
                <div
                  className="mb-2 h-20"
                  style={{ backgroundColor: b.primary_color + "15" }}
                />
                <div
                  className="mx-auto mb-1 h-3 w-3/4"
                  style={{ backgroundColor: b.primary_color + "30" }}
                />
                <div
                  className="mx-auto h-3 w-1/2"
                  style={{ backgroundColor: b.secondary_color + "40" }}
                />
              </div>
            ))}
          </div>
        </div>

        {/* Footer / Powered by */}
        {!hideBranding && (
          <footer className="border-t border-border px-6 py-3 text-center text-xs text-muted-foreground">
            Powered by <span style={{ color: b.primary_color }}>ShopiBD</span>
          </footer>
        )}
      </div>
    </div>
  );
}
