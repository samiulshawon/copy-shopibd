import * as React from "react";
import { Circle } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export type OrderStatus = "pending" | "confirmed" | "shipped" | "delivered" | "cancelled";

interface StatusBadgeProps extends React.HTMLAttributes<HTMLDivElement> { status: OrderStatus | string; }

const STATUS_CONFIG: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" | "success" | "warning" | "info" }> = {
  pending: { label: "Pending", variant: "warning" },
  confirmed: { label: "Confirmed", variant: "info" },
  shipped: { label: "Shipped", variant: "info" },
  delivered: { label: "Delivered", variant: "success" },
  cancelled: { label: "Cancelled", variant: "destructive" },
};

export function StatusBadge({ status, className, ...props }: StatusBadgeProps) {
  const normalized = String(status).toLowerCase();
  const config = STATUS_CONFIG[normalized] || { label: String(status), variant: "secondary" as const };
  return <Badge variant={config.variant} className={`gap-1.5 ${className || ""}`} {...props}><Circle className="size-1.5 fill-current" />{config.label}</Badge>;
}
