"use client";

import React, { useCallback, useState } from "react";
import { settingsApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import type { Shop } from "@/types/shop";
import {
  SectionDescription,
  SectionHeader,
  SectionTitle,
  SurfaceSection,
} from "@/components/layout/page-structure";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface PaymentMethodsFormProps {
  shop: Shop;
  onSuccess: () => void;
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export function PaymentMethodsForm({ shop, onSuccess }: PaymentMethodsFormProps) {
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    bkash_number: shop.bkash_number || "",
    nagad_number: shop.nagad_number || "",
    rocket_number: (shop as any).rocket_number || "",
  });

  const [saving, setSaving] = useState(false);

  // -------------------------------------------------------------------------
  // Handlers
  // -------------------------------------------------------------------------

  const handleChange = useCallback(
    (field: string, value: string) => {
      setFormData((prev) => ({ ...prev, [field]: value }));
    },
    [],
  );

  const handleSubmit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();

      const payload: Record<string, string | null> = {};
      if (formData.bkash_number !== (shop.bkash_number || ""))
        payload.bkash_number = formData.bkash_number || null;
      if (formData.nagad_number !== (shop.nagad_number || ""))
        payload.nagad_number = formData.nagad_number || null;
      if (formData.rocket_number !== ((shop as any).rocket_number || ""))
        payload.rocket_number = formData.rocket_number || null;

      if (Object.keys(payload).length === 0) {
        toast({
          message: "No changes to save",
          variant: "info",
        });
        return;
      }

      setSaving(true);
      try {
        await settingsApi.updateSettings(payload);
        toast({
          message: "Payment methods updated successfully",
          variant: "success",
        });
        onSuccess();
      } catch (err: any) {
        const message =
          err?.response?.data?.detail ||
          err?.message ||
          "Failed to update payment methods";
        toast({
          message,
          variant: "error",
        });
      } finally {
        setSaving(false);
      }
    },
    [formData, shop, onSuccess, toast],
  );

  // -------------------------------------------------------------------------
  // Render
  // -------------------------------------------------------------------------

  return (
    <SurfaceSection>
      <SectionHeader>
        <div>
          <SectionTitle>Payment Methods</SectionTitle>
          <SectionDescription>
            Configure the mobile payment numbers your customers can use to pay.
          </SectionDescription>
        </div>
      </SectionHeader>
      <form onSubmit={handleSubmit}>
        <div className="mt-4 space-y-4">
          {/* bKash */}
          <div className="space-y-2">
            <label
              htmlFor="bkash-number"
              className="text-sm font-medium leading-none"
            >
              bKash Number
            </label>
            <Input
              id="bkash-number"
              value={formData.bkash_number}
              onChange={(e) => handleChange("bkash_number", e.target.value)}
              placeholder="01XXXXXXXXX"
              disabled={saving}
              className="bg-muted"
            />
            <p className="text-xs text-muted-foreground">
              Your bKash merchant or personal number
            </p>
          </div>

          {/* Nagad */}
          <div className="space-y-2">
            <label
              htmlFor="nagad-number"
              className="text-sm font-medium leading-none"
            >
              Nagad Number
            </label>
            <Input
              id="nagad-number"
              value={formData.nagad_number}
              onChange={(e) => handleChange("nagad_number", e.target.value)}
              placeholder="01XXXXXXXXX"
              disabled={saving}
              className="bg-muted"
            />
            <p className="text-xs text-muted-foreground">
              Your Nagad merchant or personal number
            </p>
          </div>

          {/* Rocket */}
          <div className="space-y-2">
            <label
              htmlFor="rocket-number"
              className="text-sm font-medium leading-none"
            >
              Rocket Number
            </label>
            <Input
              id="rocket-number"
              value={formData.rocket_number}
              onChange={(e) => handleChange("rocket_number", e.target.value)}
              placeholder="01XXXXXXXXX"
              disabled={saving}
              className="bg-muted"
            />
            <p className="text-xs text-muted-foreground">
              Your Rocket (DBBL) merchant or personal number
            </p>
          </div>
        </div>

        <div className="mt-6 flex justify-end gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => {
              setFormData({
                bkash_number: shop.bkash_number || "",
                nagad_number: shop.nagad_number || "",
                rocket_number: (shop as any).rocket_number || "",
              });
            }}
            disabled={saving}
          >
            Reset
          </Button>
          <Button type="submit" disabled={saving}>
            {saving ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </form>
    </SurfaceSection>
  );
}