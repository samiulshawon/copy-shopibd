"use client";

import React, { useMemo } from "react";
import { ArrowUpRight, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { cn, formatCurrency } from "@/lib/utils";
import type { SalesDataPoint } from "@/types/analytics";

interface SalesChartProps {
  data: SalesDataPoint[] | null;
  isLoading: boolean;
  error: string | null;
  onPeriodChange: (period: string) => void;
  period: string;
}

const PERIODS = [
  { value: "7d", label: "7 Days" },
  { value: "30d", label: "30 Days" },
  { value: "90d", label: "90 Days" },
];

function PeriodSelector({
  period,
  onChange,
}: {
  period: string;
  onChange: (p: string) => void;
}) {
  return (
    <div className="grid grid-cols-3 gap-2 border border-border/80 bg-muted/70 p-1.5 sm:flex sm:w-auto">
      {PERIODS.map((p) => (
        <button
          key={p.value}
          type="button"
          onClick={() => onChange(p.value)}
          className={cn(
            "px-3 py-2 text-xs font-medium transition-all duration-200 ease-premium",
            period === p.value
              ? "bg-primary text-primary-foreground"
              : "text-muted-foreground hover:bg-background hover:text-foreground",
          )}
        >
          {p.label}
        </button>
      ))}
    </div>
  );
}

function LineChart({
  data,
  dataKey,
  height = 220,
}: {
  data: SalesDataPoint[];
  dataKey: "revenue" | "orders";
  height?: number;
}) {
  const { path, maxVal, minVal } = useMemo(() => {
    if (!data.length) return { path: "", maxVal: 0, minVal: 0 };

    const values = data.map((d) => d[dataKey]);
    const max = Math.max(...values);
    const min = Math.min(...values);
    const range = max - min || 1;

    const width = 100;
    const stepX = width / (data.length - 1 || 1);

    const points = data.map((d, i) => {
      const x = i * stepX;
      const y = ((max - d[dataKey]) / range) * height;
      return `${x},${y}`;
    });

    return {
      path: `M${points.join(" L")}`,
      maxVal: max,
      minVal: min,
    };
  }, [data, dataKey, height]);

  if (!data.length) {
    return (
      <div className="flex h-[220px] items-center justify-center border border-dashed border-border/80 bg-muted/40 text-sm text-muted-foreground">
        No data available
      </div>
    );
  }

  return (
    <div className="relative pl-10">
      <svg viewBox={`0 0 100 ${height}`} preserveAspectRatio="none" className="h-[220px] w-full overflow-visible">
        {[0, 0.25, 0.5, 0.75, 1].map((f) => (
          <line
            key={f}
            x1="0"
            y1={height * f}
            x2="100"
            y2={height * f}
            stroke="currentColor"
            className="stroke-border/70"
            strokeWidth="0.5"
          />
        ))}

        <path d={`${path} L100,${height} L0,${height} Z`} fill="hsl(var(--success) / 0.1)" />
        <path
          d={path}
          fill="none"
          stroke="hsl(var(--success))"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
          pathLength={1}
          className="animate-draw-path"
          style={{ strokeDasharray: 1, strokeDashoffset: 1 } as React.CSSProperties}
        />

        {data.map((d, i) => {
          const stepX = 100 / (data.length - 1 || 1);
          const x = i * stepX;
          const values = data.map((pt) => pt[dataKey]);
          const max = Math.max(...values);
          const min = Math.min(...values);
          const range = max - min || 1;
          const y = ((max - d[dataKey]) / range) * height;
          return <circle key={i} cx={x} cy={y} r="1.7" fill="hsl(var(--success))" className="transition-all" />;
        })}
      </svg>

      <div className="absolute left-0 top-0 flex h-[220px] flex-col justify-between text-[10px] text-muted-foreground sm:text-xs">
        <span>{dataKey === "revenue" ? formatCurrency(maxVal) : maxVal}</span>
        <span>
          {dataKey === "revenue"
            ? formatCurrency((maxVal + minVal) / 2)
            : Math.round((maxVal + minVal) / 2)}
        </span>
        <span>{dataKey === "revenue" ? formatCurrency(minVal) : minVal}</span>
      </div>
    </div>
  );
}

function SalesChartSkeleton() {
  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div className="space-y-2">
            <Skeleton className="h-6 w-40" />
            <Skeleton className="h-4 w-64" />
          </div>
          <Skeleton className="h-11 w-full sm:w-52" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_280px]">
          <Skeleton className="h-[280px] w-full" />
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-1">
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-32 w-full" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function SalesChartError({ message }: { message: string }) {
  return (
    <Card className="border-destructive/30 bg-destructive/10">
      <CardContent className="pt-6">
        <p className="text-sm text-destructive">{message}</p>
      </CardContent>
    </Card>
  );
}

export function SalesChart({
  data,
  isLoading,
  error,
  onPeriodChange,
  period,
}: SalesChartProps) {
  const summary = useMemo(() => {
    if (!data || data.length === 0) {
      return {
        totalRevenue: 0,
        totalOrders: 0,
        averageOrderValue: 0,
      };
    }

    const totalRevenue = data.reduce((sum, item) => sum + item.revenue, 0);
    const totalOrders = data.reduce((sum, item) => sum + item.orders, 0);

    return {
      totalRevenue,
      totalOrders,
      averageOrderValue: totalOrders > 0 ? totalRevenue / totalOrders : 0,
    };
  }, [data]);

  if (isLoading) return <SalesChartSkeleton />;
  if (error) return <SalesChartError message={error} />;

  return (
    <Card className="overflow-hidden">
      <CardHeader className="space-y-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="info" className="px-3 py-1">
                Performance
              </Badge>
              <Badge variant="secondary" className="px-3 py-1">
                {period === "7d" ? "Weekly pulse" : period === "30d" ? "Monthly view" : "Quarterly view"}
              </Badge>
            </div>
            <div>
              <CardTitle className="text-xl sm:text-2xl">Sales performance overview</CardTitle>
              <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">
                Track revenue momentum, order volume, and average order value without leaving the dashboard.
              </p>
            </div>
          </div>
          <PeriodSelector period={period} onChange={onPeriodChange} />
        </div>
      </CardHeader>
      <CardContent>
        {data && data.length > 0 ? (
          <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_300px]">
            <div className="border border-border/80 bg-muted/30 p-4 sm:p-5">
              <div className="mb-4 flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Revenue trend</p>
                  <p className="text-xs text-muted-foreground">Main performance signal for the selected period</p>
                </div>
                <div className="flex items-center gap-2 border border-primary/20 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                  <TrendingUp className="size-3.5" />
                  Revenue
                </div>
              </div>
              <LineChart data={data} dataKey="revenue" />
            </div>

            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-1">
              <div className="border border-border/80 bg-muted/30 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Revenue in period</p>
                    <p className="mt-2 text-2xl font-semibold tracking-tight text-foreground">
                      {formatCurrency(summary.totalRevenue)}
                    </p>
                  </div>
                  <div className="flex size-10 items-center justify-center border border-primary/20 bg-primary/10 text-primary">
                    <ArrowUpRight className="size-4" />
                  </div>
                </div>
                <p className="mt-3 text-xs leading-5 text-muted-foreground">Combined revenue from the selected range.</p>
              </div>

              <div className="border border-border/80 bg-muted/30 p-4">
                <div className="space-y-3">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Order volume</p>
                    <p className="mt-2 text-2xl font-semibold tracking-tight text-foreground">{summary.totalOrders}</p>
                  </div>
                  <div className="h-px bg-border/80" />
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Average order value</p>
                    <p className="mt-2 text-xl font-semibold tracking-tight text-foreground">
                      {formatCurrency(summary.averageOrderValue)}
                    </p>
                  </div>
                </div>
              </div>

              <div className="border border-border/80 bg-muted/30 p-4 sm:col-span-2 xl:col-span-1">
                <p className="mb-3 text-sm font-medium text-muted-foreground">Order trend</p>
                <LineChart data={data} dataKey="orders" height={160} />
              </div>
            </div>
          </div>
        ) : (
          <div className="flex h-[220px] items-center justify-center border border-dashed border-border/80 bg-muted/30 text-sm text-muted-foreground">
            No sales data available for this period
          </div>
        )}
      </CardContent>
    </Card>
  );
}
