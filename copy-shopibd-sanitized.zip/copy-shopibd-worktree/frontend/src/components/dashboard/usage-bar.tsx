"use client";

import React from "react";
import { cn } from "@/lib/utils";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface UsageBarProps {
  current: number;
  max: number;
  label: string;
  className?: string;
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export function UsageBar({ current, max, label, className }: UsageBarProps) {
  const percentage = max > 0 ? Math.min((current / max) * 100, 100) : 0;
  const isNearLimit = percentage >= 80;
  const isAtLimit = percentage >= 100;

  return (
    <div className={cn("space-y-1", className)}>
      <div className="flex items-center justify-between text-sm">
        <span className="text-muted-foreground">{label}</span>
        <span
          className={cn(
            "font-medium",
            isAtLimit && "text-destructive",
            isNearLimit && !isAtLimit && "text-warning",
          )}
        >
          {current} / {max}
        </span>
      </div>
      <div className="h-2 w-full bg-muted">
        <div
          className={cn(
            "h-full transition-all duration-300",
            isAtLimit
              ? "bg-destructive"
              : isNearLimit
                ? "bg-warning"
                : "bg-primary",
          )}
          style={{ width: `${Math.min(percentage, 100)}%` }}
        />
      </div>
    </div>
  );
}