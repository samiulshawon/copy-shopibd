"use client";

import React from "react";
import { ArrowRight, ArrowUpRight, Clock3, Package, ShoppingBag, Wallet } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import type { DashboardStats } from "@/types/analytics";
import { MetricCard, MetricStrip } from "@/components/layout/page-structure";

interface StatsCardsProps {
  data: DashboardStats | null;
  isLoading: boolean;
  error: string | null;
}

interface StatItem {
  label: string;
  value: number;
  helper: string;
  icon: React.ComponentType<{ className?: string }>;
  tone?: "default" | "danger" | "success";
  format?: "currency" | "number";
}

function StatCard({
  label,
  value,
  helper,
  icon: Icon,
  tone = "default",
  format = "number",
  index,
}: StatItem & { index: number }) {
  return (
    <MetricCard
      value={value}
      format={format}
      label={label}
      helper={helper}
      index={index}
      className="overflow-hidden"
    >
      <div className="flex items-start justify-between gap-3">
        <div
          className={cn(
            "flex h-11 w-11 shrink-0 items-center justify-center border",
            tone === "danger"
              ? "border-destructive/25 bg-destructive/10 text-destructive"
              : tone === "success"
                ? "border-success/25 bg-success/10 text-success"
                : "border-primary/20 bg-primary/10 text-primary",
          )}
        >
          <Icon className="size-5" />
        </div>
      </div>
    </MetricCard>
  );
}

function StatsCardsSkeleton() {
  return (
    <MetricStrip>
      {Array.from({ length: 6 }).map((_, i) => (
        <MetricCard key={i} index={i}>
          <div className="space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-8 w-20" />
              </div>
              <Skeleton className="size-11" />
            </div>
            <Skeleton className="h-3 w-32" />
          </div>
        </MetricCard>
      ))}
    </MetricStrip>
  );
}

function StatsCardsError({ message }: { message: string }) {
  return (
    <MetricCard className="border-destructive/30 bg-destructive/10 xl:col-span-4">
      <p className="text-sm text-destructive">{message}</p>
    </MetricCard>
  );
}

export function StatsCards({ data, isLoading, error }: StatsCardsProps) {
  if (isLoading) return <StatsCardsSkeleton />;
  if (error) return <StatsCardsError message={error} />;
  if (!data) return null;

  const items: StatItem[] = [
    {
      label: "Today’s Orders",
      value: data.today_orders,
      helper: "Orders placed since midnight",
      icon: ShoppingBag,
      tone: data.today_orders > 0 ? "success" : "default",
    },
    {
      label: "Today’s Revenue",
      value: data.today_revenue,
      helper: "Gross revenue collected today",
      icon: Wallet,
      tone: data.today_revenue > 0 ? "success" : "default",
      format: "currency",
    },
    {
      label: "Pending Orders",
      value: data.pending_orders,
      helper: data.pending_orders > 0 ? "Needs review and fulfillment" : "No pending backlog",
      icon: Clock3,
      tone: data.pending_orders > 0 ? "danger" : "default",
    },
    {
      label: "Low Stock Items",
      value: data.low_stock_count,
      helper: data.low_stock_count > 0 ? "Restock before demand slips" : "Inventory health is stable",
      icon: Package,
      tone: data.low_stock_count > 0 ? "danger" : "default",
    },
    {
      label: "Total Products",
      value: data.total_products,
      helper: "Active catalog items available",
      icon: ArrowUpRight,
    },
    {
      label: "Total Orders",
      value: data.total_orders,
      helper: "Lifetime processed order volume",
      icon: ArrowRight,
    },
  ];

  return (
    <MetricStrip>
      {items.map((item, index) => (
        <StatCard key={item.label} {...item} index={index} />
      ))}
    </MetricStrip>
  );
}
