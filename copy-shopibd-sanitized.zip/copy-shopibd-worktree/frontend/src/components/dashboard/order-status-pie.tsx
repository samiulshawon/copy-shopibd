"use client";

import React, { useMemo } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import type { StatusBreakdown } from "@/types/analytics";

interface OrderStatusPieProps {
  data: StatusBreakdown[] | null;
  isLoading: boolean;
  error: string | null;
}

const STATUS_COLORS: Record<string, string> = {
  pending: "hsl(var(--warning))",
  confirmed: "hsl(var(--success))",
  shipped: "hsl(var(--muted-foreground))",
  delivered: "hsl(var(--success))",
  cancelled: "hsl(var(--destructive))",
};

const STATUS_LABELS: Record<string, string> = {
  pending: "Pending",
  confirmed: "Confirmed",
  shipped: "Shipped",
  delivered: "Delivered",
  cancelled: "Cancelled",
};

function PieChart({ data }: { data: StatusBreakdown[] }) {
  const total = useMemo(() => data.reduce((sum, d) => sum + d.count, 0), [data]);

  const arcs = useMemo(() => {
    if (total === 0) return [];

    const cx = 100;
    const cy = 100;
    const r = 80;

    let currentAngle = -90;
    const slices: {
      path: string;
      color: string;
      label: string;
      percentage: number;
      count: number;
    }[] = [];

    data.forEach((d) => {
      const percentage = d.count / total;
      const angle = percentage * 360;
      const startAngle = currentAngle;
      const endAngle = currentAngle + angle;

      const startRad = (startAngle * Math.PI) / 180;
      const endRad = (endAngle * Math.PI) / 180;

      const x1 = cx + r * Math.cos(startRad);
      const y1 = cy + r * Math.sin(startRad);
      const x2 = cx + r * Math.cos(endRad);
      const y2 = cy + r * Math.sin(endRad);

      const largeArc = angle > 180 ? 1 : 0;
      const path = `M${cx},${cy} L${x1},${y1} A${r},${r} 0 ${largeArc} 1 ${x2},${y2} Z`;

      slices.push({
        path,
        color: STATUS_COLORS[d.status] || "#8B91A0",
        label: STATUS_LABELS[d.status] || d.status,
        percentage,
        count: d.count,
      });

      currentAngle = endAngle;
    });

    return slices;
  }, [data, total]);

  if (total === 0) {
    return (
      <div className="flex h-[200px] items-center justify-center border border-dashed border-border/80 bg-muted/30 text-sm text-muted-foreground">
        No orders yet
      </div>
    );
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[180px_minmax(0,1fr)] lg:items-center">
      <div className="mx-auto">
        <svg viewBox="0 0 200 200" className="h-[180px] w-[180px] shrink-0">
          {arcs.map((slice, i) => (
            <path
              key={i}
              d={slice.path}
              fill={slice.color}
              className="animate-fade-in"
              style={{ animationDelay: `${i * 70}ms` }}
            />
          ))}
          <circle cx="100" cy="100" r="42" fill="hsl(var(--background))" />
          <text
            x="100"
            y="94"
            textAnchor="middle"
            dominantBaseline="central"
            className="fill-foreground text-lg font-bold"
          >
            {total}
          </text>
          <text
            x="100"
            y="112"
            textAnchor="middle"
            dominantBaseline="central"
            className="fill-muted-foreground text-[10px]"
          >
            total orders
          </text>
        </svg>
      </div>

      <div className="space-y-3">
        {arcs.map((slice, i) => (
          <div key={i} className="border border-border/80 bg-muted/30 p-3">
            <div className="flex items-center justify-between gap-3">
              <div className="flex min-w-0 items-center gap-3">
                <span
                  className="inline-block size-3.5 shrink-0"
                  style={{ backgroundColor: slice.color }}
                />
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-foreground">{slice.label}</p>
                  <p className="text-xs text-muted-foreground">{slice.count} orders</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-semibold text-foreground">{Math.round(slice.percentage * 100)}%</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function OrderStatusPieSkeleton() {
  return (
    <Card>
      <CardHeader>
        <div className="space-y-2">
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-4 w-56" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid gap-6 lg:grid-cols-[180px_minmax(0,1fr)] lg:items-center">
          <Skeleton className="mx-auto h-[180px] w-[180px]" />
          <div className="space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function OrderStatusPieError({ message }: { message: string }) {
  return (
    <Card className="border-destructive/30 bg-destructive/10">
      <CardContent className="pt-6">
        <p className="text-sm text-destructive">{message}</p>
      </CardContent>
    </Card>
  );
}

export function OrderStatusPie({ data, isLoading, error }: OrderStatusPieProps) {
  if (isLoading) return <OrderStatusPieSkeleton />;
  if (error) return <OrderStatusPieError message={error} />;
  if (!data || data.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Order Status</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            No order status data available yet.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="h-full">
      <CardHeader className="space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant="warning" className="px-3 py-1">
            Fulfillment health
          </Badge>
        </div>
        <div>
          <CardTitle className="text-xl">Order status breakdown</CardTitle>
          <p className="mt-2 text-sm text-muted-foreground">
            A quick view of where order volume is sitting across the fulfillment pipeline.
          </p>
        </div>
      </CardHeader>
      <CardContent>
        <PieChart data={data} />
      </CardContent>
    </Card>
  );
}
