"use client";

import React from "react";
import Link from "next/link";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface UpgradePromptProps {
  productCount: number;
  maxProducts: number;
  orderCount: number;
  maxOrders: number;
  plan: string;
  className?: string;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

// Real plan ids are free/starter/business/enterprise. "enterprise" is unlimited.
const isUnlimitedPlan = (plan: string) => plan === "enterprise";

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export function UpgradePrompt({
  productCount,
  maxProducts,
  orderCount,
  maxOrders,
  plan,
  className,
}: UpgradePromptProps) {
  const productPercent = maxProducts > 0 ? (productCount / maxProducts) * 100 : 0;
  const orderPercent = maxOrders > 0 ? (orderCount / maxOrders) * 100 : 0;
  const isNearLimit = productPercent >= 80 || orderPercent >= 80;
  const isAtLimit = productPercent >= 100 || orderPercent >= 100;

  if (!isNearLimit && !isAtLimit) {
    return null;
  }

  if (isUnlimitedPlan(plan)) {
    // Enterprise users have unlimited, no prompt needed
    return null;
  }

  const exceeded: string[] = [];
  if (productPercent >= 100) exceeded.push("products");
  if (orderPercent >= 100) exceeded.push("orders");

  const title = isAtLimit
    ? "Plan limit reached"
    : "Approaching plan limit";

  const planName = plan.charAt(0).toUpperCase() + plan.slice(1);

  const description = isAtLimit
    ? `You've reached the limit for: ${exceeded.join(" and ")}. Upgrade your plan to continue without restrictions.`
    : `You're using ${Math.round(Math.max(productPercent, orderPercent))}% of your ${planName} plan limits. Upgrade to avoid interruptions.`;

  return (
    <Alert
      variant={isAtLimit ? "destructive" : "default"}
      className={cn(
        isNearLimit && !isAtLimit && "border-warning/40 bg-warning/10",
        className,
      )}
    >
      <AlertTitle className={cn(isNearLimit && !isAtLimit && "text-warning")}>
        {title}
      </AlertTitle>
      <AlertDescription>
        <p className="mb-3">{description}</p>
        <Button size="sm" variant={isAtLimit ? "destructive" : "default"} asChild>
          <Link href="/dashboard/subscription">Upgrade Plan</Link>
        </Button>
      </AlertDescription>
    </Alert>
  );
}
