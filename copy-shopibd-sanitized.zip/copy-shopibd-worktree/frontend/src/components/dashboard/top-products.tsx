"use client";

import React from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { formatCurrency } from "@/lib/utils";
import type { TopProduct } from "@/types/analytics";

interface TopProductsProps {
  data: TopProduct[] | null;
  isLoading: boolean;
  error: string | null;
}

function TopProductsSkeleton() {
  return (
    <Card>
      <CardHeader>
        <div className="space-y-2">
          <Skeleton className="h-6 w-40" />
          <Skeleton className="h-4 w-48" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-20 w-full" />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function TopProductsError({ message }: { message: string }) {
  return (
    <Card className="border-destructive/30 bg-destructive/10">
      <CardContent className="pt-6">
        <p className="text-sm text-destructive">{message}</p>
      </CardContent>
    </Card>
  );
}

function ProductRow({ product, index }: { product: TopProduct; index: number }) {
  return (
    <div
      className="animate-fade-up border border-border/80 bg-muted/30 p-4"
      style={{ animationDelay: `${index * 60}ms` }}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="flex size-7 shrink-0 items-center justify-center bg-primary/10 text-xs font-semibold text-primary">
              {index + 1}
            </span>
            <p className="truncate text-sm font-medium text-foreground sm:text-base">
              {product.product_name}
            </p>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-3 text-xs sm:text-sm">
            <div>
              <p className="text-muted-foreground">Sold</p>
              <p className="mt-1 font-semibold text-foreground">{product.total_quantity}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Revenue</p>
              <p className="mt-1 font-semibold text-foreground">{formatCurrency(product.total_revenue)}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Orders</p>
              <p className="mt-1 font-semibold text-foreground">{product.order_count}</p>
            </div>
          </div>
        </div>
        <Badge variant="secondary" className="px-3 py-1">
          Top seller
        </Badge>
      </div>
    </div>
  );
}

export function TopProducts({ data, isLoading, error }: TopProductsProps) {
  if (isLoading) return <TopProductsSkeleton />;
  if (error) return <TopProductsError message={error} />;
  if (!data || data.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Top Products</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            No product data available yet.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="h-full">
      <CardHeader className="space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant="info" className="px-3 py-1">
            Product momentum
          </Badge>
        </div>
        <div>
          <CardTitle className="text-xl">Top products</CardTitle>
          <p className="mt-2 text-sm text-muted-foreground">
            Best-performing items based on order activity and revenue contribution.
          </p>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {data.slice(0, 5).map((product, index) => (
            <ProductRow key={product.product_id} product={product} index={index} />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
