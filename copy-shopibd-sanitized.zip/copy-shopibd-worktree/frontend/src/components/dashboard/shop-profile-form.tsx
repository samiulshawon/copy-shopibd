"use client";

import React, { useCallback, useState } from "react";
import { settingsApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import type { Shop } from "@/types/shop";
import {
  SectionDescription,
  SectionHeader,
  SectionTitle,
  SurfaceSection,
} from "@/components/layout/page-structure";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface ShopProfileFormProps {
  shop: Shop;
  onSuccess: () => void;
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export function ShopProfileForm({ shop, onSuccess }: ShopProfileFormProps) {
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: shop.name || "",
    slug: shop.slug || "",
    description: shop.description || "",
    logo_url: shop.logo_url || "",
    contact_phone: shop.contact_phone || "",
  });

  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // -------------------------------------------------------------------------
  // Handlers
  // -------------------------------------------------------------------------

  const handleChange = useCallback(
    (field: string, value: string) => {
      setFormData((prev) => ({ ...prev, [field]: value }));
      setErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    },
    [],
  );

  const handleSubmit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();

      const newErrors: Record<string, string> = {};
      if (!formData.name.trim()) {
        newErrors.name = "Shop name is required";
      }
      if (!formData.slug.trim()) {
        newErrors.slug = "Slug is required";
      } else if (!/^[a-z0-9-]+$/.test(formData.slug)) {
        newErrors.slug =
          "Slug can only contain lowercase letters, numbers, and hyphens";
      }

      if (Object.keys(newErrors).length > 0) {
        setErrors(newErrors);
        return;
      }

      setSaving(true);
      try {
        const payload: Record<string, unknown> = {};
        if (formData.name !== shop.name) payload.name = formData.name;
        if (formData.slug !== shop.slug) payload.slug = formData.slug;
        if (formData.description !== (shop.description || ""))
          payload.description = formData.description;
        if (formData.logo_url !== (shop.logo_url || ""))
          payload.logo_url = formData.logo_url;
        if (formData.contact_phone !== (shop.contact_phone || ""))
          payload.contact_phone = formData.contact_phone;

        if (Object.keys(payload).length === 0) {
          toast({
            message: "No changes to save",
            variant: "info",
          });
          setSaving(false);
          return;
        }

        await settingsApi.updateShop(payload);
        toast({
          message: "Shop profile updated successfully",
          variant: "success",
        });
        onSuccess();
      } catch (err: any) {
        const message =
          err?.response?.data?.detail ||
          err?.message ||
          "Failed to update shop profile";
        toast({
          message,
          variant: "error",
        });
      } finally {
        setSaving(false);
      }
    },
    [formData, shop, onSuccess, toast],
  );

  // -------------------------------------------------------------------------
  // Render
  // -------------------------------------------------------------------------

  return (
    <SurfaceSection>
      <SectionHeader>
        <div>
          <SectionTitle>Shop Profile</SectionTitle>
          <SectionDescription>
            Update your shop name, URL slug, description, logo, and contact information.
          </SectionDescription>
        </div>
      </SectionHeader>
      <form onSubmit={handleSubmit}>
        <div className="mt-4 space-y-4">
          {/* Shop Name */}
          <div className="space-y-2">
            <label
              htmlFor="shop-name"
              className="text-sm font-medium leading-none"
            >
              Shop Name *
            </label>
            <Input
              id="shop-name"
              value={formData.name}
              onChange={(e) => handleChange("name", e.target.value)}
              placeholder="My Awesome Shop"
              disabled={saving}
              className="bg-muted"
            />
            {errors.name && (
              <p className="text-sm text-destructive">{errors.name}</p>
            )}
          </div>

          {/* Slug */}
          <div className="space-y-2">
            <label
              htmlFor="shop-slug"
              className="text-sm font-medium leading-none"
            >
              URL Slug *
            </label>
            <Input
              id="shop-slug"
              value={formData.slug}
              onChange={(e) => handleChange("slug", e.target.value)}
              placeholder="my-awesome-shop"
              disabled={saving}
              className="bg-muted"
            />
            <p className="text-xs text-muted-foreground">
              Your shop&apos;s unique URL: shopibd.com/
              {formData.slug || "your-slug"}
            </p>
            {errors.slug && (
              <p className="text-sm text-destructive">{errors.slug}</p>
            )}
          </div>

          {/* Description */}
          <div className="space-y-2">
            <label
              htmlFor="shop-description"
              className="text-sm font-medium leading-none"
            >
              Description
            </label>
            <textarea
              id="shop-description"
              value={formData.description}
              onChange={(e) => handleChange("description", e.target.value)}
              placeholder="Tell customers about your shop..."
              disabled={saving}
              rows={4}
              className="flex w-full border border-border bg-muted px-3 py-2 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring disabled:cursor-not-allowed disabled:opacity-50"
            />
          </div>

          {/* Logo URL */}
          <div className="space-y-2">
            <label
              htmlFor="shop-logo"
              className="text-sm font-medium leading-none"
            >
              Logo URL
            </label>
            <Input
              id="shop-logo"
              value={formData.logo_url}
              onChange={(e) => handleChange("logo_url", e.target.value)}
              placeholder="https://example.com/logo.png"
              disabled={saving}
              className="bg-muted"
            />
          </div>

          {/* Contact Phone */}
          <div className="space-y-2">
            <label
              htmlFor="shop-phone"
              className="text-sm font-medium leading-none"
            >
              Contact Phone
            </label>
            <Input
              id="shop-phone"
              value={formData.contact_phone}
              onChange={(e) => handleChange("contact_phone", e.target.value)}
              placeholder="+8801XXXXXXXXX"
              disabled={saving}
              className="bg-muted"
            />
          </div>
        </div>

        <div className="mt-6 flex justify-end gap-2">
          <Button
            type="button"
            variant="outline"
            className=""
            onClick={() => {
              setFormData({
                name: shop.name || "",
                slug: shop.slug || "",
                description: shop.description || "",
                logo_url: shop.logo_url || "",
                contact_phone: shop.contact_phone || "",
              });
              setErrors({});
            }}
            disabled={saving}
          >
            Reset
          </Button>
          <Button type="submit" className="" disabled={saving}>
            {saving ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </form>
    </SurfaceSection>
  );
}