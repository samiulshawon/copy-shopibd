"use client";

import React, { useCallback, useRef, useState } from "react";
import { productApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { isPlanLimitError, getPlanLimitMessage } from "@/lib/utils";
import { Upload, FileText, CheckCircle, AlertCircle, Loader2 } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface CsvImportWizardProps {
  shopId: number;
  onSuccess: () => void;
  onCancel: () => void;
}

type Step = "upload" | "preview" | "result";

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5 MB

interface ParsedRow {
  [key: string]: string;
}

export function CsvImportWizard({ shopId, onSuccess, onCancel }: CsvImportWizardProps) {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [step, setStep] = useState<Step>("upload");
  const [file, setFile] = useState<File | null>(null);
  const [previewData, setPreviewData] = useState<ParsedRow[]>([]);
  const [previewHeaders, setPreviewHeaders] = useState<string[]>([]);
  const [isImporting, setIsImporting] = useState(false);
  const [importResult, setImportResult] = useState<{
    total: number;
    created: number;
    failed: Array<{ row: number; error: string }>;
  } | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  // -----------------------------------------------------------------------
  // Parse CSV in browser for preview
  // -----------------------------------------------------------------------

  const parseCsvPreview = useCallback((content: string) => {
    const lines = content.split(/\r?\n/).filter((line) => line.trim());
    if (lines.length === 0) return;

    // Detect delimiter
    const firstLine = lines[0];
    const delimiter = firstLine.includes("\t") ? "\t" : ",";

    const headers = firstLine.split(delimiter).map((h) => h.trim());
    const rows: ParsedRow[] = [];

    for (let i = 1; i < Math.min(lines.length, 11); i++) {
      const values = lines[i].split(delimiter);
      const row: ParsedRow = {};
      headers.forEach((header, idx) => {
        row[header] = values[idx]?.trim() || "";
      });
      rows.push(row);
    }

    setPreviewHeaders(headers);
    setPreviewData(rows);
  }, []);

  // -----------------------------------------------------------------------
  // Handle file selection
  // -----------------------------------------------------------------------

  const handleFile = useCallback(
    (selectedFile: File) => {
      if (!selectedFile.name.endsWith(".csv")) {
        toast({
          message: "Error",
          description: "Please select a CSV file",
          variant: "error",
        });
        return;
      }

      if (selectedFile.size > MAX_FILE_SIZE) {
        toast({
          message: "Error",
          description: `File too large (${(selectedFile.size / (1024 * 1024)).toFixed(1)} MB). Maximum size is 5 MB.`,
          variant: "error",
        });
        return;
      }

      setFile(selectedFile);

      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        parseCsvPreview(content);
        setStep("preview");
      };
      reader.readAsText(selectedFile);
    },
    [toast, parseCsvPreview],
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      const droppedFile = e.dataTransfer.files[0];
      if (droppedFile) handleFile(droppedFile);
    },
    [handleFile],
  );

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => setIsDragging(false);

  // -----------------------------------------------------------------------
  // Import
  // -----------------------------------------------------------------------

  const handleImport = useCallback(async () => {
    if (!file) return;
    setIsImporting(true);
    try {
      const response = await productApi.importCsv(file, shopId);
      const result = response.data;
      setImportResult(result);
      setStep("result");

      if (result.created > 0) {
        toast({
          message: "Import Complete",
          description: `${result.created} products created out of ${result.total}`,
          variant: result.failed.length > 0 ? "warning" : "success",
        });
      }
    } catch (error: any) {
      if (isPlanLimitError(error)) {
        toast({
          message: "Plan limit reached",
          description: getPlanLimitMessage(
            error,
            "You've reached your plan's product limit. Upgrade to create more products via CSV.",
          ),
          variant: "error",
          duration: 8000,
        });
      } else {
        toast({
          message: "Error",
          description: error?.response?.data?.detail || "Failed to import CSV",
          variant: "error",
        });
      }
    } finally {
      setIsImporting(false);
    }
  }, [file, shopId, toast]);

  // -----------------------------------------------------------------------
  // Reset
  // -----------------------------------------------------------------------

  const reset = () => {
    setStep("upload");
    setFile(null);
    setPreviewData([]);
    setPreviewHeaders([]);
    setImportResult(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  // -----------------------------------------------------------------------
  // Render: Upload Step
  // -----------------------------------------------------------------------

  if (step === "upload") {
    return (
      <div className="space-y-6">
        {/* Hidden file input */}
        <input
          ref={fileInputRef}
          type="file"
          accept=".csv"
          className="hidden"
          onChange={(e) => {
            if (e.target.files?.[0]) handleFile(e.target.files[0]);
          }}
        />

        {/* Drag & Drop Zone */}
        <div
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          className={`cursor-pointer border-2 border-dashed p-12 text-center transition-colors ${
            isDragging
              ? "border-primary bg-primary/5"
              : "border-muted-foreground/25 hover:border-primary/50"
          }`}
          onClick={() => fileInputRef.current?.click()}
        >
          <Upload className="mx-auto size-12 text-muted-foreground/50" />
          <p className="mt-4 text-lg font-medium">
            {isDragging ? "Drop file here" : "Drop CSV file here or click to browse"}
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            Required columns: name, price
          </p>
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        </div>
      </div>
    );
  }

  // -----------------------------------------------------------------------
  // Render: Preview Step
  // -----------------------------------------------------------------------

  if (step === "preview") {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <FileText className="size-4" />
          <span>
            {file?.name} &mdash; preview of first {previewData.length} rows
          </span>
        </div>

        {/* Preview Table */}
        <div className="max-h-64 overflow-auto border">
          <Table>
            <TableHeader>
              <TableRow>
                {previewHeaders.map((header) => (
                  <TableHead key={header}>{header}</TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {previewData.map((row, idx) => (
                <TableRow key={idx}>
                  {previewHeaders.map((header) => (
                    <TableCell key={header}>{row[header] || ""}</TableCell>
                  ))}
                </TableRow>
              ))}
              {previewData.length === 0 && (
                <TableRow>
                  <TableCell colSpan={previewHeaders.length} className="py-4 text-center">
                    No data rows found
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-2">
          <Button variant="ghost" size="sm" onClick={reset}>
            Choose different file
          </Button>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onCancel} disabled={isImporting}>
              Cancel
            </Button>
            <Button onClick={handleImport} disabled={isImporting}>
              {isImporting ? (
                <>
                  <Loader2 className="mr-2 size-4 animate-spin" />
                  Importing...
                </>
              ) : (
                "Confirm & Import"
              )}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // -----------------------------------------------------------------------
  // Render: Result Step
  // -----------------------------------------------------------------------

  if (step === "result") {
    return (
      <div className="space-y-6">
        {importResult && importResult.created > 0 ? (
          <div className="flex flex-col items-center py-6">
            <CheckCircle className="mb-4 size-16 text-success" />
            <h3 className="text-xl font-semibold">Import Complete</h3>
            <p className="mt-1 text-muted-foreground">
              {importResult.created} of {importResult.total} products created successfully
            </p>
          </div>
        ) : (
          <div className="flex flex-col items-center py-6">
            <AlertCircle className="mb-4 size-16 text-destructive" />
            <h3 className="text-xl font-semibold">Import Failed</h3>
            <p className="mt-1 text-muted-foreground">
              No products could be created. Please check your CSV file.
            </p>
          </div>
        )}

        {/* Failed rows */}
        {importResult && importResult.failed.length > 0 && (
          <div className="border p-4">
            <h4 className="mb-2 font-medium text-destructive">
              {importResult.failed.length} Failed Row(s)
            </h4>
            <div className="max-h-40 space-y-1 overflow-y-auto text-sm">
              {importResult.failed.map((f, idx) => (
                <div key={idx} className="text-muted-foreground">
                  Row {f.row}: {f.error}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="flex justify-end gap-2 border-t pt-4">
          <Button variant="outline" onClick={reset}>
            Import Another File
          </Button>
          <Button onClick={onSuccess}>Done</Button>
        </div>
      </div>
    );
  }

  return null;
}
