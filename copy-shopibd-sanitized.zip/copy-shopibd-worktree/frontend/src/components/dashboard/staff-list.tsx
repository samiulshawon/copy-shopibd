"use client";

import React, { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Select } from "@/components/ui/select";
import type { Staff, StaffRole } from "@/types/staff";
import {
  SectionDescription,
  SectionHeader,
  SectionTitle,
  SurfaceSection,
} from "@/components/layout/page-structure";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface StaffListProps {
  members: Staff[];
  onUpdate: (id: number, data: { role?: string; is_active?: boolean }) => Promise<void>;
  onRemove: (id: number) => Promise<void>;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const roleBadgeVariant = (role: string) => {
  switch (role) {
    case "owner":
      return "default" as const;
    case "manager":
      return "info" as const;
    case "staff":
      return "secondary" as const;
    default:
      return "outline" as const;
  }
};

const statusBadgeVariant = (isActive: boolean) =>
  isActive ? ("success" as const) : ("destructive" as const);

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export function StaffList({ members, onUpdate, onRemove }: StaffListProps) {
  const [editTarget, setEditTarget] = useState<Staff | null>(null);
  const [editRole, setEditRole] = useState<string>("");
  const [deleteTarget, setDeleteTarget] = useState<Staff | null>(null);
  const [actionLoading, setActionLoading] = useState(false);

  const handleEditSave = async () => {
    if (!editTarget) return;
    setActionLoading(true);
    try {
      await onUpdate(editTarget.id, { role: editRole });
      setEditTarget(null);
    } catch {
      // Error handled upstream
    } finally {
      setActionLoading(false);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!deleteTarget) return;
    setActionLoading(true);
    try {
      await onRemove(deleteTarget.id);
      setDeleteTarget(null);
    } catch {
      // Error handled upstream
    } finally {
      setActionLoading(false);
    }
  };

  const handleToggleActive = async (member: Staff) => {
    setActionLoading(true);
    try {
      await onUpdate(member.id, { is_active: !member.is_active });
    } catch {
      // Error handled upstream
    } finally {
      setActionLoading(false);
    }
  };

  const roleOptions = [
    { value: "owner", label: "Owner" },
    { value: "manager", label: "Manager" },
    { value: "staff", label: "Staff" },
  ];

  return (
    <>
      <SurfaceSection>
        <SectionHeader>
          <div>
            <SectionTitle>Team members</SectionTitle>
            <SectionDescription>
              {members.length} member{members.length !== 1 ? "s" : ""} in your team.
            </SectionDescription>
          </div>
        </SectionHeader>

        <div className="mt-4 border border-border">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {members.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="py-8 text-center text-muted-foreground">
                    No staff members yet. Invite your first team member.
                  </TableCell>
                </TableRow>
              ) : (
                members.map((member) => (
                  <TableRow key={member.id} className="hover:bg-muted/50">
                    <TableCell className="font-medium text-foreground">{member.name}</TableCell>
                    <TableCell className="text-muted-foreground">{member.email}</TableCell>
                    <TableCell>
                      <Badge variant={roleBadgeVariant(member.role)}>
                        {member.role.charAt(0).toUpperCase() + member.role.slice(1)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={statusBadgeVariant(member.is_active)}>
                        {member.is_active ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        {member.role !== "owner" && (
                          <>
                            <Button
                              variant="outline"
                              size="sm"
                              className=""
                              onClick={() => {
                                setEditTarget(member);
                                setEditRole(member.role);
                              }}
                            >
                              Edit Role
                            </Button>
                            <Button
                              variant={member.is_active ? "secondary" : "outline"}
                              size="sm"
                              className=""
                              onClick={() => handleToggleActive(member)}
                              disabled={actionLoading}
                            >
                              {member.is_active ? "Deactivate" : "Activate"}
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              className=""
                              onClick={() => setDeleteTarget(member)}
                              disabled={actionLoading}
                            >
                              Remove
                            </Button>
                          </>
                        )}
                        {member.role === "owner" && (
                          <span className="text-xs italic text-muted-foreground">
                            Owner
                          </span>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </SurfaceSection>

      {/* Edit Role Dialog */}
      <Dialog open={!!editTarget} onOpenChange={(open) => !open && setEditTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Role</DialogTitle>
            <DialogDescription>
              Change the role for {editTarget?.name}.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Select
              value={editRole}
              onChange={(e) => setEditRole(e.target.value)}
              options={roleOptions}
              placeholder="Select a role"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" className="" onClick={() => setEditTarget(null)}>
              Cancel
            </Button>
            <Button className="" onClick={handleEditSave} disabled={actionLoading}>
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Remove Staff Member</DialogTitle>
            <DialogDescription>
              Are you sure you want to remove {deleteTarget?.name} from your team?
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" className="" onClick={() => setDeleteTarget(null)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              className=""
              onClick={handleDeleteConfirm}
              disabled={actionLoading}
            >
              Remove
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}