"use client";

import React from "react";
import { Eye, MoreHorizontal, Phone, ShoppingBag } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { StatusBadge } from "@/components/dashboard/status-badge";
import type { OrderListItem } from "@/types/order";
import { formatCurrency } from "@/lib/utils";

interface OrdersTableProps {
  orders: OrderListItem[];
  onRowClick: (orderId: number) => void;
  onStatusChange: (orderId: number, status: string) => void;
}

function formatDate(dateString: string) {
  return new Date(dateString).toLocaleDateString("en-BD", { year: "numeric", month: "short", day: "numeric" });
}

function initial(name: string) {
  return name.trim().slice(0, 1).toUpperCase() || "?";
}

export function OrdersTable({ orders, onRowClick, onStatusChange }: OrdersTableProps) {
  return (
    <Table>
      <TableHeader>
        <TableRow className="hover:bg-transparent">
          <TableHead>Order</TableHead><TableHead>Customer</TableHead><TableHead>Phone</TableHead><TableHead>Items</TableHead><TableHead>Status</TableHead><TableHead>Date</TableHead><TableHead className="text-right">Total</TableHead><TableHead className="w-12" />
        </TableRow>
      </TableHeader>
      <TableBody>
        {orders.map((order) => (
          <TableRow key={order.id} className="cursor-pointer" onClick={() => onRowClick(order.id)}>
            <TableCell><div><p className="font-mono text-sm font-semibold text-foreground">#{order.order_number}</p><p className="mt-0.5 text-xs capitalize text-muted-foreground">{order.payment_status}</p></div></TableCell>
            <TableCell><div className="flex items-center gap-2.5"><span className="flex size-7 shrink-0 items-center justify-center border border-border bg-muted text-[10px] font-semibold text-muted-foreground">{initial(order.customer_name)}</span><span className="max-w-40 truncate font-medium text-foreground">{order.customer_name}</span></div></TableCell>
            <TableCell className="text-muted-foreground"><span className="flex items-center gap-1.5"><Phone className="size-3.5" />{order.customer_phone}</span></TableCell>
            <TableCell><span className="inline-flex items-center gap-1.5 text-muted-foreground"><ShoppingBag className="size-3.5" />{order.item_count}</span></TableCell>
            <TableCell><StatusBadge status={order.status} /></TableCell>
            <TableCell className="whitespace-nowrap text-muted-foreground">{formatDate(order.created_at)}</TableCell>
            <TableCell className="text-right font-semibold text-foreground">{formatCurrency(order.total_amount)}</TableCell>
            <TableCell className="text-right"><DropdownMenu><DropdownMenuTrigger asChild><Button variant="ghost" size="icon" className="size-8" onClick={(event) => event.stopPropagation()}><MoreHorizontal className="size-4" /><span className="sr-only">Order actions</span></Button></DropdownMenuTrigger><DropdownMenuContent align="end"><DropdownMenuItem onClick={(event) => { event.stopPropagation(); onRowClick(order.id); }}><Eye className="mr-2 size-4" />View details</DropdownMenuItem><DropdownMenuItem onClick={(event) => { event.stopPropagation(); onStatusChange(order.id, "confirmed"); }}>Mark confirmed</DropdownMenuItem><DropdownMenuItem onClick={(event) => { event.stopPropagation(); onStatusChange(order.id, "shipped"); }}>Mark shipped</DropdownMenuItem><DropdownMenuItem onClick={(event) => { event.stopPropagation(); onStatusChange(order.id, "delivered"); }}>Mark delivered</DropdownMenuItem><DropdownMenuItem onClick={(event) => { event.stopPropagation(); onStatusChange(order.id, "cancelled"); }} className="text-destructive">Cancel order</DropdownMenuItem></DropdownMenuContent></DropdownMenu></TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
