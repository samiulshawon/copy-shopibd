"use client";

import React, { useEffect, useMemo, useState } from "react";
import { ArrowLeft, Check, Image as ImageIcon, Package2, Save, Tags, Wallet } from "lucide-react";
import { useRouter } from "next/navigation";
import { api, productApi } from "@/lib/api";
import type { Product, ProductCreate, ProductImage, ProductUpdate } from "@/types/product";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { isPlanLimitError, getPlanLimitMessage } from "@/lib/utils";
import {
  MobileStickyActions,
  PageActions,
  PageDescription,
  PageEyebrow,
  PageFrame,
  PageHeader,
  PageHeaderContent,
  PageTitle,
  SectionDescription,
  SectionHeader,
  SectionTitle,
  SurfaceSection,
} from "@/components/layout/page-structure";

interface CategoryOption {
  id: number;
  name_bn: string;
}

interface ProductFormProps {
  product?: Product;
}

function FormSection({
  icon: Icon,
  title,
  description,
  children,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  children: React.ReactNode;
}) {
  return (
    <SurfaceSection>
      <SectionHeader>
        <div className="flex gap-3">
          <div className="flex size-10 shrink-0 items-center justify-center border border-primary/20 bg-primary/10 text-primary">
            <Icon className="size-4" />
          </div>
          <div>
            <SectionTitle>{title}</SectionTitle>
            <SectionDescription>{description}</SectionDescription>
          </div>
        </div>
      </SectionHeader>
      <div className="mt-5">{children}</div>
    </SurfaceSection>
  );
}

export function ProductForm({ product }: ProductFormProps) {
  const router = useRouter();
  const { toast } = useToast();
  const isEditing = Boolean(product);

  const [name, setName] = useState(product?.name ?? "");
  const [description, setDescription] = useState(product?.description ?? "");
  const [sku, setSku] = useState(product?.sku ?? "");
  const [price, setPrice] = useState(product ? String(product.price) : "");
  const [stock, setStock] = useState(product ? String(product.stock) : "0");
  const [categoryId, setCategoryId] = useState(product?.category_id ? String(product.category_id) : "");
  const [isActive, setIsActive] = useState(product?.is_active ?? true);
  const [categories, setCategories] = useState<CategoryOption[]>([]);
  const [isSaving, setIsSaving] = useState(false);
  const [images, setImages] = useState<ProductImage[]>(product?.images ?? []);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  useEffect(() => {
    // Use the shared API client (correct base URL + auth) instead of a raw
    // relative fetch, which only worked behind the local dev proxy.
    api
      .get<{ items?: CategoryOption[] }>("/categories/", {
        params: { page: 1, page_size: 100 },
      })
      .then((response) => {
        if (response.data?.items) setCategories(response.data.items);
      })
      .catch(() => {});
  }, []);

  const MAX_IMAGES = 10;
  const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || !product) return;
    setUploadError(null);

    const remainingSlots = MAX_IMAGES - images.length;
    if (remainingSlots <= 0) {
      setUploadError(`You can upload at most ${MAX_IMAGES} images per product.`);
      event.target.value = "";
      return;
    }

    const fileList = Array.from(files).slice(0, remainingSlots);
    setIsUploading(true);
    try {
      const uploaded: ProductImage[] = [];
      for (const file of fileList) {
        if (!file.type.startsWith("image/")) {
          setUploadError(`"${file.name}" is not an image file.`);
          continue;
        }
        if (file.size > MAX_IMAGE_BYTES) {
          setUploadError(`"${file.name}" exceeds the 5 MB limit.`);
          continue;
        }
        const res = await productApi.uploadImage(product.id, file);
        uploaded.push(res.data);
      }
      if (uploaded.length) {
        setImages((current) => [...current, ...uploaded]);
        toast({
          message: "Images uploaded",
          description: `${uploaded.length} image(s) added to the gallery.`,
          variant: "success",
        });
      }
    } catch (err: any) {
      setUploadError(
        err?.response?.data?.detail || "Failed to upload image. Please try again.",
      );
    } finally {
      setIsUploading(false);
      event.target.value = "";
    }
  };

  const handleDeleteImage = async (imageId: number) => {
    if (!product) return;
    try {
      await productApi.deleteImage(product.id, imageId);
      setImages((current) => current.filter((image) => image.id !== imageId));
      toast({ message: "Image removed", variant: "success" });
    } catch (err: any) {
      toast({
        message: "Could not remove image",
        description: err?.response?.data?.detail || "Please try again.",
        variant: "error",
      });
    }
  };

  const handleSetPrimary = async (imageId: number) => {
    if (!product) return;
    try {
      const res = await productApi.setPrimaryImage(product.id, imageId);
      setImages((current) =>
        current.map((image) => ({ ...image, is_primary: image.id === res.data.id })),
      );
    } catch (err: any) {
      toast({
        message: "Could not set primary image",
        description: err?.response?.data?.detail || "Please try again.",
        variant: "error",
      });
    }
  };

  const formSummary = useMemo(() => {
    const completed = [name.trim(), price.trim(), stock.trim()].filter(Boolean).length;
    return `${completed} of 3 required details complete`;
  }, [name, price, stock]);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!name.trim() || !price.trim() || !stock.trim()) {
      toast({
        message: "Missing details",
        description: "Add a product name, price, and stock amount before saving.",
        variant: "error",
      });
      return;
    }

    setIsSaving(true);
    try {
      const basePayload = {
        name: name.trim(),
        description: description.trim() || undefined,
        price: Number(price),
        stock: Number(stock),
        sku: sku.trim() || undefined,
        is_active: isActive,
        category_id: categoryId ? Number(categoryId) : undefined,
      };

      if (product) {
        const payload: ProductUpdate = basePayload;
        await productApi.update(product.id, payload);
      } else {
        const payload: ProductCreate = basePayload;
        await productApi.create(payload, 1);
      }

      toast({
        message: "Success",
        description: isEditing ? "Product updated successfully." : "Product created successfully.",
        variant: "success",
      });
      router.push("/dashboard/products");
      router.refresh();
    } catch (error: any) {
      if (isPlanLimitError(error)) {
        toast({
          message: "Plan limit reached",
          description: getPlanLimitMessage(
            error,
            "You've reached your plan's product limit. Upgrade to create more products.",
          ),
          variant: "error",
          duration: 8000,
        });
      } else {
        toast({
          message: "Could not save product",
          description: error?.response?.data?.detail || "Please check the product details and try again.",
          variant: "error",
        });
      }
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <PageFrame>
      <PageHeader>
        <PageHeaderContent>
          <PageEyebrow>{isEditing ? "Catalog editor" : "Catalog setup"}</PageEyebrow>
          <PageTitle>{isEditing ? "Edit product" : "Add a new product"}</PageTitle>
          <PageDescription>
            {isEditing
              ? "Update the essential catalog details without losing your place in the mobile workflow."
              : "Start with the information customers need most. You can refine the rest as your catalog grows."}
          </PageDescription>
        </PageHeaderContent>
        <PageActions>
          <Button variant="outline" type="button" onClick={() => router.back()}>
            <ArrowLeft className="size-4" />
            Back
          </Button>
        </PageActions>
      </PageHeader>

      <form className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_320px]" onSubmit={handleSubmit}>
        <div className="space-y-6">
          <FormSection icon={Package2} title="Product basics" description="Name the item and describe what customers are buying.">
            <div className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="product-name" className="text-sm font-medium text-foreground">Product name <span className="text-destructive">*</span></label>
                <Input id="product-name" className="h-11 bg-muted" placeholder="e.g. Wireless Bluetooth Earbuds" value={name} onChange={(event) => setName(event.target.value)} />
              </div>
              <div className="space-y-2">
                <label htmlFor="product-description" className="text-sm font-medium text-foreground">Description</label>
                <textarea id="product-description" className="min-h-32 w-full border border-border bg-muted p-3 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring" placeholder="Describe key benefits, size, color, or other buying details..." value={description} onChange={(event) => setDescription(event.target.value)} />
              </div>
            </div>
          </FormSection>

          <FormSection icon={Wallet} title="Pricing and inventory" description="Set what the customer pays and how many units you have available.">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <label htmlFor="product-price" className="text-sm font-medium text-foreground">Price (৳) <span className="text-destructive">*</span></label>
                <Input id="product-price" className="h-11 bg-muted" type="number" min="0" step="0.01" placeholder="0.00" value={price} onChange={(event) => setPrice(event.target.value)} />
              </div>
              <div className="space-y-2">
                <label htmlFor="product-stock" className="text-sm font-medium text-foreground">Stock quantity <span className="text-destructive">*</span></label>
                <Input id="product-stock" className="h-11 bg-muted" type="number" min="0" step="1" placeholder="0" value={stock} onChange={(event) => setStock(event.target.value)} />
              </div>
            </div>
          </FormSection>

          <FormSection icon={Tags} title="Organization and visibility" description="Keep your catalog easy to manage and control when this product is available for sale.">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <label htmlFor="product-sku" className="text-sm font-medium text-foreground">SKU</label>
                <Input id="product-sku" className="h-11 bg-muted" placeholder="Optional internal code" value={sku} onChange={(event) => setSku(event.target.value)} />
              </div>
              <div className="space-y-2">
                <label htmlFor="product-category" className="text-sm font-medium text-foreground">Category</label>
                <Select id="product-category" className="h-11 bg-muted" value={categoryId} onChange={(event) => setCategoryId(event.target.value)} options={[{ value: "", label: "No category" }, ...categories.map((category) => ({ value: String(category.id), label: category.name_bn }))]} />
              </div>
            </div>
            <button type="button" onClick={() => setIsActive((current) => !current)} className="mt-5 flex w-full items-center justify-between gap-4 border border-outline-variant bg-muted p-4 text-left transition-colors hover:bg-muted/60">
              <div>
                <p className="font-medium text-foreground">Available for sale</p>
                <p className="mt-1 text-sm text-muted-foreground">Inactive products stay in your catalog but are hidden from buyers.</p>
              </div>
              <span className={`flex h-7 w-12 shrink-0 items-center p-1 transition-colors ${isActive ? "bg-primary" : "bg-secondary"}`}>
                <span className={`size-5 bg-white transition-transform ${isActive ? "translate-x-5" : "translate-x-0"}`} />
              </span>
            </button>
          </FormSection>

          {product ? (
            <FormSection icon={ImageIcon} title="Product images" description="Add up to 10 photos. The first image becomes the primary storefront photo.">
              <input
                id="product-images"
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={handleImageUpload}
                disabled={isUploading}
              />
              <div className="grid grid-cols-3 gap-3 sm:grid-cols-4">
                {images.map((image) => (
                  <div key={image.id} className="group relative aspect-square overflow-hidden border border-border bg-muted">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={image.image_url} alt="Product" className="size-full object-cover" />
                    {image.is_primary ? (
                      <span className="absolute left-1.5 top-1.5 bg-primary px-2 py-0.5 text-[10px] font-medium text-white">
                        Primary
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleSetPrimary(image.id)}
                        className="absolute left-1.5 top-1.5 bg-black/60 px-2 py-0.5 text-[10px] font-medium text-white opacity-0 transition-opacity group-hover:opacity-100"
                      >
                        Set primary
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleDeleteImage(image.id)}
                      className="absolute right-1.5 top-1.5 flex size-6 items-center justify-center bg-black/60 text-white opacity-0 transition-opacity group-hover:opacity-100"
                      aria-label="Remove image"
                    >
                      ×
                    </button>
                  </div>
                ))}
                {images.length < MAX_IMAGES && (
                  <label
                    htmlFor="product-images"
                    className="flex aspect-square cursor-pointer items-center justify-center border border-dashed border-border bg-muted/40 text-muted-foreground transition-colors hover:border-primary hover:text-primary"
                  >
                    <span className="text-2xl leading-none">+</span>
                  </label>
                )}
              </div>
              {isUploading && <p className="mt-3 text-sm text-muted-foreground">Uploading...</p>}
              {uploadError && <p className="mt-3 text-sm text-destructive">{uploadError}</p>}
              <p className="mt-3 text-xs text-muted-foreground">{images.length}/{MAX_IMAGES} images · JPG, PNG, WEBP, GIF · max 5 MB each</p>
            </FormSection>
          ) : null}
        </div>

        <div className="space-y-6 xl:sticky xl:top-6 xl:h-fit">
          <SurfaceSection>
            <SectionHeader>
              <div>
                <SectionTitle>Product readiness</SectionTitle>
                <SectionDescription>{formSummary}</SectionDescription>
              </div>
            </SectionHeader>
            <div className="mt-5 space-y-3">
              {[
                { label: "Product name", complete: Boolean(name.trim()) },
                { label: "Price", complete: Boolean(price.trim()) },
                { label: "Stock quantity", complete: Boolean(stock.trim()) },
                { label: "Category", complete: Boolean(categoryId) },
              ].map((item) => (
                <div key={item.label} className="flex items-center gap-3 text-sm">
                  <span className={`flex size-5 items-center justify-center ${item.complete ? "bg-success/15 text-success" : "bg-muted text-muted-foreground"}`}>
                    {item.complete ? <Check className="size-3" /> : null}
                  </span>
                  <span className={item.complete ? "text-foreground" : "text-muted-foreground"}>{item.label}</span>
                </div>
              ))}
            </div>
          </SurfaceSection>

          <SurfaceSection className="hidden xl:block">
            <p className="text-sm font-medium text-foreground">Save changes</p>
            <p className="mt-2 text-sm leading-6 text-muted-foreground">The product will use the availability setting chosen above.</p>
            <div className="mt-5 flex gap-2">
              <Button type="button" variant="outline" className="flex-1" onClick={() => router.push("/dashboard/products")}>Cancel</Button>
              <Button type="submit" className="flex-1" disabled={isSaving}>
                <Save className="size-4" />
                {isSaving ? "Saving..." : isEditing ? "Save changes" : "Create product"}
              </Button>
            </div>
          </SurfaceSection>
        </div>

        <MobileStickyActions className="flex gap-2 xl:hidden">
          <Button type="button" variant="outline" className="flex-1" onClick={() => router.push("/dashboard/products")}>Cancel</Button>
          <Button type="submit" className="flex-1" disabled={isSaving}>
            <Save className="size-4" />
            {isSaving ? "Saving..." : isEditing ? "Save changes" : "Create product"}
          </Button>
        </MobileStickyActions>
      </form>
    </PageFrame>
  );
}
