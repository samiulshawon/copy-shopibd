"use client";

import React, { useState } from "react";
import { productApi } from "@/lib/api";
import type { BulkProductItem } from "@/types/product";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { isPlanLimitError, getPlanLimitMessage } from "@/lib/utils";
import { Plus, Trash2, Loader2 } from "lucide-react";

interface BulkAddFormProps {
  shopId: number;
  onSuccess: () => void;
  onCancel: () => void;
}

const INITIAL_ROWS = 5;

interface RowData {
  name: string;
  price: string;
  stock: string;
  category_id: string;
}

function emptyRow(): RowData {
  return { name: "", price: "", stock: "0", category_id: "" };
}

export function BulkAddForm({ shopId, onSuccess, onCancel }: BulkAddFormProps) {
  const { toast } = useToast();
  const [rows, setRows] = useState<RowData[]>(() =>
    Array.from({ length: INITIAL_ROWS }, () => emptyRow()),
  );
  const [isSubmitting, setIsSubmitting] = useState(false);

  const updateRow = (index: number, field: keyof RowData, value: string) => {
    setRows((prev) => {
      const next = [...prev];
      next[index] = { ...next[index], [field]: value };
      return next;
    });
  };

  const addRow = () => {
    setRows((prev) => [...prev, emptyRow()]);
  };

  const removeRow = (index: number) => {
    setRows((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async () => {
    // Filter out empty rows
    const validRows = rows.filter((r) => r.name.trim() !== "");
    if (validRows.length === 0) {
      toast({
        message: "Error",
        description: "Please add at least one product with a name",
        variant: "error",
      });
      return;
    }

    setIsSubmitting(true);
    try {
      const products: BulkProductItem[] = validRows.map((r) => ({
        name: r.name.trim(),
        price: parseFloat(r.price) || 0,
        stock: parseInt(r.stock, 10) || 0,
        category_id: r.category_id ? parseInt(r.category_id, 10) : undefined,
      }));

      const response = await productApi.bulkCreate(products, shopId);
      const result = response.data;

      toast({
        message: "Success",
        description: `${result.created} product(s) created${
          result.failed.length > 0
            ? `, ${result.failed.length} failed`
            : ""
        }`,
        variant: result.failed.length > 0 ? "warning" : "success",
      });

      if (result.created > 0) {
        onSuccess();
      }
    } catch (error: any) {
      if (isPlanLimitError(error)) {
        toast({
          message: "Plan limit reached",
          description: getPlanLimitMessage(
            error,
            "You've reached your plan's product limit. Upgrade to create more products.",
          ),
          variant: "error",
          duration: 8000,
        });
      } else {
        toast({
          message: "Error",
          description: error?.response?.data?.detail || "Failed to create products",
          variant: "error",
        });
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Table header */}
      <div className="grid grid-cols-12 gap-3 px-1 text-sm font-medium text-muted-foreground">
        <div className="col-span-5">Name *</div>
        <div className="col-span-2">Price</div>
        <div className="col-span-2">Stock</div>
        <div className="col-span-2">Category ID</div>
        <div className="col-span-1" />
      </div>

      {/* Rows */}
      <div className="max-h-96 space-y-2 overflow-y-auto">
        {rows.map((row, index) => (
          <div key={index} className="grid grid-cols-12 items-center gap-3">
            <div className="col-span-5">
              <Input
                placeholder="Product name"
                value={row.name}
                onChange={(e) => updateRow(index, "name", e.target.value)}
              />
            </div>
            <div className="col-span-2">
              <Input
                type="number"
                step="0.01"
                min="0"
                placeholder="0.00"
                value={row.price}
                onChange={(e) => updateRow(index, "price", e.target.value)}
              />
            </div>
            <div className="col-span-2">
              <Input
                type="number"
                min="0"
                placeholder="0"
                value={row.stock}
                onChange={(e) => updateRow(index, "stock", e.target.value)}
              />
            </div>
            <div className="col-span-2">
              <Input
                type="number"
                min="0"
                placeholder="Category ID"
                value={row.category_id}
                onChange={(e) => updateRow(index, "category_id", e.target.value)}
              />
            </div>
            <div className="col-span-1 flex justify-center">
              <Button
                variant="ghost"
                size="icon"
                className="size-8 text-destructive"
                aria-label="Remove row"
                onClick={() => removeRow(index)}
                disabled={rows.length <= 1}
              >
                <Trash2 className="size-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>

      {/* Add Row Button */}
      <Button variant="outline" size="sm" onClick={addRow} className="w-full">
        <Plus className="mr-2 size-4" />
        Add Row
      </Button>

      {/* Footer */}
      <div className="flex justify-end gap-2 border-t pt-4">
        <Button variant="outline" onClick={onCancel} disabled={isSubmitting}>
          Cancel
        </Button>
        <Button onClick={handleSubmit} disabled={isSubmitting}>
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 size-4 animate-spin" />
              Creating...
            </>
          ) : (
            `Create ${rows.filter((r) => r.name.trim()).length || 0} Products`
          )}
        </Button>
      </div>
    </div>
  );
}
