"use client";

import React from "react";
import { Badge } from "@/components/ui/badge";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface PlanBadgeProps {
  plan: string;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const planVariant = (plan: string) => {
  switch (plan) {
    case "enterprise":
      return "default" as const;
    case "business":
      return "info" as const;
    case "starter":
      return "secondary" as const;
    case "free":
    default:
      return "outline" as const;
  }
};

const planLabel = (plan: string) => {
  switch (plan) {
    case "enterprise":
      return "Enterprise";
    case "business":
      return "Business";
    case "starter":
      return "Starter";
    case "free":
    default:
      return "Free";
  }
};

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export function PlanBadge({ plan }: PlanBadgeProps) {
  return (
    <Badge variant={planVariant(plan)} className="text-xs">
      {planLabel(plan)} Plan
    </Badge>
  );
}
