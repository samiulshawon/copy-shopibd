import { cn } from "@/lib/utils";

export function Skeleton({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div aria-hidden="true" className={cn("skeleton-shimmer animate-shimmer border border-border/40 bg-muted", className)} {...props} />;
}

export function SkeletonCard() {
  return (
    <div aria-hidden="true" className="border border-border bg-background p-5">
      <Skeleton className="h-[200px] w-full" />
      <div className="mt-4 space-y-2"><Skeleton className="h-4 w-3/4" /><Skeleton className="h-4 w-1/2" /></div>
    </div>
  );
}

export function SkeletonTableRow({ columns = 4 }: { columns?: number }) {
  return <div aria-hidden="true" className="flex items-center gap-4 border-b border-border py-4">{Array.from({ length: columns }).map((_, index) => <Skeleton key={index} className="h-4 flex-1" />)}</div>;
}

export function SkeletonAvatar() {
  return <div aria-hidden="true" className="flex items-center gap-4"><Skeleton className="size-10" /><div className="space-y-2"><Skeleton className="h-4 w-[200px]" /><Skeleton className="h-4 w-[150px]" /></div></div>;
}
