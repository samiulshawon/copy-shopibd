"use client";

import { cn } from "@/lib/utils";
import { useState } from "react";

interface StarRatingProps {
  /** Current rating value (0–5). Supports half stars for display. */
  value: number;
  /** Maximum number of stars (default 5). */
  max?: number;
  /** If true, user can click to set a rating. */
  interactive?: boolean;
  /** Called when user clicks a star (interactive only). */
  onChange?: (rating: number) => void;
  /** Show the numeric value next to stars. */
  showValue?: boolean;
  /** Additional CSS classes. */
  className?: string;
  /** Size variant. */
  size?: "sm" | "md" | "lg";
}

const sizeClasses = {
  sm: "h-3.5 w-3.5",
  md: "h-5 w-5",
  lg: "h-7 w-7",
};

/**
 * StarRating — renders a row of stars (filled, half, or empty).
 *
 * - **Interactive mode**: click any star to select rating 1–5.
 * - **Readonly mode**: displays the current value (supports half stars).
 *
 * Accessible via aria-label and role="radiogroup" in interactive mode.
 */
export function StarRating({
  value,
  max = 5,
  interactive = false,
  onChange,
  showValue = false,
  className,
  size = "md",
}: StarRatingProps) {
  const [hovered, setHovered] = useState<number | null>(null);

  const displayValue = hovered ?? value;

  function handleClick(star: number) {
    if (interactive && onChange) {
      onChange(star);
    }
  }

  function handleKeyDown(e: React.KeyboardEvent, star: number) {
    if (!interactive) return;
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      handleClick(star);
    }
  }

  const stars = Array.from({ length: max }, (_, i) => i + 1);

  return (
    <div
      className={cn("inline-flex items-center gap-0.5", className)}
      role={interactive ? "radiogroup" : "img"}
      aria-label={
        interactive
          ? `Rating: ${value} out of ${max} stars`
          : `${value} out of ${max} stars`
      }
    >
      {stars.map((star) => {
        const filled = displayValue >= star;
        const half = !filled && displayValue >= star - 0.5;

        return (
          <button
            key={star}
            type="button"
            disabled={!interactive}
            role={interactive ? "radio" : undefined}
            aria-checked={interactive ? star === Math.round(value) : undefined}
            aria-label={interactive ? `${star} star${star > 1 ? "s" : ""}` : undefined}
            tabIndex={interactive ? 0 : -1}
            onMouseEnter={() => interactive && setHovered(star)}
            onMouseLeave={() => interactive && setHovered(null)}
            onClick={() => handleClick(star)}
            onKeyDown={(e) => handleKeyDown(e, star)}
            className={cn(
              "transition-colors",
              interactive
                ? "cursor-pointer transition-transform hover:scale-105 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
                : "cursor-default",
            )}
          >
            {filled ? (
              <StarFilled className={sizeClasses[size]} />
            ) : half ? (
              <StarHalf className={sizeClasses[size]} />
            ) : (
              <StarEmpty className={sizeClasses[size]} />
            )}
          </button>
        );
      })}
      {showValue && (
        <span className="ml-1.5 text-sm font-medium text-muted-foreground">
          {value.toFixed(1)}
        </span>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  SVG star glyphs                                                    */
/* ------------------------------------------------------------------ */

function StarFilled({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="currentColor"
      className={cn("text-warning", className)}
      aria-hidden="true"
    >
      <path
        fillRule="evenodd"
        d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.006 5.404.434c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.434 2.082-5.005Z"
        clipRule="evenodd"
      />
    </svg>
  );
}

function StarHalf({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      className={cn("text-warning", className)}
      aria-hidden="true"
    >
      <path
        fill="currentColor"
        fillRule="evenodd"
        d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.006 5.404.434c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.434 2.082-5.005Z"
        clipRule="evenodd"
      />
    </svg>
  );
}

function StarEmpty({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      className={cn("text-muted-foreground/50", className)}
      aria-hidden="true"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        d="M11.48 3.499a.562.562 0 0 1 1.04 0l2.125 5.111a.563.563 0 0 0 .475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 0 0-.182.557l1.285 5.385a.562.562 0 0 1-.84.61l-4.725-2.885a.562.562 0 0 0-.586 0L6.982 20.54a.562.562 0 0 1-.84-.61l1.285-5.386a.562.562 0 0 0-.182-.557l-4.204-3.602a.562.562 0 0 1 .321-.988l5.518-.442a.563.563 0 0 0 .475-.345L11.48 3.5Z"
      />
    </svg>
  );
}
