"use client";

import * as React from "react";
import { X } from "lucide-react";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { cn } from "@/lib/utils";

const Dialog = DialogPrimitive.Root;
const DialogTrigger = DialogPrimitive.Trigger;
const DialogPortal = DialogPrimitive.Portal;
const DialogClose = DialogPrimitive.Close;

const DialogOverlay = React.forwardRef<React.ElementRef<typeof DialogPrimitive.Overlay>, React.ComponentPropsWithoutRef<typeof DialogPrimitive.Overlay>>(
  ({ className, ...props }, ref) => <DialogPrimitive.Overlay ref={ref} className={cn("fixed inset-0 z-50 bg-black/70 data-[state=closed]:opacity-0 data-[state=open]:opacity-100 data-[state=closed]:transition-opacity data-[state=open]:transition-opacity", className)} {...props} />,
);
DialogOverlay.displayName = DialogPrimitive.Overlay.displayName;

const CloseButton = () => <DialogPrimitive.Close className="absolute right-4 top-4 p-1 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"><X className="size-4" /><span className="sr-only">Close</span></DialogPrimitive.Close>;

const DialogContent = React.forwardRef<React.ElementRef<typeof DialogPrimitive.Content>, React.ComponentPropsWithoutRef<typeof DialogPrimitive.Content>>(
  ({ className, children, ...props }, ref) => <DialogPortal><DialogOverlay /><DialogPrimitive.Content ref={ref} className={cn("fixed left-1/2 top-1/2 z-50 grid w-[calc(100%-2rem)] max-w-lg -translate-x-1/2 -translate-y-1/2 gap-4 border border-foreground bg-popover p-5 text-popover-foreground transition-[opacity,transform] duration-150 data-[state=closed]:translate-y-[calc(-50%+4px)] data-[state=closed]:opacity-0 data-[state=open]:opacity-100 sm:p-6", className)} {...props}>{children}<CloseButton /></DialogPrimitive.Content></DialogPortal>,
);
DialogContent.displayName = DialogPrimitive.Content.displayName;

const DialogHeader = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => <div className={cn("flex flex-col gap-1.5 text-left", className)} {...props} />;
const DialogFooter = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => <div className={cn("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className)} {...props} />;
const DialogTitle = React.forwardRef<React.ElementRef<typeof DialogPrimitive.Title>, React.ComponentPropsWithoutRef<typeof DialogPrimitive.Title>>(({ className, ...props }, ref) => <DialogPrimitive.Title ref={ref} className={cn("pr-8 text-lg font-semibold tracking-tight", className)} {...props} />);
const DialogDescription = React.forwardRef<React.ElementRef<typeof DialogPrimitive.Description>, React.ComponentPropsWithoutRef<typeof DialogPrimitive.Description>>(({ className, ...props }, ref) => <DialogPrimitive.Description ref={ref} className={cn("text-sm leading-6 text-muted-foreground", className)} {...props} />);
DialogHeader.displayName = "DialogHeader";
DialogFooter.displayName = "DialogFooter";
DialogTitle.displayName = DialogPrimitive.Title.displayName;
DialogDescription.displayName = DialogPrimitive.Description.displayName;

function Sheet({ open, onOpenChange, children }: { open?: boolean; onOpenChange?: (open: boolean) => void; children: React.ReactNode }) { return <Dialog open={open} onOpenChange={onOpenChange}>{children}</Dialog>; }
function SheetTrigger({ children, asChild, ...props }: { children: React.ReactNode; asChild?: boolean; onClick?: () => void }) { return <DialogTrigger asChild={asChild} {...props}>{children}</DialogTrigger>; }
function SheetClose({ children, asChild, ...props }: { children: React.ReactNode; asChild?: boolean; onClick?: () => void }) { return <DialogClose asChild={asChild} {...props}>{children}</DialogClose>; }

const SheetContent = React.forwardRef<React.ElementRef<typeof DialogPrimitive.Content>, React.ComponentPropsWithoutRef<typeof DialogPrimitive.Content> & { side?: "top" | "bottom" | "left" | "right" }>(
  ({ className, children, side = "right", ...props }, ref) => <DialogPortal><DialogOverlay /><DialogPrimitive.Content ref={ref} className={cn("fixed z-50 gap-4 border border-foreground bg-popover p-5 text-popover-foreground transition-transform duration-150 ease-premium sm:p-6", side === "top" && "inset-x-0 top-0 data-[state=closed]:-translate-y-full data-[state=open]:translate-y-0", side === "bottom" && "inset-x-0 bottom-0 data-[state=closed]:translate-y-full data-[state=open]:translate-y-0", side === "left" && "inset-y-0 left-0 h-full w-[88vw] data-[state=closed]:-translate-x-full data-[state=open]:translate-x-0 sm:max-w-sm", side === "right" && "inset-y-0 right-0 h-full w-[88vw] data-[state=closed]:translate-x-full data-[state=open]:translate-x-0 sm:max-w-sm", className)} {...props}>{children}<CloseButton /></DialogPrimitive.Content></DialogPortal>,
);
SheetContent.displayName = "SheetContent";

export { Dialog, DialogPortal, DialogOverlay, DialogClose, DialogTrigger, DialogContent, DialogHeader, DialogFooter, DialogTitle, DialogDescription, Sheet, SheetTrigger, SheetClose, SheetContent };
