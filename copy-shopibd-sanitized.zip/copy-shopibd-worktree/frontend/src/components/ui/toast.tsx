"use client";

import * as React from "react";
import { X } from "lucide-react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";
import { useToast, type Toast as ToastType } from "@/hooks/use-toast";

const toastVariants = cva(
  "animate-slide-in-right group pointer-events-auto relative flex w-full items-start justify-between gap-4 overflow-hidden border border-border bg-background p-4 pr-10 text-foreground transition-[opacity,transform] duration-150 data-[state=closed]:translate-x-full data-[swipe=cancel]:translate-x-0 data-[swipe=end]:translate-x-[var(--radix-toast-swipe-end-x)] data-[swipe=move]:translate-x-[var(--radix-toast-swipe-move-x)] data-[state=closed]:opacity-0 data-[swipe=move]:transition-none",
  {
    variants: {
      variant: {
        default: "border-foreground",
        success: "border-success bg-success/10",
        error: "border-destructive bg-destructive/10",
        warning: "border-warning bg-warning/10",
        info: "border-info bg-info/10",
      },
    },
    defaultVariants: { variant: "default" },
  },
);

interface ToastViewportProps { className?: string; children?: React.ReactNode; }
function ToastViewport({ className, children }: ToastViewportProps) {
  return <div className={cn("fixed bottom-0 right-0 z-[100] flex max-h-screen w-full flex-col-reverse gap-2 p-4 sm:max-w-[420px]", className)}>{children}</div>;
}

interface ToastRootProps extends React.HTMLAttributes<HTMLDivElement>, VariantProps<typeof toastVariants> { toastItem: ToastType; }
function ToastRoot({ className, variant, toastItem, ...props }: ToastRootProps) {
  const duration = toastItem.duration ?? 4000;
  const resolvedVariant = toastItem.variant || variant || "default";

  return (
    <div className={cn(toastVariants({ variant: resolvedVariant }), className)} data-testid="toast" {...props}>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold">{toastItem.message}</p>
        {toastItem.description ? <p className="text-current/80 mt-1 text-xs leading-5">{toastItem.description}</p> : null}
      </div>
      <button
        type="button"
        onClick={() => window.dispatchEvent(new CustomEvent("dismiss-toast", { detail: toastItem.id }))}
        className="text-current/70 absolute right-2 top-2 p-1 opacity-0 transition-opacity hover:text-current focus:opacity-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring group-hover:opacity-100"
      >
        <X className="size-4" />
        <span className="sr-only">Dismiss</span>
      </button>
      {duration > 0 ? (
        <span
          aria-hidden="true"
          className="absolute bottom-0 left-0 h-0.5 w-full origin-left bg-current"
          style={{ animation: `toast-progress ${duration}ms linear forwards` }}
        />
      ) : null}
    </div>
  );
}

export function ToastContainer() {
  const { toasts, dismiss } = useToast();
  React.useEffect(() => {
    const handler = (event: Event) => dismiss((event as CustomEvent<string>).detail);
    window.addEventListener("dismiss-toast", handler);
    return () => window.removeEventListener("dismiss-toast", handler);
  }, [dismiss]);

  if (toasts.length === 0) return null;
  return <ToastViewport>{toasts.map((toast) => <ToastRoot key={toast.id} toastItem={toast} />)}</ToastViewport>;
}

export { toastVariants, ToastViewport, ToastRoot };
