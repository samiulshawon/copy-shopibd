import * as React from "react";
import { cn } from "@/lib/utils";

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  icon?: React.ReactNode;
}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, type, icon, ...props }, ref) => (
    <div className="relative">
      {icon ? (
        <div className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
          {icon}
        </div>
      ) : null}
      <input
        type={type}
        className={cn(
          "flex h-10 w-full border border-input bg-background px-3 py-2 text-sm text-foreground transition-[border-color,background-color,color] duration-150 placeholder:text-muted-foreground focus-visible:border-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring disabled:cursor-not-allowed disabled:bg-muted disabled:opacity-60 file:mr-3 file:border-0 file:bg-transparent file:text-sm file:font-semibold file:text-foreground",
          icon && "pl-10",
          className,
        )}
        ref={ref}
        {...props}
      />
    </div>
  ),
);
Input.displayName = "Input";

export { Input };
