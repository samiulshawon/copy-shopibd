import Link from "next/link";

interface StorefrontFooterProps {
  shopName?: string;
}

export function StorefrontFooter({ shopName }: StorefrontFooterProps) {
  const year = new Date().getFullYear();

  return (
    <footer className="mt-12 border-t border-foreground bg-background">
      <div className="mx-auto w-full max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center justify-between gap-3 sm:flex-row">
          <p className="text-sm text-muted-foreground">
            &copy; {year} {shopName ? `${shopName} · ` : ""}
            <span className="font-medium text-foreground">Powered by ShopiBD</span>
          </p>
          <nav aria-label="Storefront navigation" className="flex flex-wrap items-center justify-center gap-4 text-sm">
            <Link
              href="/"
              className="text-muted-foreground transition-colors hover:text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
            >
              ShopiBD
            </Link>
          </nav>
        </div>
      </div>
    </footer>
  );
}
