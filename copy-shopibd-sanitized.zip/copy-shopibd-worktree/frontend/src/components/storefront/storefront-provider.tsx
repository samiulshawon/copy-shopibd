"use client";

import { createContext, useContext, useState, useEffect, type ReactNode } from "react";
import type { StorefrontShop } from "@/types/shop";
import { storefrontApi } from "@/lib/api";

interface StorefrontContextValue {
  shop: StorefrontShop | null;
  loading: boolean;
  error: string | null;
  slug: string;
}

const StorefrontContext = createContext<StorefrontContextValue | null>(null);

export function useStorefront() {
  const ctx = useContext(StorefrontContext);
  if (!ctx) {
    throw new Error("useStorefront must be used within StorefrontProvider");
  }
  return ctx;
}

interface StorefrontProviderProps {
  slug: string;
  children: ReactNode;
}

export function StorefrontProvider({ slug, children }: StorefrontProviderProps) {
  const [shop, setShop] = useState<StorefrontShop | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function loadShop() {
      setLoading(true);
      setError(null);
      try {
        const response = await storefrontApi.getShop(slug);
        if (!cancelled) {
          setShop(response.data);
        }
      } catch (err: unknown) {
        if (!cancelled) {
          const status = (err as { response?: { status?: number } })?.response?.status;
          if (status === 404) {
            setError("Shop not found");
          } else {
            setError("Failed to load shop. Please try again later.");
          }
          setShop(null);
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    loadShop();

    return () => {
      cancelled = true;
    };
  }, [slug]);

  return (
    <StorefrontContext.Provider value={{ shop, loading, error, slug }}>
      {children}
    </StorefrontContext.Provider>
  );
}
