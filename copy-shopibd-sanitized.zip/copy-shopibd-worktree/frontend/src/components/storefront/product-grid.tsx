"use client";

import { Filter, Package, Search, SlidersHorizontal, X } from "lucide-react";
import { useMemo, useState } from "react";
import type { StorefrontShop, StorefrontProduct } from "@/types/shop";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetTrigger, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { ProductCard } from "./product-card";

type SortOrder = "featured" | "price-low" | "price-high" | "name";

interface ProductGridProps { shop: StorefrontShop; }

export function ProductGrid({ shop }: ProductGridProps) {
  const [query, setQuery] = useState("");
  const [showSoldOut, setShowSoldOut] = useState(true);
  const [sort, setSort] = useState<SortOrder>("featured");
  const [filtersOpen, setFiltersOpen] = useState(false);

  const filteredProducts = useMemo<StorefrontProduct[]>(() => {
    const normalizedQuery = query.trim().toLowerCase();
    const products = shop.products.filter((product) => {
      if (!product.is_active || (!showSoldOut && product.stock <= 0)) return false;
      return !normalizedQuery || [product.name, product.sku, product.description].filter(Boolean).some((value) => value!.toLowerCase().includes(normalizedQuery));
    });

    return [...products].sort((a, b) => {
      if (sort === "price-low") return Number(a.price) - Number(b.price);
      if (sort === "price-high") return Number(b.price) - Number(a.price);
      if (sort === "name") return a.name.localeCompare(b.name);
      return 0;
    });
  }, [query, shop.products, showSoldOut, sort]);

  const hasFilters = Boolean(query.trim()) || !showSoldOut || sort !== "featured";
  const resetFilters = () => { setQuery(""); setShowSoldOut(true); setSort("featured"); setFiltersOpen(false); };

  const controls = (
    <div className="space-y-5">
      <div className="space-y-2"><label htmlFor="storefront-sort" className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">Sort catalog</label><select id="storefront-sort" className="h-10 w-full border border-input bg-background px-3 text-sm" value={sort} onChange={(event) => setSort(event.target.value as SortOrder)}><option value="featured">Featured</option><option value="price-low">Price: low to high</option><option value="price-high">Price: high to low</option><option value="name">Name: A to Z</option></select></div>
      <label className="flex cursor-pointer items-center justify-between gap-3 border border-border p-3 text-sm"><span><span className="block font-semibold">Availability</span><span className="mt-1 block text-xs text-muted-foreground">Include out-of-stock products</span></span><input type="checkbox" checked={showSoldOut} onChange={(event) => setShowSoldOut(event.target.checked)} className="size-4 accent-primary" /></label>
      {hasFilters ? <Button type="button" variant="outline" className="w-full" onClick={resetFilters}><X className="size-4" />Reset filters</Button> : null}
    </div>
  );

  return (
    <section className="mx-auto max-w-7xl px-4 pb-28 pt-10 sm:px-6 sm:pt-12" aria-labelledby="catalog-heading">
      <div className="border-b border-foreground pb-5 sm:flex sm:items-end sm:justify-between">
        <div>
          <div className="flex items-baseline gap-3">
            <h2 id="catalog-heading" className="text-2xl font-bold tracking-tight sm:text-3xl">Products</h2>
            <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">{shop.products.length} products</span>
          </div>
          <p className="mt-2 text-sm text-muted-foreground" aria-live="polite">{filteredProducts.length} of {shop.products.length} shown</p>
        </div>
        <div className="mt-5 flex gap-2 sm:mt-0"><div className="relative min-w-0 flex-1 sm:w-72"><Search aria-hidden="true" className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" /><label htmlFor="storefront-product-search" className="sr-only">Search products</label><Input id="storefront-product-search" className="pl-9" placeholder="Search catalog" value={query} onChange={(event) => setQuery(event.target.value)} /></div><Sheet open={filtersOpen} onOpenChange={setFiltersOpen}><SheetTrigger asChild><Button variant="outline" size="icon" aria-label="Open catalog filters"><SlidersHorizontal className="size-4" /></Button></SheetTrigger><SheetContent side="right" className="w-[min(100vw,360px)]">
              <DialogTitle className="sr-only">Catalog controls</DialogTitle>
              <DialogDescription className="sr-only">Filter, sort, and search the product catalog.</DialogDescription>
              <p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">Catalog controls</p><h3 className="mt-2 text-xl font-semibold">Filter and sort</h3><div className="mt-6">{controls}</div></SheetContent></Sheet></div>
      </div>
      {hasFilters ? <div className="mt-4 flex items-center justify-between border border-border bg-muted px-3 py-2 text-xs"><span>{query ? `Search: “${query}”` : "Catalog controls active"}</span><Button variant="link" size="sm" onClick={resetFilters}>Clear</Button></div> : null}
      {filteredProducts.length === 0 ? <div className="mt-6 flex flex-col items-center border border-dashed border-border px-6 py-14 text-center"><Package className="size-6" /><h3 className="mt-4 font-semibold">No products match these controls</h3><p className="mt-2 max-w-sm text-sm text-muted-foreground">Try a different search or reset the availability and sorting choices.</p><Button className="mt-5" variant="outline" onClick={resetFilters}>Reset catalog</Button></div> : <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4">{filteredProducts.map((product) => <ProductCard key={product.id} product={product} shopSlug={shop.slug} compact />)}</div>}
    </section>
  );
}
