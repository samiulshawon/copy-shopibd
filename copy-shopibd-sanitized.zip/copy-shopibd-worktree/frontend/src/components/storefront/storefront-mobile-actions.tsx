"use client";

import { MessageCircle, Phone, ShoppingBag } from "lucide-react";
import type { StorefrontShop } from "@/types/shop";
import { cn } from "@/lib/utils";

interface StorefrontMobileActionsProps { shop: StorefrontShop; className?: string; }

export function StorefrontMobileActions({ shop, className }: StorefrontMobileActionsProps) {
  const phone = shop.contact_phone;
  const message = encodeURIComponent(`Hi ${shop.name}, I'd like to know more about your products.`);
  const whatsappHref = phone ? `https://wa.me/${phone.replace(/[^0-9]/g, "")}?text=${message}` : undefined;

  return <nav aria-label="Storefront actions" className={cn("fixed inset-x-0 bottom-0 z-40 border-t border-foreground bg-background px-3 py-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))] sm:hidden", className)}><div className="mx-auto grid max-w-md grid-cols-3 gap-2">{phone ? <a href={`tel:${phone}`} className="flex min-h-[44px] items-center justify-center gap-1.5 border border-border px-2 text-xs font-semibold focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"><Phone className="size-4" />Call</a> : <span className="flex min-h-[44px] items-center justify-center gap-1.5 border border-border px-2 text-xs text-muted-foreground"><Phone className="size-4" />Call</span>}{whatsappHref ? <a href={whatsappHref} target="_blank" rel="noopener noreferrer" className="flex min-h-[44px] items-center justify-center gap-1.5 border border-border px-2 text-xs font-semibold focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"><MessageCircle className="size-4" />Message</a> : <span className="flex min-h-[44px] items-center justify-center gap-1.5 border border-border px-2 text-xs text-muted-foreground"><MessageCircle className="size-4" />Message</span>}<a href="#products" className="flex min-h-[44px] items-center justify-center gap-1.5 bg-foreground px-2 text-xs font-semibold text-primary-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"><ShoppingBag className="size-4" />Products</a></div></nav>;
}
