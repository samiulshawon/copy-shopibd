"use client";

import Image from "next/image";
import Link from "next/link";
import { Package } from "lucide-react";
import type { StorefrontProduct } from "@/types/shop";
import { cn } from "@/lib/utils";

interface ProductCardProps { product: StorefrontProduct; shopSlug: string; compact?: boolean; }

export function ProductCard({ product, shopSlug, compact }: ProductCardProps) {
  const inStock = product.stock > 0;
  const lowStock = inStock && product.stock <= 5;

  return <Link href={`/${shopSlug}/products/${product.id}`} aria-label={`View ${product.name} — ৳${product.price.toLocaleString()}`} className={cn("group flex flex-col border border-border bg-background transition-[border-color,opacity] duration-150 hover:border-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring", !inStock && "opacity-70")}>
    <div className="relative aspect-[2/3] overflow-hidden bg-muted">
      {product.primary_image_url ? (
        <>
          <Image src={product.primary_image_url} alt={product.name} fill sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw" className={cn("object-cover transition-opacity duration-300", product.secondary_image_url ? "group-hover:opacity-0" : "transition-transform duration-300 group-hover:scale-[1.02]")} />
          {product.secondary_image_url ? (
            <Image src={product.secondary_image_url} alt={`${product.name} alternate view`} fill sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw" className="absolute inset-0 object-cover opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
          ) : null}
        </>
      ) : (
        <div className="flex size-full items-center justify-center text-muted-foreground"><Package className="size-9" /></div>
      )}
      {!inStock ? <span className="absolute left-0 top-0 border-b border-r border-destructive bg-destructive px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.08em] text-destructive-foreground">Sold out</span> : lowStock ? <span className="absolute left-0 top-0 border-b border-r border-warning bg-warning/15 px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.08em]">Only {product.stock} left</span> : null}
    </div>
    <div className={cn("flex flex-1 flex-col gap-2 p-3", !compact && "sm:p-4")}><h3 className={cn("line-clamp-2 min-h-[2.5rem] font-semibold leading-snug text-foreground", compact ? "text-sm" : "text-base")}>{product.name}</h3><p className="mt-auto text-base font-bold tracking-tight">৳{product.price.toLocaleString()}</p>{inStock ? <span className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">View product</span> : null}</div>
  </Link>;
}
