"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { storefrontApi, couponApi } from "@/lib/api";
import type { StorefrontProduct } from "@/types/shop";
import type { CouponValidateResponse } from "@/types/coupon";
import { isPlanLimitError, getPlanLimitMessage } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Loader2, Copy, CheckCircle2, Tag, XCircle, Smartphone, Banknote } from "lucide-react";

interface OrderFormProps {
  product: StorefrontProduct;
  shopName: string;
  shopSlug: string;
  shopContactPhone: string;
  bkashNumber?: string;
  nagadNumber?: string;
}

interface FormState {
  buyer_name: string;
  buyer_phone: string;
  division: string;
  district: string;
  area: string;
  details: string;
  quantity: number;
  notes: string;
  payment_method: string;
}

const INITIAL_STATE: FormState = {
  buyer_name: "",
  buyer_phone: "",
  division: "",
  district: "",
  area: "",
  details: "",
  quantity: 1,
  notes: "",
  payment_method: "manual",
};

type PaymentMethod = "manual" | "bkash" | "nagad" | "cod";

const PAYMENT_METHODS: { value: PaymentMethod; label: string; icon: React.ReactNode }[] = [
  { value: "bkash", label: "bKash", icon: <Smartphone className="size-4" style={{ color: "#E2136E" }} /> },
  { value: "nagad", label: "Nagad", icon: <Smartphone className="size-4" style={{ color: "#F6891F" }} /> },
  { value: "manual", label: "Manual (Bank Transfer)", icon: <Banknote className="size-4 text-muted-foreground" /> },
  { value: "cod", label: "Cash on Delivery", icon: <Banknote className="size-4 text-muted-foreground" /> },
];

export function OrderForm({
  product,
  shopName,
  shopSlug,
  shopContactPhone,
  bkashNumber,
  nagadNumber,
}: OrderFormProps) {
  const router = useRouter();
  const [form, setForm] = useState<FormState>(INITIAL_STATE);
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);
  const [success, setSuccess] = useState<{
    orderNumber: string;
    total: number;
    phone: string;
    paymentMethod: string;
    paymentUrl?: string;
    paymentID?: string;
  } | null>(null);
  const [copied, setCopied] = useState(false);
  const [paymentProcessing, setPaymentProcessing] = useState(false);

  // Coupon state
  const [couponCode, setCouponCode] = useState("");
  const [couponValidating, setCouponValidating] = useState(false);
  const [couponResult, setCouponResult] = useState<CouponValidateResponse | null>(null);
  const [showCouponInput, setShowCouponInput] = useState(false);

  const baseTotal = product.price * form.quantity;
  const total = couponResult?.valid
    ? baseTotal - couponResult.discount_amount
    : baseTotal;

  function validate(): boolean {
    const next: Partial<Record<keyof FormState, string>> = {};

    if (!form.buyer_name.trim()) {
      next.buyer_name = "Buyer name is required";
    }

    const phone = form.buyer_phone.trim();
    if (!phone) {
      next.buyer_phone = "Phone number is required";
    } else if (!/^(?:\+880|01)[1-9]\d{8}$/.test(phone)) {
      next.buyer_phone = "Invalid BD phone. Use +880XXXXXXXXXX or 01XXXXXXXXX";
    }

    if (!form.division.trim()) next.division = "Division is required";
    if (!form.district.trim()) next.district = "District is required";
    if (!form.area.trim()) next.area = "Area is required";
    if (!form.details.trim()) next.details = "Address details are required";

    if (form.quantity < 1) {
      next.quantity = "Quantity must be at least 1";
    } else if (form.quantity > product.stock) {
      next.quantity = `Only ${product.stock} items available`;
    }

    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function handleApplyCoupon() {
    if (!couponCode.trim()) return;
    setCouponValidating(true);
    setCouponResult(null);
    try {
      const res = await couponApi.validate({
        code: couponCode.trim(),
        shop_slug: shopSlug,
        total_amount: baseTotal,
        product_ids: [product.id],
      });
      setCouponResult(res.data);
    } catch {
      setCouponResult({
        valid: false,
        discount_amount: 0,
        message: "Failed to validate coupon",
        coupon: null,
      });
    } finally {
      setCouponValidating(false);
    }
  }

  function handleRemoveCoupon() {
    setCouponCode("");
    setCouponResult(null);
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setServerError(null);
    if (!validate()) return;

    setSubmitting(true);
    try {
      const response = await storefrontApi.createOrder(shopSlug, {
        buyer_name: form.buyer_name.trim(),
        buyer_phone: form.buyer_phone.trim(),
        buyer_address: {
          division: form.division.trim(),
          district: form.district.trim(),
          area: form.area.trim(),
          details: form.details.trim(),
        },
        product_id: product.id,
        quantity: form.quantity,
        notes: form.notes.trim() || undefined,
        coupon_code: couponResult?.valid ? couponCode.trim().toUpperCase() : undefined,
        payment_method: form.payment_method || "manual",
      });

      const data = response.data as {
        order_number: string;
        total_amount: number;
        customer_phone: string;
        payment_method: string;
        payment_url?: string;
        paymentID?: string;
      };

      setSuccess({
        orderNumber: data.order_number,
        total: Number(data.total_amount),
        phone: data.customer_phone,
        paymentMethod: data.payment_method || "manual",
        paymentUrl: data.payment_url,
        paymentID: data.paymentID,
      });

      // If bKash/Nagad, redirect to payment URL
      if (data.payment_url && (data.payment_method === "bkash" || data.payment_method === "nagad")) {
        setPaymentProcessing(true);
        // Small delay to show confirmation before redirect
        setTimeout(() => {
          window.location.href = data.payment_url!;
        }, 1500);
      }
    } catch (err: unknown) {
      if (isPlanLimitError(err)) {
        const message = getPlanLimitMessage(
          err,
          "This shop has reached its monthly order limit. Please contact the shop owner to upgrade their plan.",
        );
        setServerError(message);
      } else {
        const message =
          (err as { response?: { data?: { detail?: string } } })?.response?.data
            ?.detail || "Failed to place order. Please try again.";
        setServerError(message);
      }
    } finally {
      setSubmitting(false);
    }
  }

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
    if (errors[key]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[key];
        return next;
      });
    }
  }

  async function copyPaymentDetails() {
    if (!success) return;
    const lines = [
      `Order: ${success.orderNumber}`,
      `Total: ৳${success.total.toFixed(2)}`,
      `bKash: ${bkashNumber || "N/A"}`,
      `Nagad: ${nagadNumber || "N/A"}`,
      `Reference: ${success.orderNumber}`,
    ];
    await navigator.clipboard.writeText(lines.join("\n"));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  function handlePayNow() {
    if (success?.paymentUrl) {
      window.location.href = success.paymentUrl;
    }
  }

  // -------------------------------------------------------------------
  // Success view
  // -------------------------------------------------------------------
  if (success) {
    const isBkash = success.paymentMethod === "bkash";
    const isNagad = success.paymentMethod === "nagad";
    const isOnline = isBkash || isNagad;

    return (
      <div className="mx-auto max-w-2xl space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-success">
              <CheckCircle2 className="size-6" />
              Order Confirmed
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <p className="text-sm text-muted-foreground">Order ID</p>
                <p className="font-mono font-semibold">{success.orderNumber}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Amount</p>
                <p className="font-semibold">৳{success.total.toFixed(2)}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Buyer Phone</p>
                <p className="font-medium">{success.phone}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Payment Method</p>
                <p className="font-medium capitalize">{success.paymentMethod}</p>
              </div>
            </div>

            {/* Payment status for online payments */}
            {isOnline && (
              <div className="border border-primary/30 bg-primary/10 p-4">
                <p className="mb-2 text-sm font-medium text-primary">
                  {paymentProcessing ? "Redirecting to payment..." : "Complete Payment"}
                </p>
                {paymentProcessing ? (
                  <div className="flex items-center gap-2 text-sm text-primary">
                    <Loader2 className="size-4 animate-spin" />
                    <span>Redirecting to {isBkash ? "bKash" : "Nagad"} checkout...</span>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <p className="text-sm text-foreground/80">
                      Click the button below to complete your payment via{" "}
                      {isBkash ? "bKash" : "Nagad"}.
                    </p>
                    {success.paymentUrl ? (
                      <Button
                        type="button"
                        className="w-full"
                        onClick={handlePayNow}
                      >
                        {isBkash ? "Pay with bKash" : "Pay with Nagad"}
                      </Button>
                    ) : (
                      <p className="text-sm text-destructive">
                        Payment URL unavailable. Please contact support.
                      </p>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Manual payment instructions */}
            {!isOnline && (
              <div className="border border-border bg-background p-4">
                <p className="mb-2 text-sm font-medium">Payment Instructions</p>
                <p className="text-sm text-muted-foreground">
                  Please send the exact amount to the number below and click &quot;I&apos;ve Paid&quot;.
                  Our team will verify and confirm your order.
                </p>
                <div className="mt-3 space-y-1 text-sm">
                  {bkashNumber && (
                    <p>
                      <span className="font-medium">bKash:</span> {bkashNumber}
                    </p>
                  )}
                  {nagadNumber && (
                    <p>
                      <span className="font-medium">Nagad:</span> {nagadNumber}
                    </p>
                  )}
                  {!bkashNumber && !nagadNumber && (
                    <p>Contact: {shopContactPhone}</p>
                  )}
                  <p>
                    <span className="font-medium">Reference:</span> {success.orderNumber}
                  </p>
                </div>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex flex-col gap-3 sm:flex-row">
            {!isOnline && (
              <Button
                type="button"
                variant="outline"
                className="w-full sm:w-auto"
                onClick={copyPaymentDetails}
              >
                {copied ? (
                  <>
                    <CheckCircle2 className="mr-2 size-4" />
                    Copied
                  </>
                ) : (
                  <>
                    <Copy className="mr-2 size-4" />
                    Copy Payment Details
                  </>
                )}
              </Button>
            )}
            <Button
              type="button"
              className="w-full sm:w-auto"
              onClick={() => router.push(`/${shopSlug}/order/success?order=${success.orderNumber}&product_id=${product.id}`)}
            >
              Track Order
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  // -------------------------------------------------------------------
  // Form view
  // -------------------------------------------------------------------
  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Place Order</h1>
        <p className="text-muted-foreground">
          {shopName} &bull; {product.name}
        </p>
      </div>

      {serverError && (
        <Alert variant="destructive">
          <AlertTitle>Order failed</AlertTitle>
          <AlertDescription>{serverError}</AlertDescription>
        </Alert>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Buyer Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium" htmlFor="buyer-name">Full name *</label>
              <Input
                id="buyer-name"
                autoComplete="name"
                aria-invalid={Boolean(errors.buyer_name)}
                aria-describedby={errors.buyer_name ? "buyer-name-error" : undefined}
                placeholder="আপনার নাম লিখুন"
                value={form.buyer_name}
                onChange={(e) => update("buyer_name", e.target.value)}
                disabled={submitting}
              />
              {errors.buyer_name && (
                <p id="buyer-name-error" className="text-sm text-destructive">{errors.buyer_name}</p>
              )}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium" htmlFor="buyer-phone">Phone number *</label>
              <Input
                id="buyer-phone"
                type="tel"
                inputMode="tel"
                autoComplete="tel"
                aria-invalid={Boolean(errors.buyer_phone)}
                aria-describedby={errors.buyer_phone ? "buyer-phone-error" : undefined}
                placeholder="+8801XXXXXXXXX"
                value={form.buyer_phone}
                onChange={(e) => update("buyer_phone", e.target.value)}
                disabled={submitting}
              />
              {errors.buyer_phone && (
                <p id="buyer-phone-error" className="text-sm text-destructive">{errors.buyer_phone}</p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Delivery Address</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <label className="text-sm font-medium" htmlFor="delivery-division">Division *</label>
                <Input
                  id="delivery-division"
                  autoComplete="address-level1"
                  aria-invalid={Boolean(errors.division)}
                  placeholder="ঢাকা"
                  value={form.division}
                  onChange={(e) => update("division", e.target.value)}
                  disabled={submitting}
                />
                {errors.division && (
                  <p className="text-sm text-destructive">{errors.division}</p>
                )}
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium" htmlFor="delivery-district">District *</label>
                <Input
                  id="delivery-district"
                  autoComplete="address-level2"
                  aria-invalid={Boolean(errors.district)}
                  placeholder="ঢাকা"
                  value={form.district}
                  onChange={(e) => update("district", e.target.value)}
                  disabled={submitting}
                />
                {errors.district && (
                  <p className="text-sm text-destructive">{errors.district}</p>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium" htmlFor="delivery-area">Area / Thana *</label>
              <Input
                id="delivery-area"
                autoComplete="address-level3"
                aria-invalid={Boolean(errors.area)}
                placeholder="মিরপুর"
                value={form.area}
                onChange={(e) => update("area", e.target.value)}
                disabled={submitting}
              />
              {errors.area && (
                <p className="text-sm text-destructive">{errors.area}</p>
              )}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium" htmlFor="delivery-details">Full address details *</label>
              <Input
                id="delivery-details"
                autoComplete="street-address"
                aria-invalid={Boolean(errors.details)}
                placeholder="রোড নং, হাউজ নং, etc."
                value={form.details}
                onChange={(e) => update("details", e.target.value)}
                disabled={submitting}
              />
              {errors.details && (
                <p className="text-sm text-destructive">{errors.details}</p>
              )}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium" htmlFor="order-notes">Notes (optional)</label>
              <Input
                id="order-notes"
                placeholder="Any special instructions?"
                value={form.notes}
                onChange={(e) => update("notes", e.target.value)}
                disabled={submitting}
              />
            </div>
          </CardContent>
        </Card>

        {/* Payment Method Selection */}
        <Card>
          <CardHeader>
            <CardTitle>Payment Method</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2" role="radiogroup" aria-label="Payment method">
              {PAYMENT_METHODS.map((method) => (
                <button
                  key={method.value}
                  type="button"
                  disabled={submitting}
                  role="radio"
                  aria-checked={form.payment_method === method.value}
                  aria-label={`Pay with ${method.label}`}
                  className={`flex items-center gap-3 border p-4 text-left transition-[border-color,background-color] hover:border-primary/50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring ${
                    form.payment_method === method.value
                      ? "border-primary bg-primary/10"
                      : "border-border"
                  }`}
                  onClick={() => update("payment_method", method.value)}
                >
                  {method.icon}
                  <div>
                    <p className="text-sm font-medium">{method.label}</p>
                  </div>
                </button>
              ))}
            </div>
            {form.payment_method === "bkash" && bkashNumber && (
              <p className="mt-2 text-xs text-muted-foreground">
                Pay via bKash Merchant: {bkashNumber}
              </p>
            )}
            {form.payment_method === "nagad" && nagadNumber && (
              <p className="mt-2 text-xs text-muted-foreground">
                Pay via Nagad Merchant: {nagadNumber}
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Order Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">{product.name}</p>
                <p className="text-sm text-muted-foreground">
                  ৳{product.price.toFixed(2)} each
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Stock</p>
                <p className="font-medium">{product.stock}</p>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="text-sm font-medium" htmlFor="order-quantity">Quantity</label>
              <Input
                id="order-quantity"
                aria-invalid={Boolean(errors.quantity)}
                type="number"
                min={1}
                max={product.stock}
                className="w-24"
                value={form.quantity}
                onChange={(e) => update("quantity", Number(e.target.value))}
                disabled={submitting}
              />
            </div>
            {errors.quantity && (
              <p className="text-sm text-destructive">{errors.quantity}</p>
            )}

            {/* Coupon Code */}
            <div className="border-t pt-3">
              <button
                type="button"
                className="flex items-center gap-1 text-sm text-primary hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
                aria-expanded={showCouponInput}
                aria-controls="coupon-entry"
                onClick={() => setShowCouponInput(!showCouponInput)}
              >
                <Tag className="size-3" />
                {showCouponInput ? "Hide coupon" : "Have a coupon code?"}
              </button>
              {showCouponInput && (
                <div id="coupon-entry" className="mt-2 flex items-center gap-2">
                  <Input
                    placeholder="Enter coupon code"
                    value={couponCode}
                    onChange={(e) => {
                      setCouponCode(e.target.value.toUpperCase());
                      if (couponResult) setCouponResult(null);
                    }}
                    disabled={couponValidating}
                    className="flex-1 uppercase"
                  />
                  {couponResult?.valid ? (
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={handleRemoveCoupon}
                      title="Remove coupon"
                      aria-label="Remove coupon"
                    >
                      <XCircle className="size-4 text-destructive" />
                    </Button>
                  ) : (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={handleApplyCoupon}
                      disabled={couponValidating || !couponCode.trim()}
                    >
                      {couponValidating ? (
                        <Loader2 className="size-3 animate-spin" />
                      ) : (
                        "Apply"
                      )}
                    </Button>
                  )}
                </div>
              )}
              {couponResult && !couponResult.valid && (
                <p className="mt-1 text-xs text-destructive">
                  {couponResult.message}
                </p>
              )}
              {couponResult?.valid && (
                <div className="mt-2 space-y-1">
                  <p className="text-xs text-success">
                    {couponResult.message}
                  </p>
                  <div className="flex items-center justify-between text-sm">
                    <span>Discount</span>
                    <span className="text-success">
                      -৳{couponResult.discount_amount.toFixed(2)}
                    </span>
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between border-t pt-3">
              <p className="font-semibold">Total</p>
              <p className="text-lg font-bold">
                ৳{total.toFixed(2)}
              </p>
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" className="w-full" disabled={submitting} aria-busy={submitting}>
              {submitting && <Loader2 className="mr-2 size-4 animate-spin" />}
              {submitting ? "Placing Order..." : "Place Order"}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </div>
  );
}
