"use client";

import { useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, History } from "lucide-react";
import { storefrontApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ProductCard } from "./product-card";
import type { StorefrontProduct, StorefrontShop } from "@/types/shop";

interface RecentEntry {
  id: number;
  viewedAt: string;
}

const MAX_RECENT = 6;

function storageKey(slug: string) {
  return `shopibd_recent_${slug}`;
}

function readRecent(slug: string): RecentEntry[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(storageKey(slug));
    const parsed: RecentEntry[] = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeRecent(slug: string, entries: RecentEntry[]) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(storageKey(slug), JSON.stringify(entries));
  } catch {
    // Ignore storage errors (e.g. private mode).
  }
}

interface RecentlyViewedRailProps {
  shop: StorefrontShop;
  currentProductId: number;
}

export function RecentlyViewedRail({ shop, currentProductId }: RecentlyViewedRailProps) {
  const slug = shop.slug;
  const railRef = useRef<HTMLDivElement>(null);
  const [items, setItems] = useState<StorefrontProduct[]>([]);
  const [loading, setLoading] = useState(true);

  // Record current product and load the stored history.
  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoading(true);

      // Update history first so the current product appears at the front.
      const history = readRecent(slug);
      const withoutCurrent = history.filter((entry) => entry.id !== currentProductId);
      const updated = [{ id: currentProductId, viewedAt: new Date().toISOString() }, ...withoutCurrent].slice(0, MAX_RECENT);
      writeRecent(slug, updated);

      const idsToFetch = updated
        .filter((entry) => entry.id !== currentProductId)
        .slice(0, MAX_RECENT - 1)
        .map((entry) => entry.id);

      if (idsToFetch.length === 0) {
        if (!cancelled) {
          setItems([]);
          setLoading(false);
        }
        return;
      }

      const results = await Promise.allSettled(
        idsToFetch.map((id) => storefrontApi.getProduct(slug, id).then((res) => res.data as StorefrontProduct)),
      );

      const products = results
        .filter((r): r is PromiseFulfilledResult<StorefrontProduct> => r.status === "fulfilled")
        .map((r) => r.value)
        .filter((p) => p && p.is_active);

      if (!cancelled) {
        setItems(products);
        setLoading(false);
      }
    }

    load();

    return () => {
      cancelled = true;
    };
  }, [slug, currentProductId]);

  const scrollBy = (direction: "left" | "right") => {
    const el = railRef.current;
    if (!el) return;
    const scrollAmount = el.clientWidth * 0.8;
    el.scrollBy({ left: direction === "left" ? -scrollAmount : scrollAmount, behavior: "smooth" });
  };

  if (!loading && items.length === 0) return null;

  return (
    <section className="mt-16 border-t pt-10" aria-label="Recently viewed products">
      <div className="mb-5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <History className="size-4 text-muted-foreground" />
          <h2 className="text-xl font-bold tracking-tight">Recently Viewed</h2>
        </div>
        {items.length > 1 ? (
          <div className="flex gap-1">
            <Button type="button" variant="outline" size="icon" aria-label="Scroll recently viewed left" onClick={() => scrollBy("left")}>
              <ChevronLeft className="size-4" />
            </Button>
            <Button type="button" variant="outline" size="icon" aria-label="Scroll recently viewed right" onClick={() => scrollBy("right")}>
              <ChevronRight className="size-4" />
            </Button>
          </div>
        ) : null}
      </div>

      {loading ? (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="space-y-2">
              <Skeleton className="aspect-[2/3] w-full" />
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
            </div>
          ))}
        </div>
      ) : (
        <div
          ref={railRef}
          className="flex snap-x snap-mandatory gap-3 overflow-x-auto pb-2 sm:gap-4"
          tabIndex={0}
          aria-live="polite"
        >
          {items.map((product) => (
            <div key={product.id} className="w-[45%] flex-shrink-0 snap-start sm:w-[30%] lg:w-[23%]">
              <ProductCard product={product} shopSlug={slug} compact />
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
