"use client";

import Image from "next/image";
import Link from "next/link";
import { useState, useRef, useEffect } from "react";
import { storefrontApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { StarRating } from "@/components/ui/star-rating";
import { RecentlyViewedRail } from "./recently-viewed";
import type { ReviewPublic } from "@/types/review";
import type { StorefrontShop, StorefrontProductVariant } from "@/types/shop";
import {
  ChevronLeft,
  ChevronRight,
  ShoppingCart,
  Package,
  Tag,
  Phone,
  MessageSquare,
  ShieldCheck,
  Truck,
  Star,
  ChevronDown,
  Store,
  RotateCcw,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface ProductDetailProps {
  product: {
    id: number;
    name: string;
    description?: string;
    price: number;
    stock: number;
    sku?: string;
    is_active: boolean;
  };
  shop: StorefrontShop;
}

export function ProductDetail({ product, shop }: ProductDetailProps) {
  const shopSlug = shop.slug;
  const shopName = shop.name;

  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);
  const imageContainerRef = useRef<HTMLDivElement>(null);

  // Variant selection state — only used when the storefront API starts returning variants.
  const variants = (product as { variants?: StorefrontProductVariant[] }).variants;
  const hasVariants = Boolean(variants && variants.length > 0);
  const [selectedVariant, setSelectedVariant] = useState<StorefrontProductVariant | null>(null);

  // Review state
  const [reviews, setReviews] = useState<ReviewPublic[]>([]);
  const [reviewsLoading, setReviewsLoading] = useState(true);
  const [reviewsPage, setReviewsPage] = useState(1);
  const [reviewsTotalPages, setReviewsTotalPages] = useState(1);
  const [averageRating, setAverageRating] = useState(0);
  const [totalReviews, setTotalReviews] = useState(0);

  const inStock = product.stock > 0;
  const lowStock = product.stock > 0 && product.stock <= 5;
  const outOfStock = product.stock === 0;

  // Build image list from the full gallery when available, otherwise fall back to the primary image.
  const images = (() => {
    const gallery = (product as { images?: { image_url: string; is_primary?: boolean }[] }).images;
    if (gallery && gallery.length > 0) {
      return gallery.map((i) => i.image_url);
    }
    const primary = (product as { primary_image_url?: string }).primary_image_url;
    return primary ? [primary] : [];
  })();

  const hasMultipleImages = images.length > 1;

  const goToPrevious = () => {
    if (hasMultipleImages) {
      setCurrentImageIndex((prev) =>
        prev === 0 ? images.length - 1 : prev - 1,
      );
    }
  };

  const goToNext = () => {
    if (hasMultipleImages) {
      setCurrentImageIndex((prev) =>
        prev === images.length - 1 ? 0 : prev + 1,
      );
    }
  };

  // Touch handlers for swipe support
  const minSwipeDistance = 50;

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd || !hasMultipleImages) return;
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;
    if (isLeftSwipe) {
      goToNext();
    } else if (isRightSwipe) {
      goToPrevious();
    }
  };

  // Reset image index and variant selection when product changes
  useEffect(() => {
    setCurrentImageIndex(0);
    setSelectedVariant(null);
  }, [product.id]);

  // Load reviews when component mounts or page changes
  useEffect(() => {
    let cancelled = false;

    async function loadReviews() {
      setReviewsLoading(true);
      try {
        const response = await storefrontApi.getProductReviews(product.id, reviewsPage);
        const data = response.data as {
          items: ReviewPublic[];
          total: number;
          page: number;
          page_size: number;
          total_pages: number;
          average_rating?: number;
        };
        if (!cancelled) {
          setReviews(data.items || []);
          setTotalReviews(data.total || 0);
          setReviewsTotalPages(data.total_pages || 1);
          if (data.average_rating !== undefined) {
            setAverageRating(data.average_rating);
          }
        }
      } catch {
        // Reviews are non-critical; silently ignore errors
        if (!cancelled) {
          setReviews([]);
        }
      } finally {
        if (!cancelled) {
          setReviewsLoading(false);
        }
      }
    }

    loadReviews();

    return () => {
      cancelled = true;
    };
  }, [product.id, reviewsPage]);

  const orderHref = `/${shopSlug}/order?product_id=${product.id}`;
  const orderDisabled = outOfStock || (hasVariants && !selectedVariant);
  const orderButtonText = outOfStock
    ? "Out of Stock"
    : hasVariants && !selectedVariant
      ? "Select an option"
      : "Order Now";

  function formatDate(dateStr: string): string {
    try {
      return new Date(dateStr).toLocaleDateString("en-BD", {
        year: "numeric",
        month: "short",
        day: "numeric",
      });
    } catch {
      return dateStr;
    }
  }

  const delivery = shop.delivery_settings;
  const hasDeliveryInfo = Boolean(
    delivery &&
      (delivery.inside_dhaka !== undefined ||
        delivery.outside_dhaka !== undefined ||
        delivery.estimated_days ||
        delivery.free_delivery_min),
  );

  return (
    <main className="mx-auto max-w-5xl px-4 pb-32 sm:px-6 sm:pb-12">
      <nav aria-label="Breadcrumb" className="mb-5 flex items-center gap-2 border-b border-border pb-3 text-sm text-muted-foreground">
        <Link
          href={`/${shopSlug}`}
          className="transition-colors hover:text-foreground"
        >
          {shopName}
        </Link>
        <span aria-hidden="true">/</span>
        <Link
          href={`/${shopSlug}#products`}
          className="transition-colors hover:text-foreground"
        >
          Products
        </Link>
        <span aria-hidden="true">/</span>
        <span className="truncate text-foreground">{product.name}</span>
      </nav>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 md:gap-8 lg:gap-12">
        {/* Image Gallery */}
        <div className="space-y-4">
          <div
            ref={imageContainerRef}
            className="group relative aspect-square overflow-hidden border border-border bg-muted"
            onTouchStart={onTouchStart}
            onTouchMove={onTouchMove}
            onTouchEnd={onTouchEnd}
          >
            {images.length > 0 && images[currentImageIndex] ? (
              <Image
                src={images[currentImageIndex]}
                alt={product.name}
                fill
                className="object-cover transition-transform duration-300 ease-premium motion-safe:group-hover:scale-[1.02]"
                priority
                sizes="(max-width: 768px) 100vw, 50vw"
              />
            ) : (
              <div className="flex size-full items-center justify-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={1}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="size-24 text-muted-foreground"
                >
                  <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
                  <circle cx="9" cy="9" r="2" />
                  <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" />
                </svg>
              </div>
            )}

            {/* Navigation arrows */}
            {hasMultipleImages && (
              <>
                <button
                  type="button"
                  onClick={goToPrevious}
                  className="absolute left-2 top-1/2 -translate-y-1/2 border border-border bg-background p-2 transition-colors hover:bg-muted focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
                  aria-label="Previous image"
                >
                  <ChevronLeft className="size-5" />
                </button>
                <button
                  type="button"
                  onClick={goToNext}
                  className="absolute right-2 top-1/2 -translate-y-1/2 border border-border bg-background p-2 transition-colors hover:bg-muted focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
                  aria-label="Next image"
                >
                  <ChevronRight className="size-5" />
                </button>
              </>
            )}

            {/* Stock badge overlay */}
            {outOfStock && (
              <div className="absolute left-3 top-3">
                <Badge variant="destructive">Out of Stock</Badge>
              </div>
            )}
            {lowStock && (
              <div className="absolute left-3 top-3">
                <Badge variant="warning">Only {product.stock} left</Badge>
              </div>
            )}
          </div>

          {/* Thumbnail indicators */}
          {hasMultipleImages && (
            <div className="flex gap-2 overflow-x-auto pb-1">
              {images.map((img, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setCurrentImageIndex(idx)}
                  className={cn(
                    "relative h-16 w-16 flex-shrink-0 overflow-hidden border-2 transition-colors",
                    idx === currentImageIndex
                      ? "border-primary"
                      : "border-transparent opacity-70 hover:opacity-100",
                  )}
                  aria-label={`View image ${idx + 1}`}
                  aria-current={idx === currentImageIndex ? "true" : undefined}
                >
                  <Image
                    src={img}
                    alt={`${product.name} thumbnail ${idx + 1}`}
                    fill
                    className="object-cover"
                    sizes="64px"
                  />
                </button>
              ))}
            </div>
          )}

          {/* Trust strip (desktop, below image) */}
          <div className="hidden gap-2 sm:grid sm:grid-cols-2">
            <div className="flex items-center gap-2 border border-border bg-muted p-3 text-sm">
              <Truck className="size-4 shrink-0 text-primary" />
              <div>
                <p className="font-medium text-foreground">Fast delivery</p>
                <p className="text-xs text-muted-foreground">
                  All Bangladesh
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 border border-border bg-muted p-3 text-sm">
              <ShieldCheck className="size-4 shrink-0 text-success" />
              <div>
                <p className="font-medium text-foreground">Verified shop</p>
                <p className="text-xs text-muted-foreground">Trusted seller</p>
              </div>
            </div>
          </div>
        </div>

        {/* Product Info */}
        <div className="flex flex-col gap-5">
          <div className="space-y-2">
            <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
              {product.name}
            </h1>
            {product.sku && (
              <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                <Tag className="size-3.5" />
                <span>SKU: {product.sku}</span>
              </div>
            )}
          </div>

          {/* Price + rating row */}
          <div className="flex items-center gap-3">
            <span className="text-3xl font-bold text-primary">
              ৳{product.price.toLocaleString()}
            </span>
            {totalReviews > 0 ? (
              <div className="flex items-center gap-1.5 border border-border bg-muted px-2.5 py-1 text-xs">
                <Star className="size-3 fill-warning text-warning" />
                <span className="font-medium text-foreground">
                  {averageRating.toFixed(1)}
                </span>
                <span className="text-muted-foreground">
                  ({totalReviews})
                </span>
              </div>
            ) : null}
          </div>

          {/* Stock Status */}
          <div className="flex items-center gap-2">
            <Package className="size-4 text-muted-foreground" />
            {inStock ? (
              <span className="text-sm font-medium text-success">
                In stock — {product.stock} available
              </span>
            ) : (
              <span className="text-sm font-medium text-destructive">
                Out of Stock
              </span>
            )}
          </div>

          {/* Variant selector — only rendered when variants are returned by the API */}
          {hasVariants && variants ? (
            <div className="space-y-2">
              <span className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">
                Options
              </span>
              <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="Product options">
                {variants.map((variant) => {
                  const selected = selectedVariant?.id === variant.id;
                  const disabled = (variant.stock ?? 1) <= 0;
                  return (
                    <button
                      key={variant.id}
                      type="button"
                      role="radio"
                      disabled={disabled}
                      aria-checked={selected}
                      onClick={() => setSelectedVariant(variant)}
                      className={cn(
                        "border px-3 py-2 text-sm transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring",
                        selected
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-border bg-background hover:border-foreground",
                        disabled && "opacity-50 cursor-not-allowed",
                      )}
                    >
                      {variant.name}
                    </button>
                  );
                })}
              </div>
            </div>
          ) : null}

          {/* Order Buttons (desktop inline) */}
          <div className="mt-2 hidden flex-col gap-3 sm:flex sm:flex-row">
            <Button
              asChild
              size="lg"
              disabled={orderDisabled}
              className="flex-1"
            >
              <Link href={orderHref} aria-disabled={orderDisabled}>
                <ShoppingCart className="mr-2 size-4" />
                {orderButtonText}
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="sm:w-auto">
              <Link href={`/${shopSlug}`}>
                <ChevronLeft className="mr-2 size-4" />
                Back
              </Link>
            </Button>
          </div>

          {/* Contact info hint (desktop) */}
          <div className="hidden items-center gap-1.5 text-xs text-muted-foreground sm:flex">
            <Phone className="size-3.5" />
            <span>For inquiries, contact the shop directly</span>
          </div>
        </div>
      </div>

      {/* Product information accordions */}
      <section className="mt-10 border-t border-border pt-8" aria-label="Product information">
        <div className="space-y-0 divide-y divide-border border border-border">
          <details open className="group">
            <summary className="flex cursor-pointer list-none items-center justify-between p-4 text-sm font-semibold transition-colors hover:bg-muted focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring">
              <span className="flex items-center gap-2">
                <Store className="size-4 text-muted-foreground" />
                Description
              </span>
              <ChevronDown className="size-4 transition-transform duration-200 group-open:rotate-180 motion-reduce:transition-none" aria-hidden="true" />
            </summary>
            <div className="px-4 pb-4 pt-0 text-sm leading-relaxed text-muted-foreground">
              {product.description ? (
                <p className="whitespace-pre-line">{product.description}</p>
              ) : (
                <p>No description available for this product.</p>
              )}
            </div>
          </details>

          <details className="group">
            <summary className="flex cursor-pointer list-none items-center justify-between p-4 text-sm font-semibold transition-colors hover:bg-muted focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring">
              <span className="flex items-center gap-2">
                <Truck className="size-4 text-muted-foreground" />
                Delivery
              </span>
              <ChevronDown className="size-4 transition-transform duration-200 group-open:rotate-180 motion-reduce:transition-none" aria-hidden="true" />
            </summary>
            <div className="px-4 pb-4 pt-0 text-sm leading-relaxed text-muted-foreground">
              {hasDeliveryInfo ? (
                <ul className="list-none space-y-1">
                  {delivery?.inside_dhaka !== undefined ? (
                    <li>Inside Dhaka: ৳{Number(delivery.inside_dhaka).toLocaleString()}</li>
                  ) : null}
                  {delivery?.outside_dhaka !== undefined ? (
                    <li>Outside Dhaka: ৳{Number(delivery.outside_dhaka).toLocaleString()}</li>
                  ) : null}
                  {delivery?.free_delivery_min ? (
                    <li>Free delivery on orders over ৳{Number(delivery.free_delivery_min).toLocaleString()}</li>
                  ) : null}
                  {delivery?.estimated_days ? (
                    <li>Estimated delivery: {delivery.estimated_days}</li>
                  ) : null}
                </ul>
              ) : (
                <p>Delivery details will be confirmed by the seller during checkout.</p>
              )}
            </div>
          </details>

          <details className="group">
            <summary className="flex cursor-pointer list-none items-center justify-between p-4 text-sm font-semibold transition-colors hover:bg-muted focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring">
              <span className="flex items-center gap-2">
                <RotateCcw className="size-4 text-muted-foreground" />
                Returns
              </span>
              <ChevronDown className="size-4 transition-transform duration-200 group-open:rotate-180 motion-reduce:transition-none" aria-hidden="true" />
            </summary>
            <div className="px-4 pb-4 pt-0 text-sm leading-relaxed text-muted-foreground">
              <p>
                Returns are handled according to the seller&apos;s policy. Please contact{" "}
                {shopName} directly with your order details if you need to return or exchange an item.
              </p>
            </div>
          </details>

          <details className="group">
            <summary className="flex cursor-pointer list-none items-center justify-between p-4 text-sm font-semibold transition-colors hover:bg-muted focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring">
              <span className="flex items-center gap-2">
                <Store className="size-4 text-muted-foreground" />
                About {shopName}
              </span>
              <ChevronDown className="size-4 transition-transform duration-200 group-open:rotate-180 motion-reduce:transition-none" aria-hidden="true" />
            </summary>
            <div className="px-4 pb-4 pt-0 text-sm leading-relaxed text-muted-foreground">
              {shop.description ? <p className="whitespace-pre-line">{shop.description}</p> : <p>No additional shop information available.</p>}
              {shop.contact_phone ? (
                <p className="mt-2">
                  Contact: <a href={`tel:${shop.contact_phone}`} className="font-medium text-foreground underline">{shop.contact_phone}</a>
                </p>
              ) : null}
            </div>
          </details>
        </div>
      </section>

      {/* Mobile sticky buy bar */}
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background p-3 motion-safe:transition-transform motion-safe:duration-300 sm:hidden">
        <div className="mx-auto grid max-w-md gap-2">
          {hasVariants && variants ? (
            <div className="flex flex-wrap gap-2">
              {variants.map((variant) => {
                const selected = selectedVariant?.id === variant.id;
                const disabled = (variant.stock ?? 1) <= 0;
                return (
                  <button
                    key={variant.id}
                    type="button"
                    disabled={disabled}
                    aria-pressed={selected}
                    onClick={() => setSelectedVariant(variant)}
                    className={cn(
                      "border px-2.5 py-1.5 text-xs transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring",
                      selected
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border bg-background hover:border-foreground",
                      disabled && "opacity-50 cursor-not-allowed",
                    )}
                  >
                    {variant.name}
                  </button>
                );
              })}
            </div>
          ) : null}
          <div className="grid grid-cols-2 gap-2">
            <Button asChild variant="outline" className="min-h-[44px]">
              <Link href={`/${shopSlug}`} aria-label="Back to shop">
                <ChevronLeft className="mr-1.5 size-4" />
                Shop
              </Link>
            </Button>
            <Button asChild disabled={orderDisabled} className="min-h-[44px]">
              <Link href={orderHref} aria-label="Order this product now" aria-disabled={orderDisabled}>
                <ShoppingCart className="mr-1.5 size-4" />
                {orderButtonText}
              </Link>
            </Button>
          </div>
        </div>
      </div>

      {/* ── Reviews Section ── */}
      <section className="mt-16 border-t pt-10">
        <div className="mb-6 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">
              Customer Reviews
            </h2>
            <div className="mt-1 flex items-center gap-2">
              <StarRating value={averageRating} size="sm" />
              <span className="text-sm font-medium">
                {averageRating.toFixed(1)}
              </span>
              <span className="text-sm text-muted-foreground">
                ({totalReviews} review{totalReviews !== 1 ? "s" : ""})
              </span>
            </div>
          </div>
        </div>

        {reviewsLoading && (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="space-y-2 border border-border p-4" aria-hidden="true">
                <div className="h-4 w-24 bg-muted" />
                <div className="h-3 w-48 bg-muted" />
                <div className="h-12 w-full bg-muted" />
              </div>
            ))}
          </div>
        )}

        {!reviewsLoading && reviews.length === 0 && (
          <div className="flex flex-col items-center gap-2 border border-dashed py-12 text-center" role="status">
            <MessageSquare className="size-10 text-muted-foreground/50" />
            <p className="text-sm text-muted-foreground">
              No reviews yet. Be the first to review this product!
            </p>
          </div>
        )}

        {!reviewsLoading && reviews.length > 0 && (
          <div className="space-y-4">
            {reviews.map((review) => (
              <div
                key={review.id}
                className="border border-border bg-background p-4 transition-colors hover:bg-muted"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">
                        {review.buyer_name}
                      </span>
                      <StarRating value={review.rating} size="sm" />
                    </div>
                    {review.title && (
                      <p className="text-sm font-medium">{review.title}</p>
                    )}
                  </div>
                  <time className="shrink-0 text-xs text-muted-foreground">
                    {formatDate(review.created_at)}
                  </time>
                </div>

                <p className="mt-2 whitespace-pre-line text-sm text-muted-foreground">
                  {review.body}
                </p>

                {review.reply_text && (
                  <div className="mt-3 bg-muted p-3">
                    <p className="text-xs font-medium text-muted-foreground">
                      Seller Response
                    </p>
                    <p className="mt-1 text-sm">{review.reply_text}</p>
                  </div>
                )}
              </div>
            ))}

            {/* Pagination */}
            {reviewsTotalPages > 1 && (
              <div className="flex items-center justify-center gap-2 pt-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  disabled={reviewsPage <= 1}
                  onClick={() => setReviewsPage((p) => Math.max(1, p - 1))}
                >
                  Previous
                </Button>
                {Array.from({ length: reviewsTotalPages }, (_, i) => i + 1).map(
                  (page) => (
                    <Button
                      key={page}
                      type="button"
                      variant={page === reviewsPage ? "default" : "outline"}
                      size="sm"
                      onClick={() => setReviewsPage(page)}
                    >
                      {page}
                    </Button>
                  ),
                )}
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  disabled={reviewsPage >= reviewsTotalPages}
                  onClick={() =>
                    setReviewsPage((p) => Math.min(reviewsTotalPages, p + 1))
                  }
                >
                  Next
                </Button>
              </div>
            )}
          </div>
        )}
      </section>

      {/* Recently viewed products */}
      <RecentlyViewedRail shop={shop} currentProductId={product.id} />
    </main>
  );
}
