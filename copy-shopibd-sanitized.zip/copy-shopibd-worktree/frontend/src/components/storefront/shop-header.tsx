"use client";

import Image from "next/image";
import { Banknote, Phone, Store as StoreIcon, Truck } from "lucide-react";
import type { StorefrontShop } from "@/types/shop";

interface ShopHeaderProps { shop: StorefrontShop; }

export function ShopHeader({ shop }: ShopHeaderProps) {
  const inStock = shop.products.filter((product) => product.is_active && product.stock > 0).length;
  const codEnabled = shop.delivery_settings?.cod_enabled !== false;

  return <header className="border-b border-foreground bg-background">
    <div className="border-b border-border bg-foreground px-4 py-2 text-center text-[11px] font-semibold uppercase tracking-widest text-primary-foreground">{codEnabled ? "Direct orders and cash on delivery available" : "Browse the current catalog"}</div>
    {shop.banner_url ? <div className="relative h-40 border-b border-border sm:h-52"><Image src={shop.banner_url} alt={`${shop.name} banner`} fill priority sizes="100vw" className="object-cover" /></div> : null}
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6"><div className="flex flex-col gap-5 border-b border-border pb-5 sm:flex-row sm:items-end sm:justify-between"><div className="flex min-w-0 items-center gap-4">{shop.logo_url ? <div className="relative size-16 shrink-0 border border-foreground"><Image src={shop.logo_url} alt={`${shop.name} logo`} fill className="object-cover" sizes="64px" /></div> : <div className="flex size-16 shrink-0 items-center justify-center border border-foreground bg-muted"><StoreIcon className="size-6" /></div>}<div><p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">Independent storefront</p><h1 className="mt-1 text-2xl font-bold tracking-tight sm:text-3xl">{shop.name}</h1>{shop.description ? <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">{shop.description}</p> : null}</div></div>{shop.contact_phone ? <a href={`tel:${shop.contact_phone}`} className="inline-flex items-center gap-2 border border-foreground px-4 py-3 text-sm font-semibold hover:bg-foreground hover:text-primary-foreground"><Phone className="size-4" />{shop.contact_phone}</a> : null}</div>
      <div className="grid border-l border-t border-border sm:grid-cols-3"><div className="border-b border-r border-border p-3"><p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">Catalog</p><p className="mt-2 text-sm font-semibold">{inStock} available products</p></div><div className="border-b border-r border-border p-3"><p className="flex items-center gap-1 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground"><Banknote className="size-3" />Payments</p><p className="mt-2 text-sm font-semibold">{codEnabled ? "Cash on delivery" : "Contact seller"}</p></div><div className="border-b border-r border-border p-3"><p className="flex items-center gap-1 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground"><Truck className="size-3" />Delivery</p><p className="mt-2 text-sm font-semibold">{shop.delivery_settings?.free_delivery_min ? `Free over ৳${shop.delivery_settings.free_delivery_min}` : "Delivery details at checkout"}</p></div></div>
    </div>
  </header>;
}
