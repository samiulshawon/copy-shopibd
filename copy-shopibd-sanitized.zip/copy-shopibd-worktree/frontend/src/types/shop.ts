/**
 * Shop TypeScript types.
 * Matches the backend Shop model in app/models/shop.py.
 */

import type { Category } from "./category";

export interface Shop {
  id: number;
  name: string;
  slug: string;
  seller_id: number;
  description?: string;
  logo_url?: string;
  banner_url?: string;
  contact_phone: string;
  bkash_number?: string;
  nagad_number?: string;
  rocket_number?: string;
  delivery_settings?: DeliverySettings;
  is_active: boolean;
}

export interface ShopCreate {
  name: string;
  slug: string;
  description?: string;
  logo_url?: string;
  banner_url?: string;
  contact_phone?: string;
  bkash_number?: string;
  nagad_number?: string;
  rocket_number?: string;
  delivery_settings?: DeliverySettings;
}

export interface ShopUpdate {
  name?: string;
  slug?: string;
  description?: string;
  logo_url?: string;
  banner_url?: string;
  contact_phone?: string;
  bkash_number?: string;
  nagad_number?: string;
  rocket_number?: string;
  delivery_settings?: DeliverySettings;
  is_active?: boolean;
}

export interface ShopStats {
  total_products: number;
  total_orders: number;
  monthly_revenue: number;
  total_revenue: number;
}

// ---------------------------------------------------------------------------
// Storefront types (public-facing shop + products)
// ---------------------------------------------------------------------------

export interface StorefrontShop {
  id: number;
  name: string;
  slug: string;
  description?: string;
  logo_url?: string;
  banner_url?: string;
  contact_phone: string;
  bkash_number?: string;
  nagad_number?: string;
  rocket_number?: string;
  delivery_settings?: DeliverySettings;
  is_active: boolean;
  products: StorefrontProduct[];
  categories?: import("./category").Category[];
}

export interface StorefrontProduct {
  id: number;
  name: string;
  description?: string;
  price: number;
  stock: number;
  sku?: string;
  primary_image_url?: string;
  secondary_image_url?: string;
  images?: { id?: number; image_url: string; is_primary?: boolean }[];
  is_active: boolean;
  category_id?: number | null;
  category_name?: string;
  /** Future-facing variant support. Currently not populated by the storefront API. */
  variants?: StorefrontProductVariant[];
}

export interface StorefrontProductVariant {
  id: number;
  name: string;
  sku?: string;
  price?: number;
  stock?: number;
}

export interface DeliverySettings {
  inside_dhaka?: number;
  outside_dhaka?: number;
  estimated_days?: string;
  free_delivery_min?: number;
  areas: DeliveryArea[];
  fee?: number;
  free_threshold?: number;
  /** Default courier provider for automatic shipments */
  default_courier?: string;
  /** Default pickup address for courier collection */
  pickup_address?: string;
  /** Whether COD (Cash on Delivery) is enabled */
  cod_enabled?: boolean;
}

export interface DeliveryArea {
  name: string;
  fee: number;
}

export interface CreateOrderData {
  buyer_name: string;
  buyer_phone: string;
  buyer_address: {
    division: string;
    district: string;
    area: string;
    details: string;
  };
  product_id: number;
  quantity: number;
  notes?: string;
  coupon_code?: string;
  payment_method?: string;
}

export interface BuyerAddress {
  division: string;
  district: string;
  area: string;
  details: string;
}

export interface OrderTrackResponse {
  id: number;
  order_number: string;
  customer_name: string;
  customer_phone: string;
  customer_address: string;
  total_amount: number;
  status: string;
  payment_status: string;
  notes?: string;
  shop_id: number;
  created_at: string;
  items: Array<{
    id: number;
    product_id: number;
    product_name: string;
    quantity: number;
    unit_price: number;
    subtotal: number;
  }>;
}

export interface SellerSettings {
  delivery_settings?: DeliverySettings;
  [key: string]: unknown;
}