export type CourierName = "steadfast" | "ecourier" | "pathao" | "redx" | "manual";

export type ShipmentStatus =
  | "pending"
  | "picked_up"
  | "in_transit"
  | "delivered"
  | "returned"
  | "failed";

export interface Delivery {
  id: number;
  order_id: number;
  seller_id: number;
  courier_name: CourierName;
  tracking_number?: string | null;
  shipment_status: ShipmentStatus;
  pickup_address: string;
  delivery_address: string;
  weight_kg?: number | null;
  cod_amount?: number | null;
  shipping_cost?: number | null;
  estimated_delivery_date?: string | null;
  delivered_at?: string | null;
  notes?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
}

export interface DeliveryCreate {
  order_id: number;
  courier_name: CourierName;
  pickup_address: string;
  weight_kg?: number | null;
  cod_amount?: number | null;
}

export interface DeliveryStatusUpdate {
  status: ShipmentStatus;
  tracking_number?: string | null;
  notes?: string | null;
}

export interface DeliveryListItem {
  id: number;
  order_id: number;
  courier_name: CourierName;
  tracking_number?: string | null;
  shipment_status: ShipmentStatus;
  cod_amount?: number | null;
  shipping_cost?: number | null;
  estimated_delivery_date?: string | null;
  created_at?: string | null;
}

export interface DeliveryListResponse {
  items: DeliveryListItem[];
  total: number;
  page: number;
  page_size: number;
  total_pages: number;
}

export interface CourierProvider {
  name: string;
  value: CourierName;
}

export interface CourierListResponse {
  couriers: CourierProvider[];
}
