/**
 * Seller (vendor) TypeScript types.
 * Matches the backend Seller model in app/models/seller.py.
 */

export interface Seller {
  id: number;
  name: string;
  email: string;
  phone: string;
  is_active: boolean;
  is_verified: boolean;
  is_super_admin: boolean;
  plan: string;
  max_products: number;
  max_orders: number;
  created_at: string;
  updated_at: string;
}

export interface SellerCreate {
  name: string;
  email: string;
  phone: string;
  password: string;
}

export interface SellerUpdate {
  name?: string;
  email?: string;
  phone?: string;
  is_active?: boolean;
  is_verified?: boolean;
  plan?: string;
  max_products?: number;
  max_orders?: number;
}

export interface SellerStats {
  total_products: number;
  total_orders: number;
  total_revenue: number;
  active_shops: number;
  rating: number;
}

export interface SellerUsage {
  products_used: number;
  products_limit: number;
  orders_this_month: number;
  orders_limit: number;
  shops_count: number;
  shops_limit: number;
  storage_used_mb: number;
  storage_limit_mb: number;
}