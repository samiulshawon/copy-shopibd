export interface ProductImage {
  id: number
  image_url: string
  is_primary: boolean
  sort_order: number
}

export interface Product {
  id: number
  name: string
  description?: string
  price: number
  stock: number
  sku?: string
  is_active: boolean
  shop_id: number
  category_id?: number
  category?: { id: number; name: string }
  images?: ProductImage[]
}

export interface ProductCreate {
  name: string
  description?: string
  price: number
  stock?: number
  sku?: string
  is_active?: boolean
  category_id?: number
}

export interface ProductUpdate {
  name?: string
  description?: string
  price?: number
  stock?: number
  sku?: string
  is_active?: boolean
  category_id?: number
}

export interface BulkProductItem {
  name: string
  description?: string
  price: number
  stock: number
  sku?: string
  category_id?: number
  is_active?: boolean
}

export interface BulkCreateResult {
  created: number
  failed: Array<{ index: number; error: string }>
}

export interface BulkStockItem {
  id: number
  stock: number
}

export interface BulkStockUpdateResult {
  updated: number
}

export interface BulkPriceUpdateRequest {
  type: "fixed" | "percentage"
  value: number
  product_ids?: number[]
}

export interface BulkPriceUpdateResult {
  updated: number
}

export interface ImportResult {
  total: number
  created: number
  failed: Array<{ row: number; error: string }>
}

export interface ProductListParams {
  shop_id: number
  search?: string
  category_id?: number
  page?: number
  limit?: number
}
