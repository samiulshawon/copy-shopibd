/**
 * Analytics dashboard types for ShopiBD.
 */

export interface DashboardStats {
  today_orders: number;
  today_revenue: number;
  pending_orders: number;
  low_stock_count: number;
  total_products: number;
  total_orders: number;
}

export interface SalesDataPoint {
  date: string;
  revenue: number;
  orders: number;
}

export interface TopProduct {
  product_id: number;
  product_name: string;
  total_quantity: number;
  total_revenue: number;
  order_count: number;
}

export interface StatusBreakdown {
  status: string;
  count: number;
}
