/**
 * Review types for ShopiBD.
 * Matches the backend Review model in app/models/review.py.
 */

/** Payload when a buyer submits a review. */
export interface ReviewCreate {
  product_id: number;
  buyer_name: string;
  buyer_phone: string;
  rating: number;
  title?: string;
  body: string;
}

/** Public-facing review returned to storefront. */
export interface ReviewPublic {
  id: number;
  product_id: number;
  buyer_name: string;
  rating: number;
  title?: string;
  body: string;
  reply_text?: string;
  created_at: string;
}

/** Full review returned to admin dashboard. */
export interface ReviewResponse {
  id: number;
  product_id: number;
  order_id: number | null;
  buyer_name: string;
  buyer_phone: string;
  rating: number;
  title: string | null;
  body: string;
  is_approved: boolean | null;
  reply_text: string | null;
  created_at: string;
}
