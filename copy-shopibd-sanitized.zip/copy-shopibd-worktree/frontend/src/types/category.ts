/**
 * Category TypeScript types.
 * Matches the backend Category model in app/models/category.py.
 */

export interface Category {
  id: number;
  name_bn: string;
  name_en?: string;
  description?: string;
  sort_order: number;
  parent_id?: number | null;
  children?: Category[];
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface CategoryCreate {
  name_bn: string;
  name_en?: string;
  description?: string;
  sort_order?: number;
  parent_id?: number | null;
}

export interface CategoryUpdate {
  name_bn?: string;
  name_en?: string;
  description?: string;
  sort_order?: number;
  parent_id?: number | null;
  is_active?: boolean;
}

export interface CategoryTreeNode extends Category {
  children: CategoryTreeNode[];
}