/**
 * Coupon type definitions for ShopiBD.
 */

export interface Coupon {
  id: number;
  seller_id: number;
  shop_id: number | null;
  code: string;
  discount_type: "percentage" | "fixed";
  discount_value: number;
  min_order_amount: number | null;
  max_discount: number | null;
  usage_limit: number | null;
  usage_count: number;
  per_customer_limit: number;
  applies_to: "all" | "specific_products" | "specific_categories";
  product_ids: string | null;
  category_ids: string | null;
  is_active: boolean;
  starts_at: string | null;
  expires_at: string | null;
  created_at: string;
  updated_at: string | null;
}

export interface CouponCreate {
  code: string;
  discount_type: "percentage" | "fixed";
  discount_value: number;
  shop_id?: number | null;
  min_order_amount?: number | null;
  max_discount?: number | null;
  usage_limit?: number | null;
  per_customer_limit?: number;
  applies_to?: string;
  product_ids?: string | null;
  category_ids?: string | null;
  is_active?: boolean;
  starts_at?: string | null;
  expires_at?: string | null;
}

export interface CouponUpdate {
  code?: string;
  discount_type?: string;
  discount_value?: number;
  min_order_amount?: number | null;
  max_discount?: number | null;
  usage_limit?: number | null;
  per_customer_limit?: number;
  applies_to?: string;
  product_ids?: string | null;
  category_ids?: string | null;
  is_active?: boolean;
  starts_at?: string | null;
  expires_at?: string | null;
}

export interface CouponValidateRequest {
  code: string;
  shop_id?: number;
  shop_slug?: string;
  total_amount: number;
  product_ids?: number[];
  customer_phone?: string;
}

export interface CouponValidateResponse {
  valid: boolean;
  discount_amount: number;
  message: string;
  coupon: Coupon | null;
}

export interface CouponListResponse {
  items: Coupon[];
  total: number;
}
