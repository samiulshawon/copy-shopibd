/**
 * Common TypeScript types used across the ShopiBD frontend.
 */

// ---------------------------------------------------------------------------
// API Response wrappers
// ---------------------------------------------------------------------------

/** Standard successful API response envelope. */
export interface ApiResponse<T = unknown> {
  success: boolean;
  data: T;
  message?: string;
}

/** Standard paginated API response. */
export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  size: number;
  pages: number;
}

/** Standard API error response. */
export interface ApiError {
  detail: string;
  status_code: number;
  errors?: Record<string, string[]>;
}

// ---------------------------------------------------------------------------
// Plan / Subscription types
// ---------------------------------------------------------------------------

/** Plan info returned by the API. */
export interface PlanInfo {
  id: string;
  name: string;
  price_bdt: number;
  max_products: number;
  max_orders: number;
  features: string[];
}

// ---------------------------------------------------------------------------
// Pagination helpers
// ---------------------------------------------------------------------------

/** Pagination query parameters sent to the API. */
export interface PaginationParams {
  page?: number;
  size?: number;
  sort?: string;
  order?: "asc" | "desc";
}

/** Pagination state used in frontend data tables / lists. */
export interface PaginationState {
  page: number;
  size: number;
  total: number;
  pages: number;
}

// ---------------------------------------------------------------------------
// Generic option (for select / combobox)
// ---------------------------------------------------------------------------

export interface SelectOption {
  label: string;
  value: string | number;
  disabled?: boolean;
}

// ---------------------------------------------------------------------------
// Date range
// ---------------------------------------------------------------------------

export interface DateRange {
  from: Date | string;
  to: Date | string;
}

// ---------------------------------------------------------------------------
// Sort
// ---------------------------------------------------------------------------

export interface SortOption {
  field: string;
  direction: "asc" | "desc";
}
