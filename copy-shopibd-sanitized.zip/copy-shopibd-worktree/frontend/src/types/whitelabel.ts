/**
 * White-label / custom domain TypeScript types for ShopiBD.
 */

export interface BrandingSettings {
  primary_color: string;
  secondary_color: string;
  font_family: string;
  logo_url?: string | null;
  favicon_url?: string | null;
  custom_css?: string | null;
}

export interface DomainRequest {
  domain: string;
}

export interface DomainVerifyResponse {
  verified: boolean;
  dns_records: DnsRecord[];
  message: string;
}

export interface DnsRecord {
  type: string;
  name: string;
  value: string;
  description: string;
}

export interface SubdomainRequest {
  subdomain: string;
}

export interface WhiteLabelStatus {
  custom_domain: string | null;
  subdomain: string | null;
  domain_verified: boolean;
  domain_verified_at: string | null;
  ssl_provisioned: boolean;
  branding: BrandingSettings | null;
  hide_branding: boolean;
}
