/**
 * Payment types for ShopiBD Payment Reconciliation Dashboard.
 */

// ---------------------------------------------------------------------------
// Payment method & status enums (aligned with backend)
// ---------------------------------------------------------------------------

export type PaymentMethod = "bkash" | "nagad" | "rocket" | "cod" | "bank";
export type PaymentStatus = "pending" | "verified" | "mismatched" | "unmatched";

// ---------------------------------------------------------------------------
// Parsed SMS data
// ---------------------------------------------------------------------------

export interface ParsedSmsData {
  provider: "bkash" | "nagad" | null;
  amount: number | null;
  sender_phone: string | null;
  trx_id: string | null;
  balance: number | null;
  raw_text: string;
}

// ---------------------------------------------------------------------------
// Payment transaction
// ---------------------------------------------------------------------------

export interface PaymentTransaction {
  id: number;
  order_id: number | null;
  seller_id: number;
  shop_id: number;
  amount: number | null;
  currency: string;
  payment_method: PaymentMethod;
  sender_phone: string | null;
  reference: string | null;
  status: PaymentStatus;
  matched_order_id: number | null;
  raw_sms_text: string | null;
  verified_by: string | null;
  verified_at: string | null;
  notes: string | null;
  created_at: string | null;
  updated_at: string | null;
}

export interface PaymentTransactionListItem {
  id: number;
  amount: number | null;
  currency: string;
  payment_method: PaymentMethod;
  sender_phone: string | null;
  reference: string | null;
  status: PaymentStatus;
  matched_order_id: number | null;
  verified_by: string | null;
  created_at: string | null;
}

// ---------------------------------------------------------------------------
// Create / Match
// ---------------------------------------------------------------------------

export interface PaymentTransactionCreate {
  raw_sms_text?: string;
  amount?: number;
  sender_phone?: string;
  reference?: string;
  payment_method: PaymentMethod;
  notes?: string;
}

export interface PaymentMatchRequest {
  transaction_id: number;
  order_id: number;
}

// ---------------------------------------------------------------------------
// Reconciliation
// ---------------------------------------------------------------------------

export interface ReconciliationSummary {
  total_transactions: number;
  total_amount: number;
  matched: number;
  matched_amount: number;
  unmatched: number;
  unmatched_amount: number;
  pending: number;
  pending_amount: number;
}

// ---------------------------------------------------------------------------
// Match suggestion
// ---------------------------------------------------------------------------

export interface MatchSuggestion {
  transaction_id: number;
  transaction_amount: number;
  transaction_reference: string | null;
  transaction_method: PaymentMethod;
  transaction_created_at: string | null;
  order_id: number;
  order_number: string;
  order_amount: number;
  customer_name: string;
  customer_phone: string;
  confidence: number;
  match_reasons: string[];
}

// ---------------------------------------------------------------------------
// Filters
// ---------------------------------------------------------------------------

export interface PaymentFilters {
  page?: number;
  limit?: number;
  status?: PaymentStatus;
  payment_method?: PaymentMethod;
  search?: string;
}
