import type { Delivery } from "./delivery";

export interface Order {
  id: number
  order_number: string
  customer_name: string
  customer_phone: string
  customer_address: string
  total_amount: number
  status: string
  payment_status: string
  notes?: string
  shop_id: number
  created_at: string
  items?: OrderItem[];
  delivery?: Delivery | null;
}

export interface OrderCreate {
  customer_name: string
  customer_phone: string
  customer_address: string
  total_amount: number
  notes?: string
}

export interface OrderUpdate {
  status?: string
  payment_status?: string
  notes?: string
}

export interface OrderItem {
  id: number
  product_id: number
  product_name: string
  quantity: number
  unit_price: number
  subtotal: number
}

export interface OrderListItem {
  id: number
  order_number: string
  customer_name: string
  customer_phone: string
  total_amount: number
  status: string
  payment_status: string
  created_at: string
  item_count: number
}

export interface OrderFilters {
  page?: number
  limit?: number
  status?: string
  date_from?: string
  date_to?: string
  search?: string
}

/** Abandoned order (pending > N hours). */
export interface AbandonedOrderItem {
  id: number
  order_number: string
  customer_name: string
  customer_phone: string
  total_amount: number
  status: string
  payment_status: string
  created_at: string
  hours_since: number
}

export interface AbandonedOrderListResponse {
  items: AbandonedOrderItem[]
  total: number
}

export interface RemindResponse {
  sent: boolean
  message: string
}
