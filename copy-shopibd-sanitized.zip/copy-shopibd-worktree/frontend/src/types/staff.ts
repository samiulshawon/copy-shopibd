/**
 * Staff / Employee TypeScript types.
 * Matches the backend Staff model and schemas.
 */

export interface Staff {
  id: number;
  name: string;
  email: string;
  phone?: string | null;
  role: "owner" | "manager" | "staff";
  is_active: boolean;
  seller_id: number;
  created_at?: string;
  updated_at?: string;
}

export type StaffRole = "owner" | "manager" | "staff";

export interface StaffInvite {
  name: string;
  email: string;
  phone?: string | null;
  role: StaffRole;
}

export interface StaffUpdate {
  name?: string;
  email?: string;
  phone?: string | null;
  role?: StaffRole;
  is_active?: boolean;
}