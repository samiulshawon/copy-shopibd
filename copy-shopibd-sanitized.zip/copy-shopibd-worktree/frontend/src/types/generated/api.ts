// ---------------------------------------------------------------------------
// Auto-generated TypeScript types from OpenAPI schema
// Regenerate with: python scripts/generate-types.py
// ---------------------------------------------------------------------------

export interface Categorycreate {
  name_bn: string;
  name_en?: unknown;
  description?: unknown;
  sort_order?: number;
  is_active?: boolean;
  parent_id?: unknown;
}

export interface Categoryresponse {
  name_bn: string;
  name_en?: unknown;
  description?: unknown;
  sort_order?: number;
  is_active?: boolean;
  id: number;
  seller_id: number;
  parent_id?: unknown;
  created_at: string;
  updated_at: string;
}

export interface Categoryupdate {
  name_bn?: unknown;
  name_en?: unknown;
  description?: unknown;
  sort_order?: unknown;
  parent_id?: unknown;
  is_active?: unknown;
}

export interface Httpvalidationerror {
  detail?: Validationerror[];
}

export interface Order {
  customer_name: string;
  customer_phone: string;
  customer_address: string;
  total_amount: number;
  notes?: unknown;
  id: number;
  order_number: string;
  status: string;
  payment_status: string;
  shop_id: number;
  created_at: string;
}

export interface Ordercreate {
  customer_name: string;
  customer_phone: string;
  customer_address: string;
  total_amount: number;
  notes?: unknown;
}

export interface Orderupdate {
  status?: unknown;
  payment_status?: unknown;
  notes?: unknown;
}

export interface PaginatedresponseCategoryresponse {
  items: Categoryresponse[];
  total: number;
  page: number;
  page_size: number;
  total_pages: number;
}

export interface Product {
  name: string;
  description?: unknown;
  price: number;
  stock?: number;
  sku?: unknown;
  is_active?: boolean;
  id: number;
  shop_id: number;
}

export interface Productcreate {
  name: string;
  description?: unknown;
  price: number;
  stock?: number;
  sku?: unknown;
  is_active?: boolean;
}

export interface Productupdate {
  name?: unknown;
  description?: unknown;
  price?: unknown;
  stock?: unknown;
  sku?: unknown;
  is_active?: unknown;
}

export interface Seller {
  name: string;
  email: string;
  phone: string;
  id: number;
  is_active: boolean;
  is_verified: boolean;
}

export interface Sellercreate {
  name: string;
  email: string;
  phone: string;
  password: string;
}

export interface Sellerlogin {
  email: string;
  password: string;
}

export interface Sellerupdate {
  name?: unknown;
  phone?: unknown;
  is_active?: unknown;
}

export interface Shoppublic {
  id: number;
  name: string;
  slug: string;
  description?: unknown;
  logo_url?: unknown;
  is_active?: boolean;
}

export interface Shopresponse {
  name: string;
  description?: unknown;
  logo_url?: unknown;
  is_active?: boolean;
  id: number;
  slug: string;
  seller_id: number;
  created_at?: unknown;
  updated_at?: unknown;
}

export interface Shopupdate {
  name?: unknown;
  slug?: unknown;
  description?: unknown;
  logo_url?: unknown;
  is_active?: unknown;
}

export interface Staffinvite {
  name: string;
  email: string;
  phone?: unknown;
  role?: Staffrole;
}

export interface Staffresponse {
  id: number;
  name: string;
  email: string;
  phone?: unknown;
  role: string;
  is_active: boolean;
  seller_id: number;
  created_at?: unknown;
  updated_at?: unknown;
}

export interface Staffrole {
}

export interface Staffupdate {
  name?: unknown;
  email?: unknown;
  phone?: unknown;
  role?: unknown;
  is_active?: unknown;
}

export interface Validationerror {
  loc: unknown[];
  msg: string;
  type: string;
  input?: unknown;
  ctx?: Record<string, unknown>;
}
