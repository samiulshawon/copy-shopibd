/**
 * Subscription & Plan types for ShopiBD frontend.
 */

import type { PlanInfo as PlanInfoSchema } from "./common";

/** Re-export PlanInfo from common types */
export type PlanInfo = PlanInfoSchema;

/** Plan limits for UI display */
export interface PlanLimits {
  max_products: number;
  max_orders: number;
}

/** Current subscription with plan details */
export interface SubscriptionResponse {
  id: number;
  seller_id: number;
  plan: string;
  status: string;
  current_period_start: string;
  current_period_end: string | null;
  auto_renew: boolean;
  payment_gateway: string | null;
  payment_gateway_subscription_id: string | null;
  trial_end: string | null;
  canceled_at: string | null;
  created_at: string;
  updated_at: string;
}

/** Subscription with full plan info */
export interface SubscriptionWithPlanResponse extends SubscriptionResponse {
  plan_info: PlanInfo;
  current_products: number;
  current_orders: number;
}

/** Request to create/select a subscription plan */
export interface SubscriptionCreate {
  plan: string;
  auto_renew?: boolean;
  payment_gateway?: string;
}

/** Request to update subscription */
export interface SubscriptionUpdate {
  plan?: string;
  auto_renew?: boolean;
}

/** Subscription status enum for UI */
export type SubscriptionStatus =
  | "active"
  | "past_due"
  | "canceled"
  | "expired"
  | "trialing";

/** Plan IDs */
export type PlanId = "free" | "starter" | "business" | "enterprise";

/** Helper to get status display label */
export function getStatusLabel(status: SubscriptionStatus): string {
  const labels: Record<SubscriptionStatus, string> = {
    active: "Active",
    past_due: "Past Due",
    canceled: "Canceled",
    expired: "Expired",
    trialing: "Trialing",
  };
  return labels[status] || status;
}

/** Helper to get status badge variant */
export function getStatusColor(status: SubscriptionStatus): "success" | "warning" | "secondary" | "destructive" | "info" {
  const variants: Record<SubscriptionStatus, "success" | "warning" | "secondary" | "destructive" | "info"> = {
    active: "success",
    past_due: "warning",
    canceled: "secondary",
    expired: "destructive",
    trialing: "info",
  };
  return variants[status] || "secondary";
}

/** Helper to format plan price */
export function formatPlanPrice(price: number): string {
  if (price === 0) return "Free";
  return `৳${price.toLocaleString()}/mo`;
}

/** Helper to format plan limit (shows ∞ for unlimited) */
export function formatPlanLimit(limit: number): string {
  if (limit >= 99999) return "Unlimited";
  return limit.toLocaleString();
}