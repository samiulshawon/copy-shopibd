/**
 * TypeScript types for Customer CRM features.
 */

export interface CustomerListItem {
  id: number;
  name: string;
  phone: string;
  total_orders: number;
  total_spent: number;
  segment: string;
  last_order_date?: string;
}

export interface Customer {
  id: number;
  name: string;
  phone: string;
  email?: string;
  total_orders: number;
  total_spent: number;
  last_order_date?: string;
  tags?: string;
  notes?: string;
  segment: string;
  created_at: string;
}

export interface CustomerUpdate {
  notes?: string;
  tags?: string;
  segment?: string;
}

export interface CustomerListResponse {
  items: CustomerListItem[];
  total: number;
  page: number;
  page_size: number;
  total_pages: number;
}

export interface CustomerFilters {
  page?: number;
  page_size?: number;
  search?: string;
  segment?: string;
}

export interface BroadcastRequest {
  segment: string;
  message: string;
}

export interface BroadcastResponse {
  message: string;
  total_customers: number;
  messages_sent: number;
}
