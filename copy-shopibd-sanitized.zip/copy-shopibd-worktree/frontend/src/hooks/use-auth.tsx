"use client";

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";
import type { Seller } from "@/types";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface AuthState {
  user: Seller | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  error: string | null;
}

export interface AuthContextValue extends AuthState {
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  register: (phone: string) => Promise<void>;
  verifyOtp: (phone: string, otp: string) => Promise<void>;
  refreshUser: () => Promise<void>;
  clearError: () => void;
  isSuperAdmin: boolean;
}

// ---------------------------------------------------------------------------
// Token helpers
// ---------------------------------------------------------------------------

const ACCESS_TOKEN_KEY = "shopibd_access_token";

function getStoredToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem(ACCESS_TOKEN_KEY);
}

function storeToken(token: string): void {
  localStorage.setItem(ACCESS_TOKEN_KEY, token);
}

function removeToken(): void {
  localStorage.removeItem(ACCESS_TOKEN_KEY);
}

// ---------------------------------------------------------------------------
// Context
// ---------------------------------------------------------------------------

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

// ---------------------------------------------------------------------------
// Provider
// ---------------------------------------------------------------------------

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [state, setState] = useState<AuthState>({
    user: null,
    isLoading: true,
    isAuthenticated: false,
    error: null,
  });

  const clearError = useCallback(() => {
    setState((prev) => ({ ...prev, error: null }));
  }, []);

  const refreshUser = useCallback(async () => {
    const token = getStoredToken();
    if (!token) {
      setState({ user: null, isLoading: false, isAuthenticated: false, error: null });
      return;
    }

    try {
      const response = await api.get<Seller>("/sellers/me", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setState({
        user: response.data,
        isLoading: false,
        isAuthenticated: true,
        error: null,
      });
    } catch {
      removeToken();
      setState({ user: null, isLoading: false, isAuthenticated: false, error: null });
    }
  }, []);

  useEffect(() => {
    refreshUser();
  }, [refreshUser]);

  const login = useCallback(
    async (email: string, password: string) => {
      setState((prev) => ({ ...prev, isLoading: true, error: null }));
      try {
        const response = await api.post<{ access_token: string; token_type: string }>(
          "/auth/login",
          { email, password },
        );
        const { access_token } = response.data;
        storeToken(access_token);
        // Also set as cookie for server-side auth checks (getServerSession reads from cookies)
        document.cookie = `shopibd_access_token=${access_token}; path=/; max-age=${60 * 60 * 24 * 8}; SameSite=Lax`;
        await refreshUser();
        // Super admin goes to owner console, sellers go to their dashboard
        const token = getStoredToken();
        if (token) {
          const meResp = await api.get<Seller>("/sellers/me", {
            headers: { Authorization: `Bearer ${token}` },
          });
          if (meResp.data.is_super_admin) {
            router.push("/admin");
            return;
          }
        }
        router.push("/dashboard/orders");
      } catch (err: any) {
        const message =
          err?.response?.data?.detail || "Login failed. Please try again.";
        setState((prev) => ({
          ...prev,
          isLoading: false,
          error: message,
        }));
        throw new Error(message);
      }
    },
    [refreshUser, router],
  );

  const logout = useCallback(async () => {
    removeToken();
    // Clear the auth cookie as well
    document.cookie = "shopibd_access_token=; path=/; max-age=0; SameSite=Lax";
    setState({ user: null, isLoading: false, isAuthenticated: false, error: null });
    router.push("/auth/login");
  }, [router]);

  const register = useCallback(async (phone: string) => {
    setState((prev) => ({ ...prev, isLoading: true, error: null }));
    try {
      await api.post("/auth/register", { phone });
      setState((prev) => ({ ...prev, isLoading: false }));
    } catch (err: any) {
      const message =
        err?.response?.data?.detail || "Registration failed. Please try again.";
      setState((prev) => ({
        ...prev,
        isLoading: false,
        error: message,
      }));
      throw new Error(message);
    }
  }, []);

  const verifyOtp = useCallback(
    async (phone: string, otp: string) => {
      setState((prev) => ({ ...prev, isLoading: true, error: null }));
      try {
        const response = await api.post<{ access_token: string; token_type: string }>(
          "/auth/verify-otp",
          { phone, otp },
        );
        const { access_token } = response.data;
        storeToken(access_token);
        // Also set as cookie for server-side auth checks (getServerSession reads from cookies)
        document.cookie = `shopibd_access_token=${access_token}; path=/; max-age=${60 * 60 * 24 * 8}; SameSite=Lax`;
        await refreshUser();
        router.push("/dashboard/orders");
      } catch (err: any) {
        const message =
          err?.response?.data?.detail || "Verification failed. Please try again.";
        setState((prev) => ({
          ...prev,
          isLoading: false,
          error: message,
        }));
        throw new Error(message);
      }
    },
    [refreshUser, router],
  );

  const value = useMemo<AuthContextValue>(
    () => ({
      ...state,
      login,
      logout,
      register,
      verifyOtp,
      refreshUser,
      clearError,
      isSuperAdmin: state.user?.is_super_admin ?? false,
    }),
    [state, login, logout, register, verifyOtp, refreshUser, clearError],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// ---------------------------------------------------------------------------
// Hook
// ---------------------------------------------------------------------------

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
