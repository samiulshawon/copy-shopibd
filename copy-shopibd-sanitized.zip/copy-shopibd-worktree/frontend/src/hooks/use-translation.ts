"use client";

import { useCallback, useState, useEffect } from "react";

// ---------------------------------------------------------------------------
// Translation dictionary
// ---------------------------------------------------------------------------

const translations: Record<string, Record<string, string>> = {
  bn: {
    // Navigation
    "nav.dashboard": "ড্যাশবোর্ড",
    "nav.orders": "অর্ডার",
    "nav.products": "পণ্য",
    "nav.customers": "গ্রাহক",
    "nav.coupons": "কুপন",
    "nav.payments": "পেমেন্ট",
    "nav.settings": "সেটিংস",
    "nav.staff": "স্টাফ",
    "nav.analytics": "অ্যানালিটিক্স",
    "nav.branding": "ব্র্যান্ডিং",
    "nav.logout": "লগআউট",

    // Auth
    "auth.login": "লগইন",
    "auth.register": "নিবন্ধন",
    "auth.email": "ইমেইল",
    "auth.password": "পাসওয়ার্ড",
    "auth.login.title": "আপনার অ্যাকাউন্টে লগইন করুন",
    "auth.register.title": "নতুন অ্যাকাউন্ট তৈরি করুন",
    "auth.forgot.password": "পাসওয়ার্ড ভুলে গেছেন?",

    // Orders
    "order.title": "অর্ডার সমূহ",
    "order.status.pending": "অপেক্ষমাণ",
    "order.status.confirmed": "নিশ্চিত",
    "order.status.shipped": "পাঠানো হয়েছে",
    "order.status.delivered": "ডেলিভারি হয়েছে",
    "order.status.cancelled": "বাতিল",
    "order.number": "অর্ডার নম্বর",
    "order.customer": "গ্রাহক",
    "order.total": "মোট মূল্য",
    "order.date": "তারিখ",
    "order.update.status": "স্টatus আপডেট",
    "order.details": "অর্ডার বিবরণ",

    // Products
    "product.title": "পণ্য সমূহ",
    "product.name": "পণ্যের নাম",
    "product.price": "মূল্য",
    "product.stock": "স্টক",
    "product.category": "বিভাগ",
    "product.add": "নতুন পণ্য",
    "product.edit": "পণ্য সম্পাদনা",
    "product.delete": "পণ্য মুছে ফেলুন",

    // Customers
    "customer.title": "গ্রাহক সমূহ",
    "customer.name": "নাম",
    "customer.phone": "ফোন",
    "customer.email": "ইমেইল",
    "customer.total.orders": "মোট অর্ডার",
    "customer.total.spent": "মোট ব্যয়",
    "customer.last.order": "সর্বশেষ অর্ডার",

    // Coupons
    "coupon.title": "কুপন সমূহ",
    "coupon.code": "কুপন কোড",
    "coupon.discount": "ডিসকাউন্ট",
    "coupon.type": "ধরণ",
    "coupon.percent": "শতাংশ",
    "coupon.fixed": "নির্দিষ্ট",
    "coupon.min.order": "সর্বনিম্ন অর্ডার",
    "coupon.expires": "মেয়াদ শেষ",
    "coupon.usage": "ব্যবহার",

    // Payments
    "payment.title": "পেমেন্ট",
    "payment.method": "পদ্ধতি",
    "payment.status": "স্টেটাস",
    "payment.amount": "পরিমাণ",
    "payment.reference": "রেফারেন্স",
    "payment.date": "তারিখ",
    "payment.bkash": "বিকাশ",
    "payment.nagad": "নগদ",
    "payment.rocket": "রকেট",
    "payment.cod": "নগদে গ্রহণ",
    "payment.bank": "ব্যাংক",

    // Common
    "common.save": "সংরক্ষণ",
    "common.cancel": "বাতিল",
    "common.delete": "মুছে ফেলুন",
    "common.edit": "সম্পাদনা",
    "common.create": "তৈরি করুন",
    "common.search": "অনুসন্ধান",
    "common.filter": "ফিল্টার",
    "common.export": "এক্সপোর্ট",
    "common.import": "ইম্পোর্ট",
    "common.loading": "লোড হচ্ছে...",
    "common.no.data": "কোন তথ্য নেই",
    "common.error": "ত্রুটি",
    "common.success": "সফল",
    "common.confirm": "নিশ্চিত করুন",
    "common.back": "পেছনে",
    "common.next": "পরবর্তী",
    "common.submit": "জমা দিন",
    "common.download": "ডাউনলোড",

    // Settings
    "settings.title": "সেটিংস",
    "settings.shop.profile": "দোকানের প্রোফাইল",
    "settings.delivery": "ডেলিভারি সেটিংস",
    "settings.payment.methods": "পেমেন্ট পদ্ধতি",

    // Analytics
    "analytics.title": "অ্যানালিটিক্স",
    "analytics.total.sales": "মোট বিক্রয়",
    "analytics.total.orders": "মোট অর্ডার",
    "analytics.average.order": "গড় অর্ডার মূল্য",
    "analytics.top.products": "শীর্ষ পণ্য",

    // Branding
    "branding.title": "ব্র্যান্ডিং",
    "branding.logo": "লোগো",
    "branding.colors": "রং",
    "branding.theme": "থিম",

    // Delivery
    "delivery.title": "ডেলিভারি",
    "delivery.address": "ঠিকানা",
    "delivery.status": "স্টেটাস",
    "delivery.courier": "কুরিয়ার",

    // Staff
    "staff.title": "স্টাফ",
    "staff.name": "নাম",
    "staff.role": "ভূমিকা",
    "staff.email": "ইমেইল",
    "staff.add": "স্টাফ যোগ করুন",
    "staff.invite": "আমন্ত্রণ পাঠান",
  },
};

// ---------------------------------------------------------------------------
// Helper
// ---------------------------------------------------------------------------

const STORAGE_KEY = "shopibd_lang";

function getInitialLocale(): string {
  if (typeof window !== "undefined") {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored === "bn" || stored === "en") return stored;
  }
  return "en"; // Default to English
}

// ---------------------------------------------------------------------------
// Hook
// ---------------------------------------------------------------------------

interface UseTranslationResult {
  /** Current locale (e.g. "en", "bn") */
  locale: string;
  /** Set the locale and persist to localStorage */
  setLocale: (locale: string) => void;
  /** Translate a key into the current locale */
  t: (key: string, fallback?: string) => string;
  /** Toggle between "en" and "bn" */
  toggleLocale: () => void;
  /** Is Bangla currently active */
  isBangla: boolean;
}

export function useTranslation(): UseTranslationResult {
  const [locale, setLocaleState] = useState<string>(getInitialLocale);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, locale);
    // Set dir attribute for RTL support
    if (typeof document !== "undefined") {
      document.documentElement.dir = "ltr"; // Bengali uses LTR
      document.documentElement.lang = locale;
    }
  }, [locale]);

  const setLocale = useCallback((newLocale: string) => {
    if (newLocale === "bn" || newLocale === "en") {
      setLocaleState(newLocale);
    }
  }, []);

  const toggleLocale = useCallback(() => {
    setLocaleState((prev) => (prev === "bn" ? "en" : "bn"));
  }, []);

  const t = useCallback(
    (key: string, fallback?: string): string => {
      if (locale === "en") return fallback ?? key;
      return translations.bn[key] ?? fallback ?? key;
    },
    [locale],
  );

  return {
    locale,
    setLocale,
    t,
    toggleLocale,
    isBangla: locale === "bn",
  };
}
