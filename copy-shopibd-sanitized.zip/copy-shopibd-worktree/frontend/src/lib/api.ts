/**
 * API client for ShopiBD frontend.
 *
 * Uses Axios with interceptors for auth token injection and error handling.
 */

import axios, {
  type AxiosInstance,
  type AxiosRequestConfig,
  type AxiosResponse,
} from "axios";
import type { CreateOrderData, StorefrontProduct, SellerSettings } from "@/types/shop";
import type { ReviewCreate } from "@/types/review";
import type { Order, OrderFilters, OrderListItem } from "@/types/order";
import type { Staff, StaffInvite, StaffUpdate } from "@/types/staff";
import type { SellerUsage } from "@/types/seller";
import type {
  Delivery,
  DeliveryCreate,
  DeliveryListResponse,
  DeliveryStatusUpdate,
  CourierListResponse,
} from "@/types/delivery";
import type {
  PlanInfo,
  SubscriptionResponse,
  SubscriptionWithPlanResponse,
  SubscriptionCreate,
  SubscriptionUpdate,
} from "@/types/subscription";

const BASE_URL =
  process.env.NEXT_PUBLIC_API_URL || "http://127.0.0.1:8000/api/v1";

/** Create an Axios instance pre-configured for the ShopiBD API. */
const api: AxiosInstance = axios.create({
  baseURL: BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
  timeout: 15000,
});

// ---------------------------------------------------------------------------
// Helper: is this running in a browser environment?
// ---------------------------------------------------------------------------
const isBrowser = typeof window !== "undefined";

// ---------------------------------------------------------------------------
// Request interceptor – inject JWT token from localStorage
// ---------------------------------------------------------------------------
api.interceptors.request.use(
  (config) => {
    if (isBrowser) {
      const token = localStorage.getItem("shopibd_access_token");
      if (token && config.headers) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    }
    return config;
  },
  (error) => Promise.reject(error),
);

// ---------------------------------------------------------------------------
// Response interceptor – handle 401/402 globally, normalise errors
// ---------------------------------------------------------------------------
api.interceptors.response.use(
  (response: AxiosResponse) => response,
  (error) => {
    if (error.response?.status === 401) {
      if (isBrowser) {
        localStorage.removeItem("shopibd_access_token");
        // Only redirect if not already on an auth page
        if (!window.location.pathname.startsWith("/auth/")) {
          window.location.href = "/auth/login";
        }
      }
    } else if (error.response?.status === 402) {
      // Plan limit exceeded — send the user to the subscription/upgrade page
      if (isBrowser && !window.location.pathname.startsWith("/dashboard/subscription")) {
        window.location.href = "/dashboard/subscription?upgrade=1";
      }
    }
    return Promise.reject(error);
  },
);

// ---------------------------------------------------------------------------
// Convenience helpers for typed API calls
// ---------------------------------------------------------------------------

/** Typed GET request. */
export async function get<T = unknown>(
  url: string,
  config?: AxiosRequestConfig,
): Promise<AxiosResponse<T>> {
  return api.get<T>(url, config);
}

/** Typed POST request. */
export async function post<T = unknown>(
  url: string,
  data?: unknown,
  config?: AxiosRequestConfig,
): Promise<AxiosResponse<T>> {
  return api.post<T>(url, data, config);
}

/** Typed PUT request. */
export async function put<T = unknown>(
  url: string,
  data?: unknown,
  config?: AxiosRequestConfig,
): Promise<AxiosResponse<T>> {
  return api.put<T>(url, data, config);
}

/** Typed PATCH request. */
export async function patch<T = unknown>(
  url: string,
  data?: unknown,
  config?: AxiosRequestConfig,
): Promise<AxiosResponse<T>> {
  return api.patch<T>(url, data, config);
}

/** Typed DELETE request. */
export async function del<T = unknown>(
  url: string,
  config?: AxiosRequestConfig,
): Promise<AxiosResponse<T>> {
  return api.delete<T>(url, config);
}

// ---------------------------------------------------------------------------
// Storefront API helpers
// ---------------------------------------------------------------------------

export const storefrontApi = {
  getShop: (slug: string) => api.get(`/shops/${slug}`),
  getProduct: (slug: string, productId: number) =>
    api.get(`/shops/${slug}/products/${productId}`),
  createOrder: (slug: string, data: CreateOrderData) =>
    api.post(`/shops/${slug}/orders`, data),
  trackOrder: (slug: string, phone: string, orderId: string) =>
    api.get(`/shops/${slug}/orders/track`, {
      params: { phone, order_id: orderId },
    }),
  submitReview: (data: ReviewCreate) => api.post("/reviews", data),
  getProductReviews: (productId: number, page: number = 1) =>
    api.get(`/products/${productId}/reviews?page=${page}`),
};

// ---------------------------------------------------------------------------
// Dashboard API helpers
// ---------------------------------------------------------------------------

export const dashboardApi = {
  // -----------------------------------------------------------------------
  // Invoice — download PDF
  // -----------------------------------------------------------------------
  async downloadInvoice(orderId: number): Promise<void> {
    const response = await api.get(`/seller-orders/${orderId}/invoice`, {
      responseType: "blob",
    });
    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement("a");
    link.href = url;
    // Extract filename from Content-Disposition or use a default
    const disposition = response.headers["content-disposition"] || "";
    const match = disposition.match(/filename="?(.+?)"?$/);
    link.download = match ? match[1] : `invoice-${orderId}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  },
  getOrders: (filters: OrderFilters = {}) =>
    api.get<{
      items: OrderListItem[];
      total: number;
      page: number;
      page_size: number;
      total_pages: number;
    }>("/seller-orders", { params: filters }),

  getOrder: (id: number) => api.get<Order>(`/seller-orders/${id}`),

  updateOrderStatus: (id: number, status: string) =>
    api.put<Order>(`/seller-orders/${id}/status`, null, { params: { status } }),
};

// ---------------------------------------------------------------------------
// Analytics API helpers
// ---------------------------------------------------------------------------

export const analyticsApi = {
  getDashboard: () => api.get("/analytics/dashboard"),
  getSales: (period: string = "7d") =>
    api.get(`/analytics/sales?period=${period}`),
  getTopProducts: (limit: number = 10) =>
    api.get(`/analytics/top-products?limit=${limit}`),
  getOrderStatusBreakdown: () => api.get("/analytics/order-status-breakdown"),
};

// ---------------------------------------------------------------------------
// Settings API helpers
// ---------------------------------------------------------------------------

export const settingsApi = {
  getShop: () => api.get("/shops/me"),
  updateShop: (data: Record<string, unknown>) =>
    api.put("/shops/me", data),
  updateSettings: (data: Partial<SellerSettings>) =>
    api.put("/sellers/me/settings", data),
};

// ---------------------------------------------------------------------------
// Staff API helpers
// ---------------------------------------------------------------------------

export const staffApi = {
  list: () => api.get<Staff[]>("/staff/"),
  invite: (data: StaffInvite) => api.post<Staff>("/staff/invite", data),
  update: (id: number, data: StaffUpdate) =>
    api.put<Staff>(`/staff/${id}`, data),
  remove: (id: number) => api.delete(`/staff/${id}`),
};

// ---------------------------------------------------------------------------
// Usage / Plan API helpers
// ---------------------------------------------------------------------------

export const usageApi = {
  getUsage: () => api.get<SellerUsage>("/sellers/me/usage"),
};

// ---------------------------------------------------------------------------
// Payment reconciliation API helpers
// ---------------------------------------------------------------------------

export const paymentApi = {
  /** Parse raw SMS text and return extracted data. */
  parseSms: (raw_sms_text: string) =>
    api.post<import("@/types/payment").ParsedSmsData>("/payments/parse-sms", {
      raw_sms_text,
    }),

  /** Create a new payment transaction (manual or from SMS). */
  createTransaction: (
    data: import("@/types/payment").PaymentTransactionCreate,
  ) =>
    api.post<import("@/types/payment").PaymentTransaction>(
      "/payments/transactions",
      data,
    ),

  /** List payment transactions (paginated, filterable). */
  listTransactions: (filters: import("@/types/payment").PaymentFilters = {}) =>
    api.get<{
      items: import("@/types/payment").PaymentTransactionListItem[];
      total: number;
      page: number;
      page_size: number;
      total_pages: number;
    }>("/payments/transactions", { params: filters }),

  /** Get a single transaction by ID. */
  getTransaction: (id: number) =>
    api.get<import("@/types/payment").PaymentTransaction>(
      `/payments/transactions/${id}`,
    ),

  /** Manually match a transaction to an order. */
  matchTransaction: (transaction_id: number, order_id: number) =>
    api.post<import("@/types/payment").PaymentTransaction>(
      `/payments/transactions/${transaction_id}/match`,
      { transaction_id, order_id },
    ),

  /** Unmatch a transaction from its order. */
  unmatchTransaction: (transaction_id: number) =>
    api.post<import("@/types/payment").PaymentTransaction>(
      `/payments/transactions/${transaction_id}/unmatch`,
      { transaction_id },
    ),

  /** Get reconciliation summary. */
  getReconciliation: () =>
    api.get<import("@/types/payment").ReconciliationSummary>(
      "/payments/reconciliation",
    ),

  /** Get auto-match suggestions. */
  getSuggestions: () =>
    api.get<import("@/types/payment").MatchSuggestion[]>(
      "/payments/suggestions",
    ),
};

// ---------------------------------------------------------------------------
// Admin / Review moderation API helpers
// ---------------------------------------------------------------------------

export const adminReviewsApi = {
  listAll: (status?: string) =>
    api.get("/admin/reviews", { params: { status_filter: status } }),
  approve: (id: number) => api.put(`/admin/reviews/${id}/approve`),
  reject: (id: number, reason: string) =>
    api.put(`/admin/reviews/${id}/reject`, { rejection_reason: reason }),
};

// ---------------------------------------------------------------------------
// Delivery / Shipment API helpers
// ---------------------------------------------------------------------------

export const deliveryApi = {
  /** Create a new shipment for an order. */
  createShipment: (data: DeliveryCreate) =>
    api.post<Delivery>("/delivery/shipments", data),

  /** List shipments (paginated, filterable by courier/status). */
  listShipments: (params?: {
    page?: number;
    limit?: number;
    courier?: string;
    status?: string;
    order_id?: number;
  }) =>
    api.get<DeliveryListResponse>("/delivery/shipments", { params }),

  /** Get a single shipment detail (optionally syncs tracking status). */
  getShipment: (id: number) => api.get<Delivery>(`/delivery/shipments/${id}`),

  /** Update shipment status (and optionally tracking number / notes). */
  updateShipmentStatus: (id: number, data: DeliveryStatusUpdate) =>
    api.put<Delivery>(`/delivery/shipments/${id}/status`, data),

  /** Cancel a shipment. */
  cancelShipment: (id: number) =>
    api.post<Delivery>(`/delivery/shipments/${id}/cancel`),

  /** List available courier providers. */
  listCouriers: () => api.get<CourierListResponse>("/delivery/couriers"),
};

// ---------------------------------------------------------------------------
// Customer / CRM API helpers
// ---------------------------------------------------------------------------

import type {
  Customer,
  CustomerListItem,
  CustomerListResponse,
  CustomerFilters,
  CustomerUpdate,
  BroadcastRequest,
  BroadcastResponse,
} from "@/types/customer";

export const customerApi = {
  /** List customers with search, filter, pagination. */
  list: (filters: CustomerFilters = {}) =>
    api.get<CustomerListResponse>("/customers", { params: filters }),

  /** Get full customer profile. */
  get: (id: number) => api.get<Customer>(`/customers/${id}`),

  /** Update customer notes / tags / segment. */
  updateNotes: (id: number, data: CustomerUpdate) =>
    api.put<Customer>(`/customers/${id}/notes`, data),

  /** Manually set customer segment. */
  setSegment: (id: number, segment: string) =>
    api.put<Customer>(`/customers/${id}/segment`, { segment }),

  /** Recalculate segments for all customers. */
  recalculateSegments: () =>
    api.post<{ message: string; total_customers: number; updated: number }>(
      "/customers/recalculate",
    ),

  /** Get order history for a customer. */
  getOrders: (id: number, page: number = 1, page_size: number = 20) =>
    api.get<{
      items: any[];
      total: number;
      page: number;
      page_size: number;
      total_pages: number;
    }>(`/customers/${id}/orders`, { params: { page, page_size } }),

  /** Broadcast a WhatsApp message to a customer segment. */
  broadcast: (data: BroadcastRequest) =>
    api.post<BroadcastResponse>("/customers/broadcast", data),
};

// ---------------------------------------------------------------------------
// White-label / Custom Domain API helpers
// ---------------------------------------------------------------------------

import type {
  WhiteLabelStatus,
  DomainRequest,
  DomainVerifyResponse,
  BrandingSettings,
  SubdomainRequest,
} from "@/types/whitelabel";
import type {
  Product,
  ProductCreate,
  ProductUpdate,
  ProductImage,
  BulkProductItem,
  BulkCreateResult,
  BulkStockItem,
  BulkStockUpdateResult,
  BulkPriceUpdateRequest,
  BulkPriceUpdateResult,
  ImportResult,
  ProductListParams,
} from "@/types/product";
import type {
  Coupon,
  CouponCreate,
  CouponUpdate,
  CouponListResponse,
  CouponValidateRequest,
  CouponValidateResponse,
} from "@/types/coupon";
import type {
  AbandonedOrderItem,
  AbandonedOrderListResponse,
  RemindResponse,
} from "@/types/order";

export const whitelabelApi = {
  /** Get current white-label status for the seller's shop. */
  getStatus: () => api.get<WhiteLabelStatus>("/whitelabel/status"),

  /** Set (or update) a custom domain. */
  setDomain: (data: DomainRequest) =>
    api.post<WhiteLabelStatus>("/whitelabel/domain", data),

  /** Check current domain verification status. */
  checkDomainVerification: () =>
    api.get<DomainVerifyResponse>("/whitelabel/domain/verify"),

  /** Trigger domain verification (check DNS records now). */
  triggerDomainVerification: () =>
    api.post<DomainVerifyResponse>("/whitelabel/domain/verify"),

  /** Set a custom subdomain. */
  setSubdomain: (data: SubdomainRequest) =>
    api.post<WhiteLabelStatus>("/whitelabel/subdomain", data),

  /** Update branding settings. */
  updateBranding: (data: BrandingSettings) =>
    api.put<WhiteLabelStatus>("/whitelabel/branding", data),

  /** Toggle the 'hide_branding' flag. */
  toggleHideBranding: () =>
    api.put<WhiteLabelStatus>("/whitelabel/branding/toggle"),
};

// ---------------------------------------------------------------------------
// Product API helpers
// ---------------------------------------------------------------------------

export const productApi = {
  /** List products with optional search, category filter, pagination. */
  list: (params: ProductListParams) =>
    api.get<Product[]>("/products", { params }),

  /** Get a single product. */
  get: (id: number) => api.get<Product>(`/products/${id}`),

  /** Create a single product. */
  create: (data: ProductCreate, shop_id: number) =>
    api.post<Product>("/products", data, { params: { shop_id } }),

  /** Update a product. */
  update: (id: number, data: ProductUpdate) =>
    api.put<Product>(`/products/${id}`, data),

  /** Delete a product. */
  delete: (id: number) => api.delete(`/products/${id}`),

  /** Bulk create products. */
  bulkCreate: (products: BulkProductItem[], shop_id: number) =>
    api.post<BulkCreateResult>("/products/bulk", { products }, { params: { shop_id } }),

  /** Import products from CSV file. */
  importCsv: (file: File, shop_id: number) => {
    const formData = new FormData();
    formData.append("file", file);
    return api.post<ImportResult>("/products/import", formData, {
      params: { shop_id },
      headers: { "Content-Type": "multipart/form-data" },
    });
  },

  /** Export products as CSV (returns blob). */
  exportCsv: (shop_id: number) =>
    api.get<Blob>("/products/export", {
      params: { shop_id },
      responseType: "blob",
    }),

  /** Bulk update stock. */
  bulkUpdateStock: (products: BulkStockItem[]) =>
    api.put<BulkStockUpdateResult>("/products/bulk/stock", { products }),

  /** Bulk update prices. */
  bulkUpdatePrice: (data: BulkPriceUpdateRequest) =>
    api.put<BulkPriceUpdateResult>("/products/bulk/price", data),

  /** Bulk delete products. */
  bulkDelete: (product_ids: number[]) =>
    api.post("/products/bulk/delete", product_ids),

  /** Upload an image to a product's gallery. */
  uploadImage: (id: number, file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    return api.post<ProductImage>(`/products/${id}/images`, fd, {
      headers: { "Content-Type": "multipart/form-data" },
    });
  },

  /** Delete a product image. */
  deleteImage: (id: number, imageId: number) =>
    api.delete(`/products/${id}/images/${imageId}`),

  /** Mark an image as the product's primary image. */
  setPrimaryImage: (id: number, imageId: number) =>
    api.put<ProductImage>(`/products/${id}/images/${imageId}/primary`),
};

// ---------------------------------------------------------------------------
// Coupon / Discount API helpers
// ---------------------------------------------------------------------------

export const couponApi = {
  /** List seller's coupons (paginated, filterable). */
  list: (params?: {
    page?: number;
    limit?: number;
    is_active?: boolean;
    search?: string;
  }) => api.get<CouponListResponse>("/coupons", { params }),

  /** Get a single coupon. */
  get: (id: number) => api.get<Coupon>(`/coupons/${id}`),

  /** Create a new coupon. */
  create: (data: CouponCreate) => api.post<Coupon>("/coupons/", data),

  /** Update a coupon. */
  update: (id: number, data: CouponUpdate) =>
    api.put<Coupon>(`/coupons/${id}`, data),

  /** Delete a coupon. */
  delete: (id: number) => api.delete(`/coupons/${id}`),

  /** Validate a coupon code at checkout. */
  validate: (data: CouponValidateRequest) =>
    api.post<CouponValidateResponse>("/coupons/validate", data),
};

// ---------------------------------------------------------------------------
// Abandoned Cart API helpers
// ---------------------------------------------------------------------------

export const abandonedCartApi = {
  /** List abandoned orders (pending > N hours). */
  list: (params?: { hours?: number; limit?: number }) =>
    api.get<AbandonedOrderListResponse>("/seller-orders/abandoned", { params }),

  /** Send WhatsApp reminder to buyer. */
  remind: (orderId: number) =>
    api.post<RemindResponse>(`/seller-orders/${orderId}/remind`),
};

// ---------------------------------------------------------------------------
// Subscription API helpers
// ---------------------------------------------------------------------------

export const subscriptionApi = {
  /** List all available plans (public). */
  listPlans: () => api.get<PlanInfo[]>("/subscription/plans"),

  /** Get current seller's subscription with plan info. */
  getSubscription: () => api.get<SubscriptionWithPlanResponse>("/subscription"),

  /** Select/upgrade plan (before payment). */
  createSubscription: (data: SubscriptionCreate) =>
    api.post<SubscriptionWithPlanResponse>("/subscription", data),

  /** Initiate payment for the current (trialing) subscription. */
  createPayment: () =>
    api.post<{
      payment_url: string;
      payment_id: string;
      payment_method: string;
      amount: number;
    }>("/subscription/payment"),

  /** Update subscription (auto_renew or plan change). */
  updateSubscription: (data: SubscriptionUpdate) =>
    api.put<SubscriptionWithPlanResponse>("/subscription", data),

  /** Cancel subscription (downgrade to free). */
  cancelSubscription: () => api.delete("/subscription"),
};

// ---------------------------------------------------------------------------
// Super-Admin API helpers (platform owner)
// ---------------------------------------------------------------------------

export const superAdminApi = {
  /** Platform-level stats: clients, shops, revenue, signups, plan distribution. */
  getStats: () => api.get("/admin/stats"),

  /** Recent platform activity feed (audit logs). */
  getActivity: (limit?: number) =>
    api.get("/admin/activity", { params: { limit } }),

  /** List all sellers (clients). */
  getSellers: () => api.get("/admin/sellers"),

  /** Phase 9: check subdomain availability + suggestions. */
  checkSubdomainAvailable: (subdomain: string) =>
    api
      .get<{
        available: boolean;
        subdomain: string;
        suggestions: string[];
        reason?: string;
      }>("/shops/subdomain-available", { params: { subdomain } })
      .then((res) => res.data),

  /** Create a new client (seller). Optional shop/URL fields provisioned by backend. */
  createSeller: (data: {
    name: string;
    email: string;
    phone: string;
    password: string;
    shop_name?: string;
    subdomain?: string;
    custom_domain?: string;
  }) => api.post("/admin/sellers", data),

  /** Edit a client's profile. */
  updateSeller: (
    id: number,
    data: { name?: string; phone?: string; is_active?: boolean },
  ) => api.put(`/admin/sellers/${id}`, data),

  /** Activate a client account. */
  activateSeller: (id: number) =>
    api.post(`/admin/sellers/${id}/activate`),

  /** Deactivate (suspend) a client account. */
  deactivateSeller: (id: number) =>
    api.post(`/admin/sellers/${id}/deactivate`),

  /** Override a client's subscription plan (bypasses payment). */
  overrideSubscription: (id: number, data: { plan: string; auto_renew?: boolean }) =>
    api.put(`/admin/sellers/${id}/subscription`, data),

  /**
   * Issue a short-lived impersonation token to access a client's dashboard.
   * Returns an access_token (15-min TTL) plus the target seller info.
   */
  impersonateSeller: (id: number, data?: { reason?: string }) =>
    api.post(`/admin/sellers/${id}/impersonate`, data || {}),

  /** Get super admin's own profile. */
  getSettings: () => api.get("/admin/settings"),

  /** Update super admin's own name and/or phone. */
  updateProfile: (data: { name?: string; phone?: string }) =>
    api.put("/admin/settings/profile", data),

  /** Change super admin's own password. */
  changePassword: (data: { current_password: string; new_password: string }) =>
    api.put("/admin/settings/password", data),
};

export { api };
export default api;
