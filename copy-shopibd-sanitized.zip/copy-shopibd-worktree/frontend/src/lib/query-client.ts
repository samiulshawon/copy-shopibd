import { QueryClient } from "@tanstack/react-query";

/**
 * Create and configure a QueryClient instance with sensible defaults
 * for the ShopiBD application.
 *
 * - staleTime: 5 minutes – data is considered fresh for 5 min
 * - retry: 1 – only retry once on failure
 * - refetchOnWindowFocus: false – avoid unnecessary refetches
 * - throwOnError: false – let components handle errors gracefully
 */
export function getQueryClient(): QueryClient {
  return new QueryClient({
    defaultOptions: {
      queries: {
        staleTime: 5 * 60 * 1000,
        retry: 1,
        refetchOnWindowFocus: false,
        throwOnError: false,
      },
      mutations: {
        retry: 0,
        throwOnError: false,
      },
    },
  });
}
