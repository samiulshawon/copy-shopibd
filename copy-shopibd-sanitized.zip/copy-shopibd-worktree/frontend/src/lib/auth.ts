import { cookies } from "next/headers";
import { api } from "./api";

const ACCESS_TOKEN_KEY = "shopibd_access_token";

export async function getServerSession() {
  const cookieStore = await cookies();
  const token = cookieStore.get(ACCESS_TOKEN_KEY)?.value;

  if (!token) {
    return null;
  }

  try {
    const response = await api.get<{ success: boolean; data: any }>("/sellers/me", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    // Backend returns seller object directly (not wrapped in {data: ...})
    const seller = (response.data as any)?.data ?? response.data;
    return seller;
  } catch {
    return null;
  }
}
