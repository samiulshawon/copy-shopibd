import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

/**
 * Merge class names with Tailwind CSS conflict resolution.
 * Uses clsx for conditional classes and tailwind-merge for deduplication.
 */
export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

/**
 * Format a numeric amount as BDT (Bangladeshi Taka).
 * Example: 1234.56 → "৳1,234.56"
 */
export function formatCurrency(
  amount: number | string,
  currency: string = "BDT",
): string {
  const num = typeof amount === "string" ? parseFloat(amount) : amount;
  if (isNaN(num)) return "৳0.00";

  return new Intl.NumberFormat("bn-BD", {
    style: "currency",
    currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(num);
}

/**
 * Format a Bangladeshi phone number for display.
 * Normalises to +880XXXXXXXXX if needed.
 */
export function formatPhoneBD(phone: string): string {
  // Strip all non-digit characters except leading '+'
  const cleaned = phone.replace(/[^\d+]/g, "");

  if (cleaned.startsWith("+880") && cleaned.length === 14) {
    // +8801XXXXXXXXX
    return `+880 ${cleaned.slice(3, 6)}-${cleaned.slice(6, 9)}-${cleaned.slice(9)}`;
  }

  if (cleaned.startsWith("01") && cleaned.length === 11) {
    // 01XXXXXXXXX → +8801XXXXXXXXX
    const normalized = `+880${cleaned.slice(1)}`;
    return `+880 ${normalized.slice(3, 6)}-${normalized.slice(6, 9)}-${normalized.slice(9)}`;
  }

  return phone; // fallback
}

/**
 * Truncate a string to a given length with ellipsis.
 */
export function truncate(str: string, length: number = 100): string {
  if (str.length <= length) return str;
  return str.slice(0, length).trimEnd() + "…";
}

/**
 * Generate a URL-friendly slug from a string.
 */
export function slugify(text: string): string {
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/\s+/g, "-")
    .replace(/[^\w-]+/g, "")
    .replace(/--+/g, "-")
    .replace(/^-+/, "")
    .replace(/-+$/, "");
}

/**
 * Debounce a function call.
 */
export function debounce<T extends (...args: unknown[]) => unknown>(
  fn: T,
  ms: number = 300,
): (...args: Parameters<T>) => void {
  let timer: ReturnType<typeof setTimeout>;
  return (...args: Parameters<T>) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), ms);
  };
}

/**
 * Get the base API URL from environment or default.
 */
export function getApiBaseUrl(): string {
  return process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
}

/**
 * Detect a plan-limit error (HTTP 402) raised by the backend's plan enforcement.
 *
 * The backend returns 402 with a detail object like:
 *   { error: "plan_limit_exceeded", limit_type, limit, current, plan, upgrade_url }
 * Axios wraps this in error.response.data. In some cases the detail is a plain
 * string, so we also match on the "plan_limit_exceeded" substring.
 */
export function isPlanLimitError(error: unknown): boolean {
  const response = (error as { response?: { status?: number; data?: unknown } })?.response;
  if (!response) return false;
  if (response.status !== 402) return false;

  const data = response.data as { error?: string; detail?: unknown } | undefined;
  if (data && typeof data.error === "string") {
    return data.error.includes("plan_limit_exceeded");
  }
  // Fallback: match on string detail
  if (typeof data?.detail === "string") {
    return data.detail.includes("plan_limit_exceeded");
  }
  // Any 402 from our API is treated as a plan-limit error
  return true;
}

/**
 * Extract a human-readable message from a plan-limit 402 error.
 */
export function getPlanLimitMessage(error: unknown, fallback: string): string {
  const response = (error as { response?: { data?: unknown } })?.response;
  const data = response?.data as
    | { detail?: string; message?: string }
    | string
    | undefined;

  if (typeof data === "string") return data;
  if (data?.detail) return data.detail;
  if (data?.message) return data.message;
  return fallback;
}
