# ShopiBD Master Roadmap

## Vision
Build the leading Bangladesh-focused SaaS social-commerce platform. ShopiBD turns Facebook-first sellers into structured storefront owners — replacing manual Messenger-based order workflows with catalog, cart, checkout, payment, delivery, and customer management. Localized for BDT, bKash/Nagad/SSLCommerz, Bangla language, and Bangladesh shipping.

---

## Phase 0: Foundation (Sprints 0–2) ✅ COMPLETE
**Goal**: Production-ready scaffolding with auth, multi-tenancy, admin panel

### Sprint 0: Project Setup
- [x] Repository structure, Docker, Makefile
- [x] FastAPI + Next.js + PostgreSQL + Redis
- [x] Alembic migrations, SQLAlchemy 2.0 models
- [x] JWT auth with refresh tokens
- [x] SQLAdmin panel with basic auth
- [x] TypeSync script (OpenAPI → TypeScript)
- [x] Contract tests (Schemathesis)
- [x] Deterministic seeder
- [x] E2E test skeleton (Playwright)
- [x] CI/CD pipeline (GitHub Actions)

### Sprint 1: Core Domain ✅ COMPLETE
- [x] Seller/Shop CRUD APIs
- [x] Category/Product management
- [x] Stock tracking (movements, reservations)
- [x] Order lifecycle (create → pending → confirmed → shipped → delivered)
- [x] Staff invitation & role management
- [x] Bengali/English i18n with RTL support

### Sprint 2: Integrations & Polish ✅ COMPLETE
- [x] SMS provider factory (mock + SSLCommerz ready)
- [x] WhatsApp Business API factory (mock + Meta ready)
- [x] bKash, Nagad, SSLCommerz payment gateways
- [x] Rate limiting middleware (Redis-backed sliding window, per-IP, per-seller, in-memory fallback)
- [x] Audit log model + service + API
- [x] API documentation (Swagger, ReDoc, OpenAPI)
- [x] Performance baseline document
- [x] Local file upload (media storage with StorageService abstraction)
- [x] S3/MinIO object storage (boto3 implementation with MinIO dev setup)
- [ ] Load testing script (locust/k6) — *not yet implemented*

---

## Sprint 3: CRM, Payments, Discounts & Platform Maturity ✅ COMPLETE
**Goal**: Equip sellers with customer management, real payment gateways, coupon engine, bulk operations, and platform polish.

- [x] Customer management (model, CRUD, auto-create, segments, bulk SMS)
- [x] Bulk product management (CSV import/export, template, validation, low stock alerts)
- [x] Discount & coupon engine (CRUD, apply to order, abandoned cart recovery)
- [x] SSLCommerz, bKash, Nagad real payment integration + webhooks + refunds
- [x] Rate limiting, audit logs, complete Bengali i18n, caching, Docker healthchecks
- [x] Frontend: customers, coupons, abandoned cart, bulk import, payment settings pages

---

## Sprint 4: Platform Harden & Subscription Billing ✅ COMPLETE
**Goal**: Fix remaining blockers, add usage enforcement, and enable revenue.

- [x] Login rate limiting (Redis-backed sliding window, per-IP, 5 attempts/60s, HTTP 429)
- [x] Image upload validation (client + server, 5 MB max, file-type allowlist, 10-image cap per product)
- [x] Primary image management (set primary, auto-promote on delete, storefront rendering)
- [x] Plan enforcement middleware (402 Payment Required on FREE/STARTER limit breach)
- [x] Subscription plan selection & checkout flow (manual/webhook payment verification)
- [x] Subscription lifecycle scheduler (asyncio background task — expiry, rollover, cancellation)
- [x] PaymentVerifier ABC unified (create_payment added to base, all 4 providers aligned)
- [x] Product list sort fix (sg COLINear model/schema name collision resolved)
- [x] Subscription payment checkout fix (import/service name collision resolved)
- [x] SQLAdmin path change (/admin → /sqladmin, avoids Next.js collision)
- [x] SECRET_KEY made mandatory at startup (model_validator)
- [x] Subscription management page, usage dashboard, cancellation flow
- [x] Super-admin panel: activity feed, settings, seller management, subscription override
- [ ] E2E test reliability (self-contained data, CI seed step)
- [x] Mobile sidebar auto-close on navigation

---

## Phase 1: Seller Dashboard & Storefront ✅ COMPLETE
**Goal**: Functional seller portal and public storefront. Sellers can create products, share links, and buyers complete self-service checkout — eliminating the manual Messenger workflow.

- [x] Dashboard with analytics (revenue, orders, low stock)
- [x] Product management (variants, bulk import, CSV, images)
- [x] Order management (fulfillment, status updates, tracking)
- [x] Customer management (lists, segments, communication)
- [x] Staff management (invite, roles, activity log)
- [x] Settings (shop profile, notifications, integrations)
- [x] Mobile-responsive layout
- [x] Public storefront themes
- [x] Shopping cart & checkout
- [x] Coupon/discount engine
- [x] COD + online payments (bKash, Nagad, SSLCommerz)
- [x] Order tracking (customer-facing)
- [x] Reviews & ratings
- [x] Printing / invoice generation (PDF download from order detail)

---

## Phase 2: Go-Live Readiness 🟡 PARTIALLY COMPLETE
**Goal**: Production-grade payment, delivery, invoicing, and storage. The platform must reliably accept money, ship goods, and generate receipts before onboarding real sellers.

- [ ] Real payment sandbox-to-production verification (bKash, Nagad, SSLCommerz) — *non-code: live credential setup*
- [x] Steadfast courier integration (booking, tracking, webhook status sync)
- [x] Invoice / packing-slip generation and PDF printing
- [x] S3/MinIO object storage implementation (+ MinIO dev service in docker-compose)
- [ ] E2E test reliability (self-contained seed data, CI Playwright step)
- [x] Mobile sidebar auto-close on navigation
- [x] Rate-limit tuning (Redis sliding window + login rate limiter deployed)
- [ ] Security audit (dependency scan, OWASP top-10 review) — *non-code: process task*
- [ ] Operational monitoring (health dashboards, backup/restore verification) — *non-code: infrastructure task*

---

## Phase 3: Social Commerce MVP 🔜 MARKET-DRIVEN
**Goal**: Turn the existing storefront engine into a volume business for Facebook sellers. The platform already works for one product / one link / one sale. Phase 3 makes it work for 50 products and 200 daily comments — without hiring assistants.

**Core premise**: A seller creates a product in ShopiBD → gets a shareable link → posts it on Facebook. The buyer clicks, sees price/images/description, adds to cart, pays via bKash/Nagad/COD, and enters their address — all self-service. Zero Messenger messages. The seller sees structured orders in the dashboard with inventory sync, customer history, and analytics. This workflow already works (Phase 1). Phase 3 adds volume, automation, and social-channel awareness.

### Tier A — Zero API Dependency (ship first, ~2 weeks)
*Works regardless of Meta API policies. Delivers immediate value with no integration risk.*

- [ ] Product share links (seller dashboard → copy link → paste on Facebook post/group)
- [ ] UTM / referral tracking (which Facebook post or group generated the order)
- [ ] Lightweight product landing pages (optimized for Facebook in-app browser, fast load on 3G)
- [ ] Bangla-first seller onboarding wizard (guided setup, minimal typing, voice-to-text where possible)
- [ ] Delivery status notifications (SMS + WhatsApp to buyers on order status change)

### Tier B — Facebook Page Integration (Meta Graph API, ~4 weeks)
*One-click publishing and comment monitoring. The seller's Facebook page becomes a channel, not a manual workload.*

- [ ] Facebook Page OAuth connection (seller links their Facebook page to ShopiBD)
- [ ] One-click publish: product goes from ShopiBD dashboard → Facebook page post with link and image
- [ ] Comment monitoring dashboard: surface "price" / "interested" / "কত" comments in seller dashboard
- [ ] Auto-reply to comments: "দাম দেখুন এবং অর্ডার করুন: [link]" (human-review queue first, not fully automated)
- [ ] Social analytics: which posts drive storefront visits and orders, conversion rate per channel

### Tier C — Conversational Commerce (Messenger/WhatsApp API, ~4 weeks)
*Full automation. Orders flow from social channels into the dashboard with minimal seller intervention.*

- [ ] Messenger bot: buyer messages page → bot sends product catalog → buyer selects items → structured order created in ShopiBD
- [ ] WhatsApp Business order flow: share catalog, capture address, generate bKash/Nagad payment link
- [ ] AI product description generator (Bangla + English, from product image or keywords)
- [ ] Abandoned cart recovery via Messenger/WhatsApp reminder

**Phase 3 target**: 50 active sellers acquired from Facebook groups, processing orders through the platform.

---

## Phase 4: Marketplace Expansion
**Goal**: Scale beyond individual seller storefronts to multi-vendor discovery and network effects.

- [ ] Guest checkout (no account required, phone-only order tracking)
- [ ] Bangladesh shipping zones & configurable rates (division/district-based)
- [ ] Multi-vendor marketplace (aggregated storefront, seller discovery, cross-seller cart)
- [ ] Marketplace commissions, vendor settlement, and dispute handling
- [ ] Catalogue moderation and seller quality scoring

---

## Phase 5: Advanced SaaS
**Goal**: Platform maturity, developer ecosystem, and enterprise-grade features.

- [ ] Seller API keys and developer access
- [ ] Webhook system for third-party integrations
- [ ] Advanced analytics (social-source conversion, repeat buyers, LTV, churn, stock forecasting)
- [ ] Automated accounting export (Tally, Xero compatible)
- [ ] White-label subscription gating (custom domain, remove ShopiBD branding)
- [ ] Multi-currency (BDT, USD) — when international expansion is active
- [ ] Usage metering dashboard (per-seller quota visualization)

---

## Phase 6: Ecosystem & Scale
**Goal**: Platform extensibility, multi-channel, and partnerships.

- [ ] TikTok Shop & Instagram channel support
- [ ] POS integration (offline sync, inventory reconciliation)
- [ ] Inventory sync with external ERPs
- [ ] Additional courier integrations (Pathao, Paperfly, RedX)
- [ ] Marketing campaign tools (email, SMS, WhatsApp bulk)
- [ ] AI-powered product recommendations
- [ ] App marketplace (plugins, extensions)
- [ ] Franchise / multi-location support

---

## Technical Debt & Maintenance (Ongoing)
- [x] Subscription lifecycle scheduler wired into FastAPI lifespan
- [x] PaymentVerifier ABC create_payment enforced across all providers
- [x] ORM model/schema naming collision fixed (Product vs ProductModel in sort)
- [x] Subscription route/service name collision fixed
- [x] SQLAdmin path isolated from Next.js /admin namespace
- [x] S3/MinIO object storage implementation (boto3, local dev MinIO)
- [x] Invoice/PDF generation service + API endpoint + frontend download button
- [ ] Dependency updates (monthly)
- [ ] Security audits (quarterly)
- [ ] Performance optimization
- [ ] Database indexing review (especially `orders.shop_id`, `products.shop_id`, `product_images.product_id`)
- [ ] Test coverage > 80%
- [ ] Documentation updates
- [ ] Disaster recovery drills
- [ ] Docker images published to registry
- [ ] Load testing (locust/k6)

---

## Success Metrics
| Metric | Phase 0 | Phase 1 | Phase 2 | Phase 3 | Phase 4 |
|--------|---------|---------|---------|---------|---------|
| Active Sellers | 5 (demo) | 20 (internal) | 50 (beta) | 500 | 5000 |
| Orders/Day | 10 | 50 | 200 | 2000 | 20000 |
| API Uptime | 99.9% | 99.9% | 99.95% | 99.95% | 99.99% |
| Test Coverage | 70% | 80% | 85% | 85% | 90% |
| Page Load (p95) | <2s | <1.5s | <1.5s | <1s | <800ms |

---

## Risk Mitigation
- **Regulatory**: Bangladesh e-commerce law compliance (Digital Security Act, Consumer Rights)
- **Payments**: SSLCommerz sandbox → production migration plan; bKash/Nagad API reliability fallbacks
- **Meta dependency**: Facebook API policy changes may restrict commerce automation. Mitigation: Tier A (Phase 3) requires zero API access and delivers standalone value; Tier B/C are amplifiers, not the foundation. Multi-platform (TikTok, Instagram) in Phase 6.
- **Redis availability**: Rate limiting falls back to in-memory when Redis is unreachable; subscription scheduler tolerates transient Redis failures without data loss
- **S3/MinIO**: Local storage is dev-only; production must use durable object storage before real seller onboarding. MinIO dev service now configured in docker-compose; switch with `STORAGE_BACKEND=s3`
- **Scaling**: Read replicas, Redis clustering, CDN for assets
- **Team**: Bus factor > 2 for critical components
- **Data**: Automated backups, PITR, GDPR-equivalent local compliance
- **Seller tech literacy**: Bangla-first UI, minimal-typing workflows, guided onboarding to reduce churn
