# Session Protocol - ShopiBD

## Development Session
1. Pull latest changes from main branch
2. Create feature branch: `feature/{module}-{description}`
3. Implement changes with tests
4. Update relevant .ai-context files
5. Push and create PR
6. Merge after review

## Code Standards
- Python: Black formatter, isort, mypy
- TypeScript: Prettier, ESLint
- Commits: Conventional commits (feat:, fix:, chore:)
- PRs: Require review, pass CI checks

## Testing Protocol
- Unit tests for services
- Integration tests for API endpoints
- E2E tests for critical flows
- Run: `pytest` (backend), `npm test` (frontend)

## Deployment Checklist
- [ ] All tests passing
- [ ] Environment variables set
- [ ] Database migrations run
- [ ] Docker images built
- [ ] Health checks verified

## Rollback Procedure
1. Identify failed deployment
2. Revert to previous Docker image
3. Restore database from backup if needed
4. Notify team on Slack

## Monitoring
- API health: `/health` endpoint
- Logs: Docker logs, structured JSON
- Metrics: Response time, error rate
- Alerts: Slack notifications for errors