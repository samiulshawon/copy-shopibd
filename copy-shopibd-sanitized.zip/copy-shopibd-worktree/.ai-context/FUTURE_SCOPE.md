# Future Scope — ShopiBD

## Legend
- ✅ **Done** — implemented and shipped
- 🔜 **Next Sprint** — planned for current/next sprint
- 📅 **Near-term** — next 1-2 months
- 🔭 **Medium-term** — 3-6 months
- 🌌 **Long-term** — 6+ months

---

## ✅ Completed (Sprints 0–3)

### Platform Foundation
- Multi-tenant seller/shop architecture
- JWT auth + refresh tokens
- Docker Compose dev & prod setup
- PostgreSQL database with Alembic migrations
- SQLAdmin panel with basic auth
- TypeSync (OpenAPI → TypeScript types)
- Contract tests (Schemathesis)
- Deterministic seed data
- Playwright E2E skeleton
- CI/CD pipeline (GitHub Actions)
- Rate limiting middleware (per-IP, per-seller)
- Audit log model + service + API
- Structured JSON logging
- Redis caching layer
- Docker healthchecks + restart policies

### Core Business Logic
- Seller registration, login, profile, dashboard stats
- Shop CRUD, storefront by slug, subdomain/custom domain routing
- Product CRUD with variants, categories
- Bulk product CSV import/export with validation
- Low stock alerts and threshold config
- Order lifecycle (create, status flow, tracking)
- Abandoned cart detection + recovery
- Staff invitation with role management (owner, manager, staff_viewer)
- Customer management with segments, search, filters
- Coupon/discount engine (percentage, fixed, min order, expiry)
- Stock movements and reservations
- Product reviews and ratings

### Bangladesh-Localized Features
- Bengali (bn) + English (en) i18n with RTL support
- BDT currency formatting throughout
- +880 phone validation
- SSLCommerz payment gateway (sandbox + production)
- bKash Merchant API integration (tokenized checkout)
- Nagad Merchant API integration
- Steadfast Courier integration
- SSLCommerz SMS provider (pluggable via factory)
- Meta WhatsApp Business API (pluggable via factory)

### Frontend Dashboard Pages
- Analytics (sales chart, stats cards, top products, pie chart)
- Orders list + detail with status updates
- Products CRUD + bulk add + CSV import wizard
- Customers list + filters + segments
- Coupon management
- Abandoned cart recovery settings
- Branding & custom domain
- Payment gateway settings (bKash/Nagad config)
- Staff invite + roles
- Shop profile & delivery settings
- Notifications
- Payment reconciliation

### Frontend Storefront Pages
- Shop landing page with product grid
- Product detail page
- Order form/checkout (address, payment method, coupon)
- Order success/confirmation
- Order tracking with progress bar

---

## 🔜 Sprint 4 — Platform Harden & Subscription Billing

**Goal:** Fix remaining blockers, add usage enforcement, and enable revenue.

- [ ] Login rate limiting (per-IP, 5 attempts/60s) ✅
- [ ] Image upload validation (client + server, max 5MB)
- [ ] E2E test reliability (self-contained data, CI seed step)
- [ ] Mobile sidebar auto-close on navigation
- [ ] Subscription billing checkout (bKash/Nagad/SSLCommerz)
- [ ] Plan enforcement middleware (block writes when over limit)
- [ ] Subscription management page & usage dashboard

---

## 📅 Near-term (Phase 2 Marketplace Features)

- [ ] Shipping zones & rates (Bangladesh divisions/districts)
- [ ] Guest checkout (no account required)
- [ ] Multi-vendor marketplace support
- [ ] Product image upload to S3/MinIO
- [ ] Unit test coverage for UI components
- [ ] Monitoring & alerting (uptime, error rates)

---

## 🔭 Medium-term (Phase 3 Advanced SaaS)

- [ ] Webhook system for external integrations
- [ ] API keys for seller developer access
- [ ] Multi-currency (BDT + USD)
- [ ] Advanced analytics (cohorts, LTV, churn)
- [ ] Automated accounting export
- [ ] White-label subscription gating

---

## 🌌 Long-term (Phase 4 Ecosystem)

- [ ] App marketplace (plugins, extensions)
- [ ] POS integration (offline sync)
- [ ] Inventory sync with external ERPs
- [ ] Accounting software integration (Tally, Xero)
- [ ] Logistics partners (Pathao, Paperfly, RedX)
- [ ] Marketing tools (email, SMS, WhatsApp campaigns)
- [ ] AI-powered product recommendations
- [ ] Franchise/multi-location support
- [ ] Mobile app (React Native)
- [ ] Elasticsearch-powered advanced search

---

## Technical Debt (Ongoing)

- [ ] Dependency updates (monthly)
- [ ] Security audits (quarterly)
- [ ] Performance optimization
- [ ] Database indexing review (especially `orders.shop_id`)
- [ ] Test coverage > 80%
- [ ] Documentation updates
- [ ] Docker images published to registry

---

## Research Topics

- GraphQL API layer
- Event-driven architecture (message queue)
- Machine learning for demand forecasting
- Progressive Web App (PWA) features
