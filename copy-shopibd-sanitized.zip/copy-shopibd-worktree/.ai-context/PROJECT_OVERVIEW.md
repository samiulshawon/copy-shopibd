# ShopiBD Project Overview

## Project Identity
- **Name**: ShopiBD
- **Type**: Multi-tenant SaaS E-commerce Platform
- **Target Market**: Bangladesh SMEs, retailers, wholesalers
- **Core Value**: "Shopify for Bangladesh" — localized, affordable, compliant

## Technical Stack
- **Backend**: FastAPI (Python 3.12+), SQLAlchemy 2.0, PostgreSQL 16, Redis 7
- **Frontend**: Next.js 14 (App Router), TypeScript, Tailwind CSS, TanStack Query
- **Infrastructure**: Docker, Docker Compose, Nginx (production)
- **Admin**: SQLAdmin with basic auth
- **Testing**: pytest, Schemathesis (contract), Playwright (E2E)

## Architecture Principles
1. **Multi-tenant by default** — Every entity scoped to seller/shop
2. **AI-agent friendly** — TypeSync, contract tests, deterministic seeds
3. **Bangladesh-first** — Bengali language, BDT currency, +880 phones, bKash/Nagad/SSLCommerz
4. **Production-ready** — Proper logging, rate limiting, audit logs, migrations
5. **Developer experience** — Makefile, dev containers, hot reload, TypeSync

## Domain Model
```
Seller (1) ──────► (1) Shop (1) ──────► (N) Product
                              │
                              ├──► (N) Category
                              ├──► (N) Order
                              ├──► (N) Customer
                              ├──► (N) Coupon
                              ├──► (N) StockMovement
                              └──► (N) Staff (roles: owner, manager, staff_viewer)
```

## Key Integrations
- **SMS**: SSLCommerz SMS, Twilio (pluggable via factory — mock active)
- **WhatsApp**: Meta Business API (pluggable via factory — mock active)
- **Payments**: bKash, Nagad, SSLCommerz (all implemented), Manual/COD
- **Courier**: Steadfast Courier API
- **Storage**: Local (S3/MinIO planned)

## Current Status
- **Phase**: Sprint 4.0 — Platform Harden & Subscription Billing 🔜
- **Completed Sprints**: Sprint 0 (Setup), Sprint 1 (Core Domain), Sprint 2 (Integrations), Sprint 3 (CRM/Payments/Discounts)
- **Focus**: Bug fixes, usage enforcement, subscription billing, plan gating
- **Next**: Marketplace features (shipping zones, guest checkout)

## Built Features (Sprints 0–3)

### Backend API Modules
| Module | Status |
|--------|--------|
| `/api/v1/auth` | ✅ Auth (register, login, rate-limited) |
| `/api/v1/sellers` | ✅ Profile, dashboard stats, usage, settings |
| `/api/v1/shops` | ✅ CRUD, storefront, subdomain/custom domain |
| `/api/v1/orders` | ✅ Order lifecycle, tracking, abandoned cart, coupon apply |
| `/api/v1/products` | ✅ CRUD, bulk create/stock/price, CSV import/export |
| `/api/v1/categories` | ✅ Category CRUD |
| `/api/v1/customers` | ✅ CRM, segments, broadcast |
| `/api/v1/coupons` | ✅ Discount engine, validation |
| `/api/v1/payments` | ✅ Payment reconciliation, SMS parsing |
| `/api/v1/payment_webhook` | ✅ bKash/Nagad/SSLCommerz webhooks |
| `/api/v1/delivery` | ✅ Shipments, courier management (Steadfast) |
| `/api/v1/staff` | ✅ Staff invite, role management |
| `/api/v1/analytics` | ✅ Dashboard stats, sales, top products |
| `/api/v1/reviews` | ✅ Product reviews & ratings |
| `/api/v1/stock` | ✅ Stock movements & reservations |
| `/api/v1/whitelabel` | ✅ Custom domain, branding settings |
| `/api/v1/audit_logs` | ✅ Activity log viewer |
| `/api/v1/admin` | ✅ Admin review moderation |

### Database Models
Seller, Shop, Product, Category, Order, OrderItem, StaffMember, StockMovement, ProductVariant, Review, PaymentTransaction, Delivery, Customer, Coupon, CouponUsage, ProductsImport, AuditLog

### Frontend Dashboard Pages
analytics, orders (list + detail), products (list + bulk import), customers, coupons, abandoned cart, branding & domain, payments, staff, settings, notifications

### Frontend Storefront Pages
shop home, product detail, order/checkout, order success, order tracking

## Constraints & Decisions
- Ports: 3000 (FE), 8000 (BE), 5434 (DB), 6380 (Redis), 8080 (Adminer)
- Auth: JWT access tokens + HttpOnly refresh cookies
- Migrations: Alembic (sync via psycopg2)
- i18n: JSON files, Bengali + English, RTL support
- Admin: SQLAdmin at /admin with basic auth
