# Task Template - ShopiBD

## Task: {TASK_NAME}

### Description
{BRIEF_DESCRIPTION}

### Acceptance Criteria
- [ ] Criterion 1
- [ ] Criterion 2
- [ ] Criterion 3

### Technical Details
**Files to modify:**
- `path/to/file.py`
- `path/to/file.ts`

**Dependencies:**
- List any dependencies

**API Changes:**
- Endpoint: `GET/POST /api/v1/resource`
- Request/Response format

### Implementation Steps
1. Step 1
2. Step 2
3. Step 3

### Testing
- Unit tests: `test_module.py`
- Integration tests: API endpoint tests
- Manual testing: Browser/API client

### Notes
- Any additional notes or considerations

### Status
- [ ] Todo
- [ ] In Progress
- [ ] Review
- [ ] Done