# Impact Graph - ShopiBD

## Core Components

```
Seller (Tenant)
    ├── Shop (Storefront)
    │   ├── Product (Catalog)
    │   ├── Order (Sales)
    │   └── Staff (Team)
    └── Settings (Configuration)
```

## Data Flow

```
User Request
    ↓
API Router (v1)
    ↓
Service Layer
    ↓
Database (SQLAlchemy)
    ↓
Response
```

## Notification Flow

```
Order Created
    ↓
Order Service
    ↓
Notification Service
    ├── SMS Service → Customer
    └── WhatsApp Service → Seller
```

## Authentication Flow

```
Login Request
    ↓
Auth Service
    ↓
JWT Token Generation
    ↓
Protected Route Access
```

## File Dependencies

- `app/main.py` → All routers and middleware
- `app/core/config.py` → All modules (configuration)
- `app/core/database.py` → All models
- `app/models/*.py` → `app/schemas/*.py`
- `app/api/v1/*.py` → `app/services/*.py`
- `app/services/sms/*.py` → `app/services/sms/factory.py`
- `app/services/whatsapp/*.py` → `app/services/whatsapp/factory.py`

## Impact Levels
- **High:** Seller, Shop models (tenant isolation)
- **Medium:** Product, Order models (core business)
- **Low:** Staff model (supporting entity)