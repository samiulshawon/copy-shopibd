# Known Issues & Technical Debt

> **Last Updated**: {{DATE}}
> **Maintainer**: Development Team

This document tracks known issues, bugs, workarounds, and technical debt items for the ShopiBD platform.

---

## How to Use

- Each issue has a unique ID (`KI-XXX`).
- Status: `Open` | `In Progress` | `Resolved` | `Won't Fix`
- Add new entries at the top of the list.
- Resolved entries are moved to the bottom section.

---

## Active Issues

### KI-005: Next.js 14 dependency chain has 3 high-severity advisories
- **Status**: Open (found 2026-08-22 via `npm audit --omit=dev`)
- **Priority**: High (must close before scaling beyond beta sellers)
- **Description**: `next@14.2.x` + bundled `postcss` flagged by GitHub: unbounded Server Action payload in Edge runtime (GHSA-4c39-4ccg-62r3), SSRF in rewrites via attacker-controlled destination hostname (GHSA-p9j2-gv94-2wf4), unauthenticated disclosure of internal Server Function endpoints (GHSA-955p-x3mx-jcvp), plus PostCSS XSS/sourceMap-path-traversal chain (GHSA-qx2v-qp2m-jg93 et al.).
- **Mitigations in place**: we do not use Next rewrites or Edge runtime; app is client-heavy calling the FastAPI API directly; nginx edge blocks internal endpoints; auth enforced per-endpoint.
- **Remediation**: dedicated sprint to upgrade Next 14 → latest 15/16 LTS-line (breaking: App Router APIs, postcss bump), then full Playwright regression. Tracked in MASTER_ROADMAP Phase 2 go-live checklist.

### KI-004: Playwright E2E tests fail without seed data
- **Status**: Resolved (2026-07-11)
- **Priority**: Medium
- **Reported**: 2024-01-20
- **Description**: The order-flow E2E tests expect products/orders to exist in the database. The CI environment needs a seed step before running Playwright tests.
- **Resolution**: The `frontend-e2e` CI job already runs `python -m scripts.seed` (seller, shop, products, 3 orders) before Playwright, and `backend/scripts/seed.py` creates the required data. All 7 E2E tests pass against the seeded DB. Locally, run `python -m scripts.seed` once before `npx playwright test`.
- **Fix**: Add a seed step to the CI workflow or make tests create data via API calls. (Done — seed step present in `.github/workflows/ci.yml`.)

### KI-003: Mobile sidebar does not close on route change
- **Status**: Resolved (2026-07-11 via Sprint 4 Task A4; reconciled 2026-08-22)
- **Priority**: Low
- **Description**: When navigating via the mobile sidebar sheet, the sheet did not automatically close after link click on some devices.
- **Resolution**: Task A4 replaced the mobile `null` return with a Sheet drawer that auto-closes via `useEffect` on `pathname`. Reopened during the 2026-08-22 verification pass only if a regression is observed on a real device.

### KI-002: OTP verification race condition
- **Status**: Won't Fix (reconciled 2026-07-11)
- **Priority**: Low
- **Reported**: 2024-01-15
- **Description**: Originally described a race condition when rapidly clicking "Resend OTP". On code review (2026-07-11), the OTP feature does not exist in the current backend: there are no `send-otp` / `verify-otp` / `resend-otp` endpoints, and the stale `test_auth.py` tests that hit `/api/v1/auth/verify-otp` were 404ing. OTP is not in Sprint 4 scope (see MASTER_ROADMAP).
- **Resolution**: Removed the two stale OTP tests from `backend/tests/test_auth.py` and updated the docstring. No code change required because the feature was never implemented.
- **Reopen if**: Phone-based OTP auth is added to the roadmap (currently Phase 2+ backlog). At that point implement a rate limiter on the OTP endpoint and invalidate previous OTPs on resend.

### KI-001: Image upload returns 413 Payload Too Large for large files
- **Status**: Resolved for CSV import; image upload is Phase 2 backlog (2026-07-11)
- **Priority**: Medium
- **Reported**: 2024-01-10
- **Description**: Originally about product image uploads >5 MB returning 413 from the reverse proxy. On code review (2026-07-11):
  - The backend has **no image-upload endpoint** — `Shop.logo_url` / product images are URL strings only. Real S3/MinIO image storage is tracked in MASTER_ROADMAP Phase 2 ("Product image upload to S3/MinIO — not yet implemented").
  - The **only** upload is CSV import (`POST /products/import`), which already has a server-side 5 MB check returning 413 (`backend/app/api/v1/products.py`) AND a client-side `MAX_FILE_SIZE = 5MB` guard in `csv-import-wizard.tsx`.
  - The nginx reverse proxy (the actual source of 413) is commented out in `docker-compose.yml`, so dev has no proxy to emit 413.
- **Resolution**: CSV import 413 is handled (server + client). Image-upload 413 cannot occur until the upload feature is built.
- **When image upload is built**: add `client_max_body_size 10M` to nginx and a server-side size guard on the new endpoint (mirror the CSV handling).

---

## Resolved Issues

### KI-000: Initial setup — placeholder
- **Status**: Resolved
- **Resolution Date**: 2024-01-01
- **Description**: Placeholder for the known issues tracker template.
- **Fix**: File created.

---

## Technical Debt Register

| ID       | Area          | Description                                | Effort | Impact |
| -------- | ------------- | ------------------------------------------ | ------ | ------ |
| TD-005   | Frontend      | ~70 `no-explicit-any` lint warnings (event handlers, API response maps) — demoted to warn in Step 4; type them while touching files in Phase 3 | 2 days | Low |
| TD-004   | Frontend      | No unit tests for UI components            | 3 days | Medium |
| TD-003   | Backend       | Missing database indexes on `orders.shop_id` | 1 day  | Low    |
| TD-002   | Infrastructure| No monitoring / alerting configured        | 5 days | High   |
| TD-001   | CI/CD         | Docker images not published to registry    | 2 days | Medium |

---

## Review Checklist

- [ ] Issues are triaged weekly
- [ ] Critical issues have an assignee
- [ ] Workarounds are documented
- [ ] Resolved issues are verified before closing
