# Prompt Templates - ShopiBD

## Feature Development
```
Create a {FEATURE_NAME} feature for ShopiBD with:
- Model: {MODEL_NAME}
- Schema: {SCHEMA_NAME}
- API endpoint: {ENDPOINT}
- Service: {SERVICE_NAME}
- Frontend component: {COMPONENT_NAME}

Follow existing patterns in the codebase.
```

## Bug Fix
```
Fix the {BUG_DESCRIPTION} in {FILE_PATH}.
The issue is {SPECIFIC_PROBLEM}.
Expected behavior: {EXPECTED_BEHAVIOR}
```

## Refactoring
```
Refactor {MODULE_NAME} to improve:
- Code organization
- Performance
- Readability
- Testability

Maintain backward compatibility.
```

## Testing
```
Add tests for {MODULE_NAME}:
- Unit tests for {FUNCTION_NAME}
- Integration tests for {ENDPOINT}
- Edge cases: {EDGE_CASES}
```

## Documentation
```
Document {FEATURE_NAME} in:
- API docs (OpenAPI)
- README.md
- Inline code comments
```

## Code Review
```
Review {PULL_REQUEST} for:
- Code quality
- Security issues
- Performance
- Best practices
```