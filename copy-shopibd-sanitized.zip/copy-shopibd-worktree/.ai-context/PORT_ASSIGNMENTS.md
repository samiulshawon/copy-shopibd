# Port Assignments - ShopiBD

## Development Ports
| Service | Port | Description |
|---------|------|-------------|
| Backend API | 8000 | FastAPI application |
| Frontend Dev | 3000 | Next.js development server |
| Database | 5434 | PostgreSQL (development, host port) |
| Redis | 6379 | Caching and sessions |
| Adminer | 8080 | Database admin UI |

## Docker Compose Ports
| Service | Host Port | Container Port |
|---------|-----------|----------------|
| backend | 8000 | 8000 |
| frontend | 3000 | 3000 |
| postgres | 5434 | 5432 |
| redis | 6380 | 6379 |
| adminer | 8080 | 8080 |

## Environment Variables
```bash
# Backend
BACKEND_HOST=0.0.0.0
BACKEND_PORT=8000

# Frontend
FRONTEND_HOST=localhost
FRONTEND_PORT=3000

# Database
POSTGRES_HOST=postgres
POSTGRES_PORT=5434
```

## Notes
- All ports are configurable via environment variables
- Development uses hot-reload on ports 3000 and 8000
- Production may use reverse proxy (nginx) on port 80/443
- 5433 was in use by Docker Desktop, using 5434 instead
