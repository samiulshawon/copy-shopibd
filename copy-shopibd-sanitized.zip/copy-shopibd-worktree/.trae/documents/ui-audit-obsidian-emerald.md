# Final UI/UX Plan — Obsidian Emerald Conformance + Premium Polish

## Summary

Bring **every user-visible page** in the ShopiBD Next.js frontend into conformance with the **Obsidian Emerald** dark design system (the system used by the `dashboard`, `order`, and `products` demos in `demodesign/`), **and** elevate it from "correct dark theme" to a **premium, dynamic** feel — without changing the brand identity or adding heavy dependencies.

Two tracks combined into one plan:
- **Track A — Conformance**: align tokens/primitives + remove drift (heavy shadows, oversized radii, blue, success-vs-primary collision) + match the 5 demo layouts.
- **Track B — Premium polish**: add a motion system, ambient depth, animated data-viz, shimmer loaders, and keyboard polish — all CSS-first (no new deps), grounded in the existing `--ease` and `shadow-glow`.

The current app is already dark-mode-only and its tokens already match Obsidian Emerald's core values (`#131313` background, mint `#83d7b4` primary, Plus Jakarta Sans). The remaining work is normalization, per-page conformance, and premium polish — not a rebuild.

**5 demo → target mapping** (demos are layout references; the two light demos are skinned dark):

| Demo | Target page(s) |
|---|---|
| `dashboard` | `src/app/dashboard/page.tsx` (+ `page-client.tsx`, `components/dashboard/stats-cards.tsx`, `sales-chart.tsx`, `top-products.tsx`) |
| `order` | `src/app/dashboard/orders/page.tsx` + `src/app/dashboard/orders/[id]/page.tsx` (+ `page-client.tsx`) |
| `products` | `src/app/dashboard/products/page.tsx` + `[id]` + `new` + `components/dashboard/product-form.tsx` |
| `payment` (layout only → dark skin) | `src/app/[slug]/order/page.tsx` (consumer checkout) |
| `storefront` (layout only → dark skin) | `src/app/[slug]/page.tsx` + `components/storefront/*` |

All other pages follow Obsidian Emerald with their own decorative patterns where no demo covers them.

## Current State Analysis (from exploration)

**Already aligned with Obsidian Emerald** (`frontend/src/app/globals.css` + `tailwind.config.ts`):
- `<html lang="bn" className="dark">`, `color-scheme: dark` — dark-mode-only ✓
- `--background: 0 0% 7.5%` ≈ `#131313`, `--primary: 158 53% 68%` ≈ `#83d7b4`, `--primary-foreground: 158 100% 11%` ≈ `#003828` ✓ (exact Obsidian match)
- Green primary across `button.tsx`, `badge.tsx`, focus rings, table selection; no blue in tokens ✓
- Fonts: Plus Jakarta Sans + Noto Sans Bengali ✓
- Premium easing `--ease: cubic-bezier(0.16, 1, 0.3, 1)` defined ✓; `prefers-reduced-motion` globally respected ✓
- Charts are **hand-rolled SVG** (`sales-chart.tsx` builds `<path>` manually) → polishable with CSS, no chart-lib dep needed
- Shared layout primitives exist: `components/layout/page-structure.tsx` exports `MetricCard`/`MetricStrip` (single enhancement point for metric polish)
- `formatCurrency` in `lib/utils` → ready for animated count-up

**Drift / premium gaps (grep-confirmed):**
1. **Heavy shadows / oversized radii** — 87 hits across 26 files (`shadow-(sm|md|lg|xl|2xl)|drop-shadow|rounded-2xl|rounded-3xl`). Worst: `orders/[id]` (15), `payments` (12), `sales-chart` (12), `analytics` (7), `dashboard/page-client` (6). Obsidian forbids heavy shadows (tonal layering + 1px borders) and caps radius at `xl` (1.5rem).
2. **Hardcoded blue / white / black** — 25 hits across 12 files. Some legitimate (branding/preview surfaces rendering user-chosen colors: `branding/page-client.tsx`, `brand-preview.tsx`, `product-form.tsx`); others real drift (`admin/page.tsx` 3, `admin/clients/*` 6).
3. **`--success` identical to `--primary`** — success indistinguishable from brand. Obsidian: success/active = deep emerald `#006a4e` at 15% opacity (`primary-container`).
4. **Radius inconsistency in primitives** — `button/card/input/dialog/dropdown` mix `rounded-lg/md/xl/sm` with no single source of truth.
5. **`info` Badge variant reuses green** — acceptable (Obsidian has no blue/info role); keep emerald-muted, do not introduce blue.
6. **No `@keyframes` exist anywhere** — zero custom animations despite a premium easing token. This is the single biggest premium gap: the UI is static.
7. **No ambient depth** — flat `#131313` everywhere; no subtle glows/grain that premium dark themes (Linear/Vercel) use to avoid banding and add tactility.
8. **Static data-viz** — SVG chart paths have no entrance animation; numbers don't count up.

**Page inventory:** ~30 routes across root/marketing (`/`, `/pricing`), auth (`/auth/login`, `/auth/register`), dashboard (17), admin (7), storefront (`/[slug]`, `/[slug]/products/[id]`, `/[slug]/order`, `/[slug]/order/success`, `/[slug]/orders/track`). Layouts: root `layout.tsx`, `dashboard/layout.tsx` → `DashboardShell`, `admin/layout.tsx` → `SuperAdminShell`, `[slug]/layout.tsx` → storefront. Shared shells in `src/components/layout/`.

## Proposed Changes

### WP1 — Token & primitive foundation (Track A) + motion/depth primitives (Track B)
**Files:** `frontend/src/app/globals.css`, `frontend/tailwind.config.ts`, `frontend/src/components/ui/*`, `frontend/src/components/layout/page-structure.tsx`

**Track A (conformance):**
- `globals.css`: add the exact Obsidian surface ramp from `demodesign/dashboard/DESIGN.md`: `--surface-1: #0e0e0e`, `--surface-2: #1c1b1b`, `--surface-3: #201f1f`, `--surface-high: #2a2a2a`, `--surface-highest: #353534`; add `--outline: #88938d`, `--outline-variant: #3f4944`. Change `--success: 162 100% 21%` (`#006a4e`) + `--success-foreground: 152 71% 81%` (`#92e7c3`) to distinguish success/active from brand primary. Keep `--background`, `--primary`, `--destructive` as-is (already correct).
- `tailwind.config.ts`: add `borderRadius` scale (`sm 0.25rem`, `DEFAULT 0.5rem`, `md 0.75rem`, `lg 1rem`, `xl 1.5rem`); map `rounded-2xl/3xl` → `rounded-xl` during WP2–WP4. Keep `shadow-glow` (sanctioned brand moment); demote other `shadow-*` toward tonal layering (`bg-surface-2 border border-outline-variant`).
- Primitives (`button`, `card`, `input`, `dialog`, `dropdown-menu`, `alert`, `badge`, `table`, `tabs`, `select`, `toast`, `avatar`, `skeleton`): normalize to one radius scale; replace heavy shadows with tonal layering; keep Button primary = `bg-primary shadow-glow`; confirm zero blue.

**Track B (premium primitives) — all CSS, no new deps:**
- `globals.css`: add `@keyframes` set using `--ease`: `fade-up`, `fade-in`, `stagger-in`, `shimmer`, `count-up`, `draw-path`, `slide-in-right` (for toasts), `glow-pulse` (subtle, for brand moments). All gated by the existing global `prefers-reduced-motion` reset (already in file) → zero a11y risk.
- Add two ambient depth layers in `layout.tsx` / shell components: (a) a fixed, pointer-events-none **SVG grain overlay** at ~3% opacity above `#131313` to kill banding and add tactility; (b) a soft **emerald radial-glow** (`--primary` at ~8% opacity, blurred) behind dashboard + storefront heroes.
- `components/layout/page-structure.tsx` (`MetricCard`): add animated **count-up** for numeric values (requestAnimationFrame + `formatCurrency`), a hover lift via tonal-layer shift (surface-2 → surface-3 + 1px outline-variant), and a staggered entrance (`animation: fade-up` with `nth-child` delay).
- `components/ui/skeleton.tsx`: add `shimmer` sweep (emerald-tinted gradient translating across) for premium loading states.
- `components/ui/toast.tsx`: add `slide-in-right` + an emerald **progress-bar auto-dismiss** sweep so toasts feel alive.

### WP2 — Match the 5 demo layouts + apply premium polish (priority)
For each target, open the matching `demodesign/<area>/code.html` for structure, render in the dark Obsidian Emerald theme using primitives + the new motion system. Do not copy light demo colors.

- **dashboard** → `app/dashboard/page.tsx` + `page-client.tsx` + `components/dashboard/stats-cards.tsx`, `sales-chart.tsx`, `top-products.tsx`: match the demo's metric-card grid + chart layout. Fix 6 shadow/rounded hits in `page-client.tsx`, 12 in `sales-chart.tsx` → tonal layering + `rounded-xl`. **Premium:** count-up on metric values; SVG path **draw-in** (`stroke-dashoffset` animation) on `sales-chart.tsx`; staggered fade-up on the card grid; emerald gradient fill under the line.
- **order** → `app/dashboard/orders/page.tsx` (list) + `[id]/page-client.tsx` (detail): match the demo's orders table + detail layout. Fix 15 hits in `[id]`, 2 in list. **Premium:** row hover tonal-shift + 1px outline-variant left indicator; status badges use the new deep-emerald success (distinct from brand primary); detail page sections fade-up on mount.
- **products** → `app/dashboard/products/page.tsx` (+ `[id]`, `new`) + `components/dashboard/product-form.tsx`: match the demo's product grid/table. Fix 6 hits in `product-form.tsx`. Leave user-color previews intact. **Premium:** product cards tonal-shift on hover with a soft emerald border-glow; grid stagger entrance.
- **payment (checkout)** → `app/[slug]/order/page.tsx`: use `demodesign/payment/code.html` as the **layout** reference (checkout summary + payment method selection + CTA) skinned dark (mint primary CTA, `#0e0e0e`/`#1c1b1b` surfaces, no Tech Blue, no white cards). **Premium:** method-selection cards get a 1px outline-variant border that animates to emerald on `:checked`; CTA uses `shadow-glow`; success transition uses `fade-up`.
- **storefront** → `app/[slug]/page.tsx` + `components/storefront/*` (`product-card.tsx`, `shop-header.tsx`, `storefront-footer.tsx`, `product-detail.tsx`): use `demodesign/storefront/code.html` as the **layout** reference (1440px container, product grid, hero) skinned dark. Fix 2 hits in `product-card.tsx`, 1 in `shop-header.tsx`, 1 in `storefront-footer.tsx`, 3 in `product-detail.tsx`. **Premium:** storefront hero gets the ambient emerald glow + grain; product cards stagger-in on scroll; "Add to Cart" uses emerald (not Tech Blue — single-brand consistency).

### WP3 — Remaining dashboard pages (conformance + light polish)
Conformance pass (replace heavy shadows with tonal layering, `rounded-2xl/3xl` → `rounded-xl`, remove blue, use Obsidian radii/typography) + apply motion where it adds value. Pages: `customers/page-client.tsx` (2), `payments/page-client.tsx` (12), `analytics/page-client.tsx` (7), `subscription/success/page-client.tsx` (1), `subscription/cancel/page-client.tsx` (1), `notifications/page-client.tsx` (1), `settings/page-client.tsx` (1), `branding/page-client.tsx` (keep user-color previews), `staff`, `coupons`, `abandoned`. Dashboard shell/header/sidebar (`components/layout/dashboard-shell.tsx` 1 hit) verified against Obsidian sidebar spec (`#0a0a0a` sidebar, emerald active indicator). **Premium:** sidebar active item gets the animated gradient-border accent; analytics charts get SVG draw-in.

### WP4 — Admin + auth + marketing + remaining storefront (conformance + polish)
- **Admin:** `admin/page.tsx` (3), `admin/clients/page.tsx` (3), `admin/clients/[id]/page.tsx` (3), `admin/reviews`, `admin/activity`, `admin/settings` + `super-admin-shell.tsx`. Same shell as dashboard (Obsidian sidebar). **Premium:** admin stat cards count-up; client list rows tonal-shift on hover.
- **Auth:** `auth/login/page.tsx`, `auth/register/page.tsx` — Obsidian Emerald centered card on `#131313`, mint primary button, `#0e0e0e` card with 1px `#3f4944` border. **Premium:** subtle emerald glow accent behind the card; `fade-up` on mount; input focus animates border to emerald.
- **Marketing:** `page.tsx` (root), `pricing/page.tsx` (2) — Obsidian Emerald hero (ambient glow + grain), no blue, tonal cards. **Premium:** hero headline `fade-up` + staggered feature cards; pricing cards tonal-shift on hover.
- **Storefront remaining:** `[slug]/products/[id]/page.tsx`, `[slug]/order/success/page.tsx`, `[slug]/orders/track/page.tsx` — match storefront demo's product-detail + success layout, dark skin. **Premium:** product image hover zoom (subtle); success page `fade-up` + emerald check glow.
- `providers.tsx`, root `layout.tsx`: confirm theme (already `dark`); add the grain overlay + ambient glow mounts here.

### WP5 — Verification
- Static grep re-run: 0 remaining `blue-*|indigo-*|sky-*|cyan-*` outside branding-preview files; `shadow-(xl|2xl)|drop-shadow|rounded-2xl|rounded-3xl` reduced to spec-allowed only (glow on primary button is allowed); 0 remaining heavy shadows on cards/dialogs.
- `cd frontend && npm run build` passes with no new errors; `npm run lint` clean.
- Visual spot-check of the 5 demo pages against `demodesign/*/screen.png` (layout parity, dark skin) — compare structure, not color, for the two light demos.
- Motion a11y check: with `prefers-reduced-motion: reduce` OS setting, confirm all animations collapse to instant (the global reset already enforces this — verify it still does after adding keyframes).
- (Optional) Playwright screenshots of one page per area for a final visual diff.

## Optional Opt-Ins (not in scope by default; decide at execution time, no re-plan needed)
These are premium extras that need a new dependency. **Default = skip** to keep the plan low-risk and dep-free. If you want any, say so before/at execution:
1. **`framer-motion`** — richer page transitions, layout animations, gestures. Replaces some CSS keyframes with a more capable system. ~1 dep.
2. **`cmdk` command palette (Cmd+K)** — premium SaaS signature for quick nav/search. ~1 dep + a new component.
3. **`vaul` drawer** — bottom-sheet drawers for mobile storefront filters. ~1 dep.
4. **`sonner`** — upgraded toast system with swipe-to-dismiss + richer stacking. Replaces current `toast.tsx`. ~1 dep.

## Assumptions & Decisions
1. **Theme = Obsidian Emerald (dark) everywhere**, per your decision. Light `payment`/`storefront` demos are layout references only; their colors are not used.
2. **Keep Plus Jakarta Sans + Noto Sans Bengali** (do not add Inter — Obsidian is single-family Plus Jakarta Sans; Bengali support required for `bn` locale).
3. **No blue accent.** `info` Badge stays emerald-muted (Obsidian has no blue/info role).
4. **Branding/preview surfaces exempt**: `dashboard/branding`, `brand-preview.tsx`, color-picker parts of `product-form.tsx` intentionally render seller-chosen colors (incl. white/blue) — left intact (user content, not theme drift).
5. **`--success` → deep emerald `#006a4e`** (distinct from mint primary) — the only token semantic change.
6. **Premium polish is CSS-first, zero new deps** (keyframes + existing `--ease` + SVG); framer-motion/cmdk/vaul/sonner are opt-in only.
7. **Heavy shadows → tonal layering** is the primary visual change; green `shadow-glow` on primary buttons kept as a sanctioned brand moment.
8. **Radii normalized** to Obsidian scale; `rounded-2xl/3xl` → `rounded-xl`/`rounded-lg` by context.
9. **Motion respects `prefers-reduced-motion`** (globally reset already) — zero a11y regression.
10. **No new roadmap phase/spec files** — this is a pre-launch UI conformance + polish pass, not a `enhancement-roadmap-2026` phase.

## Verification Steps
1. After WP1: grep `components/ui` for `blue-` (0) and `rounded-2xl|3xl` (0); load one dashboard page to confirm tokens resolve dark + emerald + animated count-up works.
2. After WP2: open each of the 5 target pages in-browser and compare structure to `demodesign/*/screen.png`; confirm dark Obsidian skin + motion (count-up, path draw-in, stagger, hover glow).
3. After WP3–WP4: re-run the two grep drift scans; expect non-branding blue = 0 and heavy-shadow/oversized-radius reduced to spec-allowed only.
4. `npm run build` + `npm run lint` clean.
5. Toggle OS `prefers-reduced-motion` and confirm all animations collapse to instant.
6. Final: per-area conformance + polish summary (which pages changed, what was fixed, which premium effects added).

## Out of Scope
- Bengali i18n translation work (deliberately deferred per the roadmap).
- Backend changes (none needed for a UI skin/polish pass).
- Adding a light theme or Tech Blue (explicitly not wanted — everything dark).
- New features; only visual conformance to Obsidian Emerald + premium polish.
- Opt-in deps (framer-motion/cmdk/vaul/sonner) unless you approve at execution time.

## Suggested Execution Order
WP1 (foundation + motion primitives) → WP2 (5 demo pages, highest value) → WP3 (dashboard) → WP4 (admin/auth/marketing/storefront) → WP5 (verify). Each WP is independently shippable; WP1 unblocks all others.
