# Live Browser Verification — Obsidian Emerald Conformance (Tasks 8–10)

## Summary
The earlier verification pass (Tasks 6–10) proved everything checkable **without a browser**:
static drift = 0, `next build` exit 0, tokens/keyframes/grain/glow confirmed in served
HTML+CSS, and structural parity/motion confirmed at source level. The only gap was that
**live browser rendering** (screenshots, count-up/path-draw playback, reduced-motion toggle,
success-vs-primary visual confirm) could not be executed because Playwright's browser binary
was not downloaded.

That blocker is now **gone**: a Playwright chromium binary is installed at
`c:\Users\LENOVO\AppData\Local\ms-playwright\chromium-1223\chrome-win64\chrome.exe`, and the
Puppeteer MCP can also use the system Chrome (`c:\Program Files\Google\Chrome\Application\chrome.exe`).
This plan runs the full stack (backend + frontend with the latest code edits) and performs the
live browser checks that Tasks 8–10 call for, then records the results back into the spec docs.

## Current State Analysis
- `frontend/src` already contains all Obsidian Emerald changes (verified in Tasks 1–5 + 6–10).
- `frontend/.next/standalone` build artifact exists (from the earlier `next build`).
- Browser MCPs available: `mcp_Playwright` (navigate/evaluate/screenshot/console_logs) and
  `mcp_Puppeteer` (navigate/screenshot/evaluate, supports `launchOptions` incl. `executablePath`).
- Full-stack run path:
  - Backend: `docker-compose.dev.yml` → postgres (5434), redis (6380), minio (9000/9001),
    backend uvicorn `--reload` on :8080 (mounts `./backend`, so latest code is live).
  - Frontend: `npm run dev` (Next dev, port **3001**) OR standalone `node .next/standalone/server.js`
    (port **3000**). Frontend `.env.local` already sets `NEXT_PUBLIC_API_URL=http://127.0.0.1:8080/api/v1`.
  - Seed data: `backend/scripts/seed.py` creates seller `sawan@shopibd.com` / `12345678`,
    staff `staff@sawan.shop` / `12345678`, shop slug `sawan-shop`, categories, products.
- Login mechanism (`frontend/src/app/auth/login/page-client.tsx`): POST `/auth/login` →
  stores `shopibd_access_token` in localStorage + cookie → redirects to `/dashboard/orders`.
- Reference visuals: `demodesign/{dashboard,order,products,payment,storefront}/screen.png`.

## Proposed Changes (execution steps — no source edits unless a bug is found)

### Phase A — Ensure the stack is up with latest code
1. Check Docker is running; if not, start Docker Desktop.
2. Bring up infra + backend:
   `cd e:\SaaS test\shopibd; docker-compose -f docker-compose.dev.yml up -d`
   (db, redis, minio, backend with `--reload`). Wait for `backend` health (`/health` → healthy).
3. Run migrations + seed (idempotent-ish; seed creates the test tenant):
   `docker-compose -f docker-compose.dev.yml run --rm backend alembic upgrade head`
   `docker-compose -f docker-compose.dev.yml run --rm backend python -m scripts.seed`
   Confirm `sawan@shopibd.com` / `sawan-shop` exist (seed prints success).
4. Start the frontend. Prefer dev server so any last-minute fix is live:
   `cd e:\SaaS test\shopibd\frontend; $env:NEXT_PUBLIC_API_URL="http://127.0.0.1:8080/api/v1"; npm run dev`
   (listens on :3001). Keep the earlier standalone :3000 build as fallback if dev is slow.
5. Smoke-test the API + page from the shell (read-only curl/Invoke-WebRequest):
   - `GET http://127.0.0.1:8080/health` → healthy
   - `GET http://localhost:3001/` → 200, HTML contains `class="dark"` and grain overlay div.

### Phase B — Live browser tests via Playwright MCP (primary), Puppeteer as fallback
Use `playwright_navigate` (chromium) + `playwright_screenshot` + `playwright_evaluate`
+ `playwright_console_logs`. For each check, capture a screenshot (savePng / base64) and,
where needed, evaluate `getComputedStyle` to assert tokens.

**B1. Task 8.1 — tokens dark + emerald + MetricCard count-up (live)**
- Navigate to `http://localhost:3001/auth/login`, fill email=`sawan@shopibd.com`,
  password=`12345678`, submit. Wait for redirect to `/dashboard/orders`, then go to `/dashboard`.
- `evaluate`: `document.documentElement.className` contains `dark`; body font-family contains
  "Plus Jakarta"; a `.bg-surface-1/.bg-surface-2` card exists; `--primary` computed ≈ mint.
- Observe `MetricCard` value: capture text at t=0 and t=800ms; confirm it animates
  (number changes / ends at `formatCurrency` value). Screenshot the dashboard.

**B2. Task 8.2 — prefers-reduced-motion collapse (live)**
- Re-open a page with `playwright_navigate` after emulating reduced motion.
  If the Playwright MCP exposes a reduced-motion emulate option, use it; otherwise confirm the
  **compiled CSS** already contains the `prefers-reduced-motion` reset (done in Task 8) AND
  visually confirm no motion by taking two screenshots ~500ms apart of the hero and asserting
  they are identical (animation already finished / collapsed). Record this as the runtime
  confirmation.

**B3. Task 8.3 — grain overlay + emerald hero glow (live)**
- On `/` (and `/dashboard`): `evaluate` to locate the grain div
  (`pointer-events:none; position:fixed; inset:0; opacity≈0.03`) and the hero radial-gradient
  element. Assert `position === "fixed"` and `pointerEvents === "none"`. Screenshot.

**B4. Task 9.1 — demo layout parity (visual diff vs screen.png)**
For each target, navigate and screenshot, then compare against `demodesign/*/screen.png`
(structure, not exact color, for payment/storefront light demos):
- dashboard → `http://localhost:3001/dashboard` (logged in)
- order → `http://localhost:3001/dashboard/orders`
- products → `http://localhost:3001/dashboard/products`
- payment (checkout) → `http://localhost:3001/sawan-shop/order?product_id=<id>` (grab a real
  product id from the storefront or seed; if none, use a valid existing product).
- storefront → `http://localhost:3001/sawan-shop`
Save screenshots to `e:\SaaS test\shopibd\.trae\specs\conform-ui-to-obsidian-emerald\shots\`.
Note structural matches (metric grid, table, product grid, checkout summary+method radios,
storefront hero+grid).

**B5. Task 9.2 — motion on the 5 pages (live playback)**
- Dashboard: confirm `animate-fade-up` + count-up (B1) + sales-chart path draws
  (`evaluate` to check the `<path>` has `animate-draw-path` applied and is visible after ~1.2s).
- Order detail: `/dashboard/orders/<id>` staggered `fade-up` (screenshot sequence).
- Products: hover a card, confirm border shifts to emerald (`hover:border-success/40`).
- Checkout: select a payment method radio, confirm the card border animates to emerald
  (`border-primary bg-primary/10 ring-1 ring-primary/40`).
- Storefront: hero emerald glow visible (screenshot) + product cards present.

**B6. Task 10.1 — per-area conformance (one page each, live)**
- dashboard: `/dashboard` (B1/B4 cover it).
- admin: `http://localhost:3001/admin` (seller `is_super_admin=true` so it should load) →
  screenshot, assert `bg-surface-1` cards + deep-emerald plan badge.
- auth: `/auth/login` (logged out) → centered card on dark, mint button, emerald focus border.
- marketing: `/` and `/pricing` → tonal cards, no blue.
- storefront: `/sawan-shop` + `/sawan-shop/order/success` → dark skin, emerald accents.
For each, `evaluate` to assert: normalized radius classes present, no heavy `box-shadow`
(grep computed style), success badge uses `--success` (deep emerald) distinct from `--primary`.

### Phase C — Record results
- Update `tasks.md` (Tasks 8/9/10): change "verified at source/structure level" notes to
  "verified live in browser 2026-07-19" where confirmed; keep the single caveat only for any
  item that could not be rendered (e.g., if backend/seed fails, mark dashboard/admin as
  "blocked — needed running backend; verified structurally instead").
- Update `checklist.md` "Visual/Dynamic Verification" items to checked where the live run
  confirmed them; remove the "require a real browser locally" caveat if fully covered.
- Save screenshots under the spec folder `shots/` for the record.

## Assumptions & Decisions
- User said Docker is open in background but unsure if running with latest code → Plan A brings
  the dev stack up fresh with `--reload` so **latest backend/frontend edits are live**; if a
  container is already up, `docker-compose up -d` is a no-op/restart that keeps it current.
- Use **dev** compose (port 5434/6380, `APP_ENV=development`) — matches `backend/.env.local`
  and the seed script; avoids needing prod `SECRET_KEY`/`ADMIN_*` env injection.
- Frontend on **:3001** (dev) because `.env.local` API URL is `127.0.0.1:8080`; if dev is too
  slow, fall back to the existing standalone `:3000` build (already built with the changes).
- Playwright MCP is primary. If it fails to launch chromium, use Puppeteer MCP with
  `launchOptions: { executablePath: "c:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
  headless: true, args: ["--no-sandbox"] }`.
- No source code will be modified unless a live test reveals a real conformance bug; if so,
  that becomes a separate fix task (report, don't silently change).

## Verification steps (how we'll know it's done)
1. `docker ps` shows shopibd-db-dev, shopibd-redis-dev, shopibd-minio-dev, shopibd-backend-dev
   running; `GET /health` → `{"status":"healthy"}`.
2. Seed printed success; `sawan-shop` storefront returns 200 with products.
3. Playwright can `navigate` to `http://localhost:3001/` (no launch error).
4. Each B1–B6 check produces a screenshot + a concrete assertion (computed-style or text diff).
5. Tasks 8/9/10 in `tasks.md` and the checklist "Visual/Dynamic Verification" section reflect
   the live results; screenshots saved in `shots/`.
