# Phase 2 Optimization Pass — Plan

## Context

The MASTER_ROADMAP defines Phase 2 "Go-Live Readiness" with 9 items. The deep reasoning review revealed:

- **Steadfast courier** is already fully implemented (backend + frontend).
- **Payment gateways** (SSLCommerz, bKash, Nagad) are code-complete; only sandbox-to-production credential testing remains (non-code task).
- **Rate-limit tuning** is already done (Redis sliding window, checked in roadmap).
- **Security audit** and **operational monitoring** are process/infrastructure tasks, not code changes.

This leaves 4 actionable code items plus 1 critical bug.

---

## Summary of Changes

| # | Item | Type | Priority |
|---|------|------|----------|
| 1 | Fix subscription scheduler runtime crash | Bug fix | P0 |
| 2 | Implement S3/MinIO storage (boto3) | Feature | P1 |
| 3 | Build invoice/PDF generation | Feature | P1 |
| 4 | Mobile sidebar auto-close on navigation | UX fix | P2 |
| 5 | Add tests for new Phase 2 components | Tests | P2 |

---

## 1. Fix Subscription Scheduler Runtime Crash (P0)

**Problem:** `main.py` line 32 calls `run_all_subscription_tasks(db=db)`, but the function in `subscription_tasks.py` line 133 takes zero parameters and creates its own session internally. This will raise a `TypeError` at runtime when the scheduler fires.

**Root cause:** During the Optimization Pass fixes 5-7, the lifespan was wired to call `run_all_subscription_tasks(db=db)` but the function signature was never updated. The function creates `SessionLocal()` internally.

**Fix:** Remove the `db=db` parameter from the call site in `main.py` line 32. The function handles its own session lifecycle.

**Affected files:**
- `e:\SaaS test\shopibd\backend\app\main.py` — line 32: change `run_all_subscription_tasks(db=db)` → `run_all_subscription_tasks()`

---

## 2. Implement S3/MinIO Storage (P1)

**Problem:** `S3StorageService.save()` and `.delete()` both raise `NotImplementedError`. No production storage exists — all media lives on the container filesystem and is lost on restart.

**What to build:**
- Real `S3StorageService` using `boto3` that uploads to S3/MinIO and returns public URLs
- Support both AWS S3 and MinIO (via `AWS_S3_ENDPOINT_URL` config)
- Content-type detection and ACL settings
- Error handling with retries for transient failures

**Implementation plan:**

### 2a. Add `boto3` dependency
- **File:** `e:\SaaS test\shopibd\backend\pyproject.toml` — add `"boto3>=1.28.0"` to dependencies
- **File:** `e:\SaaS test\shopibd\backend\requirements.txt` — add `boto3>=1.28.0`

### 2b. Implement `S3StorageService`
- **File:** `e:\SaaS test\shopibd\backend\app\services\storage.py`
- Replace the `NotImplementedError` stubs with:
  - `__init__`: Create a `boto3.client("s3")` with configurable endpoint for MinIO, region, keys
  - `save(file, folder)`: Validate → read content → `client.put_object(Bucket, Key, Body, ContentType, ACL)` → return public URL
  - `delete(url)`: Parse key from URL → `client.delete_object(Bucket, Key)`
  - URL construction: if `AWS_S3_ENDPOINT_URL` is set (MinIO), use `{endpoint}/{bucket}/{key}`; otherwise use the standard S3 URL pattern
  - Add `_get_content_type(ext)` helper mapping `.jpg`→`image/jpeg`, `.png`→`image/png`, etc.

### 2c. Update static file serving
- **File:** `e:\SaaS test\shopibd\backend\app\main.py` — lines 87-94
- When `STORAGE_BACKEND=s3`, skip the `StaticFiles` mount (S3 serves files directly). Add a comment explaining this.

### 2d. Add S3/MinIO to docker-compose
- **File:** `e:\SaaS test\shopibd\docker-compose.dev.yml`
- Add a `minio` service (MinIO is the dev-friendly S3-compatible option):
  ```yaml
  minio:
    image: minio/minio:latest
    ports:
      - "9000:9000"
      - "9001:9001"
    environment:
      MINIO_ROOT_USER: minioadmin
      MINIO_ROOT_PASSWORD: minioadmin
    command: server /data --console-address ":9001"
    volumes:
      - minio_data:/data
  ```
- Add `minio_data` to the volumes section
- Update backend env vars: `AWS_S3_ENDPOINT_URL=http://minio:9000`, `AWS_ACCESS_KEY_ID=minioadmin`, `AWS_SECRET_ACCESS_KEY=minioadmin`, `AWS_S3_BUCKET=shopibd-media`, `AWS_S3_REGION=us-east-1`

### 2e. Add auto-create bucket on startup
- **File:** `e:\SaaS test\shopibd\backend\app\main.py` — in the `lifespan` startup, when `STORAGE_BACKEND=s3`, attempt to create the bucket if it doesn't exist (idempotent `head_bucket` → `create_bucket`).

---

## 3. Build Invoice/PDF Generation (P1)

**Problem:** No invoice or PDF generation exists anywhere. Phase 1 has "Printing / invoice generation" unchecked. Bangladesh e-commerce compliance requires sellers to provide receipts. Without this, real sellers cannot operate legally.

**What to build:**
- A PDF invoice generator using `reportlab` (pure Python, no system dependencies)
- Invoice template with: shop logo, seller info, buyer info, order number, date, line items, subtotal, discount, delivery fee, total, payment method, footer
- API endpoint to generate and download invoice PDF
- Frontend button to download/view invoice from order detail

**Implementation plan:**

### 3a. Add `reportlab` dependency
- **File:** `e:\SaaS test\shopibd\backend\pyproject.toml` — add `"reportlab>=4.0.0"`
- **File:** `e:\SaaS test\shopibd\backend\requirements.txt` — add `reportlab>=4.0.0`

### 3b. Create invoice service
- **New file:** `e:\SaaS test\shopibd\backend\app\services\invoice.py`
- `InvoiceService` class:
  - `generate_invoice_pdf(order, shop, db) -> bytes`: Builds a `reportlab` canvas with:
    - Header: ShopiBD logo placeholder + "INVOICE" title
    - Shop info section: shop name, address, phone
    - Buyer info section: customer name, address, phone
    - Order details table: order number, date, status
    - Line items table: product name, quantity, unit price, total
    - Summary: subtotal, discount, delivery fee, grand total in BDT
    - Payment method and status
    - Footer: "Generated by ShopiBD" + timestamp
  - Returns PDF as `bytes` (in-memory, via `BytesIO`)

### 3c. Add invoice API endpoint
- **File:** `e:\SaaS test\shopibd\backend\app\api\v1\orders.py` (or new route file)
- `GET /api/v1/orders/{order_id}/invoice` — authenticated, returns PDF as `application/pdf` response with `Content-Disposition: attachment; filename="invoice-{order_number}.pdf"`
- Seller-scoped: only the seller who owns the order can download

### 3d. Add invoice download button to frontend
- **File:** `e:\SaaS test\shopibd\frontend\src\app\dashboard\orders\[id]\page-client.tsx`
- Add a "Download Invoice" button in the order detail header/actions area
- Calls the API endpoint, triggers browser download

---

## 4. Mobile Sidebar Auto-Close on Navigation (P2)

**Problem:** The roadmap lists this as unchecked. The `sidebar.tsx` component already has a `useEffect` that closes the mobile sheet on `pathname` change (lines 281-285). The `dashboard-shell.tsx` `MobileHeader` passes `onNavigate={() => setOpen(false)}` to `NavContent`.

**Investigation needed:** The auto-close logic exists in both sidebar implementations. This may be a false negative in the roadmap, or the behavior may be inconsistent on certain pages.

**Fix approach:**
- Verify the current behavior by reviewing both sidebar implementations
- If the `sidebar.tsx` component is the primary one used, the `useEffect` on line 281-285 should handle it
- If the `dashboard-shell.tsx` is the primary one, the `onNavigate` callback handles it
- Add a missing `onNavigate` handler only if a specific page doesn't trigger it

**Affected files:**
- `e:\SaaS test\shopibd\frontend\src\components\layout\sidebar.tsx` — verify useEffect is working
- `e:\SaaS test\shopibd\frontend\src\components\layout\dashboard-shell.tsx` — verify onNavigate is wired to all nav links

**Note:** After review, both implementations already handle auto-close. The fix may be as simple as marking this item complete in the roadmap, or adding a missing `onNavigate` prop to a specific nav section.

---

## 5. Add Tests for Phase 2 Components (P2)

**Problem:** Current test suite has zero coverage for payment gateways, courier integration, storage service, or subscription tasks. Coverage is far below the 80% target.

**Test plan:**

### 5a. Storage service tests
- **New file:** `e:\SaaS test\shopibd\backend\tests\test_storage.py`
- Tests:
  - LocalStorageService saves file and returns correct URL
  - LocalStorageService deletes file
  - LocalStorageService rejects invalid extension
  - LocalStorageService rejects oversized file
  - S3StorageService init raises StorageError when bucket not configured
  - `get_storage_service()` returns correct backend based on config

### 5b. Subscription task tests
- **New file:** `e:\SaaS test\shopibd\backend\tests\test_subscription_tasks.py`
- Tests:
  - `check_and_expire_subscriptions` expires past-due subscriptions
  - `check_and_expire_subscriptions` auto-renews when auto_renew is True
  - `sync_seller_plan_fields` syncs seller limits to plan
  - `run_all_subscription_tasks` orchestrates all tasks and returns results

### 5c. Invoice service tests
- **New file:** `e:\SaaS test\shopibd\backend\tests\test_invoice.py`
- Tests:
  - Invoice PDF is generated with correct content type
  - Invoice contains order number, customer info, line items
  - Invoice endpoint returns 200 with PDF content
  - Invoice endpoint returns 404 for non-existent order
  - Invoice endpoint returns 403 for wrong seller

---

## Assumptions & Decisions

1. **S3 vs MinIO:** In dev, we use MinIO (S3-compatible, free, runs in Docker). In production, the same `boto3` code works with AWS S3 or any S3-compatible storage. The config is the same — just change the endpoint URL.

2. **PDF library:** `reportlab` is chosen because it's pure Python (no system dependencies like `wkhtmltopdf` needed by `weasyprint`), mature, and well-suited for invoice generation. It generates PDFs from code, not HTML templates.

3. **Invoice storage:** PDFs are generated on-the-fly and not stored to disk. They are ephemeral — regenerated each time the user clicks "Download." This avoids storage costs and stale data issues.

4. **Mobile sidebar:** The code already has auto-close logic. If confirmed working, we just mark the roadmap item as complete. If broken, we add the missing `onNavigate` handler.

5. **Auto-renew charging:** The TODO in `subscription_tasks.py` line 42 ("Attempt to charge saved payment method") is left as-is. Auto-renew billing requires a payment method storage system that doesn't exist yet. This is a Phase 3+ feature.

---

## Verification Steps

1. **Scheduler fix:** Start the backend, wait for the scheduler interval, check logs for "Subscription scheduler run complete" (no TypeError).
2. **S3/MinIO:** `docker compose up -d minio`, set `STORAGE_BACKEND=s3`, upload a product image, verify it appears in the MinIO bucket via console at `http://localhost:9001`.
3. **Invoice PDF:** Create an order, hit `GET /api/v1/orders/{id}/invoice`, verify a valid PDF downloads with correct content.
4. **Mobile sidebar:** Open the app on a mobile viewport, open the sidebar, click a nav link, verify the sidebar closes.
5. **Tests:** Run `pytest` — all new tests pass, total count increases by ~15 tests.
6. **Regression:** Run `pytest tests/test_features_flow.py tests/test_plan_limits.py tests/test_plans.py` — all 20 existing tests still pass.