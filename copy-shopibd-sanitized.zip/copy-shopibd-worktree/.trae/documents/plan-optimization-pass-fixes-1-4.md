# Plan: Optimization Pass — Priority Remediation (Fixes 1–4)

## Summary

Apply the first four priority remediations identified in the deep-reasoning architecture review:
1. **Fix the `Product` schema vs `ProductModel` ORM bug** in `products.py` (line 139) that crashes product listing with sorting.
2. **Fix the `SECRET_KEY` default** in `config.py` that regenerates on every process start, invalidating all JWTs.
3. **Fix the `/admin` middleware collision** in `main.py` where the Basic-auth middleware intercepts all `/admin` paths, conflicting with the Next.js super-admin frontend served under `/admin/*`.
4. **Sync `requirements.txt` with `pyproject.toml`** so the secondary dependency manifest matches the actual install source (no runtime crash in Docker, but it is misleading and breaks `pip install -r requirements.txt` workflows).

These are low-risk, surgical fixes that directly improve production readiness before Phase 2 (Go-Live Readiness) begins.

---

## Current State Analysis

### Fix 1 — Pydantic schema used as ORM model (CRITICAL)
**File:** `backend/app/api/v1/products.py`, line 139

```python
sort_column = getattr(Product, sort_by)
```

`Product` here is the **Pydantic response schema** imported at line 20:
```python
from app.schemas.product import (
    ProductCreate, ProductUpdate, Product, ProductImageSchema,
)
```
The ORM model is imported as `ProductModel` (line 19). `getattr(Product, sort_by)` returns a Pydantic field, not a SQLAlchemy column expression. SQLAlchemy's `order_by()` rejects it with:
`Column expression, FROM clause, or other columns clause element expected, got <class 'app.schemas.product.Product'>`.

This breaks `GET /products/` whenever `sort_by` is passed (the default is `created_at`), i.e. the product list page fails on load. The same class of bug was fixed for other query sites in a prior session; this `order_by` line was missed.

**Fix:** change `Product` → `ProductModel` on line 139.

### Fix 2 — `SECRET_KEY` random default (HIGH)
**File:** `backend/app/core/config.py`, line 18

```python
SECRET_KEY: str = secrets.token_urlsafe(32)
```

Every time the process starts (container restart, deploy, scale-out), a new key is generated. All issued JWTs become invalid → every seller is logged out and the super-admin cannot authenticate. In Docker, `SECRET_KEY` is supplied via env (compose sets `${SECRET_KEY}`), but the **dev container and any environment without the env var** gets a rotating key. The default must be removed and replaced with a fail-loud required setting.

**Fix:** remove the default; raise `ValueError` at import if `SECRET_KEY` is unset. Keep a clear error message.

### Fix 3 — `/admin` middleware collision (HIGH)
**File:** `backend/app/main.py`, lines 136–159

```python
@app.middleware("http")
async def admin_auth_middleware(request: Request, call_next):
    if request.url.path.startswith("/admin"):
        auth_header = request.headers.get("Authorization")
        if not auth_header or not auth_header.startswith("Basic "):
            return Response(status_code=401, ...)
    return await call_next(request)
```

SQLAdmin is mounted at `/admin` (default `Admin(app, engine)` in `backend/app/admin/setup.py`). The super-admin **frontend** also lives under `/admin/*` (`frontend/src/app/admin/...`) and is served as static files / through the Next.js server.

In production they are separate origins (Next.js on :3001, FastAPI on :8080 behind a proxy), so the frontend `/admin/*` never reaches FastAPI — no immediate break. But the middleware is a latent trap:
- If the proxy ever routes `/admin/*` to FastAPI (common misconfiguration), the Next.js admin pages return 401.
- Local dev where someone points the browser at the FastAPI port for `/admin` breaks.
- It also intercepts `/admin` paths that may later be added for non-SQLAdmin API use.

**Fix:** scope the Basic-auth middleware to SQLAdmin's exact mount prefix only. Since SQLAdmin uses `/admin`, restrict the check to paths that are NOT the known Next.js admin frontend routes. The cleanest approach: exclude the frontend admin routes (`/admin/activity`, `/admin/clients`, `/admin/settings`, `/admin/reviews`, `/admin` exact) from Basic auth, OR rename SQLAdmin mount to `/sqladmin` and guard only that prefix. Renaming SQLAdmin mount is the most robust and is the recommended approach.

### Fix 4 — `requirements.txt` out of sync (MEDIUM, maintenance)
**File:** `backend/requirements.txt`

The Docker build installs via `pyproject.toml` (`pip install -e .`), which already declares `python-dateutil`, `httpx`, `requests`, `cryptography`, `email-validator`. So there is **no runtime crash** in Docker. However `requirements.txt` is stale:
- Missing: `python-dateutil`, `httpx`, `requests`, `cryptography`, `email-validator`.
- Has wrong pinned versions that don't match `pyproject.toml` (e.g. `bcrypt==5.0.0` vs `bcrypt==4.0.1`, `pytest==9.1.1`, `starlette==1.3.1`).
- Includes dev tools (`black`, `mypy`, `pre-commit`) that shouldn't be in a runtime requirements file.

This breaks anyone who runs `pip install -r requirements.txt` and gives a false picture of the dependency tree.

**Fix:** regenerate `requirements.txt` to match `pyproject.toml` runtime deps (or delete it and document that `pyproject.toml` is the source of truth). Recommended: replace contents with the runtime deps from `pyproject.toml` and add a header comment pointing to `pyproject.toml`.

---

## Proposed Changes

### Change 1 — `backend/app/api/v1/products.py` (line 139)
- **What:** `sort_column = getattr(Product, sort_by)` → `getattr(ProductModel, sort_by)`
- **Why:** `Product` is the Pydantic schema; `ProductModel` is the SQLAlchemy ORM class. `order_by` requires a column expression.
- **How:** single-token edit on line 139.

### Change 2 — `backend/app/core/config.py` (line 18)
- **What:** Replace `SECRET_KEY: str = secrets.token_urlsafe(32)` with a required setting:
  ```python
  SECRET_KEY: str
  ```
  and add validation in `Settings` (e.g. a `model_validator` or a post-init check) that raises `ValueError("SECRET_KEY must be set via environment") ` when empty.
- **Why:** prevents silent JWT invalidation on every restart.
- **How:** edit the field; add validation. Keep `import secrets` only if still used elsewhere (it is used in `main.py` for `compare_digest`, not here — safe to keep import or remove). Also update `.env.example` / `docker-compose.yml` docs to note `SECRET_KEY` is now mandatory (it already is in compose via `${SECRET_KEY}`).

### Change 3 — `backend/app/main.py` + `backend/app/admin/setup.py`
- **What:** Rename SQLAdmin mount prefix from `/admin` to `/sqladmin` in `setup.py` (`Admin(app, engine, base_url="/sqladmin")`), and update `admin_auth_middleware` to guard only `request.url.path.startswith("/sqladmin")`.
- **Why:** removes the collision with the Next.js `/admin/*` frontend routes and makes the Basic-auth scope explicit.
- **How:**
  - In `setup.py`: `admin = Admin(app, engine, base_url="/sqladmin")`.
  - In `main.py`: change the middleware condition from `request.url.path.startswith("/admin")` to `request.url.path.startswith("/sqladmin")`.
  - Update the path-skip list in `custom_domain_middleware` (line 83) if it references `/admin` — currently it skips `/admin` which remains correct for the frontend, but SQLAdmin is now `/sqladmin`; no change needed there since frontend `/admin` should still bypass domain routing.
  - Check `docker-compose.yml` / nginx notes for any hardcoded `/admin` SQLAdmin URL — none found; only the app mounts it.
  - Note: SQLAdmin URLs in `setup_admin` are auto-derived; no other references to `/admin` for SQLAdmin exist in the codebase (verified via grep: only `main.py` middleware and `setup.py` mount).

### Change 4 — `backend/requirements.txt`
- **What:** Replace file contents with runtime dependencies matching `pyproject.toml`, plus a header comment.
- **Why:** `pyproject.toml` is the real install source; `requirements.txt` must not contradict it.
- **How:** Write the following (runtime only, unpinned-minor to mirror pyproject):
  ```
  # Runtime dependencies — source of truth is pyproject.toml.
  # Docker builds use `pip install -e .` from pyproject.toml.
  # This file is provided for non-Docker / virtualenv workflows.
  fastapi>=0.104.0
  uvicorn[standard]>=0.24.0
  sqlalchemy>=2.0.0
  alembic>=1.12.0
  psycopg2-binary>=2.9.0
  python-jose[cryptography]>=3.3.0
  passlib[bcrypt]>=1.7.0
  bcrypt==4.0.1
  python-multipart>=0.0.6
  pydantic>=2.0.0
  pydantic-settings>=2.0.0
  email-validator>=2.0.0
  python-dateutil>=2.8.0
  httpx>=0.25.0
  requests>=2.31.0
  python-decouple>=3.8
  sqladmin>=0.14.0
  ```
  (Add `sqladmin` since it's imported in `setup.py` and comes from `pip install -e .` but isn't in either manifest currently — verify it's installed; if missing, it's a real gap. Will confirm during implementation by checking `import sqladmin` resolves in the dev container.)

---

## Assumptions & Decisions

- **Docker remains the primary deploy path**; `pyproject.toml` is authoritative for dependencies. `requirements.txt` is fixed for parity, not because Docker needs it.
- **SQLAdmin rename to `/sqladmin`** is preferred over an exclusion list because it is explicit, future-proof, and requires no maintenance of a route allowlist.
- **`SECRET_KEY` becomes mandatory** — any environment without it fails fast at startup with a clear message, which is safer than silent key rotation.
- **No new features** are added; these are remediation-only changes per the user's request.
- **Tests are not modified** unless a test explicitly relied on the old `/admin` SQLAdmin path (none do — tests use `TestClient` directly against API routes).
- Fix 3's SQLAdmin rename may affect the super-admin's manual access URL (was `/admin`, now `/sqladmin`). This is a docs/bookmark change, not a code break for the Next.js frontend (which uses `/admin/*`).

---

## Verification Steps

1. **Fix 1 — product sort:**
   - Run the existing feature-flow suite: `docker compose -f docker-compose.dev.yml exec backend python -m pytest tests/test_features_flow.py -q`
   - Add a quick manual check: `GET /api/v1/products?sort_by=created_at` returns 200 (not 500). Can verify via the test client or a curl against the dev container.

2. **Fix 2 — SECRET_KEY:**
   - In dev container, unset `SECRET_KEY` and start uvicorn → expect startup `ValueError: SECRET_KEY must be set`.
   - With `SECRET_KEY` set, login returns a valid JWT and a second request with that token succeeds (no 401).

3. **Fix 3 — admin middleware:**
   - `GET /sqladmin` (SQLAdmin) without Basic auth → 401.
   - `GET /sqladmin` with correct Basic auth → 200 (SQLAdmin UI).
   - `GET /admin/activity` (served by Next.js, not FastAPI) → not intercepted by FastAPI Basic auth (confirmed by route separation; in Docker the frontend is a separate container so this is structural).
   - Confirm `setup_admin` mounts at `/sqladmin` (check `Admin(app, engine, base_url="/sqladmin")`).

4. **Fix 4 — requirements.txt:**
   - `pip install -r requirements.txt` in a clean venv resolves without missing packages.
   - `import sqladmin` works (confirms the added dep).
   - Grep confirms no lingering references to `/admin` for SQLAdmin in `main.py`/`setup.py` other than the frontend route skip.

5. **Regression:** full backend test suite passes:
   `docker compose -f docker-compose.dev.yml exec backend python -m pytest tests/ -q`
   (Expect the previously observed `15 passed` from `test_features_flow.py` + `test_plan_limits.py` + `test_plans.py`.)

6. **Roadmap:** after approval, update `.ai-context/MASTER_ROADMAP.md` Phase 2 checklist to mark "Security audit (dependency scan, OWASP top-10 review, rate-limit tuning)" progress — these fixes are precursors to that item. (Optional, only if user wants the roadmap touched.)
