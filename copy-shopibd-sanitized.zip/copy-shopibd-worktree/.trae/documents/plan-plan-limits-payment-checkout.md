# Plan: Plan-Limit Enforcement + Subscription Payment Checkout

## Summary

Both features are **already ~85% built** in the backend. The work is fixing gaps and wiring the frontend to handle edge cases properly — not building from scratch.

---

## Current State Analysis

### #3 — Plan-Limit Enforcement

| Aspect | Status |
|--------|--------|
| `plan_limits.py` service (402 HTTPException) | ✅ Built |
| Products API calls `check_product_limit` before create | ✅ Built |
| Orders API calls `check_order_limit` in `shops.py` | ✅ Built |
| Bulk import calls `check_bulk_product_limit` | ✅ Built |
| Tests (`test_plan_limits.py`) | ✅ Built |
| **Frontend: 402 error handling on product/order creation** | ❌ Missing — user sees generic error, not "upgrade your plan" prompt |
| **Frontend: `UpgradePrompt` component exists but unused after 402** | ❌ The component shows *before* limits are hit, but not as a recovery action |

### #4 — Subscription Payment Checkout

| Aspect | Status |
|--------|--------|
| Backend: `POST /subscription` (create TRIALING) | ✅ Built |
| Backend: `POST /subscription/payment` (get payment_url) | ✅ Built |
| Backend: `POST /payment-webhook/subscription` (activate) | ✅ Built |
| Backend: `GET /subscription`, `GET /plans` | ✅ Built |
| Frontend: Subscription page (`page-client.tsx`) | ✅ Built (full UI) |
| Frontend: Success page (`success/page-client.tsx`) | ✅ Built |
| **Bug: `SSLCommerzPaymentProvider.validate_payment` missing** | ❌ Called from webhook but doesn't exist |
| **Bug: `FRONTEND_URL` not declared in `config.py`** | ❌ Referenced in subscription.py and subscription_payments.py |
| **Bug: `Select` component in subscription page uses `onChange` prop** | ❌ Should be `onValueChange` (string) — shadcn Select API mismatch |
| **Manual payment flow** | ✅ Works (mock URL returned) |
| **Real gateway (bKash/Nagad/SSLCommerz)** | ⚠️ Code exists, requires env vars |

---

## Proposed Changes

### Phase 3A — Fix Payment Gateway Bugs (3 files, quick wins)

**3A1. Add `validate_payment` to `SSLCommerzPaymentProvider`**

- **File:** `backend/app/services/payment/sslcommerz.py`
- **What:** Add `validate_payment(self, payment_id: str)` method that calls `verify_payment` and returns `{"valid": True/False}`. The webhook at `payment_webhook.py` line 386 calls `provider.validate_payment(payment_id)` — this method doesn't exist (only `verify_payment` exists). Add a thin wrapper.
- **How:**
  ```python
  def validate_payment(self, payment_id: str) -> dict:
      try:
          self.verify_payment(payment_id)
          return {"valid": True}
      except Exception:
          return {"valid": False}
  ```

**3A2. Add `FRONTEND_URL` to config**

- **File:** `backend/app/core/config.py`
- **What:** Add `FRONTEND_URL: str = "http://localhost:3000"` (or `http://127.0.0.1:4000` matching actual dev port). Currently `subscription.py` line 229 and `subscription_payments.py` line 90 reference `settings.FRONTEND_URL` — but it's not declared in the Settings class. pydantic-settings will raise `AttributeError` if not set via env.
- **How:** Add one line to the Settings class.

**3A3. Fix `Select` API mismatch in subscription page**

- **File:** `frontend/src/app/dashboard/subscription/page-client.tsx`
- **What:** The `Select` component at line 447 uses `onChange={(e) => onGatewayChange(e.target.value)}` but the shadcn `Select` component in this project uses `onValueChange` (callback with string value, not event). This is a runtime bug that prevents gateway selection from working.
- **How:** Change to `onValueChange={onGatewayChange}` and remove the `e.target.value` wrapper. Also remove `className="w-full"` (the shadcn Select wrapper doesn't accept className directly — need to wrap in a div if needed).

### Phase 3B — Frontend: 402 Error Handling on Product/Order Creation

**3B1. Add 402 interceptor/handler for product creation**

- **File:** `frontend/src/app/dashboard/products/page-client.tsx` (or `new/page.tsx`)
- **What:** When creating a product returns 402, instead of showing a generic error toast, show a specific message: "You've reached your plan's product limit. Upgrade to create more products." with a link to `/dashboard/subscription`.
- **How:** Check `error.response?.status === 402` in the catch block, and show a custom toast with a CTA button linking to the subscription page. Also show the `UpgradePrompt` component conditionally when `productCount >= maxProducts`.

**3B2. Add 402 interceptor/handler for order creation**

- **File:** `frontend/src/app/dashboard/orders/page-client.tsx` (or wherever orders are created from the seller side)
- **What:** Same as 3B1 but for order limits. Message: "You've reached your plan's order limit for this period. Upgrade to process more orders."
- **How:** Same pattern — check for 402 status in the error handler.

**3B3. Add 402 interceptor for bulk CSV import**

- **File:** `frontend/src/app/dashboard/products/page-client.tsx` (CSV import section)
- **What:** Same approach — 402 on import → upgrade prompt.

### Phase 3C — Backend: Minor Polishes

**3C1. Rename `subscription_payments.py` to `subscription_payments_service.py`**

- **File:** `backend/app/services/subscription_payments.py` → `subscription_payments_service.py`
- **Why:** Avoids shadowing the `subscription` package name. The import in `subscription.py` line 36 references `from app.services.subscription_payments import ...` — this is fine but the filename is ambiguous.
- **Decision:** **Skip this** — the naming is already consistent in the codebase and changing it creates unnecessary churn.

**3C2. Ensure `POST /subscription/payment` accepts gateway parameter**

- **File:** `backend/app/api/v1/subscription.py` (lines 199-232)
- **What:** The endpoint currently doesn't accept a `payment_gateway` parameter from the frontend — it reads from `settings.PAYMENT_PROVIDER`. The frontend sends `payment_gateway` in the `SubscriptionCreate` payload but the payment endpoint ignores it. Add `payment_gateway` as an optional parameter to allow the user to choose their gateway.
- **How:** Add `payment_gateway: Optional[str] = None` to the endpoint and pass it to `create_subscription_payment()`. If not provided, fall back to `settings.PAYMENT_PROVIDER`.

---

## Files Changed Summary

| File | Action | Description |
|------|--------|-------------|
| `backend/app/services/payment/sslcommerz.py` | EXTEND | Add `validate_payment` method |
| `backend/app/core/config.py` | EXTEND | Add `FRONTEND_URL` setting |
| `frontend/src/app/dashboard/subscription/page-client.tsx` | FIX | Fix Select `onChange` → `onValueChange` |
| `frontend/src/app/dashboard/products/page-client.tsx` | EXTEND | Handle 402 on product create with upgrade CTA |
| `frontend/src/app/dashboard/products/new/page.tsx` | EXTEND | Handle 402 on product create with upgrade CTA |
| `frontend/src/app/dashboard/orders/page-client.tsx` | EXTEND | Handle 402 on order create with upgrade CTA |
| `backend/app/api/v1/subscription.py` | EXTEND | Accept `payment_gateway` in payment endpoint |

**Isolation:** No changes to seller dashboard layout, storefront, admin panel, or existing models.

---

## Assumptions & Decisions

1. **SSLCommerz `validate_payment`** is a thin wrapper around `verify_payment` — the webhook callback just needs to know if the payment was valid.
2. **`FRONTEND_URL`** defaults to `http://127.0.0.1:4000` (matching the current dev setup). Production will override via env.
3. **402 handling** uses toast notifications with CTA links — no modal/dialog overhead.
4. **Gateway parameter** is optional — if not provided, falls back to `settings.PAYMENT_PROVIDER` (default: "manual").
5. **No test files changed** — existing tests cover the core logic; we're adding frontend error handling and fixing minor bugs, not changing business logic.

---

## Verification Steps

1. **3A1:** Call `SSLCommerzPaymentProvider().validate_payment("test")` → returns `{"valid": False}` without crashing.
2. **3A2:** `settings.FRONTEND_URL` is accessible from Python without AttributeError.
3. **3A3:** Subscription page gateway selector dropdown works (click changes value).
4. **3B:** Create a product when at plan limit → sees "upgrade to create more" toast with link to subscription page.
5. **3C:** `POST /subscription/payment` with `payment_gateway=bkash` uses bKash provider instead of default.
6. **Compile:** Frontend dev server compiles all changed pages without errors.