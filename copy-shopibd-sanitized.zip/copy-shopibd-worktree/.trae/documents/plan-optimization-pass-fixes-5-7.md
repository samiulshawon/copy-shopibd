# Plan: Optimization Pass — Phase 2 Scope Adjustments (Fixes 5–7)

## Summary

Apply the next three priority remediations from the deep-reasoning review:
5. **Redis-backed rate limiting** — replace in-memory `defaultdict` rate limiter and login attempt tracker with Redis-backed storage (falls back to in-memory when Redis is unreachable). Redis is already provisioned in `docker-compose.dev.yml` (`redis://redis:6379/0`) but unused.
6. **Subscription task scheduler** — wire `run_all_subscription_tasks()` into a periodic background loop so billing periods roll over, trials expire, and cancellations take effect automatically.
7. **`create_payment` on `PaymentVerifier` ABC** — add the abstract method to the base class so `get_payment_verifier()` returns a uniform interface; align `ManualPaymentService` and `BKashPaymentProvider` signatures.

These move the platform from "works in one process" to "survives restarts and scale-out," and close a payment-interface contract gap. They are Phase 2 precursors (rate-limit tuning, scheduler for billing lifecycle).

---

## Current State Analysis

### Fix 5 — In-memory rate limiting (HIGH)
**Files:** `backend/app/core/middleware.py`, `backend/app/api/v1/auth.py`, `backend/app/core/config.py`, `backend/app/core/database.py` (or new `backend/app/services/redis_client.py`)

Two separate in-memory structures hold state:
- `RateLimitMiddleware` in `middleware.py` uses `self.ips: dict[str, list[float]]` (per-process).
- `auth.py` `login_rate_limiter` uses `defaultdict(list)` (per-process).

Both reset on container restart and don't share state across replicas. `docker-compose.dev.yml` already runs Redis (`REDIS_URL=redis://redis:6379/0`) but `REDIS_URL` defaults to `""` in `config.py` and no Redis client is used anywhere.

**Decision:** Add a thin Redis client wrapper (`backend/app/services/redis_client.py`) that:
- Lazily connects using `settings.REDIS_URL`.
- Exposes `is_redis_available()` (bool) and `get_redis()` (returns `redis.Redis` or `None`).
- Falls back gracefully when `REDIS_URL` is empty or Redis is down.

Then refactor `RateLimitMiddleware` to use a Redis sorted-set sliding window when available, else keep the in-memory dict. Same pattern for `login_rate_limiter` in `auth.py` (extract a small helper in `redis_client.py` or `middleware.py`).

`redis` is NOT in `pyproject.toml` — must be added to runtime deps.

### Fix 6 — Subscription task scheduler (HIGH)
**File:** `backend/app/services/subscription_tasks.py` (already has `run_all_subscription_tasks()`), `backend/app/main.py` (startup hook needed)

`run_all_subscription_tasks()` at `subscription_tasks.py:133` calls:
- `check_and_expire_trials()`
- `rollover_subscription_periods()`
- `process_scheduled_cancellations()`
- `check_and_downgrade_overdue_subscriptions()`

But nothing invokes it. There is no `@app.on_event("startup")` / lifespan hook, no Celery, no APScheduler. Subscriptions will never auto-expire or roll over.

**Decision:** Add a lightweight asyncio background loop in `main.py` (no new heavy dependency):
- On startup, spawn `asyncio.create_task(_subscription_scheduler())`.
- The loop sleeps `settings.SUBSCRIPTION_TASK_INTERVAL_SECONDS` (default 3600) between runs.
- Runs `run_all_subscription_tasks()` inside a DB session; logs errors without crashing the loop.
- Uses `asyncio` (stdlib) — no `apscheduler` needed. Keeps the dependency surface minimal.

Add `SUBSCRIPTION_TASK_INTERVAL_SECONDS: int = 3600` to `config.py`.

> Note: `apscheduler` was considered but rejected — `asyncio.create_task` + `sleep` is sufficient for a single-instance deployment and avoids adding a scheduler dependency. If multi-instance scaling is needed later, a proper distributed scheduler (APScheduler + Redis lock, or Celery beat) should replace this. Documented as a known limitation.

### Fix 7 — `create_payment` on `PaymentVerifier` ABC (HIGH)
**Files:** `backend/app/services/payment/base.py`, `backend/app/services/payment/manual.py`, `backend/app/services/payment/bkash.py`

`PaymentVerifier` (base.py) declares only:
```python
@abstractmethod
def verify_payment(self, payment_id: str) -> PaymentVerificationResult: ...
```

But `payment_webhook.py:104` calls `provider.create_payment(order_id=..., amount=..., callback_url=...)` on the object returned by `get_payment_verifier()`. Only `BKashPaymentProvider` (bkash.py) and `ManualPaymentService` (manual.py) happen to define `create_payment` by convention — `NagadPaymentProvider` and `SSLCommerzPaymentProvider` do NOT (they define `initiate_payment` / `create_session` instead). This means `get_payment_verifier("nagad")` would raise `AttributeError` if a webhook ever tried `create_payment`.

**Decision:** Add `create_payment` as an abstract method to `PaymentVerifier`:
```python
@abstractmethod
async def create_payment(self, order_id: str, amount: int, callback_url: str) -> dict:
    """Initiate a payment and return redirect/payment identifiers."""
    ...
```
Then implement it in all concrete providers:
- `ManualPaymentService.create_payment` → returns `{"payment_url": callback_url, "paymentID": f"manual_{order_id}"}` (already exists, align signature).
- `BKashPaymentProvider.create_payment` → already exists, keep.
- `NagadPaymentProvider` → add `create_payment` that wraps its existing `initiate_payment` logic.
- `SSLCommerzPaymentProvider` → add `create_payment` that wraps its existing `create_session` logic.

This makes `get_payment_verifier(name).create_payment(...)` safe for any provider and documents the contract. `shops.py`/`subscription.py` that call `BKashPaymentProvider()` directly are unaffected (their direct calls still work), but the factory path becomes uniform.

> Scope guard: Only add `create_payment` to the ABC + concrete classes. Do NOT refactor `shops.py`/`subscription.py` direct instantiations (out of scope; they work). Do NOT change `verify_payment` signature.

---

## Proposed Changes

### Change 5a — New file `backend/app/services/redis_client.py`
- `RedisClient` wrapper: `get_redis()`, `is_redis_available()`, `incr_sliding_window(key, window, max_count)`.
- Lazy connect from `settings.REDIS_URL`; returns `None` when empty/unreachable.
- No exceptions escape callers.

### Change 5b — `backend/app/core/middleware.py`
- Import `redis_client`.
- In `RateLimitMiddleware.dispatch`, if Redis available: use a sorted-set sliding window keyed by `rate_limit:{ip}`; else fall back to the existing `self.ips` dict.
- Keep the same `requests_per_minute` behavior.

### Change 5c — `backend/app/api/v1/auth.py`
- Replace `login_rate_limiter` in-memory `defaultdict(list)` with Redis-backed sliding window using `redis_client` (key `login_attempts:{ip}`), falling back to in-memory when Redis unavailable.
- Keep `MAX_LOGIN_ATTEMPTS=5`, `LOGIN_WINDOW_SECONDS=60`.

### Change 5d — `backend/app/core/config.py`
- Add `REDIS_URL` already exists (default `""`); keep.
- Add `redis` dependency to `pyproject.toml` runtime deps (`redis>=5.0.0`).

### Change 6a — `backend/app/core/config.py`
- Add `SUBSCRIPTION_TASK_INTERVAL_SECONDS: int = 3600`.

### Change 6b — `backend/app/main.py`
- Add async scheduler task `_subscription_scheduler()` that loops:
  ```python
  async def _subscription_scheduler():
      while True:
          await asyncio.sleep(settings.SUBSCRIPTION_TASK_INTERVAL_SECONDS)
          try:
              db = SessionLocal()
              try:
                  run_all_subscription_tasks(db=db)
              finally:
                  db.close()
          except Exception:
              logger.exception("Subscription scheduler task failed")
  ```
- On startup (after `setup_admin`), `asyncio.create_task(_subscription_scheduler())`.
- Import `asyncio`, `run_all_subscription_tasks`, `logger`.

### Change 7a — `backend/app/services/payment/base.py`
- Add abstract `create_payment(self, order_id: str, amount: int, callback_url: str) -> dict`.

### Change 7b — `backend/app/services/payment/manual.py`
- Ensure `create_payment` signature matches (`order_id`, `amount`, `callback_url`) and returns dict with `payment_url`/`paymentID`. (Already present; align if needed.)

### Change 7c — `backend/app/services/payment/bkash.py`
- `create_payment` already exists; confirm signature matches ABC. (No change expected.)

### Change 7d — `backend/app/services/payment/nagad.py`
- Add `create_payment` wrapping `initiate_payment(...)` to return `{"payment_url": ..., "paymentID": ...}`.

### Change 7e — `backend/app/services/payment/sslcommerz.py`
- Add `create_payment` wrapping `create_session(...)` to return `{"payment_url": ..., "paymentID": ...}`.

---

## Assumptions & Decisions

- **Redis is optional, not required.** All Redis usage degrades to in-memory when `REDIS_URL` is empty or Redis is down. This keeps local/dev and CI (no Redis) working without changes.
- **No APScheduler / Celery.** A stdlib `asyncio` loop is sufficient for single-instance. Multi-instance scheduling is a documented future need (Phase 2 "operational monitoring").
- **Scheduler runs inside the FastAPI process.** For a single-container deploy this is fine. If the backend scales to multiple replicas later, a distributed lock (Redis) must guard the scheduler to avoid duplicate runs — noted as a limitation, not implemented now.
- **`create_payment` ABC addition is backward compatible.** Existing direct provider calls (`BKashPaymentProvider().create_payment(...)`) keep working. Only the factory-returned interface becomes uniform.
- **`shops.py` / `subscription.py` direct provider instantiation is out of scope** — they work; not touched.
- **`pyproject.toml` is the install source** (Docker uses `pip install -e .`). `redis` must be added there. `requirements.txt` should also get `redis` for parity (updated in this plan since it's a runtime dep).
- **Tests are not modified** unless a new test is needed to prove Fix 5/6/7. A small test for `create_payment` uniformity across providers is recommended but optional.

---

## Verification Steps

1. **Fix 5 — Redis rate limiting:**
   - Run backend test suite (Redis is up in dev container): `docker compose -f docker-compose.dev.yml exec backend python -m pytest tests/ -q` → expect pass, no new failures.
   - Confirm `import redis` resolves (dependency added).
   - Manual: with Redis up, hit an endpoint >60 times/min from one IP → expect 429. Then confirm the counter persists across a uvicorn restart (Redis-backed). (Optional manual check; hard to automate in CI without a fixed IP.)

2. **Fix 6 — Scheduler:**
   - Unit test: call `run_all_subscription_tasks(db=session)` with a trial subscription past `current_period_end` → expect status flips to `EXPIRED`/`CANCELED` and plan downgraded. Existing `test_features_flow.py` covers subscription cancellation; add a focused test for trial expiry if not present.
   - Confirm `main.py` startup logs "Subscription scheduler started" (add a log line).
   - Confirm no crash on startup when `REDIS_URL` empty (graceful).

3. **Fix 7 — create_payment ABC:**
   - Add/run a test: for each provider name in `{"manual","bkash","nagad","sslcommerz"}`, `get_payment_verifier(name).create_payment(...)` returns a dict with `payment_url`. (Mock network calls where needed.)
   - Confirm `payment_webhook.py:104` path works for nagad/sslcommerz (no `AttributeError`).
   - Full suite green.

4. **Regression:** `docker compose -f docker-compose.dev.yml exec backend python -m pytest tests/test_features_flow.py tests/test_plan_limits.py tests/test_plans.py -q` → 20 passed (no regression from fixes 1–4).

5. **Roadmap:** after approval, optionally mark Phase 2 "rate-limit tuning" and "operational monitoring" as in-progress in `MASTER_ROADMAP.md` (only if user wants).
