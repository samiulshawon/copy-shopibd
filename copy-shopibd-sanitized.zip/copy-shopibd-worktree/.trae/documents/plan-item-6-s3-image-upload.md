# Plan: Item 6 — Product Image Upload (Local + S3-ready)

## Summary

The codebase has **zero product image support** today: no model field, no API, no
storage service, no frontend control. This plan adds a **gallery of multiple
images per product** via a `ProductImage` child table, stored through a
**storage service abstraction** that writes to local disk now (served via a
`/media` static route) but can switch to S3/MinIO later via env config.

Confirmed decisions:
- **Storage backend:** Local disk now, behind an `StorageService` interface that is S3/MinIO-ready.
- **Model:** `ProductImage` child table (multiple images, with a primary flag).

## Current State Analysis

| Layer | Current state |
|-------|---------------|
| `models/product.py` | `Product` has only scalar columns — no image fields |
| `models/__init__.py` | No `ProductImage` registered |
| `schemas/product.py` | `ProductCreate/Update/Product` have no image fields |
| `api/v1/products.py` | `create_product`/`update_product` are JSON-only; only CSV import uses `UploadFile` |
| `api/v1/shops.py` (storefront) | Returns products as dicts **without** `image_url` |
| `core/config.py` | No storage/S3 settings |
| `main.py` | No `StaticFiles` mount |
| `services/` | No storage service |
| Frontend `product-form.tsx` | No file input, sends JSON |
| Frontend `types/product.ts` | No image fields |
| Frontend `lib/api.ts` | `productApi.create/update` are JSON; `importCsv` uses FormData |
| Frontend `types/shop.ts` | `StorefrontProduct` already has `primary_image_url?` (unused by backend) |

### Migration pattern
Existing migrations live in `backend/alembic/versions/*.py` (e.g.
`d4e5f6a7b8c9_add_subscriptions_table.py`). A new migration will be added.

## Proposed Changes

### 1. Storage service — `backend/app/services/storage.py` (NEW)
A small abstraction with a local-disk implementation and an S3 stub, selected by
`settings.STORAGE_BACKEND` (`"local"` default).

- `class StorageService` (Protocol/ABC): `async def save(file: UploadFile, folder: str) -> str` returning a **public URL**; `async def delete(url: str) -> None`.
- `LocalStorageService`: writes to `MEDIA_ROOT` (e.g. `backend/media`), returns
  `/media/<folder>/<uuid>.<ext>`. Validates extension (jpg/png/webp) and size
  (max 5 MB, reusing the CSV 5 MB cap pattern).
- `S3StorageService`: placeholder that raises `NotImplementedError` with a clear
  message; real impl can be added when credentials exist. Reads
  `AWS_*`/`MINIO_*` settings.
- `get_storage_service() -> StorageService` factory based on
  `settings.STORAGE_BACKEND`.

### 2. Config — `backend/app/core/config.py` (EXTEND)
Add after the Redis block:
```python
# Storage
STORAGE_BACKEND: str = "local"          # "local" | "s3"
MEDIA_ROOT: str = "media"               # relative to backend cwd; served at /media
MEDIA_URL: str = "/media"
AWS_S3_BUCKET: str = ""
AWS_S3_REGION: str = ""
AWS_S3_ENDPOINT_URL: str = ""           # MinIO compatible
AWS_ACCESS_KEY_ID: str = ""
AWS_SECRET_ACCESS_KEY: str = ""
```
Update `Config.env_file` already covers `.env.local`.

### 3. Model — `backend/app/models/product.py` (EXTEND) + `backend/app/models/__init__.py` (EXTEND)
Add:
```python
class ProductImage(Base):
    __tablename__ = "product_images"
    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id", ondelete="CASCADE"), nullable=False)
    image_url = Column(String, nullable=False)
    sort_order = Column(Integer, default=0)
    is_primary = Column(Boolean, default=False)
    product = relationship("Product", back_populates="images")

# in Product:
images = relationship("ProductImage", back_populates="product", cascade="all, delete-orphan", order_by="ProductImage.sort_order")
```
Register `ProductImage` in `models/__init__.py` and `__all__`.

### 4. Schemas — `backend/app/schemas/product.py` (EXTEND)
Add `images: List[ProductImageSchema] = []` to `ProductInDBBase`/`Product`, with:
```python
class ProductImageSchema(BaseModel):
    id: int
    image_url: str
    is_primary: bool
    sort_order: int
    class Config: from_attributes = True
```
Keep `ProductCreate`/`ProductUpdate` image-free (images uploaded via dedicated endpoint).

### 5. API — `backend/app/api/v1/products.py` (EXTEND)
Add routes (auth: `get_current_seller`, ownership enforced via shop):
- `POST /products/{product_id}/images` — `UploadFile`, calls
  `get_storage_service().save(file, f"products/{shop_id}")`, creates
  `ProductImage` (first image auto-`is_primary=True`), returns the image schema.
  Enforce max 10 images per product.
- `DELETE /products/{product_id}/images/{image_id}` — deletes row + storage object.
- `PUT /products/{product_id}/images/{image_id}/primary` — sets `is_primary`,
  unsets others.
Include `ProductImage` import + `get_storage_service`.

### 6. Storefront — `backend/app/api/v1/shops.py` (EXTEND)
In the `/{slug}` product list comprehension, add:
```python
"primary_image_url": next(
    (i.image_url for i in p.images if i.is_primary),
    (p.images[0].image_url if p.images else None),
),
```
So the existing `StorefrontProduct.primary_image_url` field is populated.

### 7. Static serving — `backend/app/main.py` (EXTEND)
Mount local media when backend is `local`:
```python
from fastapi.staticfiles import StaticFiles
if settings.STORAGE_BACKEND == "local":
    import os
    media_dir = settings.MEDIA_ROOT
    os.makedirs(media_dir, exist_ok=True)
    app.mount(settings.MEDIA_URL, StaticFiles(directory=media_dir), name="media")
```
Place **before** `setup_admin(app, engine)` and after `include_router`.

### 8. Migration — `backend/alembic/versions/<rev>_add_product_images.py` (NEW)
Create `product_images` table (matches model). Use an autogenerated-style manual
revision consistent with existing files (single `upgrade()`/`downgrade()`).

### 9. Frontend types — `frontend/src/types/product.ts` (EXTEND)
```ts
export interface ProductImage { id: number; image_url: string; is_primary: boolean; sort_order: number }
```
Add `images?: ProductImage[]` to `Product`.

### 10. Frontend API — `frontend/src/lib/api.ts` (EXTEND)
In `productApi`:
```ts
uploadImage: (id: number, file: File) => {
  const fd = new FormData(); fd.append("file", file);
  return api.post(`/products/${id}/images`, fd, { headers: { "Content-Type": "multipart/form-data" } });
},
deleteImage: (id: number, imageId: number) => api.delete(`/products/${id}/images/${imageId}`),
setPrimaryImage: (id: number, imageId: number) => api.put(`/products/${id}/images/${imageId}/primary`),
```

### 11. Frontend form — `frontend/src/components/dashboard/product-form.tsx` (EXTEND)
- Add `images` state (loaded via `productApi.list`/existing product fetch — note
  the products list currently returns `Product[]`; ensure the single-get or list
  includes `images`). For the new/edit form, fetch product detail if editing to
  populate images.
- Add an **Images** section: file input (drag/click), client-side validation
  (image type, ≤5 MB), preview thumbnails, "Set primary" + "Remove" actions
  calling the new API methods. On create, upload images **after** the product is
  created (product id required), then refresh.
- Reuse the existing 402/`isPlanLimitError` toast pattern is not needed here; just
  show upload errors.

> Note: the products list endpoint returns `Product` schema. Confirm the list
> serializer includes `images` (it will, since `Product` gains the field). The
> dashboard `Product` type already maps to that schema.

## Assumptions & Decisions

1. **Local-first:** default `STORAGE_BACKEND=local` so it works in dev with no cloud creds. S3 path is stubbed but wired for later.
2. **Separate image endpoint** (not multipart on create) because product id is required and the existing create flow is JSON-only — cleaner than rewriting create to multipart.
3. **Max 10 images / 5 MB each** — reasonable e-commerce default; consistent with existing 5 MB CSV cap.
4. **Primary image** resolved in storefront as `is_primary` else first.
5. **No CSV bulk image import** in this pass — only manual upload in the form (keeps scope tight; matches the "item 6 = S3 image upload" ask).
6. **`product-form.tsx` hardcoded `shop_id=1`** is pre-existing; we keep it and upload images under that shop's folder.

## Verification Steps

1. **Backend import + migrate:** `cd backend && python -c "import app.models"` then run the new Alembic migration; confirm `product_images` table exists.
2. **Storage unit check:** `python -c "from app.services.storage import get_storage_service; s=get_storage_service(); print(s)"` → local service, no error.
3. **Static mount:** start uvicorn, `GET /media/` returns 404 HTML (mounted), and after upload `GET /media/products/1/<file>` returns the image bytes.
4. **API happy path:** create product → `POST /products/{id}/images` with a small PNG → 200 with `image_url` starting `/media/...`; second image auto-primary=false; `PUT .../primary` flips it; `DELETE` removes it and the file.
5. **Storefront:** `GET /shops/{slug}` product dict now includes `primary_image_url`.
6. **Frontend:** open Add Product → upload 1–2 images → thumbnails show → save → product list/detail shows image; primary toggle works.
7. **Limits:** uploading >10 images returns 400; non-image or >5 MB returns 400.
8. **Compile:** `python -m py_compile` on changed backend files; `npx tsc --noEmit` or `next build` on frontend (note: full build is slow; rely on py_compile + manual review if build times out).
