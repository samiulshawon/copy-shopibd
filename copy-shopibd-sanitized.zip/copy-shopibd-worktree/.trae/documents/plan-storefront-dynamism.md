# ShopiBD — Storefront Dynamism & Production-Readiness Plan

> **Scope**: Make the **buyer storefront** (`/[slug]`, `/[slug]/products/[id]`, `/[slug]/order`, `/[slug]/order/success`, `/[slug]/orders/track`) feel dynamic and production-ready — **without any design-system or layout change**.
>
> **Guiding constraint**: Reuse the existing Obsidian Emerald tokens, the already-defined `@keyframes` in `globals.css`, and the components already built but starved of data. No new color, no layout rebuild, no new dependencies by default.

---

## 0. Why this plan exists (findings from the codebase audit)

The storefront is functional but **static and data-thin** in four structural ways:

1. **No SEO / no social preview.** `[slug]/layout.tsx` and every `page.tsx` build `<Metadata>` from the **slug string only** ([layout.tsx L10–13](file:///e:/SaaS%20test/shopibd/frontend/src/app/[slug]/layout.tsx)). All real data is fetched in a client `useEffect` ([page-client.tsx L97–105](file:///e:/SaaS%20test/shopibd/frontend/src/app/[slug]/page-client.tsx)). Result: a seller's Facebook link has no title/description/image — which kills the product's stated "post link → get order" core premise.
2. **The UI is ahead of the API.** `ProductPublic` returns only `primary_image_url` ([shop.py L51–63](file:///e:/SaaS%20test/shopibd/backend/app/schemas/shop.py)), but the frontend already supports `secondary_image_url` hover-swap ([product-card.tsx L20–22](file:///e:/SaaS%20test/shopibd/frontend/src/components/storefront/product-card.tsx)), a full `images[]` gallery ([product-detail.tsx L70–77](file:///e:/SaaS%20test/shopibd/frontend/src/components/storefront/product-detail.tsx)), `category_id`/`category_name`, and `variants`. All of it is dead code today. The ORM model already has `images`, `category`, and `variants` relationships ([product.py L25–30](file:///e:/SaaS%20test/shopibd/backend/app/models/product.py)).
3. **Single-product checkout only.** `OrderForm` takes one `product_id` ([order-form.tsx](file:///e:/SaaS%20test/shopibd/frontend/src/components/storefront/order-form.tsx)). No cart. Caps average order value and is a hard limitation for any real store.
4. **Motion system is unused.** `.animate-fade-up`, `.animate-shimmer`, `.animate-draw-path`, `.skeleton-shimmer` exist in `globals.css` but the storefront skeleton uses plain `bg-muted` ([page-client.tsx L34–71](file:///e:/SaaS%20test/shopibd/frontend/src/app/[slug]/page-client.tsx)) and nothing animates on load.

The good news: fixing #2, #4 requires **no design work** — only data + class swaps. Fixing #1 is server-rendering the same JSX. Fixing #3 is additive inside the existing Card layout.

---

## Phase 1 — Storefront SEO & Server Rendering (unblocks growth)

**Goal**: Every seller link shared on Facebook/WhatsApp renders a real title, description, and image; pages are indexable; first paint is content, not a skeleton.

**Backend**
- `GET /shops/{slug}` already returns `ShopPublic`. Confirm it is safe to call from the Next.js server (no auth, public). Add a tiny server-side fetcher in `frontend/src/lib/storefront-server.ts` (no new dep — use native `fetch`).
- Optional but recommended: add a dedicated `GET /shops/{slug}/meta` lightweight endpoint returning only `{ name, description, logo_url, banner_url, product_count }` to keep `generateMetadata` cheap. (Skip if `ShopPublic` payload is small enough.)

**Frontend**
- `[slug]/page.tsx`: call the shop server-side, pass to `generateMetadata` (title, description, OG tags with `logo_url`/`banner_url`, Twitter card, canonical). Pass the already-fetched shop down to the client component as initial data so the client `useEffect` becomes a no-op on first load (no skeleton flash).
- `[slug]/layout.tsx`: replace the slug-string metadata with real shop metadata; add `<meta name="robots">`, `<link rel="canonical">`, and JSON-LD `Store` schema.
- `[slug]/products/[id]/page.tsx`: server-fetch the product, emit `Product` JSON-LD (name, image, price, availability, sku). OG image = `primary_image_url`.
- `[slug]/order/page.tsx` and `order/success/page.tsx`: set `noindex` (checkout shouldn't be indexed).
- `next.config.js`: the `images.remotePatterns` list does **not** include the backend media host (it currently allows unsplash/cloudinary/placeholder). Add the production media host(s) so `next/image` doesn't 400 on real seller images. ([next.config.js L3–18](file:///e:/SaaS%20test/shopibd/frontend/next.config.js))
- Add `frontend/public/og-default.png` (a ShopiBD-branded fallback) referenced when a shop has no logo/banner.

**Acceptance**
- Sharing a seller URL in the Facebook Sharing Debugger shows real title/description/image.
- View-source of `/[slug]` contains the shop name, description, and an `<img>` with a real `src` (not a skeleton).
- Lighthouse "SEO" score ≥ 95 on storefront + product detail.
- No client-side waterfall on first load (server HTML is populated).

**Files touched**: `frontend/src/app/[slug]/{layout,page,products/[id]/page,order/page,order/success/page}.tsx`, `frontend/src/lib/storefront-server.ts` (new), `frontend/next.config.js`, `frontend/public/og-default.png` (new asset).

---

## Phase 2 — Enrich the Public Storefront API (lights up existing UI)

**Goal**: Return the data the frontend already knows how to render. Zero frontend design change — purely populating existing fields.

**Backend**
- Extend `ProductPublic` in `app/schemas/shop.py`:
  - `secondary_image_url: Optional[str]` — the first non-primary image (drives hover-swap).
  - `images: List[ProductImagePublic]` — `{ id, image_url, is_primary }` (drives the gallery + thumbnails already built in [product-detail.tsx L70–77, L293–318](file:///e:/SaaS%20test/shopibd/frontend/src/components/storefront/product-detail.tsx)).
  - `category_id`, `category_name` — from the `category` relationship.
  - `variants: List[VariantPublic]` — already modeled (`ProductVariant`), just not serialized.
- Update the `get_shop_by_slug` product dict-construction in `shops.py` (L330–343) to emit these fields. The ORM relationships already exist ([product.py L20–30](file:///e:/SaaS%20test/shopibd/backend/app/models/product.py)) so this is serialization work, not a model change.
- Apply the same enrichment to `GET /shops/{slug}/products/{product_id}` ([shops.py L242–285](file:///e:/SaaS%20test/shopibd/backend/app/api/v1/shops.py)) — currently returns only 6 fields and no images at all, which is why the gallery, hover, and reviews trust strip underperform.
- N+1 guard: use `selectinload(Product.images)`, `selectinload(Product.category)`, `selectinload(Product.variants)` in both queries to avoid per-product queries at 200-product scale.

**Acceptance**
- Product card hover shows a second image when the seller uploaded more than one.
- Product detail gallery + thumbnail rail works with real multi-image products.
- Variants render and gate the "Order Now" button when a product has variants.

**Files touched**: `backend/app/schemas/shop.py`, `backend/app/api/v1/shops.py`. (Frontend types in `frontend/src/types/shop.ts` already declare these fields — no FE change required to *consume* them.)

---

## Phase 3 — Catalog Dynamism: Categories, Pagination, Live Search

**Goal**: Make the `/[slug]` product grid behave like a real catalog that scales to Phase 3 volumes (200+ products) and feels alive while browsing.

**Backend**
- `GET /shops/{slug}` currently returns **all** active products in one payload ([shops.py L307–313](file:///e:/SaaS%20test/shopibd/backend/app/api/v1/shops.py)). Add query params `?page`, `?limit`, `?category_id`, `?q`, `?sort` and return a paginated `{ items, total, page, total_pages }` shape. Keep the existing full-list response as the default for backward compat, or version it.
- Return `categories[]` with `product_count` per category so the filter UI can show counts.

**Frontend** (`components/storefront/product-grid.tsx`)
- Add a **category filter rail** (chips) above the grid using the already-fetched `shop.categories`. Active chip uses `border-primary` from existing tokens.
- Replace the in-memory filter with a debounced (250ms) server search hit when the catalog is paginated; keep instant client filter as a fast path for small catalogs.
- Add **"Load more" / infinite scroll** with `IntersectionObserver`. New rows use `animate-fade-up` with `nth-child` stagger (already in `globals.css`).
- Sort dropdown already exists ([product-grid.tsx L41](file:///e:/SaaS%20test/shopibd/frontend/src/components/storefront/product-grid.tsx)) — wire it to the server `sort` param.
- Apply `.skeleton-shimmer` (defined, unused) to the grid loading state instead of plain `bg-muted`.
- Keep the existing grid layout, gaps, and `ProductCard` exactly as-is.

**Acceptance**
- A 200-product store loads in pages without freezing the browser.
- Category chips filter the grid without a full page reload; counts are visible.
- Typing in search updates results after a short debounce with a shimmer state.

**Files touched**: `backend/app/api/v1/shops.py`, `backend/app/schemas/shop.py`, `frontend/src/components/storefront/product-grid.tsx`, `frontend/src/types/shop.ts`.

---

## Phase 4 — Multi-Item Cart (revenue + realism)

**Goal**: A buyer can add multiple products (and quantities) and check out once. This is the single biggest revenue unlock and a buyer expectation gap.

**Frontend** (additive — no existing layout removed)
- New `components/storefront/cart-provider.tsx`: client context backed by `localStorage` (per-slug key, mirroring the pattern in [recently-viewed.tsx L18–40](file:///e:/SaaS%20test/shopibd/frontend/src/components/storefront/recently-viewed.tsx)). Exposes `{ items, addItem, removeItem, updateQty, clear, subtotal, count }`.
- New `components/storefront/cart-drawer.tsx`: a right-side `Sheet` (the project already uses `Sheet`/`SheetContent` in product-grid filters) listing line items with qty steppers, line totals, subtotal, and "Checkout".
- Add an **"Add to cart"** button alongside the existing "Order Now" on product-detail (desktop row L423–441 + mobile sticky bar L538–581). Single-product "Order Now" stays for the impulse-buy fast path.
- Sticky **cart pill** (bottom-right on desktop, integrated into the existing `StorefrontMobileActions` bar on mobile) showing item count — uses `animate-slide-in-right` on first add.
- New `/[slug]/cart` route (or a `/[slug]/checkout` that accepts multiple line items) reusing the `OrderForm` Card structure. The summary section ([order-form.tsx L571–692](file:///e:/SaaS%20test/shopibd/frontend/src/components/storefront/order-form.tsx)) generalizes naturally to a line-items list.

**Backend**
- `POST /shops/{slug}/orders` currently takes a single `product_id` + `quantity` ([order schema](file:///e:/SaaS%20test/shopibd/backend/app/schemas/order.py)). Extend `OrderCreatePublic` to accept `items: List[{product_id, quantity}]` (keep `product_id`/`quantity` top-level as the single-item fast path for backward compat). Create one `OrderItem` per line; recompute total server-side; enforce per-product stock.
- Keep coupon validation working across the multi-item total (the `couponApi.validate` already accepts `product_ids: []`).

**Acceptance**
- Buyer adds 3 different products, adjusts quantities in the drawer, checks out once.
- Stock is decremented correctly per line item; oversell guard works per-product.
- Single-product "Order Now" flow still works unchanged.

**Files touched**: `backend/app/schemas/order.py`, `backend/app/api/v1/shops.py` (order creation), new `frontend/src/components/storefront/cart-provider.tsx`, `cart-drawer.tsx`, new `frontend/src/app/[slug]/cart/page.tsx`, edits to `product-detail.tsx`, `order-form.tsx`, `storefront-mobile-actions.tsx`.

---

## Phase 5 — Motion & Micro-interactions (the "premium dynamic" layer)

**Goal**: Make the storefront *feel* alive on load, on scroll, and on interaction — using only the CSS already defined in `globals.css`. No new dependency.

**Frontend** (all class swaps / small hooks)
- **Shimmer skeletons**: replace `bg-muted` with `.skeleton-shimmer` in the storefront skeleton ([page-client.tsx L34–71](file:///e:/SaaS%20test/shopibd/frontend/src/app/[slug]/page-client.tsx)) and product-detail loading state.
- **Staggered grid entrance**: add `animate-fade-up` to each `ProductCard` wrapper with an inline `animation-delay` based on index (cap at ~12 items so it doesn't lag on scroll). Gate with the existing global `prefers-reduced-motion` reset.
- **Card hover polish**: the hover-swap image already exists — once Phase 2 ships `secondary_image_url`, add a subtle `group-hover` border shift to `border-primary/40` (token already in use elsewhere).
- **Count-up on the ShopHeader stats** ([shop-header.tsx L17](file:///e:/SaaS%20test/shopibd/frontend/src/components/storefront/shop-header.tsx)): the "N available products" number animates from 0 on mount. Pure `requestAnimationFrame` hook, no dep.
- **Toast on add-to-cart / coupon-applied**: the project has a `toast.tsx` with `slide-in-right` + `toast-progress` defined. Use it for cart additions, coupon successes, and stock warnings instead of silent state changes.
- **Optimistic quantity steppers**: clicking +/- updates the line total instantly, then reconciles with stock. Prevents the "click → wait → update" feel.
- **Image zoom on hover** (product detail main image): a 2–3% `scale` on `group-hover` (already partially present at L234). Make it consistent and motion-safe.
- **Scroll-reveal for sections** (reviews, recently viewed, delivery info accordions): a tiny `IntersectionObserver` hook adds `animate-fade-up` when the section enters the viewport.

**Acceptance**
- Storefront first paint shows shimmer skeletons (not flat gray), then content fades/staggers in.
- Adding to cart fires a visible toast; the cart pill slides in.
- With OS `prefers-reduced-motion: reduce`, all of the above collapses to instant (verify the global reset still covers new elements).

**Files touched**: `frontend/src/app/[slug]/page-client.tsx`, `frontend/src/components/storefront/{product-card,product-grid,shop-header,product-detail,storefront-mobile-actions}.tsx`, `frontend/src/components/ui/toast.tsx`, new `frontend/src/hooks/use-count-up.ts`, `frontend/src/hooks/use-reveal.ts`.

---

## Phase 6 — Production Hardening (non-UI, parallel track)

These are flagged in the project's own docs as open and are the real "production-ready" blockers. Run in parallel with the UI phases.

- **Database indexes** (TD-003, [KNOWN_ISSUES.md L73](file:///e:/SaaS%20test/shopibd/.ai-context/KNOWN_ISSUES.md)): add indexes on `orders.shop_id`, `products.shop_id`, `product_images.product_id` via an Alembic migration. Critical for paginated catalog (Phase 3) and dashboard performance.
- **Image host allowlist**: complete the `next.config.js` remotePatterns for the real media host (also called out in Phase 1).
- **Monitoring/alerting** (TD-002, High): health dashboard, error-rate alerting. Out of scope for code here but a prerequisite for onboarding real sellers.
- **Rate limiting on public storefront endpoints**: `/shops/{slug}` and `/shops/{slug}/products/{id}` are unauthenticated and currently unprotected. Add per-IP rate limiting consistent with the existing login limiter before go-live.
- **Load test** (still open in roadmap): a k6/locust script hitting the paginated catalog + order creation. Required before the Phase 3 volume target.
- **Security audit** (OWASP top-10) — non-code process task, also still open.

**Files touched**: `backend/alembic/versions/`, `frontend/next.config.js`, `backend/app/api/v1/shops.py` (rate limit), new load-test script.

---

## Suggested execution order

1. **Phase 1** (SEO/SSR) — highest growth impact, no visual change. Ship first.
2. **Phase 2** (API enrichment) — unlocks existing dead UI with minimal code.
3. **Phase 6** (indexes + image host + rate limiting) — do alongside Phase 2/3; unblocks scale and security.
4. **Phase 3** (catalog categories/pagination/search) — depends on Phase 2 data.
5. **Phase 5** (motion) — fast, pure-CSS wins; can start as early as Phase 1.
6. **Phase 4** (cart) — largest scope; do last but high revenue value.

Each phase is independently shippable. Phases 1, 2, 5, 6 can be worked in parallel by different concerns.

---

## What is explicitly NOT in scope

- Any change to the Obsidian Emerald design system, tokens, radii, fonts, or color roles.
- Any layout rebuild of the storefront or dashboard.
- New frontend dependencies (framer-motion, cmdk, vaul, sonner) — these remain opt-in extras as noted in `ui-audit-obsidian-emerald.md`.
- Bengali i18n translation work (deferred per roadmap).
- The seller dashboard dynamism (live polling, count-up metrics, animated charts) — that is a separate, equally valuable track and should be planned next after the storefront.

---

## Open questions to resolve before execution

1. **Multi-item orders backward compatibility**: keep the single `product_id` field on `OrderCreatePublic` for existing clients, or migrate cleanly to `items[]` only? (Recommendation: keep both during transition.)
2. **Pagination shape**: introduce a breaking change to `ShopPublic.products` (paginated) or add a separate `/shops/{slug}/products` collection endpoint? (Recommendation: separate endpoint; keep `ShopPublic.products` as a small "featured" set for the initial render.)
3. **Cart persistence**: per-shop (current `recently-viewed` pattern) or global across shops? (Recommendation: per-shop — matches the single-seller storefront model.)
4. **OG image source**: prefer `banner_url` (wide) or `logo_url` (square) as the primary OG image when both exist? (Recommendation: banner, falling back to logo, falling back to `og-default.png`.)
