# Plan: Verify/Test the 6 Built Features + Design-Compliance Audit

## Summary

Two-part verification task for the 6 recently-built features (Super-admin activity
& settings pages, plan-limit enforcement, subscription payment checkout, S3-ready
image upload) plus a design-compliance check of any new pages against the
`e:\SaaS test\shopibd\demodesign\` reference.

**Part A — Functional verification** of each built flow via the existing
in-memory-SQLite + `TestClient` + `dependency_overrides` test pattern
(`tests/test_plan_limits.py`). Adds a focused test module + manual API smoke
checks.

**Part B — Design audit** of the new pages (`admin/activity`, `admin/settings`,
`dashboard/subscription`, product-form Images section) against `demodesign/`
(Obsidian Emerald dark system). Reports compliance + fixes the clear violations.

## Current State Analysis

### What was built (the "6 tasks")
| # | Task | Key files | Status |
|---|------|-----------|--------|
| 1 | `/admin/activity` page | `frontend/.../admin/activity/page.tsx` | Built (frontend only; API in `api/v1/admin.py:236`) |
| 2 | `/admin/settings` page | `frontend/.../admin/settings/page.tsx` | Built (frontend only; API in `api/v1/admin.py:452`) |
| 3 | Plan-limit enforcement | `services/plan_limits.py`, enforced in `products.py`/`shops.py` | Done; `test_plan_limits.py` exists |
| 4 | Subscription payment checkout | `subscription.py`, `subscription_payments.py`, `payment_webhook.py` | Done |
| 5 | Real integrations (bKash/SSLCommerz/Steadfast) | `services/payment/*`, `services/courier/steadfast.py` | Coded, dormant (no creds) |
| 6 | S3 image upload | `services/storage.py`, `models/product.py` (ProductImage), `api/v1/products.py` image routes, `main.py` `/media` mount, migration `e1f2a3b4c5d6` | Done this session |

### Test infrastructure (verified)
- `tests/test_plan_limits.py` — self-contained pattern: `StaticPool` in-memory
  SQLite, `db_session` + `client` fixtures, `dependency_overrides[get_db]`,
  `low_free_limits` autouse fixture mutating `PLANS["free"]`, `_make_seller` /
  `_auth` helpers. **Baseline passes (exit 0).**
- `pyproject.toml` — `pytest` + `pytest-asyncio` declared, but **no
  `asyncio_mode`** set → exercise async endpoints via `TestClient` (sync), not
  `async def test_*`.
- No `conftest.py` — replicate the per-file pattern (codebase convention).

### Design reference (verified)
- `demodesign/dashboard/DESIGN.md` = **Obsidian Emerald** dark system.
  CRITICAL CORRECTION: the reference primary IS `#83d7b4` (light mint), with
  `primary-container: #006a4e` as the deep-emerald fill. The frontend
  `globals.css` `--primary: 158 53% 68%` (mint) **matches** the reference — so
  the earlier concern about "primary is wrong" is **invalid**; the token is
  correct. The dark system forbids navy/cobalt (blue) tones and caps large
  containers at 12px (`rounded-lg`).
- Frontend uses `page-structure` layout components (`PageFrame`,
  `SurfaceSection`, `SectionHeader`, `PageHeader`, etc.) as the convention.

## Proposed Changes

### Part A — Functional tests (new file: `backend/tests/test_features_flow.py`)
Self-contained, mirrors `test_plan_limits.py`. Covers the flows not yet tested.

1. **Product image upload (Feature 6)**
   - Fixtures: reuse `_make_seller`/`_auth` pattern; add `override_storage`
     monkeypatch that sets `app.dependency_overrides` for
     `app.services.storage.get_storage_service` to return a **fake in-memory
     StorageService** (no disk) returning `/media/products/1/fake.png`.
   - Tests:
     - `POST /products/{id}/images` → 201, `image_url` returned, first image
       `is_primary=true`.
     - Second image → `is_primary=false`.
     - `PUT /products/{id}/images/{image_id}/primary` → flips primary.
     - `DELETE` the primary → 204, next image auto-promoted to primary.
     - 11th image → 400 `Maximum of 10 images`.
     - Non-image upload (`.txt`) → 400 via storage `StorageError` → 400.
   - Note: image routes need a product owned by the seller; create via
     `POST /products` with `shop_id`.

2. **Subscription lifecycle (Feature 4)**
   - `POST /subscription` with plan `starter` → 200/201, status `TRIALING`.
   - `POST /subscription/payment` with `payment_gateway=manual` → returns
     `payment_url` containing `/dashboard/subscription?manual=true`.
   - `POST /payment-webhook/subscription` (manual) → subscription `ACTIVE`,
     `seller.plan == starter`, `max_products/max_orders` synced from `PLANS`.
   - `DELETE /subscription` → reverts seller to `free`.

3. **Admin activity + settings (Features 1 & 2)**
   - Override `get_current_super_admin` to a seeded super-admin seller (avoids
     the Basic-auth middleware in `main.py`).
   - Seed `AuditLog` rows; `GET /admin/activity` → 200, returns list with
     `action`/`entity_type`/`actor_email`.
   - `GET /admin/settings` → 200, returns own email.
   - `PUT /admin/settings/profile` → 200.
   - `PUT /admin/settings/password` (correct old + ≥8 new) → 200; wrong old → 400.

4. **Plan-limit order path (Feature 3, extend coverage)**
   - Reuse `low_free_limits` to set `max_orders=0`; `POST /shops/{slug}/orders`
     (public order endpoint in `shops.py`) → 402 `plan_limit_exceeded`.

### Part A2 — Manual API smoke (documented, not automated)
A short runbook (in the plan/PR notes) for the Docker container once running:
- `GET /api/v1/plans` returns 4 plans.
- `GET /media/<uploaded-image>` returns bytes (local storage mount works).
- `GET /shops/{slug}` product dict includes `primary_image_url`.

### Part B — Design-compliance fixes (frontend)
Based on audit, fix the **clear violations only** (no over-engineering):

1. **`admin/activity/page.tsx` — remove forbidden blue.**
   - Lines ~30,32 use `blue-500/blue-400` for "update" and `amber` for
     `status_update`. Obsidian Emerald forbids navy/cobalt. Replace with token
     classes: `text-primary`/`bg-primary/10` (emerald) for update,
     `text-warning`/`bg-warning/10` (amber is acceptable as semantic warning) for
     status_update. Keep the table's `#000`/`#0a0a0a`/`#1f1f1f` hex since they
     match the reference literally.
   - (Optional, lower priority) migrate containers to `SurfaceSection` — flagged
     but **not auto-applied** unless you want full consistency; the hex values
     already match the reference, so this is convention-only.

2. **`admin/settings/page.tsx` — token usage.**
   - Replace hardcoded `bg-[#0a0a0a]/border-[#1f1f1f]` with `bg-surface-1/
     border-border` so it responds to token changes. Functionally identical
     colors. (Low-risk consistency fix.)

3. **Product-form Images section (`product-form.tsx`) — radius.**
   - Currently `rounded-xl` (24px) on tiles/icon chips. DESIGN.md caps large
     containers at 12px (`rounded-lg`). Change image tiles + icon chip to
     `rounded-lg` for fidelity. (Cosmetic; confirm you want this.)

> Note: `dashboard/subscription/page-client.tsx` is the **exemplar** — no changes.

## Assumptions & Decisions
1. Tests use the **existing self-contained per-file pattern** (no shared
   conftest) to match codebase convention.
2. Async endpoints exercised via `TestClient` (sync wrapper), because
   `asyncio_mode` is unset.
3. Image tests **stub the storage service** (in-memory fake) — never touch disk,
   fully offline.
4. Admin tests override the super-admin dependency to bypass the Basic-auth
   middleware (cleaner than sending Basic + Bearer).
5. Real payment gateways (bKash/Nagad/SSLCommerz) and `STORAGE_BACKEND=s3` are
   **out of scope** for automated tests (need live creds).
6. Design fixes are **limited to clear violations** (forbidden blue, raw-hex
   that breaks token system, oversized radius) — not a full restyle.
7. The `demodesign/order|payment|storefront` DESIGN.md prescribe a *light*
   theme; the admin/dashboard area is intentionally dark, so those light files
   are documentation-only and not applied here (pre-existing reference
   inconsistency, not a defect).

## Verification Steps
1. `cd backend && python -m pytest tests/test_features_flow.py -q` → all green.
2. `python -m pytest tests/ -q` → existing + new suites pass together.
3. `python -m py_compile` on all changed backend files (already verified for
   Feature 6).
4. Frontend: visual diff of `admin/activity` (no blue) and `admin/settings`
   (token classes) against `demodesign/dashboard/screen.png`; confirm
   `subscription` + product-form Images still match.
5. (Manual, Docker) smoke the `/media` static mount + storefront
   `primary_image_url` per Part A2 runbook.
