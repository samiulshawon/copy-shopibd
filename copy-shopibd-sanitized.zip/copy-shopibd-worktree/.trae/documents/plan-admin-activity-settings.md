# Plan: Super Admin Activity Page + Settings Page

## Summary

Build two missing super-admin pages:
1. **`/admin/activity`** — Full audit-log table (paginated, filterable by action/entity).
2. **`/admin/settings`** — Super admin's own profile editor (name, email, phone, change password).

---

## Current State

| Aspect | Detail |
|--------|--------|
| Activity API | `GET /admin/activity?limit=N` exists, returns `{id, action, entity_type, entity_id, actor_email, created_at}`. Not paginated — always returns last N entries. |
| Activity page | No `page.tsx`. Nav item in `SuperAdminShell` already links to `/admin/activity`. |
| Settings API | No dedicated `/admin/settings` endpoint exists. |
| Settings page | No `page.tsx`. Account dropdown in shell links to `/admin/settings`. |
| Seller model fields | `name`, `email`, `phone`, `password_hash`, `is_active`, `is_verified`, `is_super_admin`, `plan`, `max_products`, `max_orders`. |
| Existing pattern | Dashboard page at `admin/page.tsx` uses `"use client"` single-file pattern, calls `superAdminApi.*`, uses shadcn UI components. |
| Admin layout guard | `admin/layout.tsx` already guards with `getServerSession() → is_super_admin`. Both new routes are under `/admin` so automatically protected. |
| Component library | Button, Input, Badge, Skeleton, Table, Card, Select (options-array API), Alert, DropdownMenu — all used in existing admin pages. |

---

## Proposed Changes

### Feature 1: `/admin/activity` — Activity Feed Page

**What:** A full-page audit-log viewer showing all platform activity, with search/filter.

**Files:**
- `frontend/src/app/admin/activity/page.tsx` — **NEW**

**How:**

1. **Page structure** (following `clients/page.tsx` pattern):
   - Header: "Activity Log" with subtitle "Platform activity across all clients."
   - Filter bar: search by `actor_email` text input, `action` dropdown (Select component), `entity_type` dropdown.
   - Data table (dark table style from `clients/page.tsx` or `admin/page.tsx` dashboard):
     - Columns: Action, Entity, Entity ID, Actor, Time
     - Alternating row colors, emerald badges for actions
   - Load More / pagination button (simple: "Load 20 more" since API uses `limit` param)

2. **Data fetching:**
   - Uses `superAdminApi.getActivity(limit)` with `limit` increments.
   - Initial load: `limit=50`, then "Load more" appends 30 more.
   - Client-side filtering: search/filter applied to already-fetched data (no backend filter params yet; keep it simple).

3. **UI components used:** Button, Input, Select, Badge, Skeleton (loading state), empty-state message.

4. **Empty state:** "No activity recorded yet."

**API:** No changes. `GET /admin/activity?limit=N` is already built and used by the dashboard widget.

---

### Feature 2: `/admin/settings` — Super Admin Profile

**What:** Super admin can edit their own name, phone, and change their password.

**Backend (needed):**
- `GET /admin/settings` — returns `{ name, email, phone }` of the super admin.
- `PUT /admin/settings/profile` — update name, phone.
- `PUT /admin/settings/password` — change password (old + new).

**Why separate endpoints?** The `settingsApi` (per-seller) hits `/sellers/me/settings`, but super admin settings are different (owner profile, not shop config). A dedicated minor API avoids overloading seller endpoints.

**Backend files:**
- `backend/app/api/v1/admin.py` — **EXTEND** with 3 new endpoints.

**Frontend files:**
- `frontend/src/app/admin/settings/page.tsx` — **NEW**

**How (Backend):**

Add to `admin.py` under `tags=["super-admin"]`:

1. `GET /admin/settings` — Returns `{ name, email, phone }` from `seller` (the authenticated super admin). Depends on `get_current_super_admin`.

2. `PUT /admin/settings/profile` — Accepts `{ name, phone }`. Updates the super admin's own record. Schema: reuse `SellerUpdate` (name, phone only — no `is_active`).

3. `PUT /admin/settings/password` — Accepts `{ current_password, new_password }`. Verifies current password via `verify_password`, then sets `password_hash = get_password_hash(new_password)`.

**How (Frontend):**

Two cards on the page:

- **Profile card** (name, phone): input fields + "Save changes" button → calls `PUT /admin/settings/profile`.
- **Security card** (password change): `current_password`, `new_password`, `confirm_password` fields + "Change Password" button → calls `PUT /admin/settings/password`. Validate `new_password === confirm_password` client-side.

Uses same dark-card pattern (`bg-[#0a0a0a] border border-[#1f1f1f] rounded-lg p-6`) from `clients/[id]/page.tsx`.

**Add to `superAdminApi` (api.ts):**

```ts
getSettings: () => api.get("/admin/settings"),
updateProfile: (data: { name?: string; phone?: string }) => api.put("/admin/settings/profile", data),
changePassword: (data: { current_password: string; new_password: string }) => api.put("/admin/settings/password", data),
```

---

## Files Changed Summary

| File | Action | Description |
|------|--------|-------------|
| `backend/app/api/v1/admin.py` | EXTEND | Add GET/PUT settings endpoints |
| `frontend/src/lib/api.ts` | EXTEND | Add `getSettings`, `updateProfile`, `changePassword` to `superAdminApi` |
| `frontend/src/app/admin/activity/page.tsx` | **NEW** | Paginated activity log page |
| `frontend/src/app/admin/settings/page.tsx` | **NEW** | Super admin profile + password page |

**Isolation:** No changes to seller dashboard, storefront, existing admin pages, or backend models.

---

## Assumptions & Decisions

1. **Activity pagination:** Client-side "load more" with incrementing limit param. No server-side cursor/filter yet — the `GET /admin/activity?limit=50` backend is adequate for now. Future: add `action` and `entity_type` query params if needed.
2. **Settings scope:** Super admin settings = own profile only. NOT platform-level config (SMTP, billing, etc.) — those are out of scope.
3. **Password change:** Uses the same `app.core.security.get_password_hash / verify_password` already in `admin.py` (imported for `create_seller`).
4. **Page pattern:** Both pages use `"use client"` pattern — no server components needed (superAdminApi already fetches from client).

---

## Verification Steps

1. **Activity page:** Navigate to `/admin/activity` → table loads with audit entries → filter/search works → "Load More" paginates.
2. **Settings page:** Navigate to `/admin/settings` → profile card shows current name/email/phone → edit name → save → refresh → name persists → change password → logout → login with new password → succeeds.
3. Both pages compile cleanly (user can run `npx next build` after, but not required during implementation).