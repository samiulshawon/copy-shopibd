# Phase 2 Remaining Items — Plan

## Summary

Three actionable code areas remain in Phase 2 after the optimization pass:
1. **E2E test reliability** — fix credentials, add data isolation
2. **Operational monitoring** — enhanced health checks, production healthcheck config
3. **Deprecation cleanup** — modernise Python 3.12+ patterns across the codebase

---

## 1. E2E Test Reliability

### Current State
- 3 Playwright test files (`auth.spec.ts`, `order-flow.spec.ts`, `subscription.spec.ts`)
- All hardcode `TEST_EMAIL="rahim@shopibd.com"` / `TEST_PASSWORD="password123"`
- The seed script creates a seller with `sawan@shopibd.com` / `12345678`
- No teardown/reset data script exists; tests are order-dependent

### Changes

**1a. Fix credentials** *(completed)*
- **File:** `e:\SaaS test\shopibd\frontend\tests\e2e\auth.spec.ts`
  - `"rahim@shopibd.com"` → `"sawan@shopibd.com"`
  - `"password123"` → `"12345678"`
- **File:** `e:\SaaS test\shopibd\frontend\tests\e2e\order-flow.spec.ts`
  - Same credential fixes
- **File:** `e:\SaaS test\shopibd\frontend\tests\e2e\subscription.spec.ts`
  - Same credential fixes

**1b. Add reset/teardown script** *(completed)*
- **New file:** `e:\SaaS test\shopibd\backend\scripts\reset_db.py`
  - Drops and recreates all tables, then runs seed
  - Usage: `python -m scripts.reset_db`
  - Uses the same engine config as `seed.py`
  - Can be called from CI before E2E runs

**1c. Add CI seed step to Playwright config** *(completed)*
- **File:** `e:\SaaS test\shopibd\frontend\playwright.config.ts`
  - Added `globalSetup: './tests/e2e/global-setup'`
- **New file:** `e:\SaaS test\shopibd\frontend\tests\e2e\global-setup.ts`
  - Runs `python -m scripts.reset_db` before test suite

---

## 2. Operational Monitoring

### Current State
- `/health` endpoint returns `{"status": "healthy"}` — no dependency checks
- Production `docker-compose.yml` has no backend healthcheck

### Changes

**2a. Enhanced health endpoint** *(completed)*
- **File:** `e:\SaaS test\shopibd\backend\app\main.py`
  - Replaced simple health check with dependency-aware checks
  - Checks database connectivity (`SELECT 1`)
  - Checks Redis connectivity if configured (`PING`)
  - Returns `{"status": "healthy"|"degraded"|"unhealthy", "checks": {...}, "version": ...}`
  - Uses sync checks via `SessionLocal()` and `get_redis().ping()`

Specific implementation:
```python
@app.get("/health")
def health_check():
    status = "healthy"
    checks = {}
    
    # Database check
    try:
        db = SessionLocal()
        db.execute(text("SELECT 1"))
        checks["database"] = "ok"
        db.close()
    except Exception as e:
        checks["database"] = str(e)
        status = "unhealthy"
    
    # Redis check (only if configured)
    if settings.REDIS_URL:
        try:
            redis = get_redis()
            redis.ping()
            checks["redis"] = "ok"
        except Exception as e:
            checks["redis"] = str(e)
            if status == "healthy":
                status = "degraded"
    
    return {"status": status, "checks": checks, "version": settings.VERSION}
```

**2b. Production healthcheck** *(completed)*
- **File:** `e:\SaaS test\shopibd\docker-compose.yml`
  - Added healthcheck to backend service
  - Uses `python -c "..."` hitting `/health` endpoint
  - interval: 30s, retries: 3, start_period: 15s

---

## 3. Deprecation Cleanup *(all completed)*

### 3a. `datetime.utcnow()` → `datetime.now(timezone.utc)` — 17 occurrences across 11 files

All occurrences replaced:
- `backend/app/core/security.py` — lines 22, 24
- `backend/app/api/v1/whitelabel.py` — line 214
- `backend/app/api/v1/shops.py` — lines 304, 403
- `backend/app/api/v1/payments.py` — line 303
- `backend/app/api/v1/orders.py` — lines 375, 647
- `backend/app/api/v1/customers.py` — lines 58, 66
- `backend/app/api/v1/coupons.py` — line 312
- `backend/app/api/v1/analytics.py` — lines 64, 146
- `backend/app/services/plan_limits.py` — lines 132, 171
- `backend/app/services/payment/nagad.py` — line 212
- `backend/app/services/invoice.py` — line 191

`from datetime import timezone` added where needed.

### 3b. `regex=` → `pattern=` in analytics *(completed)*
- **File:** `e:\SaaS test\shopibd\backend\app\api\v1\analytics.py`, line 128
  - `regex="^(7d|30d|90d)$"` → `pattern="^(7d|30d|90d)$"`

### 3c. Pydantic v2: `class Config` → `model_config = ConfigDict(...)` — 30 occurrences across 16 files *(completed)*

All schema files converted:
- `backend/app/schemas/payment.py` (2 occurrences)
- `backend/app/schemas/seller.py`
- `backend/app/schemas/order.py` (3)
- `backend/app/schemas/coupon.py`
- `backend/app/schemas/review.py` (2)
- `backend/app/schemas/delivery.py` (2)
- `backend/app/schemas/product.py` (2)
- `backend/app/schemas/customer.py` (2)
- `backend/app/schemas/category.py`
- `backend/app/schemas/staff.py`
- `backend/app/schemas/stock.py`
- `backend/app/schemas/shop.py` (4)
- `backend/app/schemas/whitelabel.py`
- `backend/app/api/v1/orders.py` (5 inline schemas)
- `backend/app/api/v1/audit_logs.py`
- `backend/app/core/config.py` — Settings class: uses `SettingsConfigDict(...)`

---

## Verification Steps

1. **E2E tests**: Run `npx playwright test` — all 3 spec files authenticate successfully with new credentials
2. **Health endpoint**: `curl http://localhost:8000/health` returns `{"status": "healthy", "checks": {"database": "ok", "redis": "ok"}}`
3. **Production healthcheck**: `docker compose -f docker-compose.yml config` validates the healthcheck block
4. **Deprecations**: Run `pytest -W error::DeprecationWarning` — no deprecation warnings from our code
5. **Regression**: `pytest tests/` — all 51 tests still pass
