# Checklist — ShopiBD Enhancement Roadmap 2026

## Phase 0 — Dev Environment & Docker
- [x] All service ports configurable via env (BACKEND_PORT, FRONTEND_PORT, DB_PORT, REDIS_PORT, MINIO_PORT).
- [x] Backend runs inside `shopibd-backend-dev` container (no `sleep infinity`); live-reloads mounted code.
- [x] `docker compose -f docker-compose.dev.yml up` brings up API+DB+Redis+MinIO in one command.
- [x] Frontend `.env.local` derives `NEXT_PUBLIC_API_URL` from backend port.
- [x] `scripts/check_ports.py` detects free ports and prints/ writes `.env.local` snippet.
- [x] `docs/LOCAL_SETUP.md` documents setup + Windows reserved-port note.

## Phase 1 — Auth & Secret Hardening
- [x] Login returns access + refresh tokens.
- [x] `POST /auth/refresh` rotates refresh and revokes old jti.
- [x] `POST /auth/logout` revokes refresh jti.
- [x] `get_current_seller` rejects revoked `jti`.
- [x] Startup fails fast if `APP_ENV=production` and `SECRET_KEY` is the dev default.
- [x] Rate limiter uses Redis when available; in-process fallback + warning when down.
- [x] `RATE_LIMIT_FAIL_CLOSED` denies when state unknown (optional).

## Phase 2 — Multi-Tenant Isolation & Impersonation
- [x] `get_current_seller_id()` returns request-scoped seller id via contextvar.
- [x] DB sets `app.current_seller_id` per connection/request.
- [x] RLS policies (optional, `TENANT_RLS`) enforce row isolation; super-admin exempt.
- [x] `POST /admin/sellers/{id}/impersonate` returns short-lived token with `impersonated_by`.
- [x] Super-admin create-client, update, activate/deactivate, plan-override, and impersonate write audit entries.

## Phase 3 — Rate Limit Resilience & Alerting
- [x] Fallback limiter holds per-process when Redis down.
- [x] `ratelimit_redis_down_total` metric emitted (Phase 5 module in place; increments in middleware).
- [x] Unit/integration tests cover Redis-down path (`test_phase3_rate_limit_metrics.py`).

## Phase 4 — CI/CD & Contract Tests — **🟡 CODE COMPLETE; CI RUN PENDING**
- [x] GitHub Actions backend job runs pytest against ephemeral Postgres+Redis.
- [x] GitHub Actions frontend job builds + runs Playwright e2e with `reset_db`.
- [x] Schemathesis contract test is a required CI job and fails CI on schema-validation failures.
- [ ] First GitHub Actions PR/push run passes all three jobs.

## Phase 5 — Observability  — **✅ CODE COMPLETE; TEST RUN SANDBOX-BLOCKED**
- [x] `X-Request-ID` present on every response; logs carry it.
- [x] `/metrics` exposes DB pool, Redis hits/misses, subs-by-plan, subdomain/custom-domain counts, rate-limit fallback.
- [x] `scheduler_runs` table records last run + status; `/health` reports it.
- [x] Middleware uses request-scoped session dependency instead of raw `SessionLocal()`.

## Phase 6 — Downgrade Events & Grace  — **✅ COMPLETE**
- [x] `subscription.downgraded` event emitted on downgrade with lost capabilities (DB outbox).
- [x] 7-day grace period keeps `custom_domain` routing with warning (admin banner).
- [x] Client notified on downgrade; upgrade within grace restores fully.

## Phase 7 — Custom Domain SSL  — **✅ COMPLETE**
- [x] `provision_ssl()` implemented (ACME/Caddy/Traefik/certbot; pluggable stub/certbot backends).
- [x] Cert provisioned on verified custom domain; HTTPS serves storefront.
- [x] Auto-renewal < 30 days; `/health` shows SSL status.

## Phase 8 — Role Model Cleanup  — **✅ COMPLETE**
- [x] `is_staff` (or role) added; `get_current_admin_seller` gates on it, not `is_verified`.
- [x] Backfill marks existing super-admins as staff; seed updated.

## Phase 9 — SQLAdmin & Subdomain UX  — **✅ COMPLETE**
- [x] SQLAdmin creds centralized in config; session timeout + CSRF considered.
- [x] `GET /shops/subdomain-available` returns availability + suggestions.
- [x] Frontend signup shows availability + suggestions.

## Phase 10 — Payments, Courier, Cart  — **✅ COMPLETE**
- [x] Sandbox integration tests exist for bKash/Nagad/SSLCommerz.
- [x] Steadfast create/track + webhook verification implemented.
- [x] Abandoned-cart job notifies users and tracks recovery.

## Cross-Phase
- [x] Phase 0 done before others.
- [ ] Bengali i18n explicitly excluded (no work done).