# Tasks — ShopiBD Enhancement Roadmap 2026

Implement **one phase at a time**. Each task is independently verifiable. Dependencies noted.

---

## Phase 0 — Dev Environment & Docker Dev Workflow
- [x] Task 0.1: Make ports configurable
  - [x] 0.1.1: Add `BACKEND_PORT`, `FRONTEND_PORT`, `DB_PORT`, `REDIS_PORT`, `MINIO_PORT` to `backend/app/core/config.py` with defaults.
  - [x] 0.1.2: Update `docker-compose.dev.yml` to use these env vars for port mappings and `command`.
  - [x] 0.1.3: Replace backend `command: sleep infinity` with `uvicorn app.main:app --host 0.0.0.0 --port ${BACKEND_PORT} --reload`.
- [x] Task 0.2: Frontend env derivation
  - [x] 0.2.1: Set `frontend/.env.local` `NEXT_PUBLIC_API_URL=http://localhost:${BACKEND_PORT}/api/v1` (documented; value resolved at run).
  - [x] 0.2.2: Add `frontend/.env.example` with the same pattern.
- [x] Task 0.3: Port checker script
  - [x] 0.3.1: Create `backend/scripts/check_ports.py` that scans common ranges, finds free ports, prints a `.env.local` snippet.
  - [x] 0.3.2: Add `--write` flag to write the snippet to `frontend/.env.local`.
- [x] Task 0.4: Setup doc
  - [x] 0.4.1: Write `docs/LOCAL_SETUP.md` covering `docker compose -f docker-compose.dev.yml up`, Windows reserved-port note, and using `check_ports.py`.
- [x] Task 0.5: Tests
  - [x] 0.5.1: Verify `docker compose -f docker-compose.dev.yml up` brings up all services.
  - [x] 0.5.2: Verify `check_ports.py --write` produces valid `.env.local`.
  - [x] 0.5.3: Run full test suite to confirm no regressions.

## Phase 1 — Authentication & Secret Hardening
- [x] Task 1.1: Token factory upgrade
  - [x] 1.1.1: In `security.py`, add `create_refresh_token(subject)` with `jti`, `iat`, `type:"refresh"`.
  - [x] 1.1.2: Add `jti` + `iat` + `type:"access"` to `create_access_token`.
  - [x] 1.1.3: Add `decode_token` variant that returns full payload + validates `exp`.
- [x] Task 1.2: Revocation store
  - [x] 1.2.1: In `redis_client.py`, add `revoke_jti(jti, ttl)` and `is_jti_revoked(jti)` (Redis set with expiry).
  - [x] 1.2.2: In `security.py`, add `revoke_token(jti)` / `is_token_revoked(jti)` wrappers.
- [x] Task 1.3: Auth endpoints
  - [x] 1.3.1: Extend `POST /auth/login` to return `access_token` + `refresh_token`.
  - [x] 1.3.2: Add `POST /auth/refresh` (rotate refresh, revoke old jti).
  - [x] 1.3.3: Add `POST /auth/logout` (revoke refresh jti).
  - [x] 1.3.4: Update `get_current_seller` to check `is_jti_revoked` for access token `jti`.
- [x] Task 1.4: Secret startup guard
  - [x] 1.4.1: In `config.py`, add `DEFAULT_SECRET_KEY` constant and a validator that raises if `APP_ENV=production` and `SECRET_KEY == DEFAULT_SECRET_KEY`.
- [x] Task 1.5: Rate-limit resilience
  - [x] 1.5.1: In `middleware.py`, add in-process fallback limiter when Redis unavailable.
  - [x] 1.5.2: Add `RATE_LIMIT_FAIL_CLOSED` config; when true, deny if state unknown.
  - [x] 1.5.3: Emit warning/metric when fallback active (hook to Phase 5 metric).
  - [x] 1.5.4: Wire login endpoint to resilient limiter.
- [x] Task 1.6: Tests
  - [x] 1.6.1: Unit test: `create_access_token` includes `jti`/`iat`/`type`.
  - [x] 1.6.2: Unit test: `revoke_jti` / `is_jti_revoked` round-trip in Redis.
  - [x] 1.6.3: Integration test: login → refresh → logout → reused refresh fails.
  - [x] 1.6.4: Integration test: secret guard blocks startup in prod mode.
  - [x] 1.6.5: Integration test: login rate-limits when Redis down (fallback holds).

## Phase 2 — Multi-Tenant Isolation & Impersonation
- [x] Task 2.1: Request-scoped context
  - [x] 2.1.1: Create `backend/app/core/context.py` with `seller_id_var` contextvar + `set_current_seller_id`/`get_current_seller_id`.
  - [x] 2.1.2: In `dependencies.py get_current_seller`, set the contextvar after loading seller (and clear on auth failure).
  - [x] 2.1.3: In `database.py`, add a connect/begin event that sets `app.current_seller_id` from the contextvar.
- [x] Task 2.2: Optional RLS (gated by `TENANT_RLS`)
  - [x] 2.2.1: Add Alembic migration creating policies on 16 tenant tables using `current_setting('app.current_seller_id')`.
  - [x] 2.2.2: Super-admin role exempted via `bypassrls` or policy exception.
- [x] Task 2.3: Impersonation
  - [x] 2.3.1: Add `POST /admin/sellers/{id}/impersonate` returning short-lived token with `impersonated_by`.
  - [x] 2.3.2: Frontend "View as client" button using the token.
- [x] Task 2.4: Audit logging
  - [x] 2.4.1: Ensure `audit_log.py` model exists; add helper `log_admin_action(actor, target, action)`.
  - [x] 2.4.2: Call it in create-client, update, activate/deactivate, plan-override, and impersonate paths in `admin.py`.
- [x] Task 2.5: Tests
  - [x] 2.5.1: Unit test: `get_current_seller_id` returns set value, `None` by default.
  - [x] 2.5.2: Integration test: impersonation token has `impersonated_by` claim, 15-min TTL, `type=access`.
  - [x] 2.5.3: Integration test: impersonate self / inactive returns 400.
  - [x] 2.5.4: Integration test: create-client / activate / deactivate / plan-override / impersonate each write `AuditLog` row.
  - [x] 2.5.5: Integration test: invalid token on protected route returns 401 and clears contextvar.

## Phase 3 — Rate Limiting Resilience & Alerting
- [x] Task 3.1: Metric counter for Redis fallback
  - [x] 3.1.1: In `services/metrics.py` (Phase 5), add `ratelimit_redis_down_total` counter.
  - [x] 3.1.2: In `middleware.py` fallback path, increment counter when Redis unavailable.
- [x] Task 3.2: Tests
  - [x] 3.2.1: Unit test: mock Redis down → fallback limiter holds per-process; counter increments (`test_phase3_rate_limit_metrics.py`).
  - [x] 3.2.2: Integration test: burst with Redis down → 429 after local limit; metric exposed via `render_prometheus`.

## Phase 4 — CI/CD Pipeline & Contract Tests
- [x] Task 4.1: Backend CI job
  - [x] 4.1.1: Update `.github/workflows/ci.yml` with Python 3.12, Postgres+Redis services, `pytest`.
  - [x] 4.1.2: Cache pip dependencies.
- [x] Task 4.2: Frontend CI job
  - [x] 4.2.1: Node setup, `npm ci`, `npm run build`, `npx playwright install --with-deps chromium`.
  - [x] 4.2.2: `npx playwright test` with `reset_db` globalSetup.
- [x] Task 4.3: Contract tests
  - [x] 4.3.1: Add `schemathesis` to dev deps; `tests/contract` harness against `/api/v1/openapi.json`.
  - [x] 4.3.2: Contract test is a required CI job, so schema failures fail CI.
- [ ] Task 4.4: Tests
  - [ ] 4.4.1: Verify CI runs on PR and passes all 3 jobs (pending first GitHub Actions run).
  - [ ] 4.4.2: Introduce a breaking OpenAPI change locally → confirm CI fails (pending CI run).

## Phase 5 — Observability
- [x] Task 5.1: Request-ID middleware
  - [x] 5.1.1: `middleware.py` adds `X-Request-ID` (generate if missing).
  - [x] 5.1.2: `log.py` filter appends request-id to every log line.
- [x] Task 5.2: Metrics
  - [x] 5.2.1: `services/metrics.py` with Prometheus counters/gauges (DB pool, Redis hits/misses, subs by plan, subdomain/custom-domain counts, rate-limit fallback).
  - [x] 5.2.2: `/metrics` endpoint (protected/internal).
- [x] Task 5.3: Scheduler visibility
  - [x] 5.3.1: `models/scheduler_run.py` + migration.
  - [x] 5.3.2: `subscription_tasks.run_all_subscription_tasks` writes a run record (start, end, status, counts).
  - [x] 5.3.3: `/health` includes `scheduler: {last_run, status}`.
- [x] Task 5.4: Middleware session refactor
  - [x] 5.4.1: Replace direct `SessionLocal()` in `custom_domain_middleware`/`storefront_path_middleware` with a shared request-scoped session dependency.
- [x] Task 5.5: Tests
  - [x] 5.5.1: Unit test: every response has `X-Request-ID`; log line contains it.
  - [x] 5.5.2: Unit test: `/metrics` exposes expected counters/gauges.
  - [x] 5.5.3: Integration test: scheduler run writes `scheduler_runs` row; `/health` reflects it.
  - [x] 5.5.4: Integration test: middleware uses shared session, no leaks.

## Phase 6 — Subscription Downgrade: Events, Grace Period, Notifications
- [x] Task 6.1: Event bus
  - [x] 6.1.1: `services/events.py` (durable DB outbox + in-process subscribers + Redis fan-out).
  - [x] 6.1.2: `subscription_tasks` detects downgrade, publishes `subscription.downgraded` (expire, cancel, admin override).
- [x] Task 6.2: Grace period
  - [x] 6.2.1: Add `custom_domain_grace_until` to `Shop` + migration; middleware honors it during grace.
  - [x] 6.2.2: Admin UI warning banner when in grace (frontend client page).
- [x] Task 6.3: Notifications
  - [x] 6.3.1: `notification.py` downgrade templates; subscriber notifies client on event.
- [x] Task 6.4: Tests
  - [x] 6.4.1: Integration test: Enterprise→Business downgrade emits event + writes grace timestamp.
  - [x] 6.4.2: Integration test: within grace, custom domain still routes; admin sees warning.
  - [x] 6.4.3: Integration test: upgrade within grace restores fully; no data loss.

## Phase 7 — Custom Domain SSL Provisioning
- [x] Task 7.1: Provisioning
  - [x] 7.1.1: Implement `provision_ssl()` via ACME (certbot) or reverse proxy (Caddy/Traefik) automation.
  - [x] 7.1.2: Trigger on verified custom domain in `whitelabel.py`.
  - [x] 7.1.3: `Shop.ssl_status`, `ssl_expires_at` columns + migration.
- [x] Task 7.2: Renewal & health
  - [x] 7.2.1: Renewal job < 30 days; `/health` SSL status.
- [x] Task 7.3: Tests
  - [x] 7.3.1: Integration test: verified domain → cert provisioned → HTTPS serves storefront (use staging ACME).
  - [x] 7.3.2: Integration test: cert < 30 days → renewal job runs; `/health` shows SSL status.

## Phase 8 — Role Model Cleanup
- [x] Task 8.1: Schema
  - [x] 8.1.1: Add `is_staff` (or role) to `Seller`; migration.
  - [x] 8.1.2: `get_current_admin_seller` gates on `is_staff`, not `is_verified`.
- [x] Task 8.2: Backfill
  - [x] 8.2.1: `scripts/backfill_roles.py` marks existing super-admins as staff.
  - [x] 8.2.2: Update seed constants.
- [x] Task 8.3: Tests
  - [x] 8.3.1: Integration test: verified non-staff seller calling admin route gets 403.
  - [x] 8.3.2: Integration test: backfill script marks super-admins as staff; seed works.

## Phase 9 — SQLAdmin & Subdomain UX
- [x] Task 9.1: Centralize creds
  - [x] 9.1.1: Move SQLAdmin creds to `config.py`; `main.py` reads them.
  - [x] 9.1.2: Add session timeout; consider CSRF for form posts.
- [x] Task 9.2: Availability API
  - [x] 9.2.1: `GET /api/v1/shops/subdomain-available` returns availability + suggestions.
  - [x] 9.2.2: Frontend signup shows availability + suggestions.
- [x] Task 9.3: Tests
  - [x] 9.3.1: Integration test: `subdomain-available` returns correct suggestions for taken/available.
  - [x] 9.3.2: Integration test: frontend signup page shows live availability check.

## Phase 10 — Payments, Courier, Cart
- [x] Task 10.1: Provider sandbox tests
  - [x] 10.1.1: Sandbox tests for bKash/Nagad/SSLCommerz (marked integration).
- [x] Task 10.2: Steadfast courier
  - [x] 10.2.1: `services/courier/steadfast.py` create/track + webhook verify.
  - [x] 10.2.2: `api/v1/courier.py` endpoints.
- [x] Task 10.3: Abandoned cart
  - [x] 10.3.1: `services/abandoned_cart.py` job; notify + track recovery.
- [x] Task 10.4: Tests
  - [x] 10.4.1: Integration test: each provider sandbox smoke test passes (cred-dependent).
  - [x] 10.4.2: Integration test: create/track Steadfast shipment; webhook updates status.
  - [x] 10.4.3: Integration test: abandoned cart job finds carts > 1h; notification sent; recovery tracked.

---

# Task Dependencies
- Phase 0 → all (do first).
- Phase 1 → Phase 2 (auth model settled), Phase 3 (shares limiter).
- Phase 5 → Phase 6/7 (health signals visible).
- Phase 4 can run anytime after Phase 0.
- Phases 8–10 are independent of each other; Phase 9/10 can follow Phase 0.