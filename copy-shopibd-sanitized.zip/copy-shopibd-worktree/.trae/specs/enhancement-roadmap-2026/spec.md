# ShopiBD Enhancement Roadmap 2026 — Master Spec

> **Single structured spec** covering all agreed enhancement phases. Implement **one phase at a time**, recalling this document. Each phase is independently shippable; dependencies are noted so ordering is safe.

## Why
We have shipped the core platform (multi-tenant SaaS, plan-gated URLs, local-test routing, invoice, payments, scheduler). This spec captures the next wave of hardening and feature-completion work, discovered both from a direct enhancement review and a deep-dive into multi-tenancy isolation, security/auth, and observability. It is the single source of truth to follow phase-by-phase.

## How to use this spec
- Phases are ordered **P0 → P3** by leverage and dependency.
- Each phase has its own `## Phase N` section with: Goal, Scope, Files, Requirements (with scenarios), and Risks.
- Implement one phase, verify its checklist, then move to the next.
- Bengali (i18n) work is **explicitly deferred** per owner instruction.

---

## Phase 0 — Dev Environment & Docker Dev Workflow  *(P0, your #1 + deep-dive finding 13)*

### Goal
Make local setup reproducible and port-agnostic; run backend inside Docker dev container so code and process never drift; fix the Windows reserved-port (`3000–3020`, `8000` stale WSL) pain.

### Scope
- All ports configurable via env (`BACKEND_PORT`, `FRONTEND_PORT`, `DB_PORT`, `REDIS_PORT`, `MINIO_PORT`).
- Backend runs inside `shopibd-backend-dev` container (use `Dockerfile.dev` `CMD`, drop `sleep infinity`).
- Frontend `.env.local` derives `NEXT_PUBLIC_API_URL` from `BACKEND_PORT`.
- Add `scripts/check_ports.py` to detect free ports and print a suggested `.env`.

### Files
- `docker-compose.dev.yml` (backend `command`, ports, healthcheck)
- `frontend/.env.local`, `frontend/.env.example`
- `backend/scripts/check_ports.py` (new)
- `README` / `docs/LOCAL_SETUP.md` (new, minimal)

### Requirements
- **R0.1 Port config:** System SHALL read service ports from env with sane defaults; no hardcoded `3001`/`8000` in startup commands.
  - *Scenario:* WHEN `BACKEND_PORT=8080` is set, THEN `uvicorn` binds `0.0.0.0:8080` and frontend calls `http://localhost:8080/api/v1`.
- **R0.2 Backend in container:** `docker compose -f docker-compose.dev.yml up` SHALL start API, DB, Redis, MinIO with one command; backend serves the mounted `./backend` code with live reload.
  - *Scenario:* WHEN dev runs `docker compose up`, THEN `GET /health` returns `{"status":"healthy"}` within 30s, no separate host `uvicorn` needed.
- **R0.3 Port checker:** `python scripts/check_ports.py` SHALL print free ports and a ready `.env.local` snippet.
  - *Scenario:* WHEN run on a machine where 3000–3020 are reserved, THEN it suggests e.g. `FRONTEND_PORT=4100 BACKEND_PORT=8080`.

### Risks
- Docker Desktop WSL2 port-forwarding may still shadow host ports → verify with `Test-NetConnection` after up.
- `Dockerfile.dev` installs deps at build; changing `pyproject.toml` requires `docker compose build` → document in setup doc.

---

## Phase 1 — Authentication & Secret Hardening  *(P0, your #6 + deep-dive findings 5,7,8)*

### Goal
Make tokens revocable, secrets production-safe, and rate limiting resilient during Redis outages.

### Scope
- Add refresh tokens (`refresh_token` table or JWT with `jti`), rotation on use, revocation list (`revoked_jti` in Redis).
- `create_access_token`/`create_refresh_token` include `jti`, `iat`, `type`.
- Startup **fail-fast** if `SECRET_KEY` is the dev default while `APP_ENV=production`.
- Rate limiter: when Redis down, fall back to **process-local** limiter AND emit a warning/metric; optional `RATE_LIMIT_FAIL_CLOSED=true` to deny when unknown.
- Login endpoint uses the resilient limiter.

### Files
- `backend/app/core/security.py` (token factory + `revoke_jti`, `is_jti_revoked`)
- `backend/app/core/config.py` (secret check, `RATE_LIMIT_FAIL_CLOSED`)
- `backend/app/models/refresh_token.py` (new) or column on `Seller`
- `backend/app/api/v1/auth.py` (login returns access+refresh; `/auth/refresh`; `/auth/logout`)
- `backend/app/core/middleware.py` (rate limiter resilience)
- `backend/app/services/redis_client.py` (revocation set helpers)

### Requirements
- **R1.1 Refresh flow:** System SHALL issue an access token (short-lived) + refresh token (long-lived) on login.
  - *Scenario:* WHEN seller logs in, THEN response includes `access_token` + `refresh_token`; `POST /auth/refresh` with valid refresh returns new access token.
- **R1.2 Revocation:** System SHALL reject a token whose `jti` is in the revocation set.
  - *Scenario:* WHEN `/auth/logout` is called, THEN that refresh token's `jti` is added to revocation set; reuse returns 401.
- **R1.3 Secret guard:** System SHALL refuse to start in production with the default `SECRET_KEY`.
  - *Scenario:* WHEN `APP_ENV=production` and `SECRET_KEY` equals the dev default, THEN `uvicorn` exits with a clear error before serving.
- **R1.4 Rate-limit resilience:** Limiter SHALL use Redis when available; on outage use in-process limit and log a warning; if `RATE_LIMIT_FAIL_CLOSED=true`, deny when state unknown.
  - *Scenario:* WHEN Redis is down, THEN login still limits per-process and a warning is logged (no silent unlimited).

### Risks
- Refresh token storage = PII-adjacent; encrypt at rest or keep `jti`-only with short TTL.
- Clock skew between hosts can reject `iat`/`exp` → allow small leeway (±30s).
- Revocation set growth in Redis → expire entries with refresh TTL.

---

## Phase 2 — Multi-Tenant Isolation & Super-Admin Impersonation  *(P1, your #7 + deep-dive findings 1,3)* — **✅ COMPLETE**

### Goal
Add defense-in-depth tenant isolation (request-scoped context + optional RLS) and super-admin support tooling (impersonation + audit).

### Scope
- Request-scoped `app.current_seller_id` contextvar set in `get_current_seller`.
- Optional PostgreSQL **RLS** policies on `shop`/`product`/`order` keyed to `current_setting('app.current_seller_id')`.
- Super-admin **impersonation** endpoint returning short-lived token with `impersonated_by`.
- Audit log for super-admin mutations (create client, override plan) into existing `audit_logs`.

### Files
- `backend/app/api/v1/dependencies.py` (set contextvar)
- `backend/app/core/context.py` (new contextvar + getter/setter)
- `backend/app/core/database.py` (set `app.current_seller_id` per request via event listener)
- `backend/alembic/versions/*_rls_policies.py` (new migration, optional)
- `backend/app/api/v1/admin.py` (`/admin/sellers/{id}/impersonate`, audit logging)
- `backend/app/models/audit_log.py` (confirm exists; extend if needed)

### Requirements
- **R2.1 Tenant context:** System SHALL expose current `seller_id` via contextvar for the request lifetime.
  - *Scenario:* WHEN any request runs, THEN `get_current_seller_id()` returns the authenticated seller; `None` for anonymous.
- **R2.2 RLS (optional):** WHEN enabled (`TENANT_RLS=true`), THEN DB enforces row isolation even if app query forgets the filter.
  - *Scenario:* WHEN a seller queries orders without `seller_id` filter, THEN RLS returns only their rows.
- **R2.3 Impersonation:** Super-admin SHALL obtain a short-lived token acting as a client.
  - *Scenario:* WHEN super-admin calls `/admin/sellers/{id}/impersonate`, THEN a token with `impersonated_by=<admin>` is returned; client dashboard loads as that seller; audit log records the action.
- **R2.4 Audit:** Super-admin create-client and plan-override SHALL write an audit entry (actor, target, action, timestamp).

### Risks
- RLS + `get_db` context must be set **before** first query; use SQLAlchemy `do_connect`/`begin` event.
- Impersonation token must expire fast (e.g., 15 min) and be clearly marked in UI.
- RLS can break admin/report queries that legitimately cross tenants → exclude super-admin via `bypassrls` role or policy exception.

---

## Phase 3 — Rate Limiting Resilience & Alerting  *(P1, finding 7)* — **✅ COMPLETE**

*(Overlaps R1.4; implement together with Phase 1.)* Covered by R1.4. No separate code beyond Phase 1; add a **metric/alert** hook: when Redis fallback active, increment `ratelimit_redis_down` counter (see Phase 5 metrics). `services/metrics.py` ships a process-local Prometheus-shaped registry with `render_prometheus()`, and `RateLimitMiddleware.dispatch()` increments `ratelimit_redis_down_total` whenever `is_redis_available()` returns False at dispatch time. Tests in `tests/test_phase3_rate_limit_metrics.py` cover the fallback hold + counter increment and the burst/429 + metric-exposure paths.

---

## Phase 4 — CI/CD Pipeline & Contract Tests  *(P1, your #4)* — **🟡 CODE COMPLETE; CI RUN PENDING**

### Goal
Automate tests on every PR; prevent schema regressions; make E2E reproducible.

### Scope
- GitHub Actions: `backend-test` (Python 3.12, pytest, Postgres+Redis services), `frontend-test` (Node, build, Playwright), `contract-test` (schemathesis on OpenAPI).
- Wire `scripts/reset_db.py` as Playwright `globalSetup`.
- Fail build on OpenAPI breaking changes.

### Files
- `.github/workflows/ci.yml` (new)
- `frontend/playwright.config.ts` (already has globalSetup — confirm)
- `backend/pyproject.toml` (add `schemathesis` to dev deps)
- `backend/tests/contract/conftest.py` (schemathesis harness if not present)

### Requirements
- **R4.1 Backend CI:** WHEN PR pushed, THEN pytest runs against ephemeral Postgres+Redis; 62+ tests pass.
- **R4.2 Frontend CI:** WHEN PR pushed, THEN `npm ci && npm run build` and `npx playwright test` pass with fresh DB via `reset_db`.
- **R4.3 Contract test:** WHEN schema changes, THEN schemathesis validates `/openapi.json` against tests; breaking change fails CI.

### Risks
- Playwright browsers need `--with-deps` (Linux CI) → cache them.
- DB service in CI uses different creds than local → use `docker-compose` overrides or env in workflow.

---

## Phase 5 — Observability: Request-ID, Metrics, Scheduler Visibility  *(P2, your #5 + findings 10,11,12,13)* — **✅ CODE COMPLETE; TEST RUN SANDBOX-BLOCKED**

### Goal
Make the system operable: trace every request, graph key metrics, know scheduler health.

### Scope
- `X-Request-ID` middleware; log filter appends it.
- Prometheus `/metrics` (DB pool, Redis hits/misses, active subs by plan, subdomain/custom-domain counts, rate-limit fallback gauge).
- Persist scheduler last-run + result in a `scheduler_runs` table; surface in `/health`.
- Replace direct `SessionLocal()` in middleware with `Depends(get_db)`-style pattern (or a shared `request_session` dependency).

### Files
- `backend/app/core/middleware.py` (request-id)
- `backend/app/core/log.py` (request-id filter)
- `backend/app/main.py` (`/metrics`, `/health` scheduler block; middleware session refactor)
- `backend/app/services/metrics.py` (new)
- `backend/app/models/scheduler_run.py` (new)
- `backend/app/services/subscription_tasks.py` (write run record)

### Requirements
- **R5.1 Request-ID:** Every response SHALL include `X-Request-ID`; logs for that request include it.
  - *Scenario:* WHEN a request hits any endpoint, THEN response header has a UUID and the server log line carries it.
- **R5.2 Metrics:** `/metrics` SHALL expose Prometheus counters/gauges for the key signals above.
  - *Scenario:* WHEN scraper hits `/metrics`, THEN it returns `shopibd_subdomains_total`, `shopibd_redis_down_total`, etc.
- **R5.3 Scheduler health:** `/health` SHALL report last scheduler run time + status.
  - *Scenario:* WHEN scheduler ran 2 min ago successfully, THEN `/health` shows `"scheduler": {"last_run":"...","status":"ok"}`.

### Risks
- Metrics endpoint must be protected (internal network / auth) to avoid info leak.
- Request-ID in logs increases volume → sample or cap.

---

## Phase 6 — Subscription Downgrade: Events, Grace Period, Notifications  *(P2, your #3)* — **✅ COMPLETE**

### Goal
Turn the silent middleware downgrade into a transparent, recoverable flow.

### Scope
- On plan downgrade (Enterprise→Business), emit `subscription.downgraded` event (Redis pub/sub or DB outbox).
- 7-day grace period where `custom_domain` still routes (warning banner in admin).
- Notify client + super-admin (email/SMS via existing `notification` service).

### Files
- `backend/app/services/subscription_tasks.py` (detect downgrade, emit event)
- `backend/app/services/events.py` (new pub/sub or outbox)
- `backend/app/services/notification.py` (downgrade templates)
- `backend/app/api/v1/subscription.py` (grace-period flag on shop/custom_domain)
- `frontend/src/app/admin/clients/[id]/page.tsx` (warning banner)

### Requirements
- **R6.1 Event:** System SHALL emit `subscription.downgraded` with lost capabilities.
  - *Scenario:* WHEN a sub moves Enterprise→Business, THEN event published; client + admin notified.
- **R6.2 Grace:** For 7 days post-downgrade, `custom_domain` SHALL still route with a warning.
  - *Scenario:* WHEN within grace and domain visited, THEN storefront loads and admin sees "Custom domain expires in N days".
- **R6.3 Recovery:** IF client upgrades back within grace, THEN no data loss; domain stays active.

### Risks
- Event consumers must be idempotent (scheduler may double-run).
- Notifications need unsubscribe/rate-limit to avoid spam.

---

## Phase 7 — Custom Domain SSL Provisioning  *(P2, your #2)* — **✅ COMPLETE**

### Goal
Make Enterprise custom domains production-usable over HTTPS.

### Scope
- Implement `provision_ssl()` via ACME (certbot) or reverse proxy (Caddy/Traefik) automation.
- Cert expiry check + auto-renew 30 days before.
- Store certs in volume/Redis; surface status in admin.

### Files
- `backend/app/services/domain_verifier.py` (`provision_ssl` real impl)
- `docker-compose.yml` / `docker-compose.dev.yml` (add Caddy/Traefik or certbot sidecar)
- `backend/app/api/v1/whitelabel.py` (trigger provision on verified domain)
- `backend/app/models/shop.py` (ssl_status, ssl_expires_at)

### Requirements
- **R7.1 Provision:** WHEN a custom domain passes DNS verification, THEN system provisions a cert and serves HTTPS.
  - *Scenario:* WHEN `clientb.com` verified, THEN cert issued; `https://clientb.com` loads storefront.
- **R7.2 Renewal:** System SHALL auto-renew certs < 30 days from expiry and alert on failure.
  - *Scenario:* WHEN cert < 30 days, THEN renewal job runs; `/health` shows SSL status.

### Risks
- ACME rate limits (Let's Encrypt: 50 certs/domain/week) → use staging first.
- Wildcard certs need DNS-01 challenge + provider API keys.

---

## Phase 8 — Role Model Cleanup  *(P3, finding 6)* — **✅ COMPLETE**

### Goal
Separate "verified seller" from "admin" to prevent privilege confusion.

### Scope
- Add explicit `role` enum or `is_staff` flag; `get_current_admin_seller` uses `is_staff` not `is_verified`.
- Backfill existing admins.

### Files
- `backend/app/models/seller.py` (role/is_staff)
- `backend/app/api/v1/dependencies.py` (admin gate)
- `backend/scripts/backfill_roles.py` (new)

### Requirements
- **R8.1 Clear admin gate:** `get_current_admin_seller` SHALL require `is_staff`, not `is_verified`.
  - *Scenario:* WHEN a verified non-staff seller calls admin route, THEN 403 (not 200).
- **R8.2 Backfill:** Script SHALL mark existing `is_super_admin` sellers as staff.

### Risks
- Changing admin semantics may break seed/super-admin login → update seed constants.

---

## Phase 9 — SQLAdmin Hardening & Subdomain Availability UX  *(P3, findings 2,4,9)* — **✅ COMPLETE**

### Goal
Harden DB tooling and improve signup UX.

### Scope
- Centralize SQLAdmin creds in `config.py` (single source); rotate; add session timeout; consider CSRF for any form posts.
- Add `GET /api/v1/shops/subdomain-available?subdomain=x` endpoint.
- Frontend signup shows availability + suggestions.

### Files
- `backend/app/main.py` (use config creds)
- `backend/app/core/config.py` (admin creds)
- `backend/app/api/v1/shops.py` (availability endpoint)
- `frontend/src/app/admin/clients/new/page.tsx` (availability check)

### Requirements
- **R9.1 Centralized creds:** SQLAdmin SHALL read credentials from `config`, not hardcoded literals.
- **R9.2 Availability:** `GET /shops/subdomain-available` SHALL return `{available: bool, suggestions: [...]}`.
  - *Scenario:* WHEN `client-a` taken, THEN returns `available:false, suggestions:["client-a-bd","client-a1"]`.

### Risks
- Subdomain suggestions must still pass `reserve_subdomain` collision logic.

---

## Phase 10 — Payments, Courier & Abandoned Cart  *(P2, your #4)* — **✅ COMPLETE**

### Goal
Complete the commerce loop: tested providers, automated shipping, recovered carts.

### Scope
- Sandbox integration tests for bKash/Nagad/SSLCommerz (test creds).
- `services/courier/steadfast.py`: `create_shipment`, `track_shipment`, webhook.
- Abandoned-cart job: find carts > 1h with items → notify → track.

### Files
- `backend/app/services/payment/*` (sandbox tests)
- `backend/app/services/courier/steadfast.py` (new)
- `backend/app/api/v1/courier.py` (new)
- `backend/app/services/abandoned_cart.py` (new)
- `backend/app/services/subscription_tasks.py` or new scheduler hook

### Requirements
- **R10.1 Provider tests:** Each payment provider SHALL have a sandbox smoke test.
- **R10.2 Courier:** System SHALL create + track Steadfast shipments and accept status webhooks.
- **R10.3 Abandoned cart:** System SHALL notify users with abandoned carts and measure recovery.

### Risks
- Provider test creds expire/rate-limit → mark tests as integration, skip in unit CI.
- Webhook signature verification required to avoid spoofed status.

---

## Cross-Phase Notes
- **Phase 1 + 3** share rate-limit work — do together.
- **Phase 2** depends on **Phase 1** auth model being settled.
- **Phase 5** metrics endpoint should be wired before **Phase 6/7** so their health signals are visible.
- **Phase 0** should be done first so every later phase runs in the same containerized dev environment.
- Bengali i18n deliberately **excluded** from this spec.
