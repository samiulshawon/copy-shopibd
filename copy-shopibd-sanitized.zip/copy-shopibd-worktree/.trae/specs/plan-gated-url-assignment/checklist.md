# Checklist

- [x] Plan capability matrix correct: Free/Starter/Business → `allow_subdomain=True`, `allow_custom_domain=False`; Enterprise → both `True` (derived from `features`).
- [x] `plan_capabilities.py` exists and is the single enforcement point used by admin, whitelabel, and middleware.
- [x] `POST /admin/sellers` creates a `Shop` for the new client.
- [x] Free-tier client auto-provisions a subdomain (e.g. `client-a.shopibd.com`), not a path URL.
- [x] Subdomain auto-provision handles collisions with numeric suffix and never fails on unique constraint.
- [x] Enterprise client may supply `custom_domain` at creation; non-permitted tiers are rejected with `402`.
- [x] `/whitelabel/subdomain` and `/whitelabel/custom-domain` reject non-permitted plans with `402`.
- [x] Already-verified domains are grandfathered (not retroactively revoked on new claims or downgrade).
- [x] `custom_domain_middleware` skips custom-domain routing when the plan no longer allows it (downgrade handled at the edge).
- [x] Frontend client-creation form shows live URL preview tied to selected plan; custom-domain field shown only for Enterprise.
- [x] `superAdminApi.createSeller` sends the new fields.
- [x] All backend tests pass (`pytest tests/ --ignore=tests/contract`), including new gating/collision/downgrade tests (62 passing).
- [x] No code path can assign a subdomain or custom domain without a capability check.
