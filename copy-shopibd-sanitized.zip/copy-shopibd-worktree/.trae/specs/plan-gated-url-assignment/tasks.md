# Tasks

- [ ] Task 1: Add plan capability helpers (single enforcement point)
  - [ ] SubTask 1.1: Create `backend/app/services/plan_capabilities.py` with `can_use_subdomain(plan)` and `can_use_custom_domain(plan)` derived from `PLANS[plan].features`.
  - [ ] SubTask 1.2: Add `allow_subdomain` / `allow_custom_domain` properties to `PlanInfo` in `backend/app/schemas/subscription.py` (derived from `features` to avoid drift).
  - [ ] SubTask 1.3: Unit-test the capability matrix (Free/Starter/Business → subdomain only; Enterprise → both).

- [ ] Task 2: Extend client creation to provision Shop + subdomain
  - [ ] SubTask 2.1: Extend `SellerCreate` in `backend/app/schemas/seller.py` with `shop_name?` and `subdomain?` (optional).
  - [ ] SubTask 2.2: Add `reserve_subdomain(db, base)` helper (slugify + unique-suffix retry) in `plan_capabilities.py` (or a small `slug.py`).
  - [ ] SubTask 2.3: Modify `POST /admin/sellers` in `backend/app/api/v1/admin.py` to create `Shop` + auto-provision `subdomain` when plan allows; accept `custom_domain` only when plan permits (else `402/403`).
  - [ ] SubTask 2.4: Tests — Free client auto-gets subdomain; collision suffix; Enterprise custom-domain accepted; non-permitted custom-domain rejected.

- [x] Task 3: Gate white-label endpoints by plan
  - [ ] SubTask 3.1: Modify `set_subdomain` and `set_custom_domain` in `backend/app/api/v1/whitelabel.py` to call `plan_capabilities` and reject non-permitted tiers with `402/403`.
  - [ ] SubTask 3.2: Tests — Free seller blocked from custom domain; Starter allowed subdomain; already-verified domain grandfathered on downgrade.

- [ ] Task 4: Edge-check downgrade in routing middleware
  - [ ] SubTask 4.1: Modify `custom_domain_middleware` in `backend/app/main.py` to skip `custom_domain` routing when `can_use_custom_domain(seller.plan)` is False (fall back to subdomain/path).
  - [ ] SubTask 4.2: Tests — enterprise→business lapse stops custom-domain resolution at the edge.

- [ ] Task 5: Frontend owner-console client form + URL preview
  - [ ] SubTask 5.1: Extend `superAdminApi.createSeller` in `frontend/src/lib/api.ts` to send `shop_name` / `subdomain` / `custom_domain`.
  - [ ] SubTask 5.2: Add live URL preview to the client-creation form (subdomain shown for Starter+ tiers; custom-domain field shown only for Enterprise) in `frontend/src/app/admin/clients/...`.

- [x] Task 6: Regression + full-suite verification
  - [ ] SubTask 6.1: Run `pytest tests/ --ignore=tests/contract` — all pass (target: 51 + new).
  - [ ] SubTask 6.2: Confirm no remaining unguarded `/whitelabel` or admin-create path that can assign a domain without capability check.

# Task Dependencies
- Task 1 must complete before Tasks 2, 3, 4 (they import the capability helpers).
- Task 2 SubTask 2.2 (`reserve_subdomain`) can be done in parallel with Task 1.
- Task 5 depends on Task 2 (payload shape) and Task 1 (capability matrix for preview).
- Task 6 depends on all prior tasks.
