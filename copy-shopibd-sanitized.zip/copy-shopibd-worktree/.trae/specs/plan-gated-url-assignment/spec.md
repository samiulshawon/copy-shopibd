# Plan-Gated URL Assignment Spec

## Why
Today the super-admin can create a client (seller) but no storefront URL is provisioned, and any seller can claim a subdomain or custom domain regardless of their paid plan. We need the client's storefront URL type (subdomain vs. own custom domain) to be decided by the super-admin at creation time and **enforced by the client's plan tier**, so pricing tiers translate into real URL entitlements.

## What Changes
- Add plan capability flags (`allow_subdomain`, `allow_custom_domain`) — **derived from the existing `features` list** (single source of truth, no drift).
- **Free tier gets a subdomain** `clientA.shopibd.com` (NOT the path URL `shopibd.com/shop/<slug>`). Starter/Business also get subdomains. Only **Enterprise** may claim a custom domain (`clientA.com`).
- `POST /admin/sellers` (super-admin) auto-creates a `Shop` and auto-provisions a unique `subdomain` when the plan allows; accepts an optional `custom_domain` only when the plan permits.
- `/whitelabel/subdomain` and `/whitelabel/custom-domain` are gated by plan capability; reject with `402/403` when not permitted (new claims only; already-verified domains are grandfathered).
- Centralize all capability checks in a new `plan_capabilities.py` helper used by admin, whitelabel, and routing.
- Handle plan **downgrade** (e.g. enterprise → business) via a **declarative edge-check in `custom_domain_middleware`**: if the seller's current plan no longer allows a custom domain, the custom domain stops resolving (fall back to subdomain/path). No scheduler mutation needed.
- Frontend owner-console client-creation form shows a **live URL preview** based on the selected plan.

## Impact
- Affected specs: multi-tenancy routing, subscription/plan enforcement, white-label, super-admin client management.
- Affected code:
  - `backend/app/schemas/subscription.py` (PlanInfo capabilities)
  - `backend/app/schemas/seller.py` (SellerCreate extensions)
  - `backend/app/api/v1/admin.py` (client creation + Shop + subdomain)
  - `backend/app/api/v1/whitelabel.py` (plan gating)
  - `backend/app/services/plan_capabilities.py` (NEW — single enforcement point)
  - `backend/app/services/subscription_tasks.py` (no change needed for downgrade — handled at edge)
  - `backend/app/main.py` (middleware edge-check for downgrade)
  - `frontend/src/.../client-form` (URL preview + conditional fields)
  - `frontend/src/lib/api.ts` (createSeller payload)
  - `backend/tests/` (gating, auto-provision collision, downgrade edge-check)

## ADDED Requirements
### Requirement: Plan capability contract
The system SHALL expose `allow_subdomain` and `allow_custom_domain` for each plan, derived from the plan's `features` list.

#### Scenario: Capability matrix
- **WHEN** the plan catalog is loaded
- **THEN** Free/Starter/Business have `allow_subdomain=True`, `allow_custom_domain=False`; Enterprise has both `True`.

### Requirement: Super-admin provisions client URL at creation
The system SHALL, on `POST /admin/sellers`, create a `Shop` and auto-provision a unique `subdomain` (e.g. `client-a.shopibd.com`) when the selected plan allows subdomains; and accept an optional `custom_domain` only when the plan allows it.

#### Scenario: Free client gets subdomain
- **WHEN** super-admin creates "Client A" on the Free plan
- **THEN** a Shop is created and `subdomain="client-a"` is reserved, resolving at `client-a.shopibd.com`.

#### Scenario: Enterprise client may get custom domain
- **WHEN** super-admin creates "Client A" on Enterprise and supplies `custom_domain="clienta.com"`
- **THEN** the Shop is created with `custom_domain="clienta.com"` (unverified until DNS proves).

#### Scenario: Subdomain collision
- **WHEN** a generated subdomain already exists
- **THEN** the system appends a numeric suffix (`client-a-2`) and retries until unique; no unique-constraint failure escapes.

### Requirement: White-label endpoints enforce plan
The system SHALL reject `/whitelabel/subdomain` and `/whitelabel/custom-domain` with `402/403` when the seller's current plan lacks the capability. Existing verified domains are grandfathered (not retroactively revoked).

#### Scenario: Free seller cannot claim custom domain
- **WHEN** a Free-tier seller calls `/whitelabel/custom-domain` with `clienta.com`
- **THEN** the system returns `402/403` and does not store the domain.

### Requirement: Downgrade revokes custom-domain resolution at the edge
The system SHALL, in `custom_domain_middleware`, skip routing to a shop's `custom_domain` when the seller's current plan no longer allows custom domains, falling back to subdomain/path. No background mutation required.

#### Scenario: Enterprise lapses to Business
- **WHEN** a shop's `custom_domain` is set but the seller's plan is now Business
- **THEN** requests to `clienta.com` no longer route to the shop (fall back behavior); the `custom_domain` record is retained but inactive.

## MODIFIED Requirements
### Requirement: Storefront routing
The `custom_domain_middleware` SHALL resolve `subdomain` and `custom_domain` as before, but a `custom_domain` match is only honored when `plan_capabilities.can_use_custom_domain(seller.plan)` is True; otherwise the middleware falls through to subdomain/path resolution.

## REMOVED Requirements
### Requirement: Manual-only domain assignment without plan check
**Reason**: Allowed any tier to claim any URL, breaking the pricing model.
**Migration**: Existing verified domains remain valid (grandfathered); only new claims and downgrade resolution are gated.
