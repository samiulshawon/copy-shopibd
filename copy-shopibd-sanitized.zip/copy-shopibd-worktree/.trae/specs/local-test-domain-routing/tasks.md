# Tasks

- [ ] Task 1: Add local-mode settings
  - [ ] SubTask 1.1: In `backend/app/core/config.py`, clarify `DOMAIN` semantics and add `LOCAL_DOMAIN_MODE: bool = False` (auto-True when `DOMAIN` is `localhost`/`127.0.0.1`).
  - [ ] SubTask 1.2: Document go-live DNS/SSL steps as comments.

- [ ] Task 2: Preview-URL resolver helper
  - [ ] SubTask 2.1: Create `backend/app/services/shop_url.py` with `shop_preview_url(shop, base_url=None)` returning host-based URL in production mode, path-based `/shop/<subdomain>` in local mode.
  - [ ] SubTask 2.2: Unit-test resolver for both modes (production vs local).

- [ ] Task 3: Middleware path resolution for local mode
  - [ ] SubTask 3.1: In `backend/app/main.py`, ensure `/shop/<key>` resolves a shop by **subdomain first, then slug** so local previews render correctly.
  - [ ] SubTask 3.2: Test — `GET /shop/client-a` returns the shop storefront in local mode.

- [ ] Task 4: Frontend uses resolver
  - [ ] SubTask 4.1: Add a client helper in `frontend/src/lib/api.ts` (or a `shopUrl` util) that builds the preview URL from `subdomain`/`custom_domain` + current mode (read from a `/config` or env-exposed value).
  - [ ] SubTask 4.2: Update owner-console "Visit store" and storefront links to use the helper.

- [x] Task 5: Verification
  - [ ] SubTask 5.1: Run `pytest tests/ --ignore=tests/contract` — all pass.
  - [ ] SubTask 5.2: Manually confirm `http://localhost:3001/shop/client-a` opens a seeded shop in local mode (no domain needed).

# Task Dependencies
- Task 1 before Task 2 (resolver reads mode from settings).
- Task 3 can run in parallel with Task 2.
- Task 4 depends on Task 2 (resolver shape).
- Task 5 depends on all.
