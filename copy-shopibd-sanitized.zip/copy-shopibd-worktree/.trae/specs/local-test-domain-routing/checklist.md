# Checklist

- [x] `LOCAL_DOMAIN_MODE` added to settings; auto-True for localhost/127.0.0.1; `DOMAIN` semantics documented with go-live DNS/SSL steps.
- [x] `shop_preview_url()` returns host-based URL in production mode and path-based `/shop/<subdomain>` in local mode.
- [x] Resolver unit-tested for both modes.
- [x] `/shop/<key>` resolves by subdomain first, then slug, in local mode.
- [x] Path-based storefront renders the correct shop in local mode without any purchased domain.
- [x] Frontend "Visit store" link uses the relative `/shop/<subdomain>` path (client detail page); storefront links use the resolver pattern.
- [x] Going live requires configuration only (set `DOMAIN`, point DNS, enable SSL) — no routing-code change.
- [x] All backend tests pass including new resolver/middleware tests (62 passing).
