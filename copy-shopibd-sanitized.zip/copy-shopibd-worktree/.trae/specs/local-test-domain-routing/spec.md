# Local-Test & Live Domain Routing Spec

## Why
The platform assigns each client a `subdomain` (e.g. `client-a.shopibd.com`) or, on Enterprise, a `custom_domain` (e.g. `clienta.com`). The owner currently has **no domain purchased** and no DNS control, so real subdomain/custom-domain hostnames cannot resolve during local development, testing, or demos. We need (a) a working **local-test alternative** that resolves shop URLs without owning a domain, and (b) a clean **path to go live** under a real domain later — without code changes to the routing logic.

## What Changes
- Add a **local-test routing mode** controlled by `settings.DOMAIN` + a new `settings.LOCAL_DOMAIN_MODE` (or simply `DOMAIN=localhost` / a dev base). In this mode shop URLs are reachable via **path-based preview** that encodes the subdomain, e.g. `http://localhost:3001/shop/client-a` (and an API/CLI helper to resolve a subdomain → preview URL). This mirrors the always-available `/shop/<slug>` but is keyed by **subdomain** so it works identically to the live subdomain.
- Keep the **host-header routing** (subdomain + custom domain) fully intact for production. No removal — the middleware already falls back correctly when Host is `localhost`/base domain.
- Add a **preview URL resolver** helper `shop_preview_url(subdomain, custom_domain, base)` that returns the correct URL for the current mode: host-based when `DOMAIN` is a real domain, path-based when in local mode.
- Document (in-code constants / settings comments) the **go-live steps**: set `DOMAIN=shopibd.com` (or the purchased apex), point DNS (CNAME `*.shopibd.com` → platform, and client A/AAAA or CNAME for custom domains), enable SSL — no code change required.
- The frontend storefront link and super-admin "visit store" action use the resolver so the same UI works in both modes.

## Impact
- Affected code:
  - `backend/app/core/config.py` (add `LOCAL_DOMAIN_MODE` / clarify `DOMAIN` semantics)
  - `backend/app/services/domain_verifier.py` or new `backend/app/services/shop_url.py` (preview URL resolver)
  - `backend/app/main.py` (middleware already handles localhost fallback; minor: ensure path `/shop/<subdomain>` resolves in local mode)
  - `frontend/src/lib/api.ts` and storefront/owner "visit store" links (use resolver)
- No changes to `plan-gated-url-assignment` logic; this spec is complementary (how URLs are *reached* in each environment).

## ADDED Requirements
### Requirement: Local-test shop URL resolution
The system SHALL, when running without a purchased domain (`LOCAL_DOMAIN_MODE=True` or `DOMAIN` is `localhost`/`127.0.0.1`), expose each shop via a **path-based preview URL** keyed by subdomain, so it can be opened in a browser without DNS.

#### Scenario: Open a client store locally
- **WHEN** the storefront for subdomain `client-a` is opened in local mode
- **THEN** it is reachable at `http://localhost:3001/shop/client-a` (or the dev frontend port), rendering the same shop as `client-a.shopibd.com` would in production.

### Requirement: Unified preview-URL resolver
The system SHALL provide `shop_preview_url(shop)` that returns a host-based URL (`https://client-a.shopibd.com` or `https://clienta.com`) when a real domain is configured, and a path-based URL when in local mode.

#### Scenario: Resolver in production mode
- **WHEN** `DOMAIN=shopibd.com` and shop has `subdomain="client-a"`
- **THEN** resolver returns `https://client-a.shopibd.com`.

#### Scenario: Resolver in local mode
- **WHEN** `LOCAL_DOMAIN_MODE=True` and shop has `subdomain="client-a"`
- **THEN** resolver returns `http://localhost:3001/shop/client-a`.

### Requirement: Go-live path without code change
The system SHALL support going live under a purchased domain by **configuration only**: set `DOMAIN` to the apex, configure DNS (wildcard CNAME for subdomains + client CNAME/A for custom domains), and enable SSL. No routing-code modification required.

#### Scenario: Flip to production
- **WHEN** operator sets `DOMAIN=shopibd.com` and points DNS
- **THEN** the same `subdomain`/`custom_domain` values now resolve via host headers with zero code changes.

## MODIFIED Requirements
### Requirement: Storefront routing fallback
`custom_domain_middleware` SHALL continue to skip host rewriting when Host is the base domain or localhost, and the path `/shop/<key>` SHALL resolve a shop by **subdomain first, then slug** so local-mode previews work.

## REMOVED Requirements
### Requirement: (none)
No capabilities removed; host-based routing is preserved for production.
