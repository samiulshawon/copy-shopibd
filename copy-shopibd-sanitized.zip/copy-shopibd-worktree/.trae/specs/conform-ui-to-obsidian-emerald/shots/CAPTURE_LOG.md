# Live Browser Captures — 2nd verification session (2026-07-19)

These PNGs were captured by the **Puppeteer MCP** (system Chrome, headless) during the
live stack run. The MCP returned each capture as an inline PNG attachment in the
verification session; it does NOT accept a `path` save argument — files saved are kept
in the MCP server's own working directory. To persist captures on disk for this repo,
re-run inside a wrapper that writes `evaluate(() => document.querySelector('…')
.outerHTML)` or pipes the MCP image bytes to PowerShell `Out-File`.

## Captures (in order)

| # | Page | URL | What was observed |
|---|------|-----|-------------------|
| 01 | Marketing home | `/` | Dark hero with trust badge ("Trusted by Bangladeshi SMEs"), "Sell online, the Bangladeshi way" headline in mint, "Create your own online store in minutes. Accept bKash, Nagad, COD, and cards. Built for Bangladesh — no technical skills needed." subheading, mint "Get Started — Free" pill CTA + dark "View Pricing" pill CTA. Obsidian Emerald theme confirmed. |
| 02 | Dashboard (intended) | `/dashboard` | **actually rendered the login page** — ShopiBD logo + "Welcome back. Sign in to your store." + Email/Password form on dark `bg-surface-1` card with outline-variant border + mint "Login" pill. The Puppeteer session did not carry the auth cookie set by the prior `fill`+`click` into a fresh `navigate`. (See Session notes in `tasks.md` — the login page itself confirms dark + mint + surface conformance.) |
| 03 | Orders (intended) | `/dashboard/orders` | same login page (redirect because no auth cookie carried) |
| 04 | Products (intended) | `/dashboard/products` | same login page (redirect because no auth cookie carried) |
| 05 | Storefront | `/sawan-shop` | TonalCard outline hero (visible rounded-corner tonal card with bKash/Nagad/COD pills area, lime-green bag icon in bottom-right) — seeded shop renders its dark shell |
| 06 | Checkout | `/sawan-shop/order?product_id=1` | dark TonalCard shell with the order-form outline, awaiting product/cart data fetch |

## Useful observations across the captures

- The **dark Obsidian surface ramp** + grain overlay + emerald radial-glow are visible on every captured page that loaded successfully.
- The **mint primary button styling** matches `bg-primary` + `shadow-glow` on the marketing hero
  CTA and the login "Login" pill.
- The **storefront TonalCard** outlines (05, 06) prove the `bg-surface-1` + `border-outline-variant`
  + `rounded-2xl`-normalized radius layout is being applied to public route templates.
- The login form (02–04) confirms the **TonalCard-style auth surface** (dark `bg-surface-1`
  card, `outline-variant` border, mint primary button, emerald focus border).

## What still needs a proper browser session

- A single Puppeteer/page session (not separate `navigate` calls) filling credentials, submitting, and then `page.waitForNavigation('/dashboard')` — so the cookie is carried into subsequent paths. That will confirm the live count-up MetricCard, path-draw chart, hover emerald glow, method-card border animation, and the success-vs-primary badge distinction.
- Pixel diff vs `demodesign/*/screen.png` (left to in-person inspection of these captures).
