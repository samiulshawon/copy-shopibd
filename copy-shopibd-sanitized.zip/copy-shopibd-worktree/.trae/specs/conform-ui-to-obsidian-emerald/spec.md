# Conform UI to Obsidian Emerald (Dark) + Premium Polish Spec

## Why
The ShopiBD frontend needs a single, consistent dark design system before go-live. The codebase is already dark-mode-only with green tokens that match the "Obsidian Emerald" system used by three of the five `demodesign/` demos, but pages have drifted (heavy shadows, oversized radii, scattered blue/white/black, success-vs-primary collision) and the UI is static (no `@keyframes`, no ambient depth, no animated data-viz). A conformance + premium-polish pass will make every user-visible page feel like one cohesive, premium product.

## What Changes
- Adopt **Obsidian Emerald (dark)** as the sole design system across all user-visible pages; the two light demos (`payment`, `storefront`) are used only as **layout references** and are skinned dark.
- Add the exact Obsidian surface ramp (`#0e0e0e`/`#1c1b1b`/`#201f1f`/`#2a2a2a`/`#353534`), outline tokens (`#88938d`/`#3f4944`), and change `--success` to deep emerald `#006a4e` (distinct from the mint `#83d7b4` primary).
- Normalize the radius scale (`sm`/`DEFAULT`/`md`/`lg`/`xl`) and map all `rounded-2xl`/`rounded-3xl` to `rounded-xl`; replace heavy `shadow-*` on cards/dialogs with tonal layering (`bg-surface-*` + 1px `border-outline-variant`), keeping the green `shadow-glow` on primary buttons as a sanctioned brand moment.
- Remove hardcoded `blue-*`/`indigo-*`/`sky-*`/`cyan-*` drift from non-branding surfaces (branding/preview surfaces that render seller-chosen colors are exempt and left intact).
- Add a **CSS-only motion system** (`@keyframes`: `fade-up`, `fade-in`, `shimmer`, `count-up`, `draw-path`, `slide-in-right`, `glow-pulse`) gated by the existing global `prefers-reduced-motion` reset — zero new dependencies.
- Add **ambient depth** layers: a fixed pointer-events-none SVG grain overlay (~3% opacity) to kill banding, and a soft emerald radial-glow (~8% opacity, blurred) behind dashboard + storefront heroes.
- Add **premium data-viz + metric polish**: animated count-up on `MetricCard` values, SVG `stroke-dashoffset` draw-in on `sales-chart.tsx`, staggered fade-up on card grids, shimmer sweep on `skeleton.tsx`, slide-in + emerald auto-dismiss progress bar on `toast.tsx`.
- Bring the 5 demo target page groups into layout parity with `demodesign/*/code.html` (dark skin): `dashboard`, `order`, `products`, `payment`(checkout), `storefront`.
- Apply conformance + light polish to all remaining dashboard, admin, auth, marketing, and storefront pages.

**No `BREAKING` backend or API changes.** This is a frontend-only visual conformance + polish pass.

## Impact
- Affected specs: none (this is a pre-launch UI pass, not an `enhancement-roadmap-2026` phase).
- Affected code (frontend, all read-verified during exploration):
  - Tokens/primitives: `frontend/src/app/globals.css`, `frontend/tailwind.config.ts`, `frontend/src/components/ui/*` (button, card, input, dialog, dropdown-menu, alert, badge, table, tabs, select, toast, avatar, skeleton), `frontend/src/components/layout/page-structure.tsx` (`MetricCard`).
  - Layout shells: `frontend/src/app/layout.tsx`, `frontend/src/app/providers.tsx`, `frontend/src/components/layout/{dashboard-shell,super-admin-shell,sidebar,header,footer}.tsx`.
  - Dashboard demo pages: `app/dashboard/page.tsx` (+ `page-client.tsx`), `components/dashboard/{stats-cards,sales-chart,top-products}.tsx`; `app/dashboard/orders/{page,[id]/page-client}.tsx`; `app/dashboard/products/{page,[id],new/page}.tsx`, `components/dashboard/product-form.tsx`.
  - Storefront/checkout demo pages: `app/[slug]/order/page.tsx`, `app/[slug]/page.tsx`, `components/storefront/{product-card,shop-header,storefront-footer,product-detail}.tsx`.
  - Remaining dashboard: `customers`, `payments`, `analytics`, `subscription/{success,cancel}`, `notifications`, `settings`, `branding`, `staff`, `coupons`, `abandoned` `page-client.tsx` files.
  - Admin: `app/admin/{page,clients/{page,new,[id]},reviews,activity,settings}.tsx`, `components/layout/super-admin-shell.tsx`.
  - Auth/marketing: `app/{page,pricing,auth/login,auth/register}/page.tsx`.
  - Storefront remaining: `app/[slug]/{products/[id],order/success,orders/track}/page.tsx`.

## ADDED Requirements

### Requirement: Single Dark Design System
The system SHALL render every user-visible page in the Obsidian Emerald dark design system (`#131313` background, mint `#83d7b4` primary, Plus Jakarta Sans). The light `payment`/`storefront` demos SHALL be treated as layout references only; their colors SHALL NOT be used.

#### Scenario: Any page renders dark
- **WHEN** a user opens any route (dashboard, admin, storefront, auth, marketing)
- **THEN** the page uses the dark token set (`color-scheme: dark`, `--background ≈ #131313`, `--primary ≈ #83d7b4`)
- **AND** no non-branding surface uses blue/indigo/sky/cyan, white cards, or black backgrounds outside the sanctioned surface ramp

### Requirement: Token & Primitive Conformance
The system SHALL define the exact Obsidian surface ramp, outline tokens, a distinct deep-emerald success color, and a single normalized radius scale in `globals.css`/`tailwind.config.ts`, and all UI primitives SHALL consume them with tonal layering instead of heavy shadows.

#### Scenario: Success is distinct from primary
- **WHEN** a success/active state is shown (e.g., a "paid" badge)
- **THEN** it uses the deep emerald `#006a4e` (15% opacity container) — not the mint primary `#83d7b4`

#### Scenario: Cards use tonal layering
- **WHEN** a Card, Dialog, or Popover is rendered
- **THEN** it uses a `--surface-*` background + 1px `--outline-variant` border
- **AND** does not apply `shadow-sm/md/lg/xl/2xl` or `drop-shadow` (only `shadow-glow` is permitted, on primary buttons)

### Requirement: CSS Motion System (Reduced-Motion Safe)
The system SHALL provide `@keyframes` animations (`fade-up`, `fade-in`, `shimmer`, `count-up`, `draw-path`, `slide-in-right`, `glow-pulse`) and SHALL collapse every animation to instant when the OS reports `prefers-reduced-motion: reduce`, with zero new runtime dependencies.

#### Scenario: Reduced-motion user
- **WHEN** the user's OS is set to reduce motion
- **THEN** all `@keyframes`-based animations render in their final state immediately
- **AND** no motion plays on mount, hover, or data-viz entrance

### Requirement: Ambient Depth
The system SHALL mount a fixed, pointer-events-none SVG grain overlay (~3% opacity) and a soft emerald radial-glow (~8% opacity, blurred) behind dashboard + storefront heroes to eliminate banding and add tactility.

#### Scenario: Dashboard hero
- **WHEN** the dashboard hero renders
- **THEN** a blurred emerald glow sits behind it and a subtle grain overlay sits above `#131313`
- **AND** neither layer intercepts pointer events

### Requirement: Premium Metrics & Data-Viz
`MetricCard` SHALL animate numeric values via count-up; `sales-chart.tsx` SHALL animate its SVG path via `stroke-dashoffset`; card grids SHALL stagger their fade-up entrance.

#### Scenario: Dashboard loads
- **WHEN** the dashboard mounts with stats
- **THEN** metric numbers count up from 0 to their value using `formatCurrency`
- **AND** the sales line draws in via stroke-dashoffset
- **AND** the metric cards fade-up with a staggered delay

### Requirement: Demo Layout Parity (5 Targets)
The 5 demo target page groups SHALL match the structure of their corresponding `demodesign/*/code.html`, rendered in the dark Obsidian Emerald theme.

#### Scenario: 5 pages match demos
- **WHEN** a user opens dashboard, orders (list + detail), products, checkout (`[slug]/order`), or storefront (`[slug]`)
- **THEN** the page structure matches the matching `demodesign/*/screen.png` (structure, not color, for the two light demos)
- **AND** the skin is dark Obsidian Emerald

### Requirement: Per-Area Conformance
All remaining pages (dashboard non-demo, admin, auth, marketing, storefront non-demo) SHALL conform to Obsidian Emerald (normalized radii, tonal layering, no blue drift, correct typography) and apply motion where it adds value.

#### Scenario: Admin pages conform
- **WHEN** a super-admin opens any `/admin/*` page
- **THEN** it uses the same Obsidian sidebar shell, tonal cards, and emerald active indicator as the dashboard
- **AND** contains no blue/white-card drift

## Out of Scope
- Bengali i18n translation work.
- Backend changes.
- Adding a light theme or any blue/Tech-Blue accent.
- New product features (only visual conformance + polish).
- Optional opt-in dependencies (`framer-motion`, `cmdk`, `vaul`, `sonner`) unless explicitly approved — default is zero new deps.
- New roadmap phase entries in `enhancement-roadmap-2026`.
