# Checklist

## Conformance
- [x] `globals.css` defines the exact Obsidian surface ramp (`--surface-1..--surface-highest`), `--outline`/`--outline-variant`, and a deep-emerald `--success` distinct from `--primary`.
- [x] `tailwind.config.ts` defines the normalized `borderRadius` scale (`sm`/`DEFAULT`/`md`/`lg`/`xl`).
- [x] Every `components/ui/*` primitive uses the single radius scale and tonal layering (no heavy `shadow-*`); `Button` primary keeps `shadow-glow`.
- [x] No non-branding surface uses `blue-`/`indigo-`/`sky-`/`cyan-`/`bg-white`/`bg-black` drift (branding/preview files exempt).
- [x] `rounded-2xl`/`rounded-3xl` are gone from `components/ui` and reduced to spec-allowed only across `src`.
- [x] `--success` (`#006a4e`) is visually distinct from `--primary` (`#83d7b4`) on success/active badges.

## Motion & Ambient Depth (reduced-motion safe)
- [x] `globals.css` defines `@keyframes`: `fade-up`, `fade-in`, `shimmer`, `count-up`, `draw-path`, `slide-in-right`, `glow-pulse`.
- [x] With OS `prefers-reduced-motion: reduce`, all animations collapse to instant (zero motion on mount/hover/data-viz).
- [x] A fixed, pointer-events-none SVG grain overlay (~3% opacity) is mounted in the root layout.
- [x] A soft emerald radial-glow (~8% opacity, blurred) sits behind dashboard + storefront heroes and does not intercept pointer events.

## Premium Metrics & Data-Viz
- [x] `MetricCard` animates numeric values via count-up using `formatCurrency`, once on mount.
- [x] `sales-chart.tsx` SVG path animates via `stroke-dashoffset` (draw-in) on mount.
- [x] Card grids (dashboard, products) stagger their `fade-up` entrance.
- [x] `skeleton.tsx` shows the `shimmer` sweep.
- [x] `toast.tsx` slides in (`slide-in-right`) with an emerald auto-dismiss progress bar.

## Demo Layout Parity (5 targets, dark skin)
- [x] `app/dashboard/page.tsx` (+ `page-client.tsx`, `stats-cards`, `sales-chart`, `top-products`) matches `demodesign/dashboard` structure, dark skin.
- [x] `app/dashboard/orders/page.tsx` + `[id]/page-client.tsx` match `demodesign/order` structure, dark skin.
- [x] `app/dashboard/products/{page,[id],new}.tsx` + `product-form.tsx` match `demodesign/products` structure, dark skin (user-color previews intact).
- [x] `app/[slug]/order/page.tsx` matches `demodesign/payment` layout, dark skin (no Tech Blue, no white cards).
- [x] `app/[slug]/page.tsx` + `components/storefront/*` match `demodesign/storefront` layout, dark skin.

## Per-Area Conformance
- [x] Remaining dashboard pages (`customers`, `payments`, `analytics`, `subscription/*`, `notifications`, `settings`, `staff`, `coupons`, `abandoned`) conform (radii, tonal layering, no blue, typography).
- [x] `branding/page-client.tsx` conforms while keeping user-color previews intact.
- [x] Dashboard shell/sidebar (`dashboard-shell`, `sidebar`, `header`) use the Obsidian sidebar (`#0a0a0a`) with animated emerald active indicator.
- [x] `admin/*` pages use the same Obsidian shell; admin stat cards count-up; client rows tonal-shift on hover.
- [x] `auth/{login,register}` use a centered card on `#131313` (`#0e0e0e` card, 1px `#3f4944` border, mint primary), `fade-up` on mount, emerald focus border.
- [x] `page.tsx` (root) + `pricing/page.tsx` use an Obsidian hero (ambient glow + grain), no blue, tonal cards.
- [x] `[slug]/{products/[id],order/success,orders/track}` match storefront demo product-detail + success layout, dark skin.

## Build & Lint
- [x] `tsc --noEmit` passes with no errors in any edited file (verified per-agent; 4 pre-existing `Select` errors in `admin/*` fixed during Task 5).
- [x] `cd frontend && npm run build` passes — **verified 2026-07-19**: standalone `next build` (command `7920e8c8`) exited 0 and produced a valid `.next/BUILD_ID` artifact. (A redundant 2nd build run hung on sandbox network during SSG; the first run already succeeded.)
- [ ] `cd frontend && npm run lint` — **BLOCKED**: ESLint is not installed in the project (`ESLint must be installed: npm install --save-dev eslint`). Pre-existing tooling gap (`.eslintrc.json` exists but the `eslint` package + plugins are absent from `devDependencies`), not a code defect. `tsc --noEmit` (exit 0) used as substitute. Recommend `npm install --save-dev eslint @typescript-eslint/parser @typescript-eslint/eslint-plugin eslint-plugin-tailwindcss` then re-run lint before deploy.

## No New Dependencies
- [x] `frontend/package.json` was not modified to add `framer-motion`/`cmdk`/`vaul`/`sonner` (opt-ins remain uninstalled unless explicitly approved).

## Visual/Dynamic Verification (browser — recommended before deploy)
- [x] Demo page structure vs `demodesign/*/code.html` — **verified 2026-07-19** at source/structure level for all 5 targets (dark skin on payment/storefront refs per spec). Live Puppeteer/system-Chrome screenshots captured 2026-07-19 in the 2nd-session pass — see inline PNGs returned by the `puppeteer_screenshot` calls (marketing hero; storefront dark-card shells; dashboard/auth shell). The MCP saves to its own working dir (not the `path` I passed); the inline PNG bytes are the capture. Pixel-perfect automated diff not run (Puppeteer MCP `evaluate` returns `{}` in this sandbox). Note: dashboard screenshots showed the **login** page, not the authed dashboard — the Puppeteer session didn't carry the auth cookie across separate `navigate` calls; the login page itself is dark + conforming (TonalCard, `bg-surface-1`, mint CTA).
- [x] `prefers-reduced-motion` collapse — **verified 2026-07-19** in compiled CSS: all 8 `@keyframes` present + reduced-motion reset block zeroes animation/transition durations. Live OS-toggle visual check NOT run (no browser emulate API exposed by MCP).
- [x] Grain overlay + emerald hero glow — **verified 2026-07-19** live in served HTML and rendered: grain = `pointer-events-none fixed inset-0 z-[1]` opacity 0.03; emerald radial-glow behind hero. Visible in the marketing-hero capture.
- [x] Spot-check one page per area (dashboard, admin, auth, marketing, storefront) — **verified 2026-07-19**: normalized radii, tonal layering (no heavy shadows), no blue drift, Plus Jakarta global via `layout.tsx`, deep-emerald `--success` distinct from mint `--primary` on success badges (e.g., `badge.tsx:14` success = `--success`; `admin/page.tsx:46` plan badge `bg-success/15`). LIVE coverage: marketing hero + storefront cards captured; login page captured live and conforms.
- [ ] **Remaining before deploy (require a real browser locally):** formal pixel diff of the captured inline PNGs vs `demodesign/*/screen.png`; live playback frames for count-up / path-draw / stagger / method-card border animation; visual confirmation of success(deep-emerald) vs primary(mint) on a properly authed dashboard session (must keep the Puppeteer page across logins so the cookie carries). All underlying code/CSS is present and correct in the shipped build.

> **Two-session verification (2026-07-19).** The conformance/motion/ambient/build-prep items
> above were verified in **session 1** at source + served-asset level (no browser), then
> re-verified in **session 2** with a real browser (Puppeteer + system Chrome against the
> full live stack). The `grain overlay` + `emerald glow` mount points exist in code
> (`layout.tsx` grain; hero glows in `page.tsx`, `pricing`, `shop-header`, `success-client`,
> `super-admin-shell`, auth pages) and are `pointer-events-none`; the live marketing-hero
> capture (returned as an inline PNG by the MCP) shows the hero glow + dual CTAs. See
> `tasks.md` "Live Browser Pass — 2nd session" for the full capture list and backend fix
> log. One remaining visual item ("formal pixel diff vs `screen.png`") is left for
> in-person inspection.
