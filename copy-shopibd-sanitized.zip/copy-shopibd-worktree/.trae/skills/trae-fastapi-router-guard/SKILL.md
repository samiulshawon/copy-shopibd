---
name: "trae-fastapi-router-guard"
description: "Guards FastAPI routers against prefix, registration-order, and schema/model name-clash bugs. Invoke when a new router is added or backend/app/api/v1/__init__.py is modified."
---

# Trae FastAPI Router Guard

Sprint 4 shipped three real bugs from router mistakes (missing `prefix`, route
shadowing, schema/model name clash). This skill is a pre-finalization checklist
that catches the same class of bugs. It reports findings and never blocks.

## When to invoke
- A new `APIRouter` is created anywhere under `backend/app/api/v1/`.
- `backend/app/api/v1/__init__.py` is edited (router registration/order).
- A route's path or a Pydantic schema imports an ORM model by the same name.

## Checklist
1. **Prefix declared?** Each router is constructed with
   `APIRouter(prefix="/<resource>", tags=[...])`. Flag any `APIRouter()` with no
   prefix — it will mount at `/api/v1` and collide with other routes.
2. **Registered correctly?** In `__init__.py`, `app.include_router(x.router,
   prefix="/api/v1")` and the resource's own prefix is NOT duplicated.
3. **Route ordering / shadowing?** Static routes (`/subscription`, `/import`,
   `/bulk`, `/payment-webhook/...`) are declared BEFORE any `/{id}` parameter
   route in the SAME router, OR the static router is `include_router`-ed first.
   Flag a `/{param}` path that would swallow a sibling static path.
4. **Name clash?** If a Pydantic schema and an ORM model share a name in one file,
   the ORM model is aliased (e.g. `from ...models.product import Product as
   ProductModel`) and ORM instantiation uses the alias. Flag any `Model(...)`
   that actually resolves to a Pydantic schema class.
5. **Verb/path coverage?** For each intended resource, confirm GET (list + detail),
   POST, PUT/PATCH, DELETE are distinct paths and none 405/422 due to ordering.

## Output
Report: File | Line | Issue | Fix suggestion | Severity (Blocker / Warn).
End with: "Router guard complete. N blocker(s), M warning(s)."

## Allowed exceptions (do NOT flag)
- A root router intentionally mounted without a prefix (e.g. a health/readiness
  probe) — only if documented inline.
- Webhook routers that legitimately sit at a non-`/api/v1` prefix.

## Keep this skill current
When the registration strategy in `__init__.py` changes (e.g. versioning added),
update checklist #2 to match the new include pattern.
