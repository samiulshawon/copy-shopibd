---
name: "trae-tenant-scoping-audit"
description: "Audits backend code for multi-tenant data scoping. Invoke whenever a new API endpoint, SQLAlchemy query, ORM model, or relationship is written or modified under backend/app/."
---

# Trae Tenant-Scoping Audit

ShopiBD is a multi-tenant SaaS. Every tenant-owned table MUST be reachable only
through its owning `shop_id` (or `seller_id` for seller-scoped data). This skill
runs a focused scoping check BEFORE code changes are finalized and reports
findings as a clear list. It is advisory — it never blocks you from proceeding.

## When to invoke
- A new endpoint is added in `backend/app/api/v1/`.
- A SQLAlchemy query / `select()` / `db.execute()` is written or changed.
- A new ORM model or relationship is added in `backend/app/models/`.
- An Alembic migration touches a tenant-owned table or its FKs.

## Tenant-owned tables (verify against current models)
product, variant, category, stock, order, payment, customer, review, coupon,
coupon_usage, delivery, staff, subscription, audit_log, import_history.
(Owners: `shop` and `seller` are the tenants themselves — not scoped.)

## Checklist
1. **Read paths scoped?** No unscoped `select(Model)` / `db.query(Model)` over a
   tenant-owned table. Reads must filter by `shop_id` (or `seller_id`), via either:
   - the established `shop_id` query-param pattern, OR
   - a dependency-injected current shop/seller from `backend/app/api/v1/dependencies.py`.
2. **Write paths scoped?** `create`/`update`/`delete` set the owning FK from the
   authenticated tenant — never from unvalidated client input.
3. **Joins leak?** Any join between two tenant-owned tables joins ON the shared
   `shop_id` (or `seller_id`); no cross-tenant data can co-mingle.
4. **Public endpoints safe?** Storefront (`POST /shops/{slug}/orders`) and webhook
   routes are the ONLY allowed exception. They must resolve the shop by slug/signature
   and never trust a client-supplied `shop_id`.
5. **RLS coverage?** New tables have a matching policy in the RLS migration
   (`backend/alembic/versions.bak/ph2_tenant_rls_policies.py`) or a migration is added.

## Output
Report a short table: File | Line | Issue | Severity (Blocker / Warn).
End with: "Tenant-scoping check complete. N blocker(s), M warning(s)."

## Allowed exceptions (do NOT flag)
- Admin/platform endpoints under a verified super-admin dependency.
- Aggregations/analytics that explicitly group by `shop_id`.
- Migrations that alter tenant tables structurally (no row access).

## Keep this skill current
When a new tenant-owned model is added, append its name to the list above.
