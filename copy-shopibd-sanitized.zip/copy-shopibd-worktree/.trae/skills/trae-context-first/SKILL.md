---
name: "trae-context-first"
description: "Saves tokens by consulting compressed knowledge (.ai-context/ docs and SearchCodebase) before reading raw source files. Invoke when exploring the codebase, answering architecture questions, or locating code."
---

# Trae Context-First (Graphify-style token saver)

Re-reads are the #1 token waste on this project. The `.ai-context/` folder is a
hand-maintained compressed knowledge graph of ShopiBD; `SearchCodebase` is a
semantic index over the live code. Use BOTH before ever opening a raw source file
for exploration. Only read raw files when you are about to modify them.

This mirrors what graphify does (query the graph, not the source) — but with zero
dependencies, zero build step, and zero extra API calls.

## When to invoke
- You are asked to explore, explain, or locate something in the codebase.
- You are about to reach for `Read` on a file you haven't been asked to edit.
- You start a new task and need to understand "how X works" or "where Y lives".

## The 3-tier lookup (stop at the first tier that answers the question)

### Tier 1 — Compressed knowledge (`.ai-context/`)
Free, instant, zero API calls. Read these FIRST:
- `PROJECT_OVERVIEW.md` — stack, architecture principles, domain model
- `IMPACT_GRAPH.md` — component tree, data flow, auth/notification flows
- `CURRENT_SPRINT.md` — what's done, in progress, and blocked (source of truth)
- `MASTER_ROADMAP.md` — phases and planned work
- `KNOWN_ISSUES.md` — active bugs, technical debt, resolutions
- `DECISION_LOG.md` — why past decisions were made
- `FUTURE_SCOPE.md` — what's intentionally out of scope
- `PORT_ASSIGNMENTS.md` — service ports (PG 5434, Redis 6380, API 8000, etc.)

### Tier 2 — Semantic search (`SearchCodebase`)
One tool call, returns relevant chunks only (not whole files). Use for:
- "Where is JWT validation done?" → intent-based, not string match
- "How does the subscription billing flow work?" → follows meaning
- "Which endpoints enforce plan limits?" → scoped to actual behavior

### Tier 3 — Raw file reads (`Read`)
Only when Tier 1 + Tier 2 don't fully answer it AND you need to modify the file.
Prefer reading a targeted line range (offset/limit) over the whole file.

## Decision rules
1. **Question about architecture, flow, or "why"?** → Tier 1 only. Don't read source.
2. **Question about current implementation details?** → Tier 1, then Tier 2 if needed.
3. **Need to edit a file?** → Tier 1/2 to find it, then `Read` the specific file.
4. **Bulk exploration across many files?** → Use the `Task` tool with `subagent_type=search`.
   It returns a summary to the main context, keeping the main window lean.
5. **Offload heavy research** to a subagent whenever 3+ files would otherwise be read.
   The subagent reads them; only its short summary enters the main context.

## Anti-patterns to avoid
- ❌ Opening `Read` on 5 files to "understand the auth flow" — IMPACT_GRAPH.md already has it.
- ❌ Re-reading a file you read earlier in the same session — it's already in context.
- ❌ Using `Grep`/`Glob` to locate a concept when `SearchCodebase` finds it by meaning.
- ❌ Reading a whole 800-line file when you only need lines 120–160 — use offset/limit.

## Output
No special output format. Just follow the tiers silently and only surface raw-file
reads when they are actually necessary. The token savings are implicit.

## Keep this skill current
When a new `.ai-context/` file is added (e.g. a new flow diagram), append its name
and purpose to the Tier 1 list above so future sessions consult it automatically.
