# Disable Sub-Agent Delegation (STRICT)

## Trigger
ALWAYS ACTIVE. Applies to every task, regardless of complexity.

## Hard Rule
NEVER use the `Task` tool to launch sub-agents (search, general_purpose_task, or any other subagent_type). All work — research, searching, reading, editing, coding — MUST be performed directly in the main agent context using built-in tools (Glob, Grep, Read, Edit, Write, RunCommand, etc.).

## Scope
- ❌ Do NOT call the `Task` tool for exploration, codebase search, or delegation.
- ❌ Do NOT spawn agents for "parallel" work.
- ✅ Use `Glob`, `Grep`, `Read`, `SearchCodebase`, and other direct tools yourself.
- ✅ If a task would normally warrant a sub-agent, do it inline instead, even if it costs more context.
