---
alwaysApply: true
---
# Docker Container Isolation Guard (STRICT)

## Trigger
ALWAYS ACTIVE. Applies to ANY operation involving Docker — running commands, starting/stopping services, executing into containers, reading logs, running migrations, inspecting state, or editing docker-compose / Dockerfile configs.

## Scope of This Project
The ONLY containers the `shopibd` project owns are those defined in:
- `docker-compose.yml` → `shopibd-db`, `shopibd-redis`, `shopibd-backend`, `shopibd-frontend` (optionally `shopibd-nginx`)
- `docker-compose.dev.yml` → `shopibd-db-dev`, `shopibd-redis-dev`, `shopibd-minio-dev`, `shopibd-backend-dev`, `shopibd-certbot-dev`

Any container or volume whose name is **NOT** prefixed with `shopibd` belongs to another project on this host and is STRICTLY OFF-LIMITS.

## Hard Rules (never violate)
1. **Target by name, never by index or `--all`.** Every `docker exec`, `docker logs`, `docker restart`, `docker stop`, `docker rm`, `docker cp`, etc. MUST name a specific `shopibd-*` container. Examples:
   - ✅ `docker exec shopibd-backend ...`
   - ✅ `docker logs shopibd-db`
   - ❌ `docker stop $(docker ps -q)` — affects everything
   - ❌ `docker restart -a`, `docker exec -it ...` without a name
2. **Never run blanket commands.** Do NOT use `docker stop -a`, `docker rm -a`, `docker kill $(docker ps -q)`, `docker system prune`, or `docker compose down` from a directory that is NOT the `shopibd` project root.
3. **Scope compose operations to this project.** Only run `docker compose ...` from `e:\SaaS test\shopibd` (or the explicit compose file via `-f docker-compose.yml`). When stopping services, prefer `docker compose stop` over `down`, and never pass `-v` to remove volumes unless the user explicitly asks.
4. **No cross-container contamination.** Do not copy files into, run commands inside, or inspect non-`shopibd` containers even if it seems convenient.
5. **Verify before destructive ops.** Before `rm`, `down`, or volume removal, confirm the target resolves to a `shopibd-*` container. If a command would match a non-`shopibd` container, abort and ask the user.

## Verification Before Any Docker Command
Before issuing a Docker command, silently confirm:
- The container/service name starts with `shopibd` (or is part of this project's compose files), AND
- The command has no wildcard/`-a`/`$(...)` expansion that could hit other containers.

If either check fails, STOP and ask the user for confirmation instead of running the command.
