---
alwaysApply: false
---
# Implementation Verification Protocol

## Trigger
Activate when the user requests code to be written, modified, or implemented after a plan has been discussed.

## Core Instructions
Do not modify any files immediately. First perform a focused verification of the intended implementation before making changes.

## Verification Checklist
1. **Architecture & Feature Alignment:** Confirm the implementation matches the agreed feature, existing architecture, coding patterns, and repository structure.
2. **Isolation & Safety:** Verify all edits are limited to only the files required for the feature. Ensure unrelated modules, configurations, tests, documentation, and existing functionality remain unchanged and are not impacted directly or indirectly.

## Output
Before writing code, provide:
- **Impact Scope:** Files to be modified and why.
- **Isolation Guard:** Confirm all other modules remain unaffected.

End with:
"Implementation verified. Reply **'Proceed'** to deploy code safely."