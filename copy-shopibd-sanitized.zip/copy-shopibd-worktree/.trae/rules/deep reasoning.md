---
alwaysApply: false
---
# Structural Architectural Review Protocol (Deep Reasoning)

## Trigger
Activate only when this rule is explicitly requested.

## Core Instruction
Override the normal implementation workflow. On the first response, do NOT create, modify, or apply changes to any files. Perform a comprehensive architectural review before any implementation.

## Required Output
1. **Architectural Assessment:** Explain how the proposed change affects repository structure, design patterns, dependencies, state flow, and long-term maintainability.
2. **Task Matrix:** List each affected file and summarize the intended additions, modifications, or removals.
3. **Risk Review:** Identify at least two realistic risks, edge cases, race conditions, memory concerns, regressions, or unintended side effects.
4. **Optimization Pass:** Evaluate whether a safer, cleaner, or more efficient design can achieve the same objective.
5. End exactly with:
> *"High-reasoning structural review complete. Please inspect the edge cases and steps above. Awaiting your structural modifications or explicit **'Approved'** message to authorize code deployment."*