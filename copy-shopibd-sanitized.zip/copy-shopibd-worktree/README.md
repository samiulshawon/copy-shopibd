# ShopiBD - Bangladesh SaaS E-commerce Platform

A production-ready, multi-tenant SaaS platform for Bangladesh e-commerce businesses. Built with FastAPI, Next.js, PostgreSQL, and Docker.

## 🚀 Quick Start

### Prerequisites
- Docker & Docker Compose
- Make (optional, for convenience commands)
- Node.js 20+ (for local frontend development)
- Python 3.12+ (for local backend development)

### Development Setup

```bash
# Clone and navigate
cd shopibd

# Start development database only
make dev

# Apply migrations
make migrate

# Seed demo data
make seed

# Start backend locally (in separate terminal)
cd backend && pip install -e ".[dev]" && uvicorn app.main:app --reload --port 8080

# Start frontend locally (in separate terminal)
cd frontend && npm install && npm run dev
```

### Production Setup

```bash
# Build and start all services
make up

# Or manually
docker-compose up -d --build
```

## 🏗 Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   Frontend      │     │   Backend       │     │   Database      │
│   (Next.js 14)  │◄───►│   (FastAPI)     │◄───►│   (PostgreSQL)  │
│   Port: 3001    │     │   Port: 8080    │     │   Port: 5433    │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                              │
                              ▼
                        ┌─────────────────┐
                        │   Redis         │
                        │   Port: 6379    │
                        └─────────────────┘
```

## 📁 Project Structure

```
shopibd/
├── .ai-context/           # AI agent context files
├── backend/               # FastAPI backend
│   ├── app/
│   │   ├── core/         # Config, DB, security, logging
│   │   ├── models/       # SQLAlchemy models
│   │   ├── schemas/      # Pydantic schemas
│   │   ├── api/v1/       # API routes
│   │   ├── services/     # Business logic (SMS, WhatsApp, Payment, i18n)
│   │   └── admin/        # AdminJS setup
│   ├── scripts/          # Seed, TypeSync
│   ├── tests/            # Unit, contract, E2E tests
│   └── alembic/          # Migrations
├── frontend/              # Next.js frontend
│   ├── src/
│   │   ├── app/          # App Router pages
│   │   ├── components/   # UI components
│   │   ├── hooks/        # Custom hooks
│   │   ├── lib/          # Utilities
│   │   └── types/        # TypeScript types
│   └── tests/            # E2E tests
├── docker-compose.yml     # Production
├── docker-compose.dev.yml # Development (DB only)
└── Makefile              # Convenience commands
```

## 🔧 Key Features

### Multi-Tenant Architecture
- **Seller** → **Shop** (1:1) → **Products, Orders, Staff**
- Row-level security via tenant isolation
- Staff roles: `owner`, `manager`, `staff_viewer`

### Bangladesh-Specific
- **Language**: Bengali (bn) + English (en) with RTL support
- **Currency**: BDT (৳) formatting
- **Phone**: +880 format validation
- **Payments**: SSLCommerz integration (sandbox/production)
- **SMS**: Local provider ready (SSLCommerz, Twilio)
- **WhatsApp**: Business API integration
- **Timezone**: Asia/Dhaka

### AI-Safe Infrastructure
- **TypeSync**: Auto-generate TS types from OpenAPI
- **Contract Tests**: Schemathesis validates API against OpenAPI
- **Seeder**: Deterministic demo data for consistent testing
- **E2E Skeleton**: Playwright tests for critical flows

### Admin Panel
- AdminJS at `/admin`
- Role-based access control
- Resource management for all entities

## 🌐 Ports

| Service | Port | Description |
|---------|------|-------------|
| Frontend | 3001 | Next.js app |
| Backend | 8080 | FastAPI app |
| PostgreSQL | 5433 | Database |
| Redis | 6379 | Cache/Sessions |
| AdminJS | 8080/admin | Admin panel |

## 📝 Environment Variables

Copy `.env.example` to `.env` and configure:

```bash
cp .env.example .env
# Edit .env with your values
```

Key variables:
- `DATABASE_URL` - PostgreSQL connection
- `SECRET_KEY` - JWT signing (min 32 chars)
- `SMS_PROVIDER` - `mock` | `sslcommerz` | `twilio`
- `WHATSAPP_PROVIDER` - `mock` | `business_api`
- `PAYMENT_PROVIDER` - `manual` | `sslcommerz`
- `ADMIN_EMAIL` / `ADMIN_PASSWORD` - Admin panel credentials

## 🧪 Testing

```bash
# All tests
make test

# Backend only
make test-backend

# Frontend unit tests
make test-frontend

# E2E tests
make test-e2e

# Contract tests (Schemathesis)
cd backend && pytest tests/contract/ -v
```

## 🔄 Database Migrations

```bash
# Create new migration
make migrate-create

# Apply migrations
make migrate

# Rollback
docker-compose -f docker-compose.dev.yml run --rm backend alembic downgrade -1
```

## 🌱 Seeding Demo Data

```bash
make seed
```

Creates:
- 1 Super Admin
- 2 Demo Sellers with shops
- Categories, products, stock
- Staff members with different roles
- Sample orders

## 📦 TypeSync (API ↔ Frontend Types)

```bash
make typesync
```

Generates `frontend/src/types/api.ts` from backend OpenAPI spec.

## 🐳 Docker Commands

```bash
# View logs
make logs

# Backend shell
make shell-backend

# Database shell
make shell-db

# Clean everything
make clean
```

## 📚 API Documentation

- Swagger UI: http://localhost:8080/docs
- ReDoc: http://localhost:8080/redoc
- OpenAPI JSON: http://localhost:8080/openapi.json

## 🔐 Authentication

- JWT access tokens (30 min)
- Refresh tokens (7 days)
- HttpOnly cookies for refresh token
- Role-based access control

## 📄 License

MIT License - see LICENSE file for details.

## 🤝 Contributing

1. Fork the repository
2. Create feature branch
3. Run `make format` and `make lint`
4. Run `make test`
5. Submit PR

## 📞 Support

- Issues: GitHub Issues
- Docs: `/docs` (when available)
- Email: support@shopibd.com