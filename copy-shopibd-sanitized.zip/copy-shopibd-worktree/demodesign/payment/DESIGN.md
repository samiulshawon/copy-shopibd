---
name: ShopiBD Design System
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3f4944'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#6f7a73'
  outline-variant: '#bec9c2'
  surface-tint: '#046c50'
  primary: '#00503a'
  on-primary: '#ffffff'
  primary-container: '#006a4e'
  on-primary-container: '#92e7c3'
  inverse-primary: '#83d7b4'
  secondary: '#003ec6'
  on-secondary: '#ffffff'
  secondary-container: '#0052fe'
  on-secondary-container: '#dfe3ff'
  tertiary: '#74302a'
  on-tertiary: '#ffffff'
  tertiary-container: '#91473f'
  on-tertiary-container: '#ffcac3'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#9ef4d0'
  primary-fixed-dim: '#83d7b4'
  on-primary-fixed: '#002116'
  on-primary-fixed-variant: '#00513b'
  secondary-fixed: '#dde1ff'
  secondary-fixed-dim: '#b7c4ff'
  on-secondary-fixed: '#001452'
  on-secondary-fixed-variant: '#0038b6'
  tertiary-fixed: '#ffdad5'
  tertiary-fixed-dim: '#ffb4aa'
  on-tertiary-fixed: '#3c0705'
  on-tertiary-fixed-variant: '#75322b'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 60px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 16px
  md: 24px
  lg: 32px
  xl: 48px
  container-max: 1440px
  gutter: 24px
  sidebar-width: 280px
---

## Brand & Style
The design system is engineered for **ShopiBD**, a commerce platform empowering Bangladeshi SMEs. The brand personality is **enterprising, reliable, and frictionless**, bridging the gap between traditional local trade and modern digital efficiency.

The design style follows a **Corporate / Modern** aesthetic with a high emphasis on functional clarity. It utilizes heavy whitespace to reduce cognitive load for business owners managing complex inventories. The visual language is defined by structured dashboard layouts and high-trust consumer storefronts, ensuring a professional atmosphere that feels both high-tech and locally grounded.

## Colors
The palette is anchored by **Bangladesh Green**, a vibrant emerald that symbolizes growth and national identity, used primarily for brand moments and primary actions. A **Tech Blue** serves as the secondary color, highlighting interactive elements, links, and progress indicators.

The dashboard utilizes a **Sophisticated Grayscale** (Slate/Zinc) to provide a neutral backdrop that allows critical business data to stand out. 
- **Primary:** Brand identity and main CTAs.
- **Secondary:** Navigation accents and utility actions.
- **Surface:** Tiered grays for sidebar navigation and container backgrounds.
- **Semantic:** Strict adherence to Green (Success), Amber (Pending), and Red (Danger) for status indicators.

## Typography
This design system employs a dual-font strategy. **Plus Jakarta Sans** is used for headlines to provide a friendly, modern, and welcoming feel to the platform. **Inter** is used for body copy and data-heavy dashboard elements due to its exceptional legibility and systematic character.

Maintain high contrast between headers and body text. Use `label-md` for table headers and sidebar categories to establish a clear structural hierarchy. On mobile devices, large headlines automatically scale down to prevent excessive line-breaking.

## Layout & Spacing
The layout follows a **Fluid Grid** model for the Merchant Dashboard and a **Centered Fixed Grid** for the Consumer Storefront.

- **Dashboard:** Features a persistent left-hand sidebar (280px). The main content area uses a 12-column fluid grid with 24px gutters. Spacing between metric cards is fixed at 24px (md).
- **Storefront:** Content is contained within a 1440px max-width wrapper. Product grids use a responsive column count (1 on mobile, 2 on tablet, 4 on desktop).
- **Rhythm:** An 8px linear scale is used for all internal component spacing to maintain a tight, professional density.

## Elevation & Depth
The system uses **Tonal Layers** combined with **Ambient Shadows** to create a sense of organized depth.

- **Level 0 (Background):** The base dashboard uses `#F8FAFC`.
- **Level 1 (Cards/Sidebar):** Pure white `#FFFFFF` surfaces with a subtle `4px` blur shadow at 5% opacity.
- **Level 2 (Modals/Popovers):** Elevated white surfaces with a `12px` blur shadow at 10% opacity and a `1px` neutral-200 border.
- **Interactive:** Hover states on buttons and cards increase the shadow depth slightly to provide tactile feedback without looking "heavy."

## Shapes
The design system adopts a **Rounded** (Medium) shape language. This softens the professional aesthetic, making the SaaS platform feel more accessible and user-friendly for non-technical business owners.

- **Standard (8px):** Applied to buttons, input fields, and small cards.
- **Large (16px):** Applied to main dashboard metric containers and product image wrappers.
- **Extra Large (24px):** Used for promotional banners in the storefront.
- **Full:** Used exclusively for status badges (pills) and profile avatars.

## Components

### Dashboard Elements
- **Sidebar Navigation:** High-contrast links using `body-sm`. Active states use a "Bangladesh Green" left indicator and a light green background tint.
- **Metric Cards:** White cards with 16px padding. Features a top-aligned icon in a colored circle (e.g., Blue for "Orders," Green for "Revenue") and a large `headline-md` value.
- **Status Badges:** Pill-shaped backgrounds with 10% opacity of the semantic color (Green, Amber, Red) and 100% opacity for the text.

### Inputs & Actions
- **Buttons:** Primary buttons use a solid "Bangladesh Green" background with white text. Storefront "Add to Cart" buttons use a "Tech Blue" to distinguish buyer actions from administrative ones.
- **Input Fields:** 1px border (`#E2E8F0`) with an 8px corner radius. Focused state uses a 2px "Tech Blue" ring.

### Storefront Specifics
- **Product Cards:** Minimalist design with a 1:1 aspect ratio image. Title uses `body-md` (bold) and price uses `body-md` in "Bangladesh Green."
- **CTAs:** Large, full-width buttons on mobile for "Buy Now" to facilitate easy thumb-driven commerce.