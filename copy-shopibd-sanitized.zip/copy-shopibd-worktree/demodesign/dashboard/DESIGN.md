---
name: Obsidian Emerald
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#bec9c2'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#88938d'
  outline-variant: '#3f4944'
  surface-tint: '#83d7b4'
  primary: '#83d7b4'
  on-primary: '#003828'
  primary-container: '#006a4e'
  on-primary-container: '#92e7c3'
  inverse-primary: '#046c50'
  secondary: '#c8c6c5'
  on-secondary: '#313030'
  secondary-container: '#4a4949'
  on-secondary-container: '#bab8b7'
  tertiary: '#c6c6c7'
  on-tertiary: '#2f3131'
  tertiary-container: '#5b5d5d'
  on-tertiary-container: '#d5d6d6'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#9ef4d0'
  primary-fixed-dim: '#83d7b4'
  on-primary-fixed: '#002116'
  on-primary-fixed-variant: '#00513b'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474646'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-xs:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
---

## Brand & Style

This design system is built for a high-end SaaS e-commerce environment where professional authority and precision are paramount. The aesthetic is a refined fusion of **Minimalism** and **Modern Corporate**, utilizing a "blackish" foundation to create a sense of depth and exclusivity. By stripping away all blue undertones in favor of neutral and ink-based grays, the UI achieves a sophisticated, "jet-black" appearance that allows content and data to lead.

The emotional response should be one of stability and high-stakes performance. The primary action color, a deep emerald green, serves as a beacon of growth and successful transactions against the dark canvas, ensuring the user's path to conversion is always unmistakable.

## Colors

The palette is strictly anchored in deep blacks and neutral grays to eliminate any perceived blue tint. 

- **Primary:** #006a4e (Emerald Green). Reserved for primary actions, success states, and key brand moments.
- **Surface (Deep):** #000000 (Pure Black). Used for the base background to maximize contrast.
- **Surface (Mid):** #0a0a0a (Deep Ink). Used for secondary layout sections and navigation sidebars.
- **Surface (Light):** #121212 (Ink Gray). Used for cards, modals, and elevated components.
- **Foreground:** #ffffff (Pure White) for maximum legibility on high-priority text.
- **Muted Foreground:** #a1a1a1 (Neutral Slate) for secondary information and labels.

Avoid any hex codes containing higher 'B' values in RGB to ensure no navy or cobalt tones emerge.

## Typography

This design system utilizes **Plus Jakarta Sans** across all levels to maintain a clean, modern, and slightly geometric feel. 

Headlines use tighter letter-spacing and heavier weights to anchor the page. Body text is optimized for readability with generous line heights. For data-heavy e-commerce tables, the `label-sm` and `label-xs` roles provide clear hierarchy. All text must maintain a minimum contrast ratio of 7:1 against the deep backgrounds to ensure accessibility in the dark-mode-only environment.

## Layout & Spacing

The layout follows a **Fluid Grid** model based on an 8px square rhythm. 

- **Desktop:** 12-column grid with 24px gutters and 48px outer margins.
- **Tablet:** 8-column grid with 24px gutters and 32px outer margins.
- **Mobile:** 4-column grid with 16px gutters and 16px outer margins.

Spacing between functional groups should use `lg` (48px) or `xl` (80px) to create the "Minimalist" breathing room required for a premium SaaS feel. Data density in tables can be increased by using `xs` and `sm` increments for internal cell padding.

## Elevation & Depth

In a pure black environment, traditional shadows are ineffective. Depth is conveyed through **Tonal Layering** and **Low-Contrast Outlines**:

1.  **Level 0 (Floor):** #000000 (Pure Black).
2.  **Level 1 (Cards/Sections):** #0a0a0a with a subtle 1px border of #1f1f1f.
3.  **Level 2 (Modals/Popovers):** #121212 with a slightly brighter 1px border of #2a2a2a.

Avoid heavy blurs. Use crisp, 1px borders to define the boundaries of interactive elements. When an element is "raised," increase its surface hex value slightly rather than relying on shadow opacity.

## Shapes

The shape language uses a consistent **8px (0.5rem)** radius for most UI components (Buttons, Inputs, Cards). This "Soft" approach balances the aggressive "blackish" palette, making the professional environment feel approachable yet disciplined. 

- **Small elements (Tags/Chips):** 4px (rounded-sm).
- **Standard elements (Buttons/Inputs):** 8px (default).
- **Large containers (Modals/Banners):** 12px (rounded-lg).

## Components

- **Buttons:** Primary buttons use a solid #006a4e fill with white text. Secondary buttons use a #121212 fill with a 1px #2a2a2a border.
- **Inputs:** Fields use a #0a0a0a background with a #1f1f1f border. On focus, the border transitions to #006a4e. Use `label-sm` for field labels.
- **Cards:** Use #0a0a0a for the container. For e-commerce product cards, use #121212 to make the product imagery pop.
- **Chips/Status:** For success/active states, use a subtle #006a4e background at 15% opacity with a solid #006a4e text label.
- **Data Tables:** Use #000000 for the header row and #0a0a0a for alternating "zebra" stripes or subtle 1px dividers in #1f1f1f.
- **Checkboxes & Radios:** When checked, these use the #006a4e emerald color. The unchecked state is a #2a2a2a ring.