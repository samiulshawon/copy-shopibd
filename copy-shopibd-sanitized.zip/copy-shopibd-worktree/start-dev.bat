@echo off
title ShopiBD Development Starter
cd /d "%~dp0"

echo ========================================
echo   ShopiBD Development Starter
echo ========================================
echo.

:: Step 1: Check if Docker is running
echo [1/5] Checking Docker...
docker info >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Docker is not running. Start Docker Desktop first.
    pause
    exit /b 1
)
echo        Docker is running.

:: Step 2: Start PostgreSQL if not running
echo [2/5] Starting PostgreSQL...
docker ps --format "{{.Names}}" | findstr "shopibd-db-dev" >nul 2>&1
if %errorlevel% neq 0 (
    echo        Container not found. Creating...
    docker compose -f docker-compose.dev.yml up -d
    echo        Waiting for PostgreSQL to be ready...
    timeout /t 5 /nobreak >nul
) else (
    echo        PostgreSQL already running.
)

:: Step 3: Clear frontend cache
echo [3/5] Clearing frontend cache...
if exist "frontend\.next" (
    rmdir /s /q "frontend\.next"
    echo        Cache cleared.
) else (
    echo        No cache to clear.
)

:: Step 4: Start backend
echo [4/5] Starting backend on :8080...
cd /d "%~dp0backend"
if exist "venv\Scripts\uvicorn.exe" (
    start "ShopiBD-Backend" /B venv\Scripts\uvicorn app.main:app --reload --port 8080
    echo        Backend starting on http://localhost:8080
) else (
    echo        WARNING: Virtual env not found. Run: python -m venv venv
)

:: Step 5: Start frontend
echo [5/5] Starting frontend on :3001...
cd /d "%~dp0frontend"
start "ShopiBD-Frontend" /B cmd /c "npm run dev"
echo        Frontend starting on http://localhost:3001

echo.
echo ========================================
echo   Ready!
echo   Frontend: http://localhost:3001
echo   Backend:  http://localhost:8080
echo   API Docs: http://localhost:8080/docs
echo ========================================
echo.
echo   Close this window or run stop-dev.bat to stop all servers.
echo.
