# Phase I0 Baseline — Sharp-Commerce Conversion

## Status

- Phase: I0 — Baseline and implementation controls.
- Scope recorded: 2026-07-26.
- Repository condition: the workspace has no initial Git commit (`git rev-parse --short HEAD` cannot resolve); consequently, this document is the source baseline for the conversion rather than a commit-to-commit comparison.
- Change boundary: presentation and interaction feedback only. Backend APIs, database models/migrations, tenant isolation, payments, subscriptions, authorization, and direct-order behavior are excluded from visual conversion changes.

## I0.1 Route inventory

### Public marketing and pricing

| Route | Source | Risk | Baseline behavior to preserve |
| --- | --- | --- | --- |
| `/` | `frontend/src/app/page.tsx` | Low | Merchant-conversion entry points and public header/footer destinations. |
| `/pricing` | `frontend/src/app/pricing/page.tsx` | Low | Plan data display and registration/subscription paths. |

### Tenant storefront and customer transaction flow

| Route | Source | Risk | Baseline behavior to preserve |
| --- | --- | --- | --- |
| `/:slug` | `frontend/src/app/[slug]/page.tsx` | Medium | Tenant lookup, seller identity, product display, loading/not-found states. |
| `/:slug/products/:id` | `frontend/src/app/[slug]/products/[id]/page.tsx` | Medium | Product data loading and navigation into direct order flow. |
| `/:slug/order` | `frontend/src/app/[slug]/order/page.tsx` | High | Existing order payload, validation, payment-method selection, submission states. |
| `/:slug/order/success` | `frontend/src/app/[slug]/order/success/page.tsx` | High | Order confirmation and post-order actions. |
| `/:slug/orders/track` | `frontend/src/app/[slug]/orders/track/page.tsx` | High | Tracking lookup request, success, unknown-order, and error states. |

### Authentication

| Route | Source | Risk | Baseline behavior to preserve |
| --- | --- | --- | --- |
| `/auth/login` | `frontend/src/app/auth/login/page.tsx` | High | Login API call, rate-limit/error semantics, session persistence, and redirects. |
| `/auth/register` | `frontend/src/app/auth/register/page.tsx` | High | Registration inputs, validation, session/redirect semantics, and related links. |

### Seller dashboard

The protected dashboard shell is defined by `frontend/src/app/dashboard/layout.tsx`. Its functional route surface includes:

- `/dashboard` — overview.
- `/dashboard/analytics` — analytics.
- `/dashboard/products`, `/dashboard/products/new`, and `/dashboard/products/:id` — product operations.
- `/dashboard/orders` and `/dashboard/orders/:id` — order operations.
- `/dashboard/customers`, `/dashboard/coupons`, and `/dashboard/abandoned` — customer and promotion operations.
- `/dashboard/payments` — payment operations.
- `/dashboard/subscription`, `/dashboard/subscription/success`, and `/dashboard/subscription/cancel` — plan, usage, and payment transition experience.
- `/dashboard/branding`, `/dashboard/staff`, `/dashboard/notifications`, and `/dashboard/settings` — merchant configuration.

All seller-dashboard routes are **high risk** because their presentation is interwoven with protected queries, mutations, plan-limit feedback, role behavior, and mobile navigation.

### Super-admin

The protected super-admin shell is defined by `frontend/src/app/admin/layout.tsx`. Its functional route surface includes:

- `/admin` — platform dashboard.
- `/admin/activity` — activity.
- `/admin/clients`, `/admin/clients/new`, and `/admin/clients/:id` — client management.
- `/admin/reviews` and `/admin/settings` — platform moderation/settings.

All super-admin routes are **high risk** because they must retain admin-only access and management actions. The configured SQLAdmin destination is an explicit verification item, not a design-change target unless its origin is proven incorrect.

## I0.1 Shared-component inventory

### Foundation and shared UI

| Area | Current source inventory | Migration sensitivity |
| --- | --- | --- |
| Theme and root | `frontend/src/app/globals.css`, `frontend/tailwind.config.ts`, `frontend/src/app/layout.tsx`, `frontend/src/app/providers.tsx` | Critical: affects every route. |
| UI primitives | Button, Input, Select, Card, Alert, Badge, Table, Tabs, Dialog, Dropdown Menu, Avatar, Skeleton, Star Rating, Toast | Critical: migrate variants compatibly before route-specific work. |
| Cross-app layout | Header, Footer, Page Structure, Sidebar, Dashboard Shell, Super Admin Shell | Critical: affects navigation, mobile overlays, and route access. |
| Storefront | Storefront Provider, Shop Header, Product Grid/Card/Detail, Order Form, mobile actions, footer | High: must preserve tenant and order contracts. |
| Dashboard | Stats, charts, order/status tables, product/CSV/bulk forms, payment/delivery/shop/staff forms, usage/plan/upgrade/branding components | High: mutations and subscription limits must remain unchanged. |

## I0.1 Current visual-system baseline

### Foundation findings

- The existing system is a dark Obsidian Emerald theme in `frontend/src/app/globals.css` and `frontend/tailwind.config.ts`.
- Root `background`, `foreground`, primary, card, popover, surface, border, and ring values are dark/emerald-oriented.
- The root font is Plus Jakarta Sans with Noto Sans Bengali fallback; Phase I1 will replace the Latin font with Be Vietnam Pro while retaining Bengali coverage.
- The Tailwind configuration declares rounded radii and project-specific shadows (`soft`, `card`, `md`, `lg`, and `glow`).
- Existing global motion includes fade, shimmer, slide-in, glow pulse, and draw-path effects. The current reduced-motion reset is present and must remain effective after conversion.

### Source conformance baseline

The initial static scan confirms the conversion has substantial planned work:

- Legacy Obsidian/Emerald terminology and token references are present in the theme foundation.
- Rounded controls/panels, shadows, gradients, and backdrop blur occur across shared primitives, public/auth views, storefront components, seller dashboard, and super-admin shell.
- No `killstar`, `KILLSTAR`, or `killstar.com` reference was found under `frontend/src`, establishing a clean external-brand-string baseline.
- Seller branding pages intentionally support merchant content colors and custom CSS. Those tenant-content features must remain functional but must not override global semantic interface tokens.

## I0.1 Test baseline

### Frontend commands configured

| Command | Purpose | Status at baseline |
| --- | --- | --- |
| `npm run build` | Next.js production compilation | Completed static compilation and page generation on 2026-07-26; Next emitted the same missing-`eslint` warning during its lint stage. |
| `npx tsc --noEmit` | TypeScript type validation | Passed on 2026-07-26. |
| `npm run lint` | Next.js lint command | Blocked at baseline: `next lint` exits because `eslint` is not installed in the project. No dependency change made during this documentation-only phase. |
| `npm test` | Playwright E2E suite | Pending execution during I0 baseline. |

The frontend Playwright configuration currently uses Desktop Chrome only, `http://localhost:3001` as its base URL, and starts/reuses the development server through `npm run dev`.

### Existing E2E coverage

| Spec | Current coverage | Baseline limitation |
| --- | --- | --- |
| `frontend/tests/e2e/auth.spec.ts` | Protected-route redirect, API-assisted valid login, invalid credentials, logout. | Uses API login/session setup rather than complete form entry for the valid-login flow. |
| `frontend/tests/e2e/order-flow.spec.ts` | Storefront product visibility, direct order placement, seller order-table visibility. | Creates order data against the shared seeded seller. |
| `frontend/tests/e2e/subscription.spec.ts` | Subscription content, plan selection, subscription/payment request flow. | Documented to run in isolation because shared seeded-seller state can pollute the full suite. |

### Existing backend regression inventory

Relevant backend tests already cover plan capabilities/limits, pricing, subscription tasks, invoice behavior, tenant isolation, rate limits/metrics, observability, downgrade, SSL, roles, subdomain availability, payment/courier behavior, shop URLs, storage, OpenAPI contract, and admin client URL behavior. These remain the regression boundary for a presentation-only conversion.

## I0.1 Visual-check evidence matrix

Visual capture must occur before modifying the relevant route group and again after its phase completes. Capture desktop (1440px), tablet (768px), and mobile (390px) where the route is responsive.

| Evidence group | Required pre-change captures | Data/state coverage |
| --- | --- | --- |
| Public | Home, pricing | Default and loading where available. |
| Storefront | Seeded tenant catalog, product detail, order form, success, tracking | In-stock item, invalid form, submitting, success, failed/unknown tracking. |
| Auth | Login and registration | Default, validation/error, loading. |
| Seller dashboard | Overview, products, product form, orders/detail, subscription, branding, staff | Loading, empty, error, selected/filter, plan-limit where available. |
| Super-admin | Dashboard, client list/detail/create, reviews, settings | Loading, empty, mutation/error states. |

No visual browser capture was generated in this baseline step because no controlled browser/screenshot command is currently configured as a project script. The evidence matrix is the mandatory capture checklist for the route-specific phases and Phase T6.

## I0.1 Environment baseline

- Frontend development server command: `npm run dev` on port `3001`.
- Frontend production Compose exposure: port `3001`.
- Compose declares project-owned container names `shopibd-db`, `shopibd-redis`, `shopibd-backend`, and `shopibd-frontend`.
- The current Compose file exposes backend production service port `8080`, while current E2E specs use `http://localhost:8000/api/v1`; test setup must validate which local backend process is active before tests run.
- Docker policy: use repository-root `docker compose -p shopibd` commands with explicit named services only. No pruning, unscoped teardown, or operation on unrelated resources.

## I0.1 Baseline exceptions / constraints

1. There is no Git commit in the workspace, so phase results must be tracked with the plan documents, command output, and source scans.
2. The E2E suite's shared seller state is a known flake risk; subscription coverage is intentionally isolated.
3. Route inventory and component inventory are complete for the existing `frontend/src/app` and `frontend/src/components` trees at baseline time.
4. This phase creates documentation only; it intentionally makes no product-code, API, schema, dependency, or Docker changes.
