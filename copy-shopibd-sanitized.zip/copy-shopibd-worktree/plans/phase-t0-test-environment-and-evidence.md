# Phase T0 — Test environment and evidence plan

This plan scopes the verification work for the killstar sharp-commerce redesign.
It is intentionally lightweight: a matrix and an evidence checklist, not a
live harness — see the exit criteria and the "known limitations" section for why
live runs are deferred to Phase T1/T2.

## 1. Service scope (docker-safety compliant)

Only ShopiBD-owned Compose services are in scope. Everything outside the
`shopibd-*` namespace is off-limits and was inspected, not touched.

| Service                | Source                   | Scope        | Notes |
|------------------------|--------------------------|--------------|-------|
| shopibd-db-dev         | docker-compose.dev.yml   | project      | PostgreSQL 16; reachable on host port 5434. |
| shopibd-redis-dev      | docker-compose.dev.yml   | project      | Redis 7; reachable on host port 6380. |
| shopibd-minio-dev      | docker-compose.dev.yml   | project      | S3-compatible storage; host ports 9000/9001. |
| shopibd-backend-dev    | docker-compose.dev.yml   | project      | FastAPI + uvicorn (--reload); host port 8080. |
| shopibd-certbot-dev    | docker-compose.dev.yml   | project      | Disabled (SSL_BACKEND=stub); only started with `--profile ssl`. |
| shopibd-frontend (TBD) | none in compose.dev.yml  | project      | Frontend runs locally with `npm run dev` (port 3001). |

Observed during T0 (no changes performed):

- db / redis / minio / backend containers are up; backend health probe reports
  unhealthy because the SQLAlchemy pool is exhausted under load
  (`QueuePool limit of size 5 overflow 10 reached`). This is a pre-existing
  environment condition unrelated to the visual changes.
- Playwright config (`frontend/playwright.config.ts`) and existing specs
  (`frontend/tests/e2e/*.spec.ts`) currently target `localhost:8000` and
  `localhost:3001` rather than the Compose ports (8080 / 4100). Phase T1/T2
  will need to reconcile this — either update the spec URLs or surface the
  backend on 8000 via the project's existing reverse proxy.

### Hard rules (always active)

1. Never run `docker stop -a`, `docker rm -a`, `docker kill $(docker ps -q)`,
   or `docker system prune` from anywhere in the host shell.
2. Compose commands must run from `e:\SaaS test\shopibd` using
   `docker compose -f docker-compose.dev.yml …`. Prefer `docker compose stop`
   over `down`; never pass `-v` unless the user explicitly asks.
3. Target by container name (`shopibd-*`); never reference other projects.

## 2. Test matrix

### 2.1 Viewport classes (Playwright device descriptors)

| Class        | Width × Height (CSS px) | Target                |
|--------------|-------------------------|-----------------------|
| Mobile       | 390 × 844               | iPhone 14             |
| Tablet       | 820 × 1180              | iPad Air              |
| Desktop      | 1280 × 800              | Desktop Chrome        |
| Wide desktop | 1536 × 960              | Desktop HiDPI         |

Existing config exposes only Desktop Chrome. T2 will add the other viewports as
new projects inside `frontend/playwright.config.ts`.

### 2.2 Browser coverage

| Engine        | Project name     | Status today | Action in T2 |
|---------------|------------------|--------------|--------------|
| Chromium      | chromium         | configured   | keep + extend |
| Firefox       | firefox          | not present  | add project  |
| WebKit        | webkit           | not present  | add project  |

### 2.3 Routes to verify

Public:
- `/` marketing home
- `/pricing`
- `/[slug]` storefront (catalog)
- `/[slug]/products/[id]` product detail
- `/[slug]/order` checkout
- `/[slug]/order/success`
- `/[slug]/orders/track`
- `/auth/login`, `/auth/register`

Seller dashboard (signed in as `sawan@shopibd.com`):
- `/dashboard`
- `/dashboard/products`, `/dashboard/products/new`, `/dashboard/products/[id]`
- `/dashboard/orders`, `/dashboard/orders/[id]`
- `/dashboard/customers`, `/dashboard/coupons`, `/dashboard/abandoned`
- `/dashboard/payments`, `/dashboard/analytics`
- `/dashboard/subscription`, `/dashboard/branding`, `/dashboard/staff`
- `/dashboard/notifications`, `/dashboard/settings`

Super-admin (signed in as `admin@mail.com`):
- `/admin`, `/admin/activity`
- `/admin/clients`, `/admin/clients/new`, `/admin/clients/[id]`
- `/admin/reviews`, `/admin/settings`

### 2.4 Evidence checklist (per viewport × per route above)

For each combination, capture:

1. Initial-load screenshot at full viewport height.
2. A focused screenshot of the primary data region (chart, table, form).
3. One interaction screenshot showing the post-action state (open drawer,
   expanded filter, validation error, mutation success).
4. `prefers-reduced-motion: reduce` variant of (1) for at least the marketing
   home, dashboard overview, and PDP routes.

Evidence output directory: `frontend/tests/e2e/evidence/<viewport>/<route>.png`.

## 3. Test environment lifecycle

T0 only documents the lifecycle; T1/T2 execute it.

1. Inspect ShopiBD containers — `docker ps -a --filter "name=shopibd"`.
2. If services are not healthy, run `docker compose -f docker-compose.dev.yml
   start db redis minio backend` (never `down`).
3. Migrations: not required in dev — `app/main.py` calls `create_all` on
   startup, and `scripts/reset_db.py` is the cleanup entry point.
4. Seed: `cd backend && python -m scripts.seed` (idempotent).
5. Backend smoke: `curl http://localhost:8080/api/v1/` should return 404 (route
   present, no DB hit) — used as a port-up check that does not exhaust the pool.
6. Frontend dev: `cd frontend && npm run dev` (port 3001).
7. Playwright: `cd frontend && npx playwright test`.

## 4. Known isolation limits (must be documented, not silently accepted)

1. Existing E2E specs share a single seeded seller (`sawan@shopibd.com`,
   `sawan-shop`). Running the suite twice in parallel mutates the same
   orders/products and can collide. Mitigation in T2: serial execution
   (`workers: 1`) for the order-flow spec and dedicated tests per persona.
2. The dev backend reports unhealthy under load (pool exhaustion). Until the
   pool sizing or async pattern is fixed in the backend, repeated E2E runs
   may need a container restart — record this in T1/T2 evidence.
3. Playwright URLs in the existing suite target 8000/3001, not the dev Compose
   ports 8080/4100. Either the suite or the proxy must be aligned before
   T1/T2 verification runs.
4. Backend service is the only project-owned `shopibd-backend` container; do
   not mistake non-`shopibd` containers (e.g., system minio, postgres) for the
   target.
5. The frontend production build (`npm run build`) hangs in this environment
   after the I8 changes; `npx tsc --noEmit` passes. The build verifier is
   expected to run in T1 from a clean shell so a stable signal can be
   captured.

## 5. Exit criteria (T0)

- Service scope, viewport/browser matrix, route surface, evidence format, and
  known limits are documented.
- No container lifecycle command was executed (only `docker ps` and
  read-only `docker logs`/`docker inspect` against `shopibd-*` targets).
- T0 deliverables are committed under `plans/` and reviewable without running
  the full stack.