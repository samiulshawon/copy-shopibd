# Phase T3 — Handover and follow-ups

This document closes out the killstar sharp-commerce redesign. It is the single
read-it-once handover for the next engineer. The detailed phase records still
live in
[`killstar-sharp-commerce-implementation-and-test-breakdown.md`](./killstar-sharp-commerce-implementation-and-test-breakdown.md)
and in the per-phase docs under `plans/`.

## 1. Final result

The ShopiBD storefront, seller dashboard, and super-admin console share one
operational design language:

- Square geometry, no decorative shadow, hairline borders, 12px grid.
- Two-color palette: deep ink (`--ink`) on warm canvas (`--canvas`), with
  semantic accents (`--success`, `--warning`, `--danger`) and one
  merch-blue accent (`--brand`) reserved for primary actions and links.
- Small-caps section labels, dense table-first surfaces, sticky local
  navigation, and a promotion ticker that pauses manually and under
  `prefers-reduced-motion: reduce`.
- The seller console and super-admin console are visually distinguishable
  only by labels and information hierarchy — not by a separate visual
  system.

## 2. Phase index

| Phase | Scope                                                   | State     |
|-------|---------------------------------------------------------|-----------|
| I0    | Controls + baseline tokens                               | ✅ done    |
| I1    | Public marketing site                                   | ✅ done    |
| I2    | Auth, errors, empty states                              | ✅ done    |
| I3    | Storefront catalog, search, sort, filters              | ✅ done    |
| I4a   | PDP structure, sticky buy bar, recently-viewed         | ✅ done    |
| I4b   | PDP info sections, hover-reveal, mobile buy bar slide | ✅ done    |
| I5    | Checkout, success, tracking, customer auth flows       | ✅ done    |
| I6    | Seller dashboard (overview, products, orders, payments, customers, coupons, abandoned, branding, staff, notifications, settings, subscription) | ✅ done |
| I7    | Super-admin (shell, dashboard, clients, reviews, settings) | ✅ done |
| I8    | Dynamicity, accessibility, visual cleanup              | ✅ done    |
| T0    | Test environment + evidence plan                        | ✅ done    |
| T1    | Static + build + contract verification                  | ✅ done    |
| T2    | Shared UI + accessibility verification                 | ✅ done    |
| T3    | Handover + follow-ups                                   | ✅ done    |

Per-phase completion records live inline in the implementation and test
breakdown file.

## 3. Verification summary (T0–T2)

- T0 — Documentation only. Read-only inspection of `shopibd-*` containers.
  No `docker stop`, `down`, `prune`, or other destructive command was run.
- T1 — Static source scans: zero unintended rounded/shadow/gradient/glass-
  blur/blue-green/focus-ring matches in `frontend/src`. The single
  `gradient` hit is the approved `skeleton-shimmer` loading pattern.
  TypeScript `tsc --noEmit` passes. `next lint` was not run (ESLint packages
  not installed; `next.config.js` already skips lint during build). The
  production build hangs in this environment during the SWC step; classified
  as environment-only.
- T2 — All 13 shared primitives clean. 8 sheets, 18 dialogs, 4 `<details>`,
  52 `aria-label`s, `aria-current="page"` on active nav. Ticker pauses
  manually and under reduced motion; no auto-scroll, autoplay, or marquee
  in source.

Full evidence and classification rationale is in the implementation plan,
not duplicated here.

## 4. Tracked follow-ups

These are the only items not closed by I0–I8 + T0–T2. They are intentionally
out of scope for the redesign and are tracked as separate work.

1. **Backend port alignment for Playwright.**
   [`plans/follow-ups/backend-port-alignment.md`](./follow-ups/backend-port-alignment.md)
   — `frontend/tests/e2e/*.spec.ts` targets `localhost:8000` / `localhost:3001`,
   while the dev Compose stack exposes backend on `8080` and frontend on
   `4100`. Align before running the existing specs against the dev stack.

2. **Missing ESLint packages.**
   [`plans/follow-ups/eslint-packages.md`](./follow-ups/eslint-packages.md)
   — `.eslintrc.json` exists but the ESLint packages it references are not
   installed. Install them and run `next lint` from CI to catch lint
   regressions.

3. **Live visual evidence at every viewport.**
   [`plans/follow-ups/live-visual-evidence.md`](./follow-ups/live-visual-evidence.md)
   — Full Playwright + axe + per-viewport screenshot pass. Deferred in T2
   because the backend is unhealthy (SQLAlchemy pool exhaustion) and the
   port-mismatch above blocks the existing suite. Re-run after both are
   fixed; Playwright config also needs Firefox + WebKit and the three new
   viewport projects.

4. **Production build re-verification.**
   [`plans/follow-ups/production-build.md`](./follow-ups/production-build.md)
   — `npm run build` hangs in this environment after the I8 wave. Retest from
   a clean shell; if it persists, capture the SWC worker stack to triage
   (likely sandbox-related, not a code regression).

5. **Backend SQLAlchemy pool sizing.**
   [`plans/follow-ups/backend-pool-exhaustion.md`](./follow-ups/backend-pool-exhaustion.md)
   — The dev backend reports unhealthy under load with `QueuePool limit of
   size 5 overflow 10 reached`. This is a backend concern, surfaced here so
   it isn't lost; addressed in a separate backend change.

## 5. Things to keep

- Square geometry, 12px grid, two-color palette. No rounded corners,
  shadows, glass, or gradients anywhere new.
- `prefers-reduced-motion: reduce` honored by default in every new
  animation.
- Promotion ticker keeps its manual pause/resume button (`aria-pressed`).
- Public promotion strip is the only place that uses motion outside of
  user-triggered transitions.

## 6. Things to avoid

- Do not re-introduce rounded corners or shadows in new UI work.
- Do not add auto-scroll, autoplay, or marquee.
- Do not run `docker compose down`, `prune`, or any command that targets
  non-`shopibd-*` containers. The dev stack lives only behind
  `docker-compose.dev.yml`.
- Do not run `scripts/reset_db.py` against the running dev backend unless
  the Playwright suite is paused — it drops the seeded seller used by the
  existing specs.