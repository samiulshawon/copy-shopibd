# ShopiBD Sharp-Commerce Visual Conversion Plan

## Objective

Convert every ShopiBD frontend experience to a ShopiBD-owned sharp monochrome commerce design inspired by the supplied visual research. Preserve all current APIs, tenant behavior, seller branding controls, authentication, payments, subscriptions, and administrative features. Do not use Killstar names, logos, taglines, source copy, or assets.

## Confirmed direction

- Scope: public marketing, pricing, seller storefront, product detail, checkout, tracking, order success, authentication, seller dashboard, and super-admin.
- Core system: off-white `#FAFAFA` canvas, ink `#141414`, black `#000000`, white `#FFFFFF`, grey `#D6D6D6`, and restrained sale/urgency red `#AB0000`.
- Typography: Be Vietnam Pro for Latin customer-facing UI, retaining Noto Sans Bengali as the Bengali fallback.
- Geometry: zero-radius controls, panels, navigation, product tiles, menus, image frames, and badges; no decorative shadows, blur, glass effects, pills, or gradient brand surfaces.
- Dynamicity: purposeful, commerce-native interactions rather than ambient SaaS animation: announcement ticker, hover image zoom/opacity, menu/drawer transitions, item/image loading states, filter/sort feedback, form submission states, table row selection, collapsible mobile navigation, and chart/data transitions that respect reduced-motion.
- Safeguard: Docker verification uses Compose project `shopibd` and explicit ShopiBD service targets only. No global Docker cleanup, container pruning, volume pruning, or commands against unrelated containers.

## Supplemental live-site research (2026-07-26)

A direct, read-only crawl of the live homepage and collection markup confirmed these reusable interaction patterns beyond the supplied static guide. This research is limited to publicly delivered HTML and scripts; it does **not** copy vendor code, website copy, data, brand assets, or third-party integrations.

| Verified pattern | Live evidence | ShopiBD implementation decision |
| --- | --- | --- |
| Layered mobile navigation | A labeled menu control opens a Bootstrap off-canvas panel; nested navigation uses collapsible submenus and maintains `aria-expanded` / `aria-controls`. | Implement a labeled `Menu` drawer using the existing Dialog/Sheet foundation. Use one-level, data-backed expandable navigation only where ShopiBD already has valid destinations; support Escape, focus return, and reduced motion. |
| Slide-in cart | Header cart actions target an off-canvas cart and a `cart-drawer` custom element exposes the current item count. | Use a ShopiBD cart/order-summary drawer only if compatible with the existing direct-order flow. Otherwise, retain the current direct checkout URL and show an accurate item/order state without inventing cart APIs. |
| Predictive search | The Shopify configuration exposes predictive search and a `/search/suggest` endpoint. | Add client-side product search only after a ShopiBD storefront search endpoint exists. In this conversion, provide an accessible local catalog filter when the page already has products loaded; do not simulate server-side predictive search. |
| Product carousels | Homepage collection tabs initialize Swiper product carousels with previous/next controls; review/media carousels explicitly disable autoplay. | Build a dependency-free, scroll-snap horizontal product rail only for featured storefront products when enough products exist. Use visible previous/next buttons, keyboard scroll, no autoplay, and a grid fallback. |
| Collection filtering and sorting | Collection markup includes a filter drawer with checkbox facets in accordion groups, plus a quick-view modal. | Add a local storefront filter/sort drawer only for attributes ShopiBD actually exposes (availability and price). Keep progressive disclosure accordions, selected-filter feedback, and reset control; defer category/material facets and quick view until supported by the API/model. |
| Quick product inspection | A dedicated `quickViewModal` is delivered on collection pages. | Do not add a duplicate quick-view purchase path in the first conversion. Keep product-card navigation to the existing product-detail route, which protects current checkout behavior. Reassess after the cart and variant data model matures. |
| Wishlist and customer-personalization integrations | Markup references wishlist, loyalty, review, recommendation, back-in-stock, and marketing vendor integrations. | Out of scope. Preserve ShopiBD's current capabilities; do not import third-party vendors, trackers, or data collection merely to mimic interaction patterns. |
| Accessibility conventions | The markup supplies labels, dialog/off-canvas relationships, and expandable-control state attributes. | Every new drawer, disclosure, carousel control, filter, and async status must supply an accessible name, correct state attributes, focus management, live feedback where needed, and `prefers-reduced-motion` support. |

## Second live-site inspection (2026-08-08)

A second read-only inspection of killstar.com was conducted via Chrome DevTools (homepage, collection page, and product detail page). The following additional patterns were identified beyond the first research pass. These are limited to structural and interaction patterns; no vendor code, copy, or assets are copied.

| Verified pattern | Live evidence | ShopiBD implementation decision |
| --- | --- | --- |
| Product image aspect ratio | Collection grid images are `400x600` (2:3 portrait); PDP gallery images are `500x` full-width. Thumbnails are `160x240`. | Define a standard storefront product image aspect ratio of **2:3 portrait** for grid tiles and a full-width gallery on PDP. Ensure existing product images are cropped/displayed in this ratio without distortion. |
| Product count on collection header | Collection page shows `"66 PRODUCTS"` next to the heading and filter button. | Display the total product count on the storefront catalog header next to the filter/sort controls. |
| Hover-reveal second image | Each product card has two images: a primary and a secondary. Hovering swaps to the second image (not a zoom). | Implement hover-reveal of a second product image on storefront product cards where a second image exists. Fall back to the existing scale/opacity hover when only one image is available. |
| Quick-add from card ("ADD TO BAG") | A solid "ADD TO BAG" button overlays the bottom of each product card on hover. | **Defer.** ShopiBD's current model uses direct-order-from-PDP. Quick-add requires either a cart system or a variant-selection prompt that does not exist yet. Keep card navigation to PDP. Reassess when cart/variant data model matures. |
| Wishlist heart icon per card | A heart-shaped "Add to Wishlist" button sits on each product card. | **Out of scope** (confirmed by first research pass). Preserve current capabilities. |
| Breadcrumb trail on PDP | `"NEW > INSECTA MINI DRESS"` breadcrumb sits above the product gallery. | Add a breadcrumb trail to the storefront product detail page using existing category + product data. |
| Size selection with disabled CTA | PDP has size radio buttons (XS–4XL). The primary "SELECT SIZE" button is **disabled** until a size is selected. A "View Guide" link opens a size chart. | Where ShopiBD products have variants/sizes, disable the order/add button until a variant is selected. Add a size-guide link if seller data provides it. |
| Collapsible accordion on PDP | PDP has expandable sections: DESCRIPTION (open by default), ORDER AMENDMENTS, DELIVERY, RETURNS, ROUTE PACKAGE PROTECTION. | Convert the PDP product information area into accordion sections (description, shipping/delivery, returns policy, seller-specific info). Open the first section by default; use border-led disclosures. |
| Related products ("YOU MAY ALSO LIKE") | A product recommendation section appears below the PDP gallery/buy-box. | **Conditional.** If ShopiBD's API can serve related products (same category or same shop), implement a compact horizontal rail below the PDP buy area. If not supported, defer. |
| Recently viewed section | A "RECENTLY VIEWED" section appears on the PDP below related products. | Implement a client-side recently-viewed tracker (localStorage) that surfaces the last 4–8 viewed products as a horizontal rail on the PDP. No API change needed. |
| Sticky mobile buy bar | On mobile, a sticky bottom bar shows a size selector dropdown and the "SELECT SIZE" action button, keeping the CTA always accessible while scrolling images. | Add a sticky mobile buy bar on the PDP that contains the primary order action. Keep it hidden on desktop where the buy-box is already visible. |
| Button radius | Buttons on the live site have a computed radius of **3.75px**, not zero. | **Design decision: keep zero-radius.** ShopiBD's sharp-commerce identity intentionally uses square edges. The 3.75px on the source site is a Shopify theme default, not a deliberate brand choice. This is a documented intentional exception. |
| Region/currency switcher | Header shows UK/US/EU store switcher links. | **Out of scope** for ShopiBD (single-market Bangladesh, BDT only). |
| Multi-message promotion bar | The promotion bar shows three rotating messages (same promo repeated, but the structure supports multiple distinct messages). | Already covered by the promotion strip in Phase I3. Confirm the rotation supports multiple distinct ShopiBD-owned messages. |

### Dynamic behavior adopted for ShopiBD

1. Compact rotating promotion and shipping strips with **manual pause** and a static reduced-motion fallback.
2. Responsive Menu and filter drawers with focus trapping, Escape close, route-change close, and nested disclosure state.
3. Product image loading placeholders plus subtle opacity/scale hover feedback; no card lift or shadow.
4. Horizontal product rails with scroll-snap and explicit arrow controls, never automatic scrolling.
5. Local availability/price filtering and sort feedback only where storefront data already supports it.
6. Crisp async feedback for order submission, login/registration, dashboard mutations, table selection, and chart loading.

## Implementation sequence

### 1. Global sharp-commerce foundation

Update global CSS, Tailwind configuration, and root layout to remove the dark-only Obsidian Emerald system. Add semantic CSS and Tailwind tokens for monochrome surfaces, text, neutral borders, utility success/info, and sale emphasis. Replace Plus Jakarta Sans with Be Vietnam Pro while maintaining Bengali glyph coverage. Convert global focus rings, scrollbar treatment, responsive containers, and motion utilities to the new system.

Acceptance: all pages resolve to `#FAFAFA` by default, text/action contrast meets accessibility needs, and no visual styling depends on the prior mint/dark token ramp.

### 2. Shared primitive migration

Refactor Button, Input, Card, Alert, Badge, Select, Table, Tabs, Dialog, Dropdown, Avatar, Skeleton, Toast, and layout primitives.

- Primary actions become ink rectangular buttons with white text.
- Secondary actions become grey rectangular buttons with ink text.
- Destructive/sale treatment uses red only when semantically correct.
- Inputs use high-contrast dark treatment where appropriate, with an explicit light utility field variant for dense internal forms.
- Cards become edge-to-edge/shadowless; product cards are image-first.
- Modals, menus, mobile drawers, tables, empty states, and pagination adopt crisp one-pixel borders.
- Focus/hover/pressed/loading states use border, inversion, underline, opacity, and transform only, not elevation or glow.

Acceptance: no rounded design-system primitive or shadow utility remains except explicitly approved third-party/browser artifacts.

### 3. Public marketing and pricing

Rebuild the root home page and pricing page as ShopiBD editorial-commerce pages: compact rotating promotion/shipping strips, a ShopiBD wordmark header, dense uppercase navigation, a full-bleed ShopiBD-owned hero treatment, direct commerce CTAs, compact image/feature grids, and the dark newsletter/footer pattern.

Use content that remains specific to Bangladeshi e-commerce and ShopiBD. Do not reuse the researched brand copy. The mobile header becomes an accessible `Menu` drawer; desktop navigation can expose grouped, ShopiBD-specific commerce links without inventing unsupported routes.

Acceptance: public routes read as ShopiBD, prioritize merchant conversion, remain fully responsive, and retain current registration/pricing links.

### 4. Tenant storefront and customer transaction flow

Rebuild storefront shared components and routes around seller product imagery, banner/logo data, catalog grid density, price hierarchy, stock state, and direct purchase actions.

- Add a reusable tenant storefront header with announcement/shipping strip, ShopiBD-powered but seller-led identity, compact contact/cart actions, and responsive navigation.
- Convert product grids to 2/3/4-column sharp image-led layouts.
- Redesign product detail, order form, payment selection, order-success, and tracking pages with crisp summary panels and validation/error states.
- Preserve seller-selected logo/banner/product colors only where they represent tenant content; they must not override the global interface tokens.

Acceptance: public shopping, payment selection, order placement, tracking, and all error/loading states continue to work with the existing storefront API contracts.

### 5. Authentication

Redesign login and registration into compact monochrome forms with clear brand header, high-contrast input variants, exact validation/error handling, password visibility/loading behavior, and links to the existing authentication routes.

Acceptance: no changes to auth API calls, session persistence, redirects, localization, or error semantics.

### 6. Seller dashboard

Replace the current rounded, spacious SaaS shell with a dense merchant operations console.

- Desktop: sharp fixed/scrollable navigation rail, compact header, uppercase section labels, inline search/actions, and a narrow data-first content grid.
- Mobile: labeled menu drawer and compact persistent primary actions, preserving navigation coverage.
- Pages: dashboard, analytics, products, orders/detail, customers, payments, coupons, abandoned carts, subscription, branding, staff, notifications, and settings.
- Charts retain useful draw/data-update behavior but remove glows/ambient decoration. Tables gain clear selected, hover, empty, and loading states via contrast and borders.

Acceptance: all dashboard routes preserve existing data queries, mutations, access checks, form behaviors, and responsive usability.

### 7. Super-admin

Apply the same operational language to the admin shell, platform dashboard, client list/detail/create screens, activity, reviews, and settings. Preserve all admin-only routes and links, including the SQLAdmin link, while correcting its configured backend origin if the current hard-coded port is inconsistent with the ShopiBD Compose configuration.

Acceptance: platform administration is visually consistent with the seller console but distinguishable through copy and information hierarchy, without capability changes.

### 8. Dynamicity and accessibility pass

Implement motion with CSS and small existing React state only: ticker/carousel movement, menu/dialog enter/exit, image reveal/zoom, skeleton/loader, status feedback, sort/filter transitions, tab/table state, chart reveal, and form submission states. Honor `prefers-reduced-motion`, maintain visible keyboard focus, preserve semantic landmarks and labels, and avoid auto-advancing content that cannot be paused.

Acceptance: no new animation dependency is required; essential states remain understandable when all animation is disabled.

### 9. Verification and containment

Run source scans for old Obsidian token usage, rounded controls, shadows, disallowed green/blue brand styling, and third-party brand strings/assets. Run TypeScript and production build. Execute targeted Playwright flows for authentication, storefront order path, dashboard product/order management, subscription visibility, and admin client management.

Container policy:

- Inspect/start/build only via this repository's Compose files and only ShopiBD named services: `shopibd-db`, `shopibd-redis`, `shopibd-backend`, `shopibd-frontend`.
- Use service-scoped Compose commands such as `docker compose -p shopibd ...` from the repository root.
- Never run `docker system prune`, `docker container prune`, `docker volume prune`, unscoped `docker compose down`, or commands that stop/remove/list-manipulate other projects' containers.

## Affected areas

- Theme/foundation: `frontend/src/app/globals.css`, `frontend/tailwind.config.ts`, `frontend/src/app/layout.tsx`, `frontend/src/app/providers.tsx`.
- Shared UI: `frontend/src/components/ui/*`.
- Layout shells: `frontend/src/components/layout/*`.
- Storefront: `frontend/src/components/storefront/*` and `frontend/src/app/[slug]/*`.
- Public/auth: `frontend/src/app/page.tsx`, `frontend/src/app/pricing/page.tsx`, `frontend/src/app/auth/*`.
- Seller console: `frontend/src/app/dashboard/*` plus dashboard components.
- Super-admin: `frontend/src/app/admin/*`.

## Explicit non-goals

- No backend API, database schema, business-rule, payment, subscription, tenant-isolation, or checkout-flow redesign.
- No external branding or proprietary source assets/copy from the researched website.
- No dependencies for motion/design unless a genuine existing dependency gap is found and explicitly approved.
- No impact on non-ShopiBD Docker projects, containers, images, volumes, networks, or files.

## Recommended visual checkpoint order

1. Shared tokens + primitives.
2. Homepage/pricing and one seller storefront with seeded data.
3. Checkout and auth.
4. Seller dashboard overview/products/orders.
5. Remaining dashboard and admin routes.
6. Build, visual drift scan, responsive walkthrough, and targeted end-to-end checks.
