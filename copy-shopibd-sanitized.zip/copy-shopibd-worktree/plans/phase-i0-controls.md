# Phase I0 Implementation Controls — Sharp-Commerce Conversion

## Scope

This control document governs all work following the baseline recorded in [phase-i0-baseline.md](phase-i0-baseline.md). It translates Phase I0.2 into concrete migration names, source-scan commands, route-risk gates, and decision logging requirements.

## I0.2.1 Token migration map

### Semantic target tokens

The conversion uses semantic names rather than visual-theme names. Exact HSL/OKLCH syntax may vary by the theme implementation, but their intended rendered values and responsibilities are fixed below.

| Current token / construct | Current meaning | Target semantic token | Target rendered value / role | Migration rule |
| --- | --- | --- | --- | --- |
| `--background` | Dark page canvas | `--background` | `#FAFAFA` canvas | Keep the public token name; replace its value. |
| `--foreground` | Light text on dark canvas | `--foreground` | `#141414` standard ink | Keep the public token name; replace its value. |
| `--surface-1` | Dark primary panel | `--surface` | `#FFFFFF` or `#FAFAFA` as context requires | Migrate consumers deliberately; do not blindly preserve surface ramp semantics. |
| `--surface-2` | Dark secondary panel | `--surface-subtle` | restrained neutral/off-white panel | Migrate consumers deliberately. |
| `--surface-3`, `--surface-high`, `--surface-highest` | Elevated dark surfaces | `--surface-muted` / border treatment | neutral separation without elevation | Remove elevation semantics; choose border/spacing/contrast. |
| `--card` and `--popover` | Dark component surfaces | `--card`, `--popover` | `#FFFFFF` | Preserve public component tokens with light values. |
| `--primary` | Mint action color | `--primary` | `#141414` ink action | Preserve the name to minimize API churn. |
| `--primary-foreground` | Dark mint foreground | `--primary-foreground` | `#FFFFFF` | Preserve the name to minimize API churn. |
| `--secondary` | Dark neutral panel | `--secondary` | `#D6D6D6` | Use for lower-priority actions. |
| `--secondary-foreground` | Light text | `--secondary-foreground` | `#141414` | Preserve contrast. |
| `--muted` / `--muted-foreground` | Dark muted system | `--muted` / `--muted-foreground` | light neutral / readable grey ink | Must meet text contrast requirements. |
| `--accent` | Dark hover surface | `--accent` | neutral inversion/hover surface | Do not use as a brand color. |
| `--destructive` | Light red text/background token | `--destructive` | sale/destructive red `#AB0000` | Restrict to destructive actions, sales, or urgency. |
| `--success` | Emerald success | `--success` | accessible semantic green | Semantic status only; never a brand anchor. |
| `--warning` | Light amber status | `--warning` | accessible warning tone | Semantic status only. |
| `--border`, `--input`, `--outline`, `--outline-variant` | Dark border system | same public names | ink/grey one-pixel border system | No visual elevation dependency. |
| `--ring` | Mint focus ring | `--ring` | high-contrast ink or accessible focus outline | Must be visible on light and dark contexts. |
| `--radius` | `0.5rem` default | `--radius` | `0px` | All project-owned surfaces and controls are sharp by default. |
| `--font-plus-jakarta` | Existing Latin UI font | `--font-be-vietnam-pro` | Be Vietnam Pro | Retain `--font-noto-bengali` as fallback. |
| `--ease` / `ease-premium` | Ambient premium motion | `--ease-ui` or retained compatible alias | short purposeful commerce feedback | No glow, float, or decorative ambient movement. |

### Explicit token restrictions

1. `#AB0000` is not a general brand background; use it only for sale, urgency, destructive action, or materially negative state.
2. Seller-provided colors, logos, banners, font values, and custom CSS remain tenant content. They cannot replace global button, form, navigation, focus, overlay, or platform-shell semantic tokens.
3. A necessary circular avatar/image mask is permitted only for actual user/avatar media. It is not a general component geometry exception.
4. Browser-native controls and unmodifiable third-party internals may retain their native geometry only when documented in the decision log.

## I0.2.2 Conformance scan catalog

Run these commands from the repository root on Windows `cmd.exe`. Each scan is intended to be reviewed, not mechanically treated as a failure. Every retained match requires either a migration task or a documented exception.

### Scan A — legacy foundation names and Latin font

```cmd
findstr /S /N /I /C:"Obsidian" /C:"Emerald" /C:"plus-jakarta" /C:"surface-1" /C:"surface-2" /C:"surface-3" /C:"surface-high" "frontend\src\*.ts" "frontend\src\*.tsx" "frontend\src\*.css"
```

Expected disposition: all Obsidian/Emerald terminology is removed by the foundation/primitives migration. Temporary `surface-*` compatibility aliases must have an explicit removal milestone before Phase I8 completes.

### Scan B — prohibited geometry, elevation, and visual effects

```cmd
findstr /S /N /I /C:"rounded-" /C:"shadow-" /C:"box-shadow" /C:"gradient" /C:"backdrop-blur" /C:"blur-" "frontend\src\*.ts" "frontend\src\*.tsx" "frontend\src\*.css"
```

Expected disposition: project-owned UI uses zero radius, no decorative shadows, no gradients, and no glass/blur. Allowed exceptions: actual avatar/image clipping, accessibility-only focus ring, and browser/third-party artifact documented in the decision log.

### Scan C — non-semantic color and sale misuse

```cmd
findstr /S /N /I /C:"bg-green" /C:"text-green" /C:"border-green" /C:"bg-blue" /C:"text-blue" /C:"border-blue" /C:"emerald-" /C:"cyan-" /C:"pink-" /C:"orange-" /C:"purple-" "frontend\src\*.ts" "frontend\src\*.tsx" "frontend\src\*.css"
```

Expected disposition: semantic success/warning/info colors are allowed only where their meaning is clear and redundant non-color cues are present. Payment-provider labels are content and should use neutral treatment rather than provider-brand color styling unless operationally required.

### Scan D — external-brand containment

```cmd
findstr /S /N /I /C:"killstar" /C:"in goth we trust" /C:"us.killstar.com" "frontend\src\*.ts" "frontend\src\*.tsx" "frontend\public\*" "frontend\src\*.css"
```

Expected disposition: zero matches.

### Scan E — motion and autoplay review

```cmd
findstr /S /N /I /C:"animate-" /C:"animation:" /C:"transition-" /C:"autoplay" /C:"setInterval" "frontend\src\*.ts" "frontend\src\*.tsx" "frontend\src\*.css"
```

Expected disposition: retain only purposeful loading, submit, drawer/disclosure, image, chart, table, and optional manually pausable promotion transitions. Product rails must not auto-scroll. All retained motion must honor reduced motion.

### Scan F — external assets/integrations review

```cmd
findstr /S /N /I /C:"http://" /C:"https://" /C:"iframe" /C:"script src" "frontend\src\*.ts" "frontend\src\*.tsx" "frontend\public\*"
```

Expected disposition: no newly introduced third-party commerce tracking, wishlisting, loyalty, reviews, or marketing integrations for visual imitation.

## I0.2.3 Route-risk controls

### Risk tiers

| Tier | Route groups | Allowed visual work | Mandatory verification before advancing |
| --- | --- | --- | --- |
| Low | `/`, `/pricing` | Layout, hierarchy, copy, asset, navigation presentation, responsive style, accessible mobile menu. | Frontend production build; navigation/link smoke check at desktop and mobile. |
| Medium | `/:slug`, `/:slug/products/:id`, shared storefront components, shared UI primitives | Presentation, local-only display/filter state for already loaded data, image feedback, grid/rail behavior. | Production build; tenant slug/no-data/not-found smoke check; product-detail navigation check. |
| High | Auth, `/:slug/order`, success/tracking, `/dashboard/**`, `/admin/**`, shared shells/overlays | Presentation only; retain field names, request builders, mutation handlers, redirects, guard checks, and accessibility semantics. | Production build; relevant E2E/API-contract check; keyboard/focus overlay check; targeted regression test. |

### Mandatory implementation gates

1. **Primitive gate:** Before a shared primitive changes its public props/variants, list every consumer with a source search and preserve backward compatibility or migrate every consumer in the same change set.
2. **Network gate:** For high-risk routes, do not modify API client methods, endpoint strings, HTTP methods, payload objects, response schemas, redirect target logic, or server-session behavior. If an unavoidable change appears necessary, stop and create a separate approved backend/API task.
3. **Tenant gate:** Do not use seller colors to theme platform UI. Test a seeded shop with logo/banner/color data and a shop without optional branding data.
4. **Overlay gate:** Drawer, dialog, dropdown, and filter work must retain accessible name, focus trap where modal, Escape close, focus restoration, and route-change close behavior where navigation leaves the current route.
5. **Motion gate:** Any new animated affordance must expose its final state without animation and respect `prefers-reduced-motion`.
6. **Responsive gate:** Test touched shared components at 390px, 768px, and 1440px before moving to the next route group.
7. **Scope gate:** No migration, generated type/schema change, dependency addition, Docker global command, or unrelated backend edit is permitted in a visual conversion change set.

## I0.2.4 Decision log protocol

Add an entry to this table before accepting any exception to the conversion rules.

| ID | Date | Route/component | Rule or scan | Exception rationale | Owner | Removal/review phase | Status |
| --- | --- | --- | --- | --- | --- | --- | --- |
| None recorded | 2026-07-26 | — | — | Baseline established; no exceptions approved. | — | — | Open |

Examples requiring a decision entry:

- A circular user avatar is retained for recognizability.
- A third-party/browser control cannot safely accept zero radius.
- A merchant-content visual need conflicts with a global token.
- A legacy token alias is retained temporarily for staged migration.
- A deliberate motion effect remains after the Phase I8 cleanup scan.

## I0.2.5 Commit and rollback discipline

1. Keep each change set limited to one phase/route group where feasible.
2. Record changed paths, scan results, build result, viewport checks, and relevant E2E result in the change summary because Git history is not yet available in this workspace.
3. If a shared component changes, verify public, storefront, dashboard, and admin consumers before continuing.
4. Revert the current change set if a high-risk route alters its request, redirect, session, tenant, role, payment, or subscription behavior.

## I0.2 completion criteria

- The token replacement map defines intended semantic ownership and the allowed target palette.
- Six reviewable source scans define the removal/exception process for legacy styling, external-brand containment, color, motion, and external assets.
- All public routes and shared components have a risk tier with verification gates.
- A decision log and staged-migration discipline exist.
- No production code has been changed as part of Phase I0.
