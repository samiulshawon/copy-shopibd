# Follow-up — Backend SQLAlchemy pool exhaustion

## Why this exists

`shopibd-backend-dev` health probe reports `unhealthy` because every
request to `/health` and most `/api/v1/*` requests time out with:

```
sqlalchemy.exc.TimeoutError: QueuePool limit of size 5 overflow 10 reached,
connection timed out, timeout 30.00
```

This was observed throughout the T0–T2 phases and is unrelated to the
visual redesign — backend code was not touched.

## Likely causes

- `pool_size=5, max_overflow=10` in `app/core/database.py` is too small for
  the dev Compose deployment, where uvicorn is started with `--reload` and
  may keep multiple worker subprocesses alive.
- The dev backend runs in DEBUG mode (`LOG_LEVEL=DEBUG`) and writes verbose
  SQL logs to stdout, which can stall under load.
- `/health` and `/metrics` both open a DB session and can compound the
  pressure.

## Steps (when picked up)

1. Bump the pool for dev in `app/core/database.py` or via env overrides:
   `DB_POOL_SIZE=10`, `DB_MAX_OVERFLOW=20`, `DB_POOL_TIMEOUT=10`.
2. Consider making `/health` non-fatal for DB outage (report `degraded`,
   not `unhealthy`).
3. Decide whether to keep `--reload` for the dev container — it doubles
   worker pressure on some filesystems.
4. Once stable, restore the backend health probe and confirm Playwright
   can use the dev stack without timing out.

## Why not fix it now

Backend concerns are out of scope for the visual redesign. Surfaced here so
the next engineer doesn't lose it.

## Out of scope

- Migrating off SQLAlchemy.
- Production deploy sizing.