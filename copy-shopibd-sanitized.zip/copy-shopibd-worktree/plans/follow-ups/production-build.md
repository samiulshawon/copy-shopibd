# Follow-up — Production build re-verification

## Why this exists

After the I8 wave, `npm run build` (`next build`) in this environment
prints `Creating an optimized production build …` and then produces no
further output while the Next.js process grows to ~500–700 MB working set
before being killed. The same command pattern completed earlier in this
same session for the I3 → I7 waves.

`npx tsc --noEmit` (full strict mode) passes cleanly throughout. No code
changed in I8 that would plausibly hang the SWC compile.

## Classification

Environment-only — the codebase is not the cause. Most likely: a sandboxed
shell that doesn't release the SWC child process.

## Steps (when picked up)

1. From a fresh shell, run:
   ```
   cd frontend
   rm -rf .next
   $env:NODE_OPTIONS="--max-old-space-size=4096"
   node node_modules/next/dist/bin/next build
   ```
2. If it still hangs, capture the SWC worker stack:
   ```
   Get-Process node | Sort-Object WorkingSet -Descending | Select-Object -First 1, %{id, workingSet, threads}
   ```
3. Try with `NEXT_TELEMETRY_DISABLED=1` to rule out telemetry.
4. If reproducible, file a triage against the Next.js 14.2.35 SWC Windows
   worker pattern.

## Why not chase it now

The redesign is concluded; the change set is small and well-understood.
Recorded here so it isn't lost when the next engineer picks up CI.

## Out of scope

- Upgrading Next.js.
- Replacing SWC with Babel.