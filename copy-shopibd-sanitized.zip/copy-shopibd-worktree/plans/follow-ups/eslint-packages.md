# Follow-up — Install ESLint packages

> **✅ DONE (2026-08-22, Sprint 5 Step 4).** All five packages installed
> (`eslint@8.57`, `eslint-config-next@14.2`, `@typescript-eslint/parser@7`,
> `@typescript-eslint/eslint-plugin@7`, `eslint-plugin-tailwindcss@3`),
> `next lint` runs green (exit 0, 124 non-blocking warnings),
> `eslint.ignoreDuringBuilds` removed from `next.config.js`.
> Remaining debt tracked as TD-005 (~70 `no-explicit-any` warns).

## Why this exists

`frontend/.eslintrc.json` is present, but the ESLint packages it references
are not in `frontend/package.json`. `frontend/next.config.js` therefore sets
`eslint.ignoreDuringBuilds: true` so that `npm run build` does not fail.

This means `next lint` was not executed during the T1 typecheck/build phase.

## Steps (when picked up)

1. Decide whether to add `eslint`, `eslint-config-next`, and any project-
   specific plugins as dev dependencies. The current `.eslintrc.json`
   already extends `next/core-web-vitals`, so the minimum is:
   ```jsonc
   "devDependencies": {
     // existing
     "eslint": "^8.57.0",
     "eslint-config-next": "^14.2.0"
   }
   ```
2. `cd frontend && npm install`.
3. Run `npm run lint` and fix any reported errors.
4. Remove (or set to `false`) `eslint.ignoreDuringBuilds` in
   `next.config.js` so CI catches regressions.

## Why not do it now

Adding ESLint as a new dev dependency is outside the visual-redesign scope
and would touch `package.json` / `package-lock.json`. Recorded here so it
isn't lost.

## Out of scope

- Adopting a stricter custom ruleset.
- Wiring `eslint --fix` into the editor.