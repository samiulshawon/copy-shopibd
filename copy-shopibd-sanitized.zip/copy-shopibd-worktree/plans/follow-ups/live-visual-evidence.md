# Follow-up — Live visual evidence at every viewport

## Why this exists

T2 verified the shared UI + accessibility posture via static source audit.
A real browser pass (Playwright + axe, per-viewport screenshots, reduced-
motion variants, keyboard traversal, and overlay focus-management tests)
was deferred because the dev backend is unhealthy and the Playwright config
targets ports that the dev Compose stack does not expose.

## What needs to run

1. Update `frontend/playwright.config.ts`:
   - Add Firefox and WebKit projects.
   - Add three viewport projects: mobile (390×844), tablet (820×1180),
     wide desktop (1536×960). Desktop Chrome (1280×800) is the existing
     default.
2. Configure axe-core via `@axe-core/playwright` for each project.
3. For each route × viewport combination, capture:
   - initial-load screenshot
   - focused screenshot of the primary data region
   - one interaction screenshot (drawer open, filter applied, validation
     error, mutation success)
   - one reduced-motion screenshot for marketing home, dashboard overview,
     and PDP
4. Route surface — already documented in
   `plans/phase-t0-test-environment-and-evidence.md` § 2.3.

## Steps (when picked up)

1. Resolve the backend port-alignment follow-up first.
2. Add the missing browser and viewport projects.
3. Decide whether to keep `workers: 1` (recommended for the order-flow
   spec — shared seeded seller) or switch to per-route isolation.
4. Capture once, store evidence under `frontend/tests/e2e/evidence/`.

## Why not do it now

- The dev backend pool is exhausted; live runs would hang.
- Adding Firefox/WebKit projects requires browser binaries that may not be
  installed in this environment.
- The redesign phase is already concluded; this is regression-protection
  work, not a blocker.

## Out of scope

- Visual regression threshold tuning (e.g. pixel-diff vs layout-shift).
- Auto-promotion to CI.