# Follow-up — Backend port alignment for Playwright

## Why this exists

`frontend/tests/e2e/*.spec.ts` and `frontend/playwright.config.ts` target
`localhost:8000` (backend) and `localhost:3001` (frontend). The dev Compose
stack (`docker-compose.dev.yml`) exposes:

| Service       | Dev Compose port |
|---------------|------------------|
| backend       | 8080             |
| frontend (dev)| 4100             |
| db            | 5434             |
| redis         | 6380             |
| minio         | 9000 / 9001      |

The Playwright suite cannot hit the running dev backend without one of two
alignments:

1. Map backend `8080 → 8000` and frontend `4100 → 3001` in
   `docker-compose.dev.yml` (preferred — keeps the existing specs).
2. Update the Playwright config and the spec URL constants to match
   8080/4100.

## Steps (when picked up)

1. Pick option 1 unless there's a reason not to.
2. If option 1: change `BACKEND_PORT` and `FRONTEND_PORT` in `.env` /
   `.env.example` to `8000` and `3001` (or add a `docker-compose.override.yml`).
3. Restart only the affected ShopiBD containers:
   `docker compose -f docker-compose.dev.yml restart backend` and
   `npm run dev` again on the frontend side. Do **not** run `down` or
   `prune`.
4. Smoke test: `curl http://localhost:8000/api/v1/` should return 404
   (route present, no DB hit — avoids the pool-exhaustion health path).
5. Run `cd frontend && npx playwright test --reporter=list`.

## Why not just rerun T2 live?

Until this is closed, the dev backend health endpoint times out under the
existing load pattern, and any Playwright run that touches `/health` or
multiple protected routes will hang. T2's source-level audit is the
interim substitute.

## Out of scope

- Changing the backend port in production deployments.
- Adding testcontainers — those belong to a separate test-infra phase.